--Job - BTP_vwKPI_SalesGraphMonthly



select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, a.* from (
SELECT 'A' as RecordType
		, TrnYear	
		, TrnMonth
		--, SUM(NetSalesValue) as MonthlySales
		, SUM(NetSalesValue + DiscValue) as MonthlySales
FROM ArTrnDetail
WHERE (TrnYear = DATEPART(year, GETDATE())) and (LineType = '1') and (NOT(Branch IN ('TR', 'CO', 'SM')))
--Added following condition to eliminate credit notes 2016-06-07
		AND (DocumentType) <> 'C'
		--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (Customer IN ('000000000048869','000000000049870'))
GROUP BY TrnYear
		, TrnMonth

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 1 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget1) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 2 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget2) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 3 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget3) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 4 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget4) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 5 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget5) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 6 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget6) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 7 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget7) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 8 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget8) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 9 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget9) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 10 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget10) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 11 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget11) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 12 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb.Budget12) as MonthlySales
		--, SUM(1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'C'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 1 as TrnMonth
		, SUM(gb.Budget1) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 2 as TrnMonth
		, SUM(gb.Budget2) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 3 as TrnMonth
		, SUM(gb.Budget3) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 4 as TrnMonth
		, SUM(gb.Budget4) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 5 as TrnMonth
		, SUM(gb.Budget5) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 6 as TrnMonth
		, SUM(gb.Budget6) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 7 as TrnMonth
		, SUM(gb.Budget7) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 8 as TrnMonth
		, SUM(gb.Budget8) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 9 as TrnMonth
		, SUM(gb.Budget9) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 10 as TrnMonth
		, SUM(gb.Budget10) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 11 as TrnMonth
		, SUM(gb.Budget11) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATEPART(year, GETDATE()) as TrnYear
		, 12 as TrnMonth
		, SUM(gb.Budget12) as MonthlySales
FROM GenBudgets gb INNER JOIN (SELECT KeyField as GlCode, AlphaValue as Rollup
								FROM AdmFormData WHERE FormType = 'GEN' and FieldName = 'BUD001') at ON gb.GlCode = at.GlCode
WHERE gb.Company = 'B' and UPPER(at.Rollup) = 'SALES' and gb.BudgetType = 'A' and gb.BudgetNumber = '8'
)a
