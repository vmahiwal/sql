--Job : BTP_vwKPI_Fulfillment_stg0_pxf

--Currently used query
SELECT ROW_NUMBER() OVER (ORDER BY WTD,YTD,MTD DESC) AS ID, GETDATE() as time,* FROM [SysproCompanyB].[dbo].[BTP_vwKPI_Fulfillment]

--Note : Job is using direct view in the connection




--Full query of view
/****** Object: View [dbo].[BTP_vwKPI_Fulfillment]   Script Date: 8/28/2017 7:55:59 AM ******/

SELECT '01-On Time' as Grouping
		, '01' as Sequence
		, 'Shipments' as Description
		, '' as SubDescription
		, '' as Brand
		, AVG(DATEDIFF(d, sod.MLineShipDate, dnm.PlannedDeliverDate)) AS Today
		, 0 as Thru25
		, 0 AS WTD
		, 0 AS MTD
		, 0 AS QTD
		, AVG(DATEDIFF(d, (CASE WHEN dnsd.DntShipDt IS NULL THEN sod.MLineShipDate ELSE dnsd.DntShipDt END), dnm.PlannedDeliverDate)) AS YTD
FROM            MdnDetail dnd INNER JOIN
                         MdnMaster dnm ON dnd.DispatchNote = dnm.DispatchNote INNER JOIN
                         SorDetail sod ON dnd.SalesOrder = sod.SalesOrder AND dnd.SalesOrderLine = sod.SalesOrderLine INNER JOIN
						 SorMaster som ON dnd.SalesOrder = som.SalesOrder LEFT OUTER JOIN
                         (SELECT     SorDetail.SalesOrder, MIN(RIGHT(RTRIM(SorDetail.NComment), 10)) AS DntShipDt
							FROM         dbo.SorDetail AS SorDetail INNER JOIN
											dbo.SorMaster AS SorMaster ON SorDetail.SalesOrder = SorMaster.SalesOrder
							WHERE     (SorDetail.LineType = '6') 
										AND (SorDetail.NComment LIKE 'Do not ship after%' OR
											SorDetail.NComment LIKE 'Ship No Later=Req Ship Date%' OR
											SorDetail.NComment LIKE 'Requested ship date%%' OR
											SorDetail.NComment LIKE 'Walgreens deliver date%' OR
											SorDetail.NComment LIKE 'Deliver by date%' OR
											SorDetail.NComment LIKE 'Do Not Deliver After%') 
										AND (SorMaster.DocumentType = 'O') 
										AND (isdate(RIGHT(RTRIM(SorDetail.NComment), 10)) = 1)
										AND NOT(SorMaster.OrderStatus IN ('*','\','8'))
							GROUP BY SorDetail.SalesOrder, SorMaster.OrderStatus) dnsd ON dnd.SalesOrder = dnsd.SalesOrder
WHERE        dnd.LineType = '1' 
				AND DATEPART(year,dnm.PlannedDeliverDate) = DATEPART(year,GETDATE()) 
				AND som.InterWhSale <> 'Y' 
				AND NOT(som.Branch IN ('TR', 'CO', 'SM'))
				--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','000000000049870'))

UNION ALL

SELECT '01-On Time' as Grouping
		, '02' as Sequence
		, 'Open Orders' as Description
		, '' as SubDescription
		, '' as Brand
		, AVG(DATEDIFF(d, sod.MLineShipDate, GETDATE())) AS Today
		, 0 as Thru25
		, 0 AS WTD
		, 0 AS MTD
		, 0 AS QTD
		, AVG(DATEDIFF(d, (CASE WHEN dnsd.DntShipDt IS NULL THEN sod.MLineShipDate ELSE dnsd.DntShipDt END), GETDATE())) AS YTD
FROM            SorDetail sod INNER JOIN
                         SorMaster som ON sod.SalesOrder = som.SalesOrder LEFT OUTER JOIN
                         (SELECT     SorDetail.SalesOrder, MIN(RIGHT(RTRIM(SorDetail.NComment), 10)) AS DntShipDt
							FROM         dbo.SorDetail AS SorDetail INNER JOIN
											dbo.SorMaster AS SorMaster ON SorDetail.SalesOrder = SorMaster.SalesOrder
							WHERE     (SorDetail.LineType = '6') 
										AND (SorDetail.NComment LIKE 'Do not ship after%' OR
											SorDetail.NComment LIKE 'Ship No Later=Req Ship Date%' OR
											SorDetail.NComment LIKE 'Requested ship date%%' OR
											SorDetail.NComment LIKE 'Walgreens deliver date%' OR
											SorDetail.NComment LIKE 'Deliver by date%' OR
											SorDetail.NComment LIKE 'Do Not Deliver After%') 
										AND (SorMaster.DocumentType = 'O') 
										AND (isdate(RIGHT(RTRIM(SorDetail.NComment), 10)) = 1)
										AND NOT(SorMaster.OrderStatus IN ('*','\','8'))
							GROUP BY SorDetail.SalesOrder, SorMaster.OrderStatus) dnsd ON som.SalesOrder = dnsd.SalesOrder
WHERE       sod.LineType = '1' 
			AND NOT (som.OrderStatus IN ('*', '\', '9', '8')) 
			AND sod.MBackOrderQty + sod.MShipQty <> 0 
			AND MLineShipDate <= CONVERT(varchar, GETDATE(), 101)
			AND som.InterWhSale <> 'Y' 
			AND NOT(som.Branch IN ('TR', 'CO', 'SM'))
			--Added following condition to eliminate credit notes 2016-06-07
			AND (som.DocumentType) <> 'C'
			--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','000000000049870'))

UNION ALL

SELECT '02-Stats' as Grouping
		, '01' as Sequence
		, 'Cases To Ship' as Description
		, 'Qty' as SubDescription
		, CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN MLineShipDate <= GETDATE() THEN BoQty ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) AND DATEPART(day,MLineShipDate) <= 25 THEN BoQty ELSE 0 END) as Thru25
		, SUM(CASE WHEN MLineShipDate > GETDATE() AND DATEPART(month,MLineShipDate) = DATEPART(month,GETDATE()) THEN BoQty ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) THEN BoQty ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN MLineShipDate > EOMONTH(GETDATE()) THEN BoQty ELSE 0 END) as FutureMonths
		, SUM(BoQty) as TotalOpen        
FROM (SELECT som.SalesOrder
		, sod.SalesOrderLine
		, sod.MLineShipDate
		, sod.MStockCode
		, sod.MStockDes
		, sod.MOrderQty AS OrderQty
		, sod.MBackOrderQty + sod.MShipQty AS BoQty
		, sod.MPrice
		, sod.MDiscValFlag
		, sod.MDiscValue
		, sod.MDiscPct1
		, sod.MDiscPct2
		, sod.MDiscPct3
		, sod.MProductClass
		, som.Customer
		, cm.Name
		, cm.CustomerClass
		, som.Branch
		, som.InterWhSale
		, som.DiscPct1
		, som.DiscPct2
		, som.DiscPct3
FROM         dbo.SorDetail sod INNER JOIN dbo.SorMaster som ON sod.SalesOrder = som.SalesOrder 
							INNER JOIN dbo.ArCustomer cm ON som.Customer = cm.Customer
WHERE     sod.LineType = '1'
			AND NOT(som.OrderStatus IN ('*','\','8','9'))
			AND (sod.MShipQty + sod.MBackOrderQty <> 0)
			--Added following condition to eliminate credit notes 2016-06-07
			AND (DocumentType) <> 'C'
			--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','000000000049870'))) bol
WHERE        RIGHT(RTRIM(MStockCode), 2) <> '01'
				AND InterWhSale <> 'Y' 
				AND NOT(Branch IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END

UNION ALL

SELECT '02-Stats' as Grouping
		, '01' as Sequence
		, 'Cases To Ship' as Description
		, 'Gross Sales' as SubDescription
		, CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN MLineShipDate <= GETDATE() THEN BoQty * MPrice ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) AND DATEPART(day,MLineShipDate) <= 25 THEN BoQty * MPrice ELSE 0 END) as Thru25
		, SUM(CASE WHEN MLineShipDate > GETDATE() AND DATEPART(month,MLineShipDate) = DATEPART(month,GETDATE()) THEN BoQty * MPrice ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) THEN BoQty * MPrice ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN MLineShipDate > EOMONTH(GETDATE()) THEN BoQty * MPrice ELSE 0 END) as FutureMonths
		, SUM(BoQty * MPrice) as TotalOpen        
FROM (SELECT som.SalesOrder
		, sod.SalesOrderLine
		, sod.MLineShipDate
		, sod.MStockCode
		, sod.MStockDes
		, sod.MOrderQty AS OrderQty
		, sod.MBackOrderQty + sod.MShipQty AS BoQty
		, sod.MPrice
		, sod.MDiscValFlag
		, sod.MDiscValue
		, sod.MDiscPct1
		, sod.MDiscPct2
		, sod.MDiscPct3
		, sod.MProductClass
		, som.Customer
		, cm.Name
		, cm.CustomerClass
		, som.Branch
		, som.InterWhSale
		, som.DiscPct1
		, som.DiscPct2
		, som.DiscPct3
FROM         dbo.SorDetail sod INNER JOIN dbo.SorMaster som ON sod.SalesOrder = som.SalesOrder 
							INNER JOIN dbo.ArCustomer cm ON som.Customer = cm.Customer
WHERE     sod.LineType = '1'
			AND NOT(som.OrderStatus IN ('*','\','8','9'))
			AND (sod.MShipQty + sod.MBackOrderQty <> 0)
			--Added following condition to eliminate credit notes 2016-06-07
			AND (DocumentType) <> 'C'
			--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','000000000049870'))) bol
WHERE        RIGHT(RTRIM(MStockCode), 2) <> '01'
				AND InterWhSale <> 'Y' 
				AND NOT(Branch IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END

UNION ALL

SELECT '02-Stats' as Grouping
		, '01' as Sequence
		, 'Cases To Ship' as Description
		, 'Net Sales' as SubDescription
		, CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN MLineShipDate <= GETDATE() THEN NetValue ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) AND DATEPART(day,MLineShipDate) <= 25 THEN NetValue ELSE 0 END) as Thru25
		, SUM(CASE WHEN MLineShipDate > GETDATE() AND DATEPART(month,MLineShipDate) = DATEPART(month,GETDATE()) THEN NetValue ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) THEN NetValue ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN MLineShipDate > EOMONTH(GETDATE()) THEN NetValue ELSE 0 END) as FutureMonths
		, SUM(NetValue) as TotalOpen        
FROM (SELECT som.SalesOrder
		, sod.SalesOrderLine
		, sod.MLineShipDate
		, sod.MStockCode
		, sod.MStockDes
		, sod.MOrderQty AS OrderQty
		, sod.MBackOrderQty + sod.MShipQty AS BoQty
		, sod.MPrice
		, sod.MDiscValFlag
		, sod.MDiscValue
		, sod.MDiscPct1
		, sod.MDiscPct2
		, sod.MDiscPct3
		, sod.MProductClass
		, som.Customer
		, cm.Name
		, cm.CustomerClass
		, som.Branch
		, som.InterWhSale
		, som.DiscPct1
		, som.DiscPct2
		, som.DiscPct3
		, CASE WHEN sod.MDiscValFlag = 'V' THEN ROUND((((sod.MBackOrderQty + sod.MShipQty) * sod.MPrice) - sod.MDiscValue) * ((100 - som.DiscPct1)/100) * ((100 - som.DiscPct2)/100) * ((100 - som.DiscPct3)/100) ,2)
			   WHEN sod.MDiscValFlag = 'U' THEN ROUND((((sod.MBackOrderQty + sod.MShipQty) * sod.MPrice) - ((sod.MBackOrderQty + sod.MShipQty) * sod.MDiscValue)) * ((100 - som.DiscPct1)/100) * ((100 - som.DiscPct2)/100) * ((100 - som.DiscPct3)/100),2)
			   ELSE ROUND(((sod.MBackOrderQty + sod.MShipQty) * sod.MPrice) * ((100 - sod.MDiscPct1)/100) * ((100 - sod.MDiscPct2)/100) * ((100 - sod.MDiscPct3)/100) * ((100 - som.DiscPct1)/100) * ((100 - som.DiscPct2)/100) * ((100 - som.DiscPct3)/100) ,2) END as NetValue
FROM         dbo.SorDetail sod INNER JOIN dbo.SorMaster som ON sod.SalesOrder = som.SalesOrder 
							INNER JOIN dbo.ArCustomer cm ON som.Customer = cm.Customer
WHERE     sod.LineType = '1'
			AND NOT(som.OrderStatus IN ('*','\','8','9'))
			AND (sod.MShipQty + sod.MBackOrderQty <> 0)
			--Added following condition to eliminate credit notes 2016-06-07
			AND (DocumentType) <> 'C'
			--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','000000000049870'))) bol
WHERE        RIGHT(RTRIM(MStockCode), 2) <> '01'
				AND InterWhSale <> 'Y' 
				AND NOT(Branch IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END

UNION ALL

SELECT '02-Stats' as Grouping
		, '02' as Sequence
		, 'Pieces To Ship' as Description
		, 'Qty' as SubDescription
		, CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN MLineShipDate <= GETDATE() THEN BoQty ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) AND DATEPART(day,MLineShipDate) <= 25 THEN BoQty ELSE 0 END) as Thru25
		, SUM(CASE WHEN MLineShipDate > GETDATE() AND DATEPART(month,MLineShipDate) = DATEPART(month,GETDATE()) THEN BoQty ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) THEN BoQty ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN MLineShipDate > EOMONTH(GETDATE()) THEN BoQty ELSE 0 END) as FutureMonths
		, SUM(BoQty) as TotalOpen        
FROM (SELECT som.SalesOrder
		, sod.SalesOrderLine
		, sod.MLineShipDate
		, sod.MStockCode
		, sod.MStockDes
		, sod.MOrderQty AS OrderQty
		, sod.MBackOrderQty + sod.MShipQty AS BoQty
		, sod.MProductClass
		, som.Customer
		, cm.Name
		, cm.CustomerClass
		, som.Branch
		, som.InterWhSale
FROM         dbo.SorDetail sod INNER JOIN dbo.SorMaster som ON sod.SalesOrder = som.SalesOrder 
							INNER JOIN dbo.ArCustomer cm ON som.Customer = cm.Customer
WHERE     sod.LineType = '1'
			AND NOT(som.OrderStatus IN ('*','\','8','9'))
			AND (sod.MShipQty + sod.MBackOrderQty <> 0)
			--Added following condition to eliminate credit notes 2016-06-07
			AND (DocumentType) <> 'C'
			--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','000000000049870'))) bol
WHERE        RIGHT(RTRIM(MStockCode), 2) = '01'
				AND InterWhSale <> 'Y' 
				AND NOT(Branch IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END

UNION ALL

SELECT '02-Stats' as Grouping
		, '02' as Sequence
		, 'Pieces To Ship' as Description
		, 'Gross Sales' as SubDescription
		, CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN MLineShipDate <= GETDATE() THEN BoQty * MPrice ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) AND DATEPART(day,MLineShipDate) <= 25 THEN BoQty * MPrice ELSE 0 END) as Thru25
		, SUM(CASE WHEN MLineShipDate > GETDATE() AND DATEPART(month,MLineShipDate) = DATEPART(month,GETDATE()) THEN BoQty * MPrice ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) THEN BoQty * MPrice ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN MLineShipDate > EOMONTH(GETDATE()) THEN BoQty * MPrice ELSE 0 END) as FutureMonths
		, SUM(BoQty * MPrice) as TotalOpen        
FROM (SELECT som.SalesOrder
		, sod.SalesOrderLine
		, sod.MLineShipDate
		, sod.MStockCode
		, sod.MStockDes
		, sod.MOrderQty AS OrderQty
		, sod.MBackOrderQty + sod.MShipQty AS BoQty
		, sod.MPrice
		, sod.MDiscValFlag
		, sod.MDiscValue
		, sod.MDiscPct1
		, sod.MDiscPct2
		, sod.MDiscPct3
		, sod.MProductClass
		, som.Customer
		, cm.Name
		, cm.CustomerClass
		, som.Branch
		, som.InterWhSale
		, som.DiscPct1
		, som.DiscPct2
		, som.DiscPct3
FROM         dbo.SorDetail sod INNER JOIN dbo.SorMaster som ON sod.SalesOrder = som.SalesOrder 
							INNER JOIN dbo.ArCustomer cm ON som.Customer = cm.Customer
WHERE     sod.LineType = '1'
			AND NOT(som.OrderStatus IN ('*','\','8','9'))
			AND (sod.MShipQty + sod.MBackOrderQty <> 0)
			--Added following condition to eliminate credit notes 2016-06-07
			AND (DocumentType) <> 'C'
			--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','000000000049870'))) bol
WHERE        RIGHT(RTRIM(MStockCode), 2) = '01'
				AND InterWhSale <> 'Y' 
				AND NOT(Branch IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END

UNION ALL

SELECT '02-Stats' as Grouping
		, '02' as Sequence
		, 'Pieces To Ship' as Description
		, 'Net Sales' as SubDescription
		, CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN MLineShipDate <= GETDATE() THEN NetValue ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) AND DATEPART(day,MLineShipDate) <= 25 THEN NetValue ELSE 0 END) as Thru25
		, SUM(CASE WHEN MLineShipDate > GETDATE() AND DATEPART(month,MLineShipDate) = DATEPART(month,GETDATE()) THEN NetValue ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATEPART(month,MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, MLineShipDate) = DATEPART(year,GETDATE()) THEN NetValue ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN MLineShipDate > EOMONTH(GETDATE()) THEN NetValue ELSE 0 END) as FutureMonths
		, SUM(NetValue) as TotalOpen        
FROM (SELECT som.SalesOrder
		, sod.SalesOrderLine
		, sod.MLineShipDate
		, sod.MStockCode
		, sod.MStockDes
		, sod.MOrderQty AS OrderQty
		, sod.MBackOrderQty + sod.MShipQty AS BoQty
		, sod.MPrice
		, sod.MDiscValFlag
		, sod.MDiscValue
		, sod.MDiscPct1
		, sod.MDiscPct2
		, sod.MDiscPct3
		, sod.MProductClass
		, som.Customer
		, cm.Name
		, cm.CustomerClass
		, som.Branch
		, som.InterWhSale
		, som.DiscPct1
		, som.DiscPct2
		, som.DiscPct3
		, CASE WHEN sod.MDiscValFlag = 'V' THEN ROUND((((sod.MBackOrderQty + sod.MShipQty) * sod.MPrice) - sod.MDiscValue) * ((100 - som.DiscPct1)/100) * ((100 - som.DiscPct2)/100) * ((100 - som.DiscPct3)/100) ,2)
			   WHEN sod.MDiscValFlag = 'U' THEN ROUND((((sod.MBackOrderQty + sod.MShipQty) * sod.MPrice) - ((sod.MBackOrderQty + sod.MShipQty) * sod.MDiscValue)) * ((100 - som.DiscPct1)/100) * ((100 - som.DiscPct2)/100) * ((100 - som.DiscPct3)/100),2)
			   ELSE ROUND(((sod.MBackOrderQty + sod.MShipQty) * sod.MPrice) * ((100 - sod.MDiscPct1)/100) * ((100 - sod.MDiscPct2)/100) * ((100 - sod.MDiscPct3)/100) * ((100 - som.DiscPct1)/100) * ((100 - som.DiscPct2)/100) * ((100 - som.DiscPct3)/100) ,2) END as NetValue
FROM         dbo.SorDetail sod INNER JOIN dbo.SorMaster som ON sod.SalesOrder = som.SalesOrder 
							INNER JOIN dbo.ArCustomer cm ON som.Customer = cm.Customer
WHERE     sod.LineType = '1'
			AND NOT(som.OrderStatus IN ('*','\','8','9'))
			AND (sod.MShipQty + sod.MBackOrderQty <> 0)
			--Added following condition to eliminate credit notes 2016-06-07
			AND (DocumentType) <> 'C'
			--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','00000000049870'))) bol
WHERE        RIGHT(RTRIM(MStockCode), 2) = '01'
				AND InterWhSale <> 'Y' 
				AND NOT(Branch IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RIGHT(MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END

UNION ALL

SELECT '03-Stats' as Grouping
		, '01' as Sequence
		, 'Cases Dispatched' as Description
		, 'Qty' as SubDescription
		, CASE WHEN RIGHT(dnd.MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(dnd.MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN DATEPART(dayofyear,dnm.PlannedDeliverDate) = DATEPART(dayofyear,GETDATE()) THEN dnd.MQtyToDispatch ELSE 0 END) as TodayCsShip
		, SUM(CASE WHEN DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month, GETDATE()) AND DATEPART(day,dnm.PlannedDeliverDate) <=25 THEN dnd.MQtyToDispatch ELSE 0 END) as Thru25
		, SUM(CASE WHEN DATEPART(week,dnm.PlannedDeliverDate) = DATEPART(week, GETDATE()) THEN dnd.MQtyToDispatch ELSE 0 END) as WTDCsShip
		, SUM(CASE WHEN DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month, GETDATE()) THEN dnd.MQtyToDispatch ELSE 0 END) as MTDCsShip
		, SUM(CASE WHEN DATEPART(quarter,dnm.PlannedDeliverDate) = DATEPART(quarter, GETDATE()) THEN dnd.MQtyToDispatch ELSE 0 END) as QTDCsShip
		, SUM(CASE WHEN DATEPART(year,dnm.PlannedDeliverDate) = DATEPART(year, GETDATE()) THEN dnd.MQtyToDispatch ELSE 0 END) as YTDCsShip
FROM            MdnDetail dnd INNER JOIN MdnMaster dnm ON dnd.DispatchNote = dnm.DispatchNote
								INNER JOIN SorMaster som on dnd.SalesOrder = som.SalesOrder
WHERE        dnd.LineType = '1' 
				AND DATEPART(year,dnm.PlannedDeliverDate) = DATEPART(year,GETDATE()) 
				AND dnm.DispatchNoteStatus <> '*'
				AND som.InterWhSale <>'Y'
				AND NOT(som.Branch IN ('TR', 'CO', 'SM'))
				AND RIGHT(RTRIM(dnd.MStockCode),2) <> '01'
				--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','000000000049870'))
GROUP BY CASE WHEN RIGHT(dnd.MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(dnd.MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END

UNION ALL

SELECT '03-Stats' as Grouping
		, '01' as Sequence
		, 'Cases Dispatched' as Description
		, 'Gross Sales' as SubDescription
		, CASE WHEN RIGHT(dnd.MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(dnd.MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN DATEPART(dayofyear,dnm.PlannedDeliverDate) = DATEPART(dayofyear,GETDATE()) THEN dnd.MQtyToDispatch * dnd.MPrice ELSE 0 END) as TodayCsShip
		, SUM(CASE WHEN DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month, GETDATE()) AND DATEPART(day,dnm.PlannedDeliverDate) <=25 THEN dnd.MQtyToDispatch * dnd.MPrice ELSE 0 END) as Thru25
		, SUM(CASE WHEN DATEPART(week,dnm.PlannedDeliverDate) = DATEPART(week, GETDATE()) THEN dnd.MQtyToDispatch * dnd.MPrice ELSE 0 END) as WTDCsShip
		, SUM(CASE WHEN DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month, GETDATE()) THEN dnd.MQtyToDispatch * dnd.MPrice ELSE 0 END) as MTDCsShip
		, SUM(CASE WHEN DATEPART(quarter,dnm.PlannedDeliverDate) = DATEPART(quarter, GETDATE()) THEN dnd.MQtyToDispatch * dnd.MPrice ELSE 0 END) as QTDCsShip
		, SUM(CASE WHEN DATEPART(year,dnm.PlannedDeliverDate) = DATEPART(year, GETDATE()) THEN dnd.MQtyToDispatch * dnd.MPrice ELSE 0 END) as YTDCsShip
FROM            MdnDetail dnd INNER JOIN MdnMaster dnm ON dnd.DispatchNote = dnm.DispatchNote
								INNER JOIN SorMaster som on dnd.SalesOrder = som.SalesOrder
WHERE        dnd.LineType = '1' 
				AND DATEPART(year,dnm.PlannedDeliverDate) = DATEPART(year,GETDATE()) 
				AND dnm.DispatchNoteStatus <> '*'
				AND som.InterWhSale <>'Y'
				AND NOT(som.Branch IN ('TR', 'CO', 'SM'))
				AND RIGHT(RTRIM(dnd.MStockCode),2) <> '01'
				--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','000000000049870'))
GROUP BY CASE WHEN RIGHT(dnd.MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(dnd.MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END

UNION ALL

SELECT '03-Stats' as Grouping
		, '01' as Sequence
		, 'Cases Dispatched' as Description
		, 'Net Sales' as SubDescription
		, CASE WHEN RIGHT(dnd.MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(dnd.MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END as Brand
		--, SUM(CASE WHEN DATEPART(dayofyear,dnm.PlannedDeliverDate) = DATEPART(dayofyear,GETDATE()) THEN dnd.TotalValue * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ELSE 0 END) as TodayCsShip
		, SUM(CASE WHEN (DATEPART(dayofyear,dnm.PlannedDeliverDate) = DATEPART(dayofyear,(GETDATE())) AND dnd.MDiscValFlag = 'V') THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - dnd.MDiscValue) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2)
				   WHEN ((DATEPART(dayofyear,dnm.PlannedDeliverDate) = DATEPART(dayofyear,(GETDATE())) AND dnd.MDiscValFlag = 'U')) THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - (dnd.MQtyToDispatch * dnd.MDiscValue)) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100),2)
				   WHEN DATEPART(dayofyear,dnm.PlannedDeliverDate) = DATEPART(dayofyear,(GETDATE())) THEN ROUND((dnd.MQtyToDispatch * dnd.MPrice) * ((100 - dnd.MDiscPct1)/100) * ((100 - dnd.MDiscPct2)/100) * ((100 - dnd.MDiscPct3)/100) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2) ELSE 0 END) As TodayCsShip
		--, SUM(CASE WHEN DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month, GETDATE()) AND DATEPART(day,dnm.PlannedDeliverDate) <=25 THEN dnd.TotalValue * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ELSE 0 END) as Thru25
		, SUM(CASE WHEN (DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month, GETDATE())) AND (DATEPART(day,dnm.PlannedDeliverDate) <=25 AND dnd.MDiscValFlag = 'V') THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - dnd.MDiscValue) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2)
				   WHEN ((DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month, GETDATE()) AND (DATEPART(day,dnm.PlannedDeliverDate) <=25 AND dnd.MDiscValFlag = 'U'))) THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - (dnd.MQtyToDispatch * dnd.MDiscValue)) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100),2)
				   WHEN DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month, GETDATE()) AND DATEPART(day,dnm.PlannedDeliverDate) <=25 THEN ROUND((dnd.MQtyToDispatch * dnd.MPrice) * ((100 - dnd.MDiscPct1)/100) * ((100 - dnd.MDiscPct2)/100) * ((100 - dnd.MDiscPct3)/100) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2) ELSE 0 END) As Thru25
		--, SUM(CASE WHEN DATEPART(week,dnm.PlannedDeliverDate) = DATEPART(week, GETDATE()) THEN dnd.TotalValue * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ELSE 0 END) as WTDCsShip
		, SUM(CASE WHEN (DATEPART(week,dnm.PlannedDeliverDate) = DATEPART(week,(GETDATE())) AND dnd.MDiscValFlag = 'V') THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - dnd.MDiscValue) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2)
				   WHEN ((DATEPART(week,dnm.PlannedDeliverDate) = DATEPART(week,(GETDATE())) AND dnd.MDiscValFlag = 'U')) THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - (dnd.MQtyToDispatch * dnd.MDiscValue)) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100),2)
				   WHEN DATEPART(week,dnm.PlannedDeliverDate) = DATEPART(week,(GETDATE())) THEN ROUND((dnd.MQtyToDispatch * dnd.MPrice) * ((100 - dnd.MDiscPct1)/100) * ((100 - dnd.MDiscPct2)/100) * ((100 - dnd.MDiscPct3)/100) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2) ELSE 0 END) As WTDCsShip
		--, SUM(CASE WHEN DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month, GETDATE()) THEN dnd.TotalValue * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ELSE 0 END) as MTDCsShip
		, SUM(CASE WHEN (DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month,(GETDATE())) AND dnd.MDiscValFlag = 'V') THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - dnd.MDiscValue) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2)
				   WHEN ((DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month,(GETDATE())) AND dnd.MDiscValFlag = 'U')) THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - (dnd.MQtyToDispatch * dnd.MDiscValue)) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100),2)
				   WHEN DATEPART(month,dnm.PlannedDeliverDate) = DATEPART(month,(GETDATE())) THEN ROUND((dnd.MQtyToDispatch * dnd.MPrice) * ((100 - dnd.MDiscPct1)/100) * ((100 - dnd.MDiscPct2)/100) * ((100 - dnd.MDiscPct3)/100) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2) ELSE 0 END) As MTDCsShip
		--, SUM(CASE WHEN DATEPART(quarter,dnm.PlannedDeliverDate) = DATEPART(quarter, GETDATE()) THEN dnd.TotalValue * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ELSE 0 END) as QTDCsShip
		, SUM(CASE WHEN (DATEPART(quarter,dnm.PlannedDeliverDate) = DATEPART(quarter,(GETDATE())) AND dnd.MDiscValFlag = 'V') THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - dnd.MDiscValue) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2)
				   WHEN ((DATEPART(quarter,dnm.PlannedDeliverDate) = DATEPART(quarter,(GETDATE())) AND dnd.MDiscValFlag = 'U')) THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - (dnd.MQtyToDispatch * dnd.MDiscValue)) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100),2)
				   WHEN DATEPART(quarter,dnm.PlannedDeliverDate) = DATEPART(quarter,(GETDATE())) THEN ROUND((dnd.MQtyToDispatch * dnd.MPrice) * ((100 - dnd.MDiscPct1)/100) * ((100 - dnd.MDiscPct2)/100) * ((100 - dnd.MDiscPct3)/100) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2) ELSE 0 END) As QTDCsShip
		--, SUM(CASE WHEN DATEPART(year,dnm.PlannedDeliverDate) = DATEPART(year, GETDATE()) THEN dnd.TotalValue * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ELSE 0 END) as YTDCsShip
		, SUM(CASE WHEN (DATEPART(year,dnm.PlannedDeliverDate) = DATEPART(year,(GETDATE())) AND dnd.MDiscValFlag = 'V') THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - dnd.MDiscValue) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2)
				   WHEN ((DATEPART(year,dnm.PlannedDeliverDate) = DATEPART(year,(GETDATE())) AND dnd.MDiscValFlag = 'U')) THEN ROUND(((dnd.MQtyToDispatch * dnd.MPrice) - (dnd.MQtyToDispatch * dnd.MDiscValue)) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100),2)
				   WHEN DATEPART(year,dnm.PlannedDeliverDate) = DATEPART(year,(GETDATE())) THEN ROUND((dnd.MQtyToDispatch * dnd.MPrice) * ((100 - dnd.MDiscPct1)/100) * ((100 - dnd.MDiscPct2)/100) * ((100 - dnd.MDiscPct3)/100) * ((100 - dnm.DiscPct1)/100) * ((100 - dnm.DiscPct2)/100) * ((100 - dnm.DiscPct3)/100) ,2) ELSE 0 END) As YTDCsShip
FROM            MdnDetail dnd INNER JOIN MdnMaster dnm ON dnd.DispatchNote = dnm.DispatchNote
								INNER JOIN SorMaster som on dnd.SalesOrder = som.SalesOrder
WHERE        dnd.LineType = '1' 
				AND DATEPART(year,dnm.PlannedDeliverDate) = DATEPART(year,GETDATE()) 
				AND dnm.DispatchNoteStatus <> '*'
				AND som.InterWhSale <>'Y'
				AND NOT(som.Branch IN ('TR', 'CO', 'SM'))
				AND RIGHT(RTRIM(dnd.MStockCode),2) <> '01'
				--2016-12-14 Next Line To Exclude Raw Material Customers
				AND NOT (som.Customer IN ('000000000048869','000000000049870'))
GROUP BY CASE WHEN RIGHT(dnd.MProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(dnd.MProductClass,2) = '02' THEN 'SM' ELSE 'OT' END


