--job view_lost_sales_ytd_stg0_pxf


SELECT  ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, tmp.* from( 
select 'LostSales' as Grouping,CorpAcctName,ar.* from (
SELECT        dbo.SorDetail.SalesOrder, dbo.SorDetail.SalesOrderLine, dbo.SorDetail.MStockCode, dbo.SorDetail.MStockDes, 
                         dbo.SorDetail.MOrderQty, dbo.SorDetail.MPrice, dbo.SorMaster.OrderStatus, CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END AS DispQty, CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END AS QtyInvoiced, 
                         (CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END) AS QtyShipped, dbo.SorDetail.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) AS QtyLost, 
                         (dbo.SorDetail.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END))) * dbo.SorDetail.MPrice AS LostSales, dbo.SorMaster.Branch, dbo.SorMaster.Customer, 
                         dbo.SorMaster.CustomerName, dbo.SorMaster.OrderDate,dbo.SorMaster.EntrySystemDate, dbo.SorDetail.MLineShipDate
FROM            dbo.SorDetail INNER JOIN
                         dbo.SorMaster ON dbo.SorDetail.SalesOrder = dbo.SorMaster.SalesOrder LEFT OUTER JOIN
                         dbo.ArCustomer ON dbo.SorMaster.Customer = dbo.ArCustomer.Customer LEFT OUTER JOIN
                             (SELECT        SalesOrder, SalesOrderLine, SUM(QtyInvoiced) AS QtyInvoiced
                               FROM            dbo.ArTrnDetail
                               GROUP BY SalesOrder, SalesOrderLine) AS derivedtbl_2 ON dbo.SorDetail.SalesOrder = derivedtbl_2.SalesOrder AND 
                         dbo.SorDetail.SalesOrderLine = derivedtbl_2.SalesOrderLine LEFT OUTER JOIN
                             (SELECT        dbo.MdnDetail.SalesOrder, dbo.MdnDetail.SalesOrderLine, SUM(dbo.MdnDetail.MQtyToDispatch) AS DispQty
                               FROM            dbo.MdnDetail INNER JOIN
                                                         dbo.MdnMaster ON dbo.MdnDetail.DispatchNote = dbo.MdnMaster.DispatchNote
                               WHERE        (NOT (dbo.MdnMaster.DispatchNoteStatus IN ('9', '*')))
                               GROUP BY dbo.MdnDetail.SalesOrder, dbo.MdnDetail.SalesOrderLine) AS derivedtbl_1 ON dbo.SorDetail.SalesOrder = derivedtbl_1.SalesOrder AND 
                         dbo.SorDetail.SalesOrderLine = derivedtbl_1.SalesOrderLine
WHERE        (dbo.SorDetail.LineType = '1') AND (dbo.SorMaster.OrderStatus = '9') AND InterWhSale<>'Y' AND (dbo.SorDetail.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) > 0) AND 
                         (NOT (dbo.SorMaster.OrderType IN ('C', 'D'))) AND (dbo.SorDetail.MLineShipDate >= GETDATE() - 124)

) ar
LEFT JOIN 
    		View_ArCust_GroupingData4KPI_New c on c.Customer=ar.Customer where month(MLineShipDate)=month(getdate())

			UNION
			SELECT 'Cancelled Order' as Grouping,cacm.CorpAcctName,om.SalesOrder,SalesOrderLine, MStockCode, MStockDes,od.MOrderQty,
			od.MPrice, OrderStatus,0 as DispQty,0 as QtyInvoiced,0 as QtyShipped,0 as QtyLost,MOrderQty*MPrice as LostSales,
			om.Branch,om.Customer,om.CustomerName, OrderDate, EntrySystemDate,   MLineShipDate
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder LEFT JOIN (SELECT KeyField as Customer
         , AlphaValue as CorpAcctCode
        FROM AdmFormData
        WHERE FormType = 'CUS' and FieldName = 'COR002') cac ON om.Customer = cac.Customer
     LEFT JOIN (SELECT Item as CorpAcctCode
         , Description as CorpAcctName
        FROM AdmFormValidation
        WHERE FormType = 'CUS' and FieldName = 'COR002') cacm on cac.CorpAcctCode = cacm.CorpAcctCode
WHERE 
   (om.CancelledFlag = 'Y') AND InterWhSale<>'Y' 
  AND (od.LineType = '1')
  AND year(om.EntrySystemDate) = year(GETDATE()) and month(om.EntrySystemDate) = month(GETDATE())
  )tmp