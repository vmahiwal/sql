--Job open_vs_available_stg0_pxf


SELECT
ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,
 StockUom,iw.StockCode,Description,im.AbcClass as ProductClass,StockOnHold,
SUM(OpenOrderQty) as OpenOrderQty, SUM(OpenOrderValue) as OpenOrderValue,
SUM(BoQty) as BoQty, SUM(BoValue) as BoValue,
SUM(PastDueQty) as PastDueQty, SUM(PastDueValue) as PastDueValue,
SUM(QtyOnHand) as QtyOnHand,SUM(QCOnHand) as QCOnHand,Sum(XQCOnHand) XQCOnHand,Sum(XFG.XFGOnHand) XFGOnHand,
Sum(XFG.XFGInTransit ) XFGInTransit,Sum(XQC.XQCInTrnasit ) XQCInTransit,
SUM(E4OnHand) as EmersonOnHand, SUM(iw.QtyOnOrder) as QtyOnOrder, SUM(SafetyStockQty) as SafetyStockQty,
SUM(fcst.FcstQtyMnt1) as FcstQtyMnt1,
SUM(fcst.FcstQtyMnt2) as FcstQtyMnt2,
SUM(fcst.FcstQtyMnt3) as FcstQtyMnt3,
SUM(fcst.FcstQtyMnt4) as FcstQtyMnt4,
SUM(fcst.JanJunNextYear) as JanJunNextYear
,
--Component as WP,SUM(WP.WPOnHand) as WPQtyOnHand,SUM(WPQtyOnOrder) as WPQtyOnOrder, 
WarehouseToUse,im.AbcClass
from InvMaster im left join (select StockCode, SUM(QtyOnOrder) as QtyOnOrder,SUM(SafetyStockQty) as SafetyStockQty
from InvWarehouse group by StockCode) iw on im.StockCode=iw.StockCode left join (SELECT REPLACE(KeyField,' ','') as ProductClass
, AlphaValue as InvType
FROM AdmFormData
WHERE FormType = 'ARPCL' and FieldName = 'KPI001') invtyp on im.ProductClass = invtyp.ProductClass
left join (select StockCode,SUM(QtyOnHand) as QCOnHand from InvWarehouse where Warehouse='QC' group by StockCode) QC on QC.StockCode=im.StockCode
left join (select StockCode,SUM(QtyOnHand) as QtyOnHand from InvWarehouse where Warehouse not in ('QC','Z9','E4') group by StockCode) F2 on F2.StockCode=im.StockCode
left join (select StockCode,SUM(QtyOnHand) as E4OnHand from InvWarehouse where Warehouse='E4' group by StockCode) E4 on E4.StockCode=im.StockCode
left join ( select StockCode,SUM(QtyOnHand) as XQCOnHand,Sum(QtyInTransit) XQCInTrnasit from InvWarehouse where Warehouse='XQC' group by StockCode) XQC on XQC.StockCode=im.StockCode
left join ( select StockCode,SUM(QtyOnHand) as XFGOnHand,Sum(QtyInTransit) XFGInTransit from InvWarehouse where Warehouse='XFG' group by StockCode) XFG on XFG.StockCode=im.StockCode

left join (select MStockCode,SUM(od.MShipQty + od.MBackOrderQty) as OpenOrderQty,SUM((od.MShipQty + od.MBackOrderQty)*MPrice) as OpenOrderValue,
SUM(case when DispatchCount>=1
then (od.MShipQty + od.MBackOrderQty) else 0 end) as BoQty,SUM(case when DispatchCount>=1
then (od.MShipQty + od.MBackOrderQty)*MPrice else 0 end) as BoValue,
SUM(case when MLineShipDate<getdate() and DispatchCount IS NULL
then (od.MShipQty + od.MBackOrderQty) else 0 end) as PastDueQty, SUM(case when MLineShipDate<getdate() and DispatchCount IS NULL
then (od.MShipQty + od.MBackOrderQty)*MPrice else 0 end) as PastDueValue

from SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
left join (select SalesOrder,count(DispatchNote) as DispatchCount from MdnMaster group by SalesOrder)mm on mm.SalesOrder=om.SalesOrder

where (om.OrderStatus in ('0','1','2','3','4','S'))
AND (om.CancelledFlag <> 'Y')
AND (om.InterWhSale <> 'Y')
AND (od.LineType = '1')
AND (om.DocumentType) <> 'C'
AND ((od.MShipQty + MBackOrderQty) <> 0) group by MStockCode)BO on BO.MStockCode=im.StockCode
--left join (select distinct ParentPart, Component from BomStructure where left(Component,2)='WP') BM on BM.ParentPart=im.StockCode
left join (SELECT [StockCode]
, SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(GETDATE())), GETDATE()), 101) AND
ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 1, GETDATE())), 101))
THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt1
, SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 1, GETDATE())),
101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 2, GETDATE())), 101))
THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt2
,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 2, GETDATE())),
101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 3, GETDATE())), 101))
THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt3


,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 3, GETDATE())),
101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 4, GETDATE())), 101))
THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt4



, SUM(CAST(CASE WHEN ForecastType = 'S' AND Year(ForecastDate) = Year(Getdate())+1 AND Month(ForecastDate)
<=6 THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS JanJunNextYear
FROM dbo.MrpForecast where
(dbo.MrpForecast.ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(M, - 12, GETDATE()))), DATEADD(M, - 12, GETDATE())), 101)) AND
(dbo.MrpForecast.ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 12, GETDATE())), 101)) group by StockCode
) fcst on fcst.StockCode=im.StockCode

--left join (select StockCode,SUM(QtyOnHand) as WPOnHand,SUM(QtyOnOrder) as WPQtyOnOrder from InvWarehouse group by StockCode) WP on WP.StockCode=BM.Component
where InvType='FG' and (QtyOnHand>0 or QCOnHand>0 or XQCOnHand>0 or XFGInTransit>0 or XQCInTrnasit>0 or XFGOnHand>0 or E4OnHand>0 or OpenOrderQty>0 or BoQty>0 or PastDueQty>0 or QtyOnOrder>0 or FcstQtyMnt1>0 or FcstQtyMnt2>0 or FcstQtyMnt3>0)
group by StockUom,iw.StockCode, Description,im.ProductClass,StockOnHold,--Component,
WarehouseToUse,im.AbcClass
