--Daily_prod_stg0

SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,jm.StockCode,StockDescription,jr.TrnDate, SUM(jr.QtySupplied) as DailyProduction
FROM WipPartBook jr INNER JOIN WipMaster jm ON jr.Job = jm.Job
					INNER JOIN InvMaster im on jm.StockCode = im.StockCode

WHERE jm.Warehouse IN ('F1','F2','F3','QC') 
		AND DATEPART(year,jr.TrnDate) >= DATEPART(year,GETDATE()) -1
		AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
		AND LEFT(im.ProductClass, 2) <> 'SO'
		AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
		group by jm.StockCode,StockDescription,jr.TrnDate