--pick_report_stg0_pxf


select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,ShipAddress4,EntrySystemDate,CorpAcctName,Customer,CustomerName,SalesOrder,OrderStatus,MStockCode,
ShipPostalCode, CustomerPoNumber,OrderDate,ReqShipDate
,DateValue,MOrderQty,MPrice,CustomerClass,ProductClass,ProductGroup,StockUom,DispatchCount,MWarehouse, AlphaValue  
from
(select 
om.ShipAddress4,EntrySystemDate,CorpAcctName,om.Customer,om.CustomerName,om.SalesOrder,OrderStatus,od.MStockCode,
case when ISNUMERIC(substring(om.ShipPostalCode,PATINDEX('%[^0 ]%',om.ShipPostalCode + ' '),LEN(om.ShipPostalCode)))=1 then substring(om.ShipPostalCode,PATINDEX('%[^0 ]%',om.ShipPostalCode + ' '),LEN(om.ShipPostalCode)) 
else 0 end as ShipPostalCode, CustomerPoNumber,OrderDate,ReqShipDate
,a.DateValue,(MBackOrderQty+MShipQty) as MOrderQty,MPrice,CustomerClass,ProductClass,ProductGroup,StockUom,DispatchCount,od.MWarehouse,b.AlphaValue  
from SorMaster om inner join SorDetail od on om.SalesOrder=od.SalesOrder 
left join (select * from AdmFormData where FieldName='DEL001')a on a.KeyField=om.SalesOrder 
left join View_ArCust_GroupingData4KPI_New vw on om.Customer=vw.Customer left join InvMaster im on od.MStockCode=im.StockCode 
left join (select SalesOrder,count(DispatchNote) as DispatchCount from MdnMaster group by SalesOrder)mm on mm.SalesOrder=om.SalesOrder 
left join (select * from AdmFormData where FieldName='WHCOMM' and FormType = 'ORD')b on b.KeyField=om.SalesOrder
where (om.OrderStatus in ('0','1','2','3','4','S')) AND (om.DocumentType) <> 'C' and (om.CancelledFlag <> 'Y') AND (om.InterWhSale <> 'Y') AND (od.LineType = '1') 
AND ((od.MShipQty + MBackOrderQty) <> 0) and CorpAcctName<>'SAMPLES                                 '
union all
(select 'NY' as ShipAddress4,getdate() as EntrySystemDate,Description as CorpAcctName,
'0000000' as Customer,'Invoiced' as CustomerName,'000000' as SalesOrder,'*' as OrderStatus
,'' as MStockCode,null as ShipPostalCode,'' as CustomerPoNumber,getdate() as OrderDate
,getdate() as ReqShipDate,getdate() as DateValue,MTD as MOrderQty,1 as MPrice,
'XX' as CustomerClass,'ABC' as ProductClass,'XYZ' as ProductGroup,'CS' as StockUom,null as DispatchCount,'F2' as MWarehouse,'' as AlphaValue
from BTP_vwKPI_InvoicedSales))a