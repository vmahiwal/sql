--Job BomSales_stg0_pxf

select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, tmp.* from(
select a.*,StockCode from
(
SELECT  		 DrawOfficeNum,art.TrnMonth,art.TrnYear,
			  SUM(case when StockUom='CS' then art.QtyInvoiced*ConvFactAltUom else QtyInvoiced end) AS QtyInvoiced
			, SUM(art.NetSalesValue) AS NetSalesValue
			, SUM(art.CostValue) AS CostValue
			, SUM(art.DiscValue) AS DiscountValue
			, SUM(art.NetSalesValue + art.DiscValue) as GrossSalesValue
FROM    ArTrnDetail art  LEFT OUTER JOIN
                         dbo.InvMaster ON art.StockCode = dbo.InvMaster.StockCode 
                         
WHERE        (art.LineType = '1')
AND (art.DocumentType) <> 'C'
and  TrnYear>=year(getdate())-1   and DrawOfficeNum<>''
GROUP BY 
     DrawOfficeNum, art.TrnYear, art.TrnMonth
	 , case when StockUom='CS' then art.QtyInvoiced*ConvFactAltUom else QtyInvoiced end
                       )a left join InvMaster im on im.DrawOfficeNum=a.DrawOfficeNum
						  and im.StockUom='EA'
 )tmp