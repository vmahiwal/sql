--Job - vwKPI2_Orders_stg0_pxf


SELECT 
 GETDATE() as time,'00' as Sequence, 'Gross Order Intake' as Description,
 SUM(CASE WHEN DATEPART(dayofyear,om.EntrySystemDate) = DATEPART(dayofyear,GETDATE()) 
    THEN ROUND((od.MOrderQty * od.MPrice) ,2)
    ELSE 0 END) as Today
   , SUM(CASE WHEN DATEPART(week,om.EntrySystemDate) = DATEPART(week,GETDATE()) 
    THEN ROUND((od.MOrderQty * od.MPrice) ,2)
    ELSE 0 END) as WTD
  
  , SUM(CASE WHEN DATEPART(month,om.EntrySystemDate) = DATEPART(month,GETDATE()) 
    THEN ROUND((od.MOrderQty * od.MPrice) ,2)
    ELSE 0 END) as MTD
  
  , SUM(CASE WHEN DATEPART(quarter,om.EntrySystemDate) = DATEPART(quarter,GETDATE()) 
    THEN ROUND((od.MOrderQty * od.MPrice) ,2)
    ELSE 0 END) as QTD
  
  , SUM(ROUND((od.MOrderQty * od.MPrice) ,2)) as YTD
  
  
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
  AND (om.CancelledFlag <> 'Y')
  AND (om.InterWhSale <> 'Y') 
  AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
  AND (od.LineType = '1')
  --Added following condition to eliminate credit notes 2016-06-07
  AND (om.DocumentType) <> 'C'
  --2016-12-14 Next Line To Exclude Raw Material Customers
    AND NOT (om.Customer IN ('000000000048869','000000000049870'))
  AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())  
union  
 SELECT  GETDATE() as time,'00' as Sequence, 'Net Order Intake' as Description,SUM(CASE WHEN DATEPART(dayofyear,om.EntrySystemDate) = DATEPART(dayofyear,GETDATE()) 
    THEN CASE WHEN od.MDiscValFlag = 'V' THEN ROUND(((od.MOrderQty * od.MPrice) - od.MDiscValue) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100) ,2)
        WHEN od.MDiscValFlag = 'U' THEN ROUND(((od.MOrderQty * od.MPrice) - (od.MOrderQty * od.MDiscValue)) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100),2)
        ELSE ROUND((od.MOrderQty * od.MPrice) * ((100 - od.MDiscPct1)/100) * ((100 - od.MDiscPct2)/100) * ((100 - od.MDiscPct3)/100) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100) ,2)
      END
    ELSE 0 END) as TodayNet
  , SUM(CASE WHEN DATEPART(week,om.EntrySystemDate) = DATEPART(week,GETDATE()) 
    THEN CASE WHEN od.MDiscValFlag = 'V' THEN ROUND(((od.MOrderQty * od.MPrice) - od.MDiscValue) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100) ,2)
        WHEN od.MDiscValFlag = 'U' THEN ROUND(((od.MOrderQty * od.MPrice) - (od.MOrderQty * od.MDiscValue)) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100),2)
        ELSE ROUND((od.MOrderQty * od.MPrice) * ((100 - od.MDiscPct1)/100) * ((100 - od.MDiscPct2)/100) * ((100 - od.MDiscPct3)/100) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100) ,2)
      END
    ELSE 0 END) as WTDNet
  , SUM(CASE WHEN DATEPART(month,om.EntrySystemDate) = DATEPART(month,GETDATE()) 
    THEN CASE WHEN od.MDiscValFlag = 'V' THEN ROUND(((od.MOrderQty * od.MPrice) - od.MDiscValue) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100) ,2)
        WHEN od.MDiscValFlag = 'U' THEN ROUND(((od.MOrderQty * od.MPrice) - (od.MOrderQty * od.MDiscValue)) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100),2)
        ELSE ROUND((od.MOrderQty * od.MPrice) * ((100 - od.MDiscPct1)/100) * ((100 - od.MDiscPct2)/100) * ((100 - od.MDiscPct3)/100) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100) ,2)
      END
    ELSE 0 END) as MTDNet
  ,  SUM(CASE WHEN DATEPART(quarter,om.EntrySystemDate) = DATEPART(quarter,GETDATE()) 
    THEN CASE WHEN od.MDiscValFlag = 'V' THEN ROUND(((od.MOrderQty * od.MPrice) - od.MDiscValue) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100) ,2)
        WHEN od.MDiscValFlag = 'U' THEN ROUND(((od.MOrderQty * od.MPrice) - (od.MOrderQty * od.MDiscValue)) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100),2)
        ELSE ROUND((od.MOrderQty * od.MPrice) * ((100 - od.MDiscPct1)/100) * ((100 - od.MDiscPct2)/100) * ((100 - od.MDiscPct3)/100) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100) ,2)
      END
    ELSE 0 END) as QTDNet
  , SUM(CASE WHEN od.MDiscValFlag = 'V' THEN ROUND(((od.MOrderQty * od.MPrice) - od.MDiscValue) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100) ,2)
        WHEN od.MDiscValFlag = 'U' THEN ROUND(((od.MOrderQty * od.MPrice) - (od.MOrderQty * od.MDiscValue)) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100),2)
        ELSE ROUND((od.MOrderQty * od.MPrice) * ((100 - od.MDiscPct1)/100) * ((100 - od.MDiscPct2)/100) * ((100 - od.MDiscPct3)/100) * ((100 - om.DiscPct1)/100) * ((100 - om.DiscPct2)/100) * ((100 - om.DiscPct3)/100) ,2)
    END) as YTDNet
  
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
  AND (om.CancelledFlag <> 'Y')
  AND (om.InterWhSale <> 'Y') 
  AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
  AND (od.LineType = '1')
  --Added following condition to eliminate credit notes 2016-06-07
  AND (om.DocumentType) <> 'C'
  --2016-12-14 Next Line To Exclude Raw Material Customers
    AND NOT (om.Customer IN ('000000000048869','000000000049870'))
  AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
 union 
 SELECT GETDATE() as time,'02' as Sequence
  , 'Picked Not Dispatched' as Description
  , SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as Today
  , SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as WTD
  , SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as MTD
  , SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as QTD
  , SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as YTD
FROM              Barcode.dbo.Orders bo INNER JOIN SysproCompanyB.dbo.SorDetail od 
           ON  SUBSTRING(od.SalesOrder, PATINDEX('%[^0 ]%', od.SalesOrder + ' '), LEN(od.SalesOrder)) = SUBSTRING(bo.OrderNo, PATINDEX('%[^0 ]%', bo.OrderNo + ' '), LEN(bo.OrderNo)) COLLATE Latin1_General_BIN 
           AND od.MStockCode = bo.ItemNo COLLATE Latin1_General_BIN 
           AND od.SalesOrderLine = bo.LineNumber
          INNER JOIN SysproCompanyB.dbo.SorMaster om
           ON od.SalesOrder = om.SalesOrder
WHERE (NOT(om.Branch IN ('TR', 'CO', 'SM')))
  --2016-12-14 Next Line To Exclude Raw Material Customers
    AND NOT (om.Customer IN ('000000000048869','000000000049870'))

UNION ALL

SELECT GETDATE() as time,'01' as Sequence
  , 'Open Orders By Ship Date' as Description
  , SUM(CASE WHEN od.MLineShipDate <= GETDATE() 
   THEN ROUND(((od.MShipQty + MBackOrderQty) * od.MPrice) ,2)
   ELSE 0 END) as TodayGross
  , SUM(CASE WHEN ((od.MLineShipDate <= GETDATE()) OR (DATEPART(week,od.MLineShipDate) = DATEPART(week,GETDATE())))
   THEN ROUND(((od.MShipQty + MBackOrderQty) * od.MPrice) ,2)
   ELSE 0 END) as WTDGross
  , SUM(CASE WHEN ((od.MLineShipDate <= GETDATE()) OR (DATEPART(month,od.MLineShipDate) = DATEPART(month,GETDATE())))
   THEN ROUND(((od.MShipQty + MBackOrderQty) * od.MPrice) ,2)
   ELSE 0 END) as MTDGross
  , SUM(CASE WHEN ((od.MLineShipDate <= GETDATE()) OR (DATEPART(quarter,od.MLineShipDate) = DATEPART(quarter,GETDATE())))
   THEN ROUND(((od.MShipQty + MBackOrderQty) * od.MPrice) ,2)
   ELSE 0 END) as QTDGross
  , SUM(CASE WHEN ((od.MLineShipDate <= GETDATE()) OR (DATEPART(year,od.MLineShipDate) = DATEPART(year,GETDATE())))
   THEN ROUND(((od.MShipQty + MBackOrderQty) * od.MPrice) ,2)
   ELSE 0 END) as YTDGross
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder 

WHERE (om.OrderStatus in ('0','1','2','3','4','S')) 
  AND (om.CancelledFlag <> 'Y')
  AND (om.InterWhSale <> 'Y') 
  AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
  AND (od.LineType = '1')
  
  AND (om.DocumentType) <> 'C'
 
    AND NOT (om.Customer IN ('000000000048869','000000000049870'))
  AND ((od.MShipQty + MBackOrderQty) <> 0) 

   union
    select GETDATE() as time,'03' as Sequence, 'Total To Be Picked' as Description, 
  (t02.TodayGross - t01.Today) AS Today,
  (t02.WTDGross - t01.WTD) AS WTD,
  (t02.MTDGross - t01.MTD) AS MTD,
   (t02.QTDGross - t01.QTD) AS QTD,
   (t02.YTDGross - t01.YTD) AS YTD  FROM (select GETDATE() as time
   , 'Picked Not Dispatched' as Description
  , SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as Today
  , SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as WTD
  , SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as MTD
  , SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as QTD
  , SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as YTD
FROM              Barcode.dbo.Orders bo INNER JOIN SysproCompanyB.dbo.SorDetail od 
           ON SUBSTRING(od.SalesOrder, PATINDEX('%[^0 ]%', od.SalesOrder + ' '), LEN(od.SalesOrder))  = SUBSTRING(bo.OrderNo, PATINDEX('%[^0 ]%', bo.OrderNo + ' '), LEN(bo.OrderNo)) COLLATE Latin1_General_BIN 
           AND od.MStockCode = bo.ItemNo COLLATE Latin1_General_BIN 
           AND od.SalesOrderLine = bo.LineNumber
          INNER JOIN SysproCompanyB.dbo.SorMaster om
           ON od.SalesOrder = om.SalesOrder
WHERE (NOT(om.Branch IN ('TR', 'CO', 'SM')))
  --2016-12-14 Next Line To Exclude Raw Material Customers
    AND NOT (om.Customer IN ('000000000048869','000000000049870'))) t01 
 CROSS JOIN (SELECT '01' as Sequence
  , 'Open Orders By Ship Date' as Description
  , SUM(CASE WHEN od.MLineShipDate <= GETDATE() 
   THEN ROUND(((od.MShipQty + MBackOrderQty) * od.MPrice) ,2)
   ELSE 0 END) as TodayGross
  , SUM(CASE WHEN ((od.MLineShipDate <= GETDATE()) OR (DATEPART(week,od.MLineShipDate) = DATEPART(week,GETDATE())))
   THEN ROUND(((od.MShipQty + MBackOrderQty) * od.MPrice) ,2)
   ELSE 0 END) as WTDGross
  , SUM(CASE WHEN ((od.MLineShipDate <= GETDATE()) OR (DATEPART(month,od.MLineShipDate) = DATEPART(month,GETDATE())))
   THEN ROUND(((od.MShipQty + MBackOrderQty) * od.MPrice) ,2)
   ELSE 0 END) as MTDGross
  , SUM(CASE WHEN ((od.MLineShipDate <= GETDATE()) OR (DATEPART(quarter,od.MLineShipDate) = DATEPART(quarter,GETDATE())))
   THEN ROUND(((od.MShipQty + MBackOrderQty) * od.MPrice) ,2)
   ELSE 0 END) as QTDGross
  , SUM(CASE WHEN ((od.MLineShipDate <= GETDATE()) OR (DATEPART(year,od.MLineShipDate) = DATEPART(year,GETDATE())))
   THEN ROUND(((od.MShipQty + MBackOrderQty) * od.MPrice) ,2)
   ELSE 0 END) as YTDGross
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder 

WHERE (om.OrderStatus in ('0','1','2','3','4','S')) 
  AND (om.CancelledFlag <> 'Y')
  AND (om.InterWhSale <> 'Y') 
  AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
  AND (od.LineType = '1')

  AND (om.DocumentType) <> 'C'
  AND NOT (om.Customer IN ('000000000048869','000000000049870'))
  AND ((od.MShipQty + MBackOrderQty) <> 0)) t02 
  
 union 
    SELECT  GETDATE() as time,'04' as Sequence
  , 'Dispatched:  Awaiting Invoicing' as Description
  , SUM(ROUND(dd.MQtyToDispatch * dd.MPrice,2)) as Today
  , SUM(ROUND(dd.MQtyToDispatch * dd.MPrice,2)) as WTD
  , SUM(ROUND(dd.MQtyToDispatch * dd.MPrice,2)) as MTD
  , SUM(ROUND(dd.MQtyToDispatch * dd.MPrice,2)) as QTD
  , SUM(ROUND(dd.MQtyToDispatch * dd.MPrice,2)) as YTD
FROM            MdnDetail dd INNER JOIN
                         MdnMaster dm ON dd.DispatchNote = dm.DispatchNote
WHERE        (dd.LineType = '1') AND (dm.DispatchNoteStatus <> '*') AND (dm.DispatchNoteStatus <> '9') AND (dd.DispatchStatus <> '*') and (NOT(dm.Branch IN ('TR', 'CO', 'SM')))
   
    AND NOT (dm.Customer IN ('000000000048869','000000000049870'))

UNION ALL

--Removed Net section 2016-03-08
SELECT  GETDATE() as time,'05' as Sequence
  , 'Invoiced Before Chargebacks' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,InvoiceDate) = DATEPART(dayofyear,GETDATE()) THEN (NetSalesValue + DiscValue) ELSE 0 END) as TodayGross
  
  , SUM(CASE WHEN DATEPART(week,InvoiceDate) = DATEPART(week,GETDATE()) THEN (NetSalesValue + DiscValue) ELSE 0 END) as WTDGross
  , SUM(CASE WHEN TrnMonth = DATEPART(month,GETDATE()) THEN (NetSalesValue + DiscValue) ELSE 0 END) as MTDGross
   , SUM(CASE WHEN (CASE WHEN TrnMonth BETWEEN 1 AND 3 THEN 1
     WHEN TrnMonth BETWEEN 4 AND 6 THEN 2
     WHEN TrnMonth BETWEEN 7 AND 9 THEN 3
     WHEN TrnMonth BETWEEN 10 and 12 THEN 4 ELSE 0 END) = DATEPART(quarter,GETDATE()) THEN (NetSalesValue + DiscValue) ELSE 0 END) as QTDGross
   , SUM((NetSalesValue + DiscValue)) as YTDGross
 
FROM ArTrnDetail
WHERE (LineType = '1') AND (TrnYear = DATEPART(year,GETDATE())) AND (NOT(Branch IN ('TR', 'CO', 'SM'))) 
   AND (DocumentType) <> 'C'
     AND NOT (Customer IN ('000000000048869','000000000049870'))