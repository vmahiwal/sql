--Job Name - KPIinvoiceByCustomer




SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,
CorpAcctName,a.Customer,InvoiceDate,SUM(NetSalesValue+DiscValue) as GrossInvoice
FROM ArTrnDetail a
left join View_ArCust_GroupingData4KPI_New b on a.Customer=b.Customer
WHERE (LineType = '1') AND (TrnYear = DATEPART(year,GETDATE())) AND (NOT(Branch IN ('TR', 'CO', 'SM')))
group by CorpAcctName,a.Customer,InvoiceDate