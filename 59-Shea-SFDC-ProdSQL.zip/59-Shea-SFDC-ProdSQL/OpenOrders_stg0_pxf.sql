--job OpenOrders_stg0_pxf

select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, case when SUBSTRING(bo.OrderNo , PATINDEX('%[^0 ]%', bo.OrderNo  + ' '), LEN(bo.OrderNo )) is null then SUBSTRING(boh.OrderNo , PATINDEX('%[^0 ]%', boh.OrderNo  + ' '), LEN(boh.OrderNo )) else SUBSTRING(bo.OrderNo , PATINDEX('%[^0 ]%', bo.OrderNo  + ' '), LEN(bo.OrderNo )) end,
case when bo.ItemNo is null then boh.ItemNo else bo.ItemNo end as ItemNo,
case when bo.LineNumber is null then boh.LineNumber else bo.LineNumber end as LineNumber,
SUM(case when bo.MStockQtyToShp is null then boh.MStockQtyToShp
when boh.MStockQtyToShp is null then bo.MStockQtyToShp
else bo.MStockQtyToShp+boh.MStockQtyToShp end) as MStockQtyToShp
from
SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
left join Barcode.dbo.Orders bo ON SUBSTRING(od.SalesOrder, PATINDEX('%[^0 ]%', od.SalesOrder + ' '), LEN(od.SalesOrder)) =SUBSTRING(bo.OrderNo , PATINDEX('%[^0 ]%', bo.OrderNo  + ' '), LEN(bo.OrderNo )) COLLATE Latin1_General_BIN
AND od.MStockCode = bo.ItemNo COLLATE Latin1_General_BIN
AND od.SalesOrderLine = bo.LineNumber
left join Barcode.dbo.OrderHistory boh ON  
SUBSTRING(od.SalesOrder, PATINDEX('%[^0 ]%', od.SalesOrder + ' '), LEN(od.SalesOrder)) =SUBSTRING(boh.OrderNo , PATINDEX('%[^0 ]%', boh.OrderNo  + ' '), LEN(boh.OrderNo ))

COLLATE Latin1_General_BIN
AND od.MStockCode = boh.ItemNo COLLATE Latin1_General_BIN
AND od.SalesOrderLine = boh.LineNumber
WHERE (om.OrderStatus in ('0','1','2','3','4','S'))
AND (om.CancelledFlag <> 'Y')
AND (om.InterWhSale <> 'Y')
AND (NOT(om.Branch IN ('TR', 'CO', 'SM')))
AND (od.LineType = '1')
AND (om.DocumentType) <> 'C'
AND ((od.MShipQty + MBackOrderQty) <> 0)
group by case when SUBSTRING(bo.OrderNo , PATINDEX('%[^0 ]%', bo.OrderNo  + ' '), LEN(bo.OrderNo )) is null then SUBSTRING(boh.OrderNo , PATINDEX('%[^0 ]%', boh.OrderNo  + ' '), LEN(boh.OrderNo )) else SUBSTRING(bo.OrderNo , PATINDEX('%[^0 ]%', bo.OrderNo  + ' '), LEN(bo.OrderNo )) end,
case when bo.ItemNo is null then boh.ItemNo else bo.ItemNo end,
case when bo.LineNumber is null then boh.LineNumber else bo.LineNumber end