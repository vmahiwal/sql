# 59-Shea-SFDC
## For Steps to talend job migration.

We have 2 ETL Servers ( 1 for dev and 1 for production)  
Following steps: In the dev server,  
1) Right click on Job Designs and choose Export Items  
2) Click radio button to "Select Archive File" and browse (or enter) a file path and .zip file name  
3) Make sure "Export Dependencies" is checked  
4) Select the folders/jobs to be exported  
5) Click finish  

Copy the file to the production ETL server in the production ETL server  
1) Right click on Jobs and select Import Items  
2) Click radio button to "Select Archive File" and browse (or enter) a file path and .zip file name  
3) Select all and click Finish  

**After import, Need to change the component setting ,configuration Path & Credential as well.**
