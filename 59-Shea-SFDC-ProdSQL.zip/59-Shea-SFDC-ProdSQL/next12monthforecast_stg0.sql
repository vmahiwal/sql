--next12monthforecast_stg0_pxf


SELECT 
ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,
StockUom,
InvType,
case when BO.CorpAcctName is null then fcst.CorpAcctName else BO.CorpAcctName end as CorpAcctName,
case when im.StockCode is null then fcst.StockCode else im.StockCode end as StockCode,
case when im.Description is null then fcst.Description else im.Description end as Description,im.AbcClass as ProductClass,
StockOnHold,
SUM(OpenOrderQty) as OpenOrderQty, SUM(OpenOrderValue) as OpenOrderValue,
SUM(BoQty) as BoQty, SUM(BoValue) as BoValue,
SUM(PastDueQty) as PastDueQty, SUM(PastDueValue) as PastDueValue,
SUM(QtyOnHand) as QtyOnHand,SUM(QCOnHand) as QCOnHand,
SUM(E4OnHand) as EmersonOnHand, SUM(iw.QtyOnOrder) as QtyOnOrder, SUM(SafetyStockQty) as SafetyStockQty,
SUM(fcst.FcstQtyMnt1) as FcstQtyMnt1, SUM(ForecastValMnt1) ForecastValMnt1,
SUM(fcst.FcstQtyMnt2) as FcstQtyMnt2, SUM(ForecastValMnt2) ForecastValMnt2,
SUM(fcst.FcstQtyMnt3) as FcstQtyMnt3, SUM(ForecastValMnt3) ForecastValMnt3,
SUM(fcst.FcstQtyMnt4) as FcstQtyMnt4, SUM(ForecastValMnt4) ForecastValMnt4,
SUM(fcst.FcstQtyMnt5) as FcstQtyMnt5, SUM(ForecastValMnt5) ForecastValMnt5,
SUM(fcst.FcstQtyMnt6) as FcstQtyMnt6, SUM(ForecastValMnt6) ForecastValMnt6,
SUM(fcst.FcstQtyMnt7) as FcstQtyMnt7, SUM(ForecastValMnt7) ForecastValMnt7,
SUM(fcst.FcstQtyMnt8) as FcstQtyMnt8, SUM(ForecastValMnt8) ForecastValMnt8,
SUM(fcst.FcstQtyMnt9) as FcstQtyMnt9, SUM(ForecastValMnt9) ForecastValMnt9,
SUM(fcst.FcstQtyMnt10) as FcstQtyMnt10, SUM(ForecastValMnt10) ForecastValMnt10,
SUM(fcst.FcstQtyMnt11) as FcstQtyMnt11, SUM(ForecastValMnt11) ForecastValMnt11,
SUM(fcst.FcstQtyMnt12) as FcstQtyMnt12, SUM(ForecastValMnt12) ForecastValMnt12
--,SUM(fcst.JanJunNextYear) as JanJunNextYear
--,Component as WP,SUM(WP.WPOnHand) as WPQtyOnHand,SUM(WPQtyOnOrder) as WPQtyOnOrder, WarehouseToUse,im.AbcClass
 from InvMaster im left join (select StockCode, SUM(QtyOnOrder) as QtyOnOrder,SUM(SafetyStockQty) as SafetyStockQty 
 from InvWarehouse group by StockCode) iw   on im.StockCode=iw.StockCode 
 left join (SELECT KeyField as ProductClass
										, AlphaValue as InvType
								FROM AdmFormData 
								WHERE FormType = 'ARPCL' and FieldName = 'KPI001') invtyp on im.ProductClass = invtyp.ProductClass
 left join (select StockCode,SUM(QtyOnHand) as QCOnHand from InvWarehouse where Warehouse='QC' group by StockCode) QC on QC.StockCode=im.StockCode
 left join (select StockCode,SUM(QtyOnHand) as QtyOnHand from InvWarehouse where Warehouse not in ('QC','Z9','E4') group by StockCode) F2 on F2.StockCode=im.StockCode
 left join (select StockCode,SUM(QtyOnHand) as E4OnHand from InvWarehouse where Warehouse='E4' group by StockCode) E4 on E4.StockCode=im.StockCode
 left join (select CorpAcctName, MStockCode,SUM(od.MShipQty + od.MBackOrderQty) as OpenOrderQty,SUM((od.MShipQty + od.MBackOrderQty)*MPrice) as OpenOrderValue,
  SUM(case when DispatchCount>=1
 then (od.MShipQty + od.MBackOrderQty) else 0 end) as BoQty,SUM(case when DispatchCount>=1
 then (od.MShipQty + od.MBackOrderQty)*MPrice else 0 end) as BoValue,
  SUM(case when MLineShipDate<getdate() and DispatchCount  IS NULL
 then (od.MShipQty + od.MBackOrderQty) else 0 end) as PastDueQty,  SUM(case when MLineShipDate<getdate() and DispatchCount  IS NULL
 then (od.MShipQty + od.MBackOrderQty)*MPrice else 0 end) as PastDueValue
  
 from SorMaster om inner JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
 left join (select Customer, SalesOrder,count(DispatchNote) as DispatchCount from MdnMaster group by SalesOrder,Customer)mm on mm.SalesOrder=om.SalesOrder 
 and mm.Customer = om.Customer
left join View_ArCust_GroupingData4KPI_New vw on vw.Customer = om.Customer 

 where (om.OrderStatus in ('0','1','2','3','4','S')) 
AND (om.CancelledFlag <> 'Y')
AND (om.InterWhSale <> 'Y') 
AND (od.LineType = '1')
AND (om.DocumentType) <> 'C'
AND ((od.MShipQty + MBackOrderQty) <> 0) group by MStockCode,CorpAcctName)BO on BO.MStockCode=im.StockCode 
--left join View_ArCust_GroupingData4KPI_New vw on vw.Customer = BO.Customer 
-- full join (select distinct ParentPart, Component from BomStructure where left(Component,2)='WP') BM on BM.ParentPart=im.StockCode
 full outer join (select CorpAcctName,fc.StockCode,Description,Sum(fc.FcstQtyMnt1) FcstQtyMnt1,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt1) AS ForecastValMnt1,
Sum(fc.FcstQtyMnt2) FcstQtyMnt2,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt2) AS ForecastValMnt2,
Sum(fc.FcstQtyMnt3) FcstQtyMnt3,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt3) AS ForecastValMnt3,
Sum(fc.FcstQtyMnt4) FcstQtyMnt4,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt4) AS ForecastValMnt4,
Sum(fc.FcstQtyMnt5) FcstQtyMnt5,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt5) AS ForecastValMnt5,
Sum(fc.FcstQtyMnt6) FcstQtyMnt6,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt6) AS ForecastValMnt6,
Sum(fc.FcstQtyMnt7) FcstQtyMnt7,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt7) AS ForecastValMnt7,
Sum(fc.FcstQtyMnt8) FcstQtyMnt8,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt8) AS ForecastValMnt8,
Sum(fc.FcstQtyMnt9) FcstQtyMnt9,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt9) AS ForecastValMnt9,
Sum(fc.FcstQtyMnt10) FcstQtyMnt10,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt10) AS ForecastValMnt10,
Sum(fc.FcstQtyMnt11) FcstQtyMnt11,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt11) AS ForecastValMnt11,
Sum(fc.FcstQtyMnt12) FcstQtyMnt12,    SUM(InvPrice.SellingPrice*fc.FcstQtyMnt12) AS ForecastValMnt12
 from (SELECT [StockCode],Description,dbo.MrpForecast.Customer
      , SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(GETDATE())), GETDATE()), 101) AND 
                      ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 1, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt1
      , SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 1, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 2, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt2
      ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 2, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 3, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt3
      ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 3, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 4, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt4
     ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 4, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 5, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt5
     ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 5, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 6, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt6
       ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 6, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 7, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt7
        ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 7, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 8, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt8
     ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 8, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 9, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt9
     ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 9, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 10, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt10
      ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 10, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 11, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt11
     ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 11, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 12, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt12
        
,   SUM(CAST(CASE WHEN ForecastType = 'S' AND Year(ForecastDate) = Year(Getdate())+1 AND Month(ForecastDate) 
                      <=6 THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS JanJunNextYear
 ,CASE
    WHEN (PriceCode IS NULL OR
      PriceCode = '') THEN LEFT(Reference, 2)
    ELSE PriceCode
  END AS PriceCode                     
  FROM dbo.MrpForecast full JOIN [SysproCompanyB].[dbo].[ArCustomer] arc
  ON dbo.MrpForecast.Customer = arc.Customer
  --left join View_ArCust_GroupingData4KPI_New c on c.Customer=dbo.MrpForecast.Customer
  where
   (dbo.MrpForecast.ForecastDate > CONVERT(varchar, DATEADD(d, -  (1 * DAY(DATEADD(M, - 12, GETDATE()))), DATEADD(M, - 12, GETDATE())), 101)) AND 
                      (dbo.MrpForecast.ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 12, GETDATE())), 101))
                      group by StockCode,Description,dbo.MrpForecast.Customer,CASE
    WHEN (PriceCode IS NULL OR
      PriceCode = '') THEN LEFT(Reference, 2)
    ELSE PriceCode
  END)fc
                      full join View_ArCust_GroupingData4KPI_New c on c.Customer=fc.Customer
                      
                      full OUTER JOIN dbo.InvPrice
  ON fc.StockCode = dbo.InvPrice.StockCode
  AND fc.PriceCode = dbo.InvPrice.PriceCode
                    
                      group by CorpAcctName,fc.StockCode,Description) 
                      fcst on fcst.StockCode=BO.MStockCode
                      and fcst.CorpAcctName = BO.CorpAcctName
                      and fcst.Description = im.Description
 --  full join (select StockCode,SUM(QtyOnHand) as WPOnHand,SUM(QtyOnOrder) as WPQtyOnOrder from InvWarehouse group by StockCode) WP on WP.StockCode=BM.Component
 where --InvType='FG' and 
 (QtyOnHand>0 or QCOnHand>0 or E4OnHand>0 or OpenOrderQty>0 or BoQty>0 or PastDueQty>0 or QtyOnOrder>0 or FcstQtyMnt1>0 or FcstQtyMnt2>0 or FcstQtyMnt3>0 or
 FcstQtyMnt4>0 or FcstQtyMnt5>0 or FcstQtyMnt6>0 or FcstQtyMnt7>0 or FcstQtyMnt8>0 or FcstQtyMnt9>0 or FcstQtyMnt10>0
 or FcstQtyMnt11>0 or FcstQtyMnt12>0)
 group by 
 StockUom,BO.CorpAcctName,iw.StockCode, im.Description,fcst.Description,im.ProductClass,StockOnHold--,Component
 ,WarehouseToUse,im.AbcClass
 ,fcst.StockCode,im.StockCode,fcst.CorpAcctName,
 InvType