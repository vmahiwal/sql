--Job DispatchedOrder_stg0


SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,vw.CorpAcctName,
SUBSTRING(dd.SalesOrder, PATINDEX('%[^0 ]%', dd.SalesOrder + ' '), LEN(dd.SalesOrder)) as SalesOrder,
SalesOrderLine,TotalValue,MStockCode,MStockDes,MWarehouse,MOrderQty,
MQtyToDispatch,MBackOrderQty,MUnitCost,MPrice,MLineShipDate,MCustRequestDat,MQtyDispatched,
SUBSTRING(dm.Customer, PATINDEX('%[^0 ]%', dm.Customer + ' '), LEN(dm.Customer)) as Customer
,dm.CustomerName,DispatchName,
PlannedDeliverDate,ActualDeliveryDate,CustomerPoNumber
FROM            MdnDetail dd INNER JOIN
                         MdnMaster dm ON dd.DispatchNote = dm.DispatchNote left join View_ArCust_GroupingData4KPI_New vw on vw.Customer=dm.Customer
WHERE        (dd.LineType = '1') AND (dm.DispatchNoteStatus <> '*') AND (dm.DispatchNoteStatus <> '9') AND (dd.DispatchStatus <> '*') and (NOT(dm.Branch IN ('TR', 'CO', 'SM')))