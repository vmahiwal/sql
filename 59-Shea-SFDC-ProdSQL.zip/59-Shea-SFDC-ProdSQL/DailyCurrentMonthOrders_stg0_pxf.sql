--Job -DailyCurrentMonthOrders_stg0



select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,cacm.CorpAcctName, 
sum(DaySale1)as DaySale1 , 
sum(DaySale2)as DaySale2,
sum(DaySale3)as DaySale3 , 
sum(DaySale4)as DaySale4 , 
sum(DaySale5)as DaySale5 , 
sum(DaySale6)as DaySale6 , 
sum(DaySale7)as DaySale7 , 
sum(DaySale8)as DaySale8 , 
sum(DaySale9)as DaySale9 , 
sum(DaySale10)as DaySale10 , 
sum(DaySale11)as DaySale11 , 
sum(DaySale12)as DaySale12 , 
sum(DaySale13)as DaySale13 , 
sum(DaySale14)as DaySale14 , 
sum(DaySale15)as DaySale15 , 
sum(DaySale16)as DaySale16 , 
sum(DaySale17)as DaySale17 , 
sum(DaySale18)as DaySale18 , 
sum(DaySale19)as DaySale19 , 
sum(DaySale20)as DaySale20 , 
sum(DaySale21)as DaySale21 , 
sum(DaySale22)as DaySale22 , 
sum(DaySale23)as DaySale23 , 
sum(DaySale24)as DaySale24 , 
sum(DaySale25)as DaySale25 , 
sum(DaySale26)as DaySale26 , 
sum(DaySale27)as DaySale27 , 
sum(DaySale28)as DaySale28 , 
sum(DaySale29)as DaySale29 , 
sum(DaySale30)as DaySale30 , 
sum(DaySale31) as DaySale31 
from (
select Customer,EntrySystemDate,
case when day(EntrySystemDate) = 1 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale1 ,
case when day(EntrySystemDate) = 2 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale2 ,
case when day(EntrySystemDate) = 3 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale3 ,
case when day(EntrySystemDate) = 4 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale4 ,
case when day(EntrySystemDate) = 5 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale5 ,
case when day(EntrySystemDate) = 6 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale6 ,
case when day(EntrySystemDate) = 7 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale7 ,
case when day(EntrySystemDate) = 8 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale8 ,
case when day(EntrySystemDate) = 9 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale9 ,
case when day(EntrySystemDate) = 10 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale10 ,
case when day(EntrySystemDate) = 11 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale11 ,
case when day(EntrySystemDate) = 12 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale12 ,
case when day(EntrySystemDate) = 13 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale13 ,
case when day(EntrySystemDate) = 14 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale14 ,
case when day(EntrySystemDate) = 15 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale15 ,
case when day(EntrySystemDate) = 16 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale16 ,
case when day(EntrySystemDate) = 17 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale17 ,
case when day(EntrySystemDate) = 18 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale18 ,
case when day(EntrySystemDate) = 19 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale19 ,
case when day(EntrySystemDate) = 20 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale20 ,
case when day(EntrySystemDate) = 21 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale21 ,
case when day(EntrySystemDate) = 22 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale22 ,
case when day(EntrySystemDate) = 23 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale23 ,
case when day(EntrySystemDate) = 24 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale24 ,
case when day(EntrySystemDate) = 25 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale25 ,
case when day(EntrySystemDate) = 26 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale26 ,
case when day(EntrySystemDate) = 27 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale27 ,
case when day(EntrySystemDate) = 28 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale28 ,
case when day(EntrySystemDate) = 29 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale29 ,
case when day(EntrySystemDate) = 30 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale30 ,
case when day(EntrySystemDate) = 31 then sum  (case when od.MOrderQty is NULL then 0 else od.MOrderQty * od.MPrice end) end as DaySale31 
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder

WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
        AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (od.LineType = '1')
		AND month(EntrySystemDate)=month(getdate()) and year(EntrySystemDate) =year(getdate())
group by EntrySystemDate,Customer
 ) a LEFT JOIN (SELECT REPLACE(KeyField,' ','') as Customer
									, AlphaValue as CorpAcctCode
								FROM AdmFormData
								WHERE FormType = 'CUS' and FieldName = 'COR002') cac ON a.Customer = cac.Customer
					LEFT JOIN (SELECT Item as CorpAcctCode
									, Description as CorpAcctName
								FROM AdmFormValidation
								WHERE FormType = 'CUS' and FieldName = 'COR002') cacm on cac.CorpAcctCode = cacm.CorpAcctCode
								group by cacm.CorpAcctName