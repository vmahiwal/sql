--Job --InsertIntoWarehouse_production



SELECT Warehouse      ,Description
  FROM InvWhControl