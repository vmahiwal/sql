--Job UpsertIntoOrder_Daily_production


select  CONVERT(varchar,CONVERT(INT,om.SalesOrder)) As SalesOrder, case when ar.Customer is null then null else CONVERT(varchar,CONVERT(INT,ar.Customer)) end As Customer, om.CustomerPoNumber,
case when om.OrderStatus='0' then '0 - In progress'
when om.OrderStatus='1' then '1 - Order entered' when om.OrderStatus='2' then '2 - Open Backorder' 
when om.OrderStatus='3' then '3 - Released backorder' when om.OrderStatus='4' then '4 - In warehouse' 
when om.OrderStatus='8' then '8 - To Invoice'
when om.OrderStatus='9' then '9 - Complete' when om.OrderStatus='F' then 'F - Forward'
when om.OrderStatus='S' then 'S - Suspense' when om.OrderStatus='\\' then '/ - Cancelled' else om.OrderStatus end As OrderStatus,case when om.CancelledFlag='Y' then 'true' else 'false' end as CancelledFlag,om.DocumentType
 from SorMaster om
 left join ArCustomer ar on om.Customer=ar.Customer where (ar.CustomerClass<>'RT' or ar.CustomerClass is null) and 
  ar.Customer is not null 
 and EntrySystemDate>=DATEADD(day,-124,getdate())   and EntrySystemDate<getdate()  and CustomerPoNumber<>''