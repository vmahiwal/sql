--UpsertIntoInventory_production


SELECT RTRIM(StockCode) as StockCode
,Description
,LongDesc
,AlternateKey1
,AlternateKey2 
,StockUom 
,AlternateUom
 ,OtherUom
 ,ConvFactAltUom 
,ConvMulDiv 
,ConvFactOthUom 
,MulDiv
,Mass
,Volume  
,ProductClass ,TaxCode ,DrawOfficeNum ,TariffCode,ProductGroup FROM SysproCompanyB.dbo.InvMaster