--Job UpsertIntoOrder_Item_Daily_production


select  CONVERT(varchar,CONVERT(INT,om.SalesOrder)) as SalesOrder,
 od.SalesOrderLine,
 concat(concat(CONVERT(varchar,CONVERT(INT,om.SalesOrder)),' - '),od.SalesOrderLine) as Syspro_ID ,
   od.MWarehouse,
od.MOrderQty, od.LineType,
od.MPrice,RTRIM(od.MStockCode) as MStockCode, vw.MQtyToDispatch,
  od.MPrice*od.MOrderQty As OrderValue, vw.InvoiceDt,vw.DispDt,
  Case
When  StockUom = 'CS' then od.MOrderQty*ConvFactAltUom 
Else MOrderQty end as  OrderQtyInEaches, case
When  StockUom = 'CS' then vw.MQtyToDispatch*ConvFactAltUom 
Else vw.MQtyToDispatch end as DispQtyInEaches,od.NComment,od.LineType,od.MBackOrderQty,od.MShipQty, MLineShipDate
  from SorDetail od LEFT JOIN SorMaster om on od.SalesOrder=om.SalesOrder left join ArCustomer ar on om.Customer=ar.Customer 
left join View_DispDet_SumBySalesOrder vw on od.SalesOrder=vw.SalesOrder and od.SalesOrderLine=vw.SalesOrderLine
left join InvMaster On od.MStockCode=StockCode
where (ar.CustomerClass<>'RT' or ar.CustomerClass is null)and (od.LineType = '1') and ar.Customer is not null  
and EntrySystemDate>=DATEADD(day,-124,getdate()) and year(EntrySystemDate) IN (year(getdate()), year(getdate())-1)  and CustomerPoNumber<>'' 