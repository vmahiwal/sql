--Job UpsertInto_CorpAccount_production


SELECT
  x.*,
  CASE
    WHEN [PriceCode] = 'AH' THEN '(AH) Ahold'
    WHEN [PriceCode] = 'AS' THEN '(AS) Aafes'
    WHEN [PriceCode] = 'FA' THEN '(FA) Family Dollar'
    WHEN [PriceCode] = 'S&' THEN '(S&) S&K Sales'
WHEN [PriceCode] = 'SS' THEN '(SS) Stage Stores'
WHEN [PriceCode] = 'SP' THEN '(SP) Sephora'
WHEN [PriceCode] = 'SK' THEN '(SK) Shopko'
WHEN [PriceCode] = 'RS' THEN '(S&) Ross Stores'
WHEN [PriceCode] = 'TJ' THEN '(TJ) TJX'
    WHEN [PriceCode] = 'BF' THEN '(BF) Beautyfly'
    WHEN [PriceCode] = 'BL' THEN '(BL) Beautyland'
    WHEN [PriceCode] = 'BM' THEN '(BM) Beautymaster'
    WHEN [PriceCode] = 'BR' THEN '(BR) Brashae''s'
    WHEN [PriceCode] = 'CJ' THEN '(CJ) C & J Beauty'
    WHEN [PriceCode] = 'CV' THEN '(CV) CVS'
    WHEN [PriceCode] = 'DB' THEN '(DB) Beauty Distributor'
    WHEN [PriceCode] = 'DH' THEN '(DH) Hybrid distributor'
    WHEN [PriceCode] = 'DN' THEN '(DN) Natural distributor'
    WHEN [PriceCode] = 'DO' THEN '(DO) Direct'
    WHEN [PriceCode] = 'DS' THEN '(DS) Drugstore'
    WHEN [PriceCode] = 'DV' THEN '(DV) Nicholas'
    WHEN [PriceCode] = 'EM' THEN '(EM) Emerson'
    WHEN [PriceCode] = 'FC' THEN '(FC) Fulton'
    WHEN [PriceCode] = 'HB' THEN '(HB) Hunters Beauty'
    WHEN [PriceCode] = 'HE' THEN '(HE) HEB'
    WHEN [PriceCode] = 'HR' THEN '(HR) Harmon'
    WHEN [PriceCode] = 'HY' THEN '(HY) Hybrid'
    WHEN [PriceCode] = 'IB' THEN '(IB) International Beauty Trade'
    WHEN [PriceCode] = 'M1' THEN '(M1) Quidsi'
    WHEN [PriceCode] = 'MI' THEN '(MI) Meijer'
    WHEN [PriceCode] = 'NI' THEN '(NI) Nicholas'
    WHEN [PriceCode] = 'NS' THEN '(NS) New Star'
    WHEN [PriceCode] = 'NX' THEN '(NX) Nexcom'
    WHEN [PriceCode] = 'RA' THEN '(RA) Rite Aid'
    WHEN [PriceCode] = 'RT' THEN '(RT) Retail'
    WHEN [PriceCode] = 'SB' THEN '(SB) Sally beauty'
    WHEN [PriceCode] = 'SV' THEN '(SV) Supervalu'
    WHEN [PriceCode] = 'SW' THEN '(SW) Safeway'
    WHEN [PriceCode] = 'TA' THEN '(TA) Taz aroma'
    WHEN [PriceCode] = 'TB' THEN '(TB) Taeget Beauty'
    WHEN [PriceCode] = 'TC' THEN '(TC) Target.com'
    WHEN [PriceCode] = 'TG' THEN '(TG) Target'
    WHEN [PriceCode] = 'TW' THEN '(TW) TWT'
    WHEN [PriceCode] = 'UF' THEN '(UL) Ulta'
    WHEN [PriceCode] = 'UN' THEN '(UN) Union supply'
    WHEN [PriceCode] = 'UW' THEN '(UW) USA Washington'
    WHEN [PriceCode] = 'UX' THEN '(UX) Utonics'
    WHEN [PriceCode] = 'VS' THEN '(VS) Vitamin shoppe'
    WHEN [PriceCode] = 'WE' THEN '(WE) Wholesale'
    WHEN [PriceCode] = 'WG' THEN '(WG) Walgreens'
    WHEN [PriceCode] = 'WH' THEN '(WH) Wholesale'
    WHEN [PriceCode] = 'WK' THEN '(WK) Wakefern'
    WHEN [PriceCode] = 'WM' THEN '(WM) Wal-mart'
	WHEN [PriceCode] = 'RB' THEN '(RB) Revenue Build'

    ELSE [PriceCode]
  END AS PriceCodePicklist
FROM (SELECT DISTINCT
  CorpAcctCode,
  CorpAcctName,
  CASE
    WHEN CorpAcctCode = 'C&S                                                                                                 ' THEN 'EM'
    WHEN CorpAcctCode = 'BEATCH                                                                                              ' THEN 'DB'
    WHEN CorpAcctCode = 'NEXNAV                                                                                              ' THEN 'AS'
    WHEN CorpAcctCode = 'HYBRD                                                                                               ' THEN 'HY'
    WHEN CorpAcctCode = 'RETWEB                                                                                              ' THEN 'RT'
    WHEN CorpAcctCode = 'TARGT                                                                                               ' THEN 'TG'
    WHEN CorpAcctCode = 'WAKFRN                                                                                              ' THEN 'EM'
    WHEN CorpAcctCode = 'WALGS                                                                                               ' THEN 'WG'
    WHEN CorpAcctCode = 'WHOLSL                                                                                              ' THEN 'WH'
    WHEN CorpAcctCode = 'ECOMM                                                                                               ' THEN 'QU'
    WHEN CorpAcctCode = 'GROCY                                                                                               ' THEN 'EM'
    WHEN CorpAcctCode = 'HARMN                                                                                               ' THEN 'HR'
    WHEN CorpAcctCode = 'INT                                                                                                 ' THEN 'FD'
    WHEN CorpAcctCode = 'JINN                                                                                                ' THEN 'DB'
    WHEN CorpAcctCode = 'KEHENB                                                                                              ' THEN 'DN'
    WHEN CorpAcctCode = 'NATCH                                                                                               ' THEN 'DN'
    WHEN CorpAcctCode = 'RICKY                                                                                               ' THEN 'RK'
    WHEN CorpAcctCode = 'SALBTY                                                                                              ' THEN 'SB'
    WHEN CorpAcctCode = 'SAMP                                                                                                ' THEN 'SA'
    WHEN CorpAcctCode = 'SEPHORA                                                                                             ' THEN 'SP'
    WHEN CorpAcctCode = 'TRADSH                                                                                              ' THEN 'RT'
    WHEN CorpAcctCode = 'WALMT                                                                                               ' THEN 'WM'
	WHEN CorpAcctCode = 'SPECCH                                                                                              ' THEN 'QV'
	WHEN CorpAcctCode = 'ABCSTO                                                                                              ' THEN 'EM'
	WHEN PriceCode='' then 'RB'
    ELSE PriceCode
  END AS PriceCode
FROM View_ArCust_GroupingData4KPI_New a
LEFT JOIN ArCustomer b
  ON a.Customer = b.Customer) x WHERE CorpAcctCode IS NOT NULL and CorpAcctCode !=''  order by CorpAcctCode
	
