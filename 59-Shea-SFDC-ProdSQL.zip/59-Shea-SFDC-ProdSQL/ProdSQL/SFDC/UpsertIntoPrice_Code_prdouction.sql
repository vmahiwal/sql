--UpsertIntoPrice_Code_prdouction


select CASE when b.PriceCode is null then a.PriceCode else b.PriceCode end as PriceCode,b.Description from   tbl_PriceCodeName b full outer join (select distinct(PriceCode) from ArCustomer) a on a.PriceCode=b.PriceCode where (a.PriceCode<>'' or a.PriceCode is null)