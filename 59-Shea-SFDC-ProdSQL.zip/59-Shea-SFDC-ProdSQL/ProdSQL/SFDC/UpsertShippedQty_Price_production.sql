select CONCAT(CONCAT(CONCAT(RTRIM(CorpAcctCode),'-2016-'),DateName( month , DateAdd( month , TrnMonth , -1 ) )),CONCAT('-',RTRIM(StockCode))) as ExternalID,
StockCode,TrnMonth,SUM(QtyInvoiced) as QtyInvoiced,
CONCAT(CONCAT(RTRIM(CorpAcctCode),'-2016-'),DateName( month , DateAdd( month , TrnMonth , -1 ) )) as Month_Id
from (
select CorpAcctCode,case when StockUom='CS' and ConvFactAltUom>1 and RIGHT(RTRIM(art.StockCode),3) NOT in ('200','150','OMO')
then CONCAT(LEFT(art.StockCode,len(art.StockCode)-3),'-01') 
when StockUom='CS' and ConvFactAltUom>1 and RIGHT(RTRIM(art.StockCode),3) in ('200','150')
then CONCAT(LEFT(art.StockCode,len(art.StockCode)-4),'    ')
when StockUom='CS' and ConvFactAltUom>1 and RIGHT(RTRIM(art.StockCode),3) in ('OMO')
then CONCAT(LEFT(art.StockCode,len(art.StockCode)-8),'01-PROMO')
else art.StockCode end as StockCode,TrnMonth
,SUM(case when StockUom='CS' then QtyInvoiced*ConvFactAltUom else QtyInvoiced end) as QtyInvoiced
 from ArTrnDetail art 
left join InvMaster iv on iv.StockCode=art.StockCode left join View_ArCust_GroupingData4KPI_New vw on art.Customer=vw.Customer
WHERE (LineType = '1') AND TrnYear = 2016 and TrnMonth >8 group by CorpAcctCode,art.StockCode,TrnMonth,iv.ConvFactAltUom,iv.StockUom)
a where StockCode in (select StockCode from InvMaster) and QtyInvoiced>0
group by a.CorpAcctCode,a.StockCode,a.TrnMonth order by ExternalID