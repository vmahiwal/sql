

SELECT concat(concat(RTRIM(iw.StockCode),' - '),iw.Warehouse) as External_Id,  
RTRIM(iw.StockCode) as StockCode,iw.Warehouse,QtyOnHand from InvWarehouse iw inner join InvMaster on iw.StockCode=InvMaster.StockCode inner join InvWhControl iwc on iwc.Warehouse=iw.Warehouse