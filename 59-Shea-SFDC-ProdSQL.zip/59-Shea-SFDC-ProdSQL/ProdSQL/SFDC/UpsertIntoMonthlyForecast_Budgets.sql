


select CorpAcctCode,year(getdate()) as Year,CASE n
when 1 then '2017-01-01'
when 2 then '2017-02-01'
when 3 then '2017-03-01'
when 4 then '2017-04-01'
when 5 then '2017-05-01'
when 6 then '2017-06-01'
when 7 then '2017-07-01'
 when 8 then '2017-08-01'
 when 9 then '2017-09-01'
 when 10 then '2017-10-01'
 when 11 then '2017-11-01'
 when 12 then '2017-12-01'
END AS Month_start, case n when 1 then CONCAT(RTRIM(CorpAcctCode),'-2017-January')
when 2 then CONCAT(RTRIM(CorpAcctCode),'-2017-February')
when 3 then CONCAT(RTRIM(CorpAcctCode),'-2017-March')
when 4 then CONCAT(RTRIM(CorpAcctCode),'-2017-April')
when 5 then CONCAT(RTRIM(CorpAcctCode),'-2017-May')
when 6 then CONCAT(RTRIM(CorpAcctCode),'-2017-June')
 when 7 then CONCAT(RTRIM(CorpAcctCode),'-2017-July')
 when 8 then CONCAT(RTRIM(CorpAcctCode),'-2017-August')
 when 9 then CONCAT(RTRIM(CorpAcctCode),'-2017-September')
 when 10 then CONCAT(RTRIM(CorpAcctCode),'-2017-October')
 when 11 then CONCAT(RTRIM(CorpAcctCode),'-2017-November')
 when 12 then CONCAT(RTRIM(CorpAcctCode),'-2017-December') end as External_Id
,SUM(case n
when 1 then BudMnt1 
when 2 then BudMnt2  
when 3 then BudMnt3 
when 4 then BudMnt4 
when 5 then BudMnt5 
when 6 then BudMnt6  
when 7 then BudMnt7
when 8 then BudMnt8 
when 9 then BudMnt9  
when 10 then BudMnt10
when 11 then BudMnt11
when 12 then BudMnt12 
END) AS Budget from
(SELECT dbo.View_ArCust_GroupingData4KPI_New.CorpAcctCode, dbo.View_ArCust_GroupingData4KPI_New.CorpAcctName, BudMnt1,BudMnt2,BudMnt3,BudMnt4,BudMnt5,BudMnt6,BudMnt7,BudMnt8,BudMnt9,BudMnt10,BudMnt11,BudMnt12      
FROM         dbo.View_ArCust_GroupingData4KPI_New 
                          LEFT OUTER JOIN
                      dbo.View_ArCust_Budgets_AdmFormData ON dbo.View_ArCust_GroupingData4KPI_New.Customer = dbo.View_ArCust_Budgets_AdmFormData.Customer
Where (BudMnt1<>0 or BudMnt2<>0 or BudMnt3<>0 or BudMnt4<>0 or BudMnt5<>0 or BudMnt6<>0 or BudMnt7<>0 or BudMnt8<>0 or BudMnt12<>0) 
UNION ALL
SELECT    corpcode.CorpAcctCode, corpname.CorpAcctName, BudMnt1, BudMnt2, BudMnt3, BudMnt4, BudMnt5, BudMnt6, BudMnt7, BudMnt8, BudMnt9, BudMnt10, BudMnt11, 
                      BudMnt12
FROM         View_ArCustClass_Budget_AdmFormData LEFT JOIN (SELECT KeyField as Class, AlphaValue as CorpAcctCode
															FROM AdmFormData
															WHERE FormType = 'CCLS' and FieldName = 'COR002') corpcode ON View_ArCustClass_Budget_AdmFormData.Class = corpcode.Class
												 LEFT JOIN (SELECT Item as CorpAcctCode, Description as CorpAcctName
															FROM AdmFormValidation WHERE FormType = 'CUS' and FieldName = 'COR002') corpname ON corpcode.CorpAcctCode = corpname.CorpAcctCode

WHERE     View_ArCustClass_Budget_AdmFormData.Class <> 'GL' and (BudMnt1<>0 or BudMnt2<>0 or BudMnt3<>0 or BudMnt4<>0 or BudMnt5<>0 or BudMnt6<>0 or BudMnt7<>0 or BudMnt8<>0 or BudMnt12<>0) 
) a

 
 CROSS JOIN 
(select 1 union 
select 2 union
select 3 union
select 4 union
select 5 union
select 6 union
select 7 union
select 8 union
select 9 union
select 10 union
select 11 union
select 12

 ) AS Nums(n)
group by CorpAcctCode,Nums.n
 