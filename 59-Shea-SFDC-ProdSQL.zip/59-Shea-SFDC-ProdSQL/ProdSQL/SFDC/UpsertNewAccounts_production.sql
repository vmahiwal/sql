--Job -UpsertNewAccounts_production



SELECT CONVERT(varchar,CONVERT(INT,ar.Customer)) As Customer,
[Name], 'Customer' As Type
,case when ar.MasterAccount<>'' then CONVERT(varchar,CONVERT(INT,ar.MasterAccount)) else NULL end as MasterAccount
,case when ar.CustomerType = 'A' then 'Associated'when ar.CustomerType = 'M' then 'Master'when ar.CustomerType = 'S' then 'Subaccount'else ar.CustomerType end as CustomerType
,[StoreNumber]
,case when [CreditStatus] ='0' then '0 - Indicates only current invoices'when [CreditStatus] ='1' then '1 - Indicates at least one invoice which is 30 days or over'when [CreditStatus] ='2' then '2 - Indicates at least one invoice which is 60 days or over'when [CreditStatus] ='3' then '3 - Indicates at least one invoice which is 90 days or over'when [CreditStatus] ='4' then '4 - Indicates at least one invoice which is 120 days or over'when [CreditStatus] ='5' then '5 - Indicates at least one invoice which is 180 days or over'when [CreditStatus] ='6' then '6 - Indicates a manual hold on the account which suspends all credit for the customer'else [CreditStatus] end as CreditStatus
,[CreditLimit]
,case when [PriceCode]='' then NULL else PriceCode end as PriceCode,case when [PriceCode]='AH' then '(AH) Ahold'when [PriceCode]='AS' then '(AS) Aafes'when [PriceCode]='BF' then '(BF) Beautyfly'when [PriceCode]='BL' then '(BL) Beautyland'when [PriceCode]='BM' then '(BM) Beautymaster'when [PriceCode]='BR' then '(BR) Brashae''s'when [PriceCode]='CJ' then '(CJ) C & J Beauty'when [PriceCode]='CV' then '(CV) CVS'when [PriceCode]='DB' then '(DB) Beauty Distributor'when [PriceCode]='DH' then '(DH) Hybrid distributor'when [PriceCode]='DN' then '(DN) Natural distributor'when [PriceCode]='DO' then '(DO) Direct'when [PriceCode]='DS' then '(DS) Drugstore'when [PriceCode]='DV' then '(DV) Nicholas'when [PriceCode]='EM' then '(EM) Emerson'when [PriceCode]='FC' then '(FC) Fulton'when [PriceCode]='HB' then '(HB) Hunters Beauty'when [PriceCode]='HE' then '(HE) HEB'when [PriceCode]='HR' then '(HR) Harmon'when [PriceCode]='HY' then '(HY) Hybrid'when [PriceCode]='IB' then '(IB) International Beauty Trade'when [PriceCode]='M1' then '(M1) Quidsi'when [PriceCode]='MI' then '(MI) Meijer'when [PriceCode]='NI' then '(NI) Nicholas'when [PriceCode]='NS' then '(NS) New Star'when [PriceCode]='NX' then '(NX) Nexcom'when [PriceCode]='RA' then '(RA) Rite Aid'when [PriceCode]='RT' then '(RT) Retail'when [PriceCode]='SB' then '(SB) Sally beauty'when [PriceCode]='SV' then '(SV) Supervalu'when [PriceCode]='SW' then '(SW) Safeway'when [PriceCode]='TA' then '(TA) Taz aroma'when [PriceCode]='TB' then '(TB) Target Beauty'when [PriceCode]='TC' then '(TC) Target.com'when [PriceCode]='TG' then '(TG) Target'when [PriceCode]='TW' then '(TW) TWT'when [PriceCode]='UF' then '(UL) Ulta'when [PriceCode]='UN' then '(UN) Union supply'when [PriceCode]='UW' then '(UW) USA Washington'when [PriceCode]='UX' then '(UX) Utonics'when [PriceCode]='VS' then '(VS) Vitamin shoppe'when [PriceCode]='WE' then '(WE) Wholesale'when [PriceCode]='WG' then '(WG) Walgreens'when [PriceCode]='WH' then '(WH) Wholesale'when [PriceCode]='WK' then '(WK) Wakefern'when [PriceCode]='WM' then '(WM) Wal-mart'else [PriceCode]end as PriceCodePicklist
,case when ar.CustomerClass = 'MR' then '(MR) Mass Retail'when ar.CustomerClass = 'DH' then '(DH) Distributer Hybrid'when ar.CustomerClass = 'DB' then '(DB) Beauty distributor'when ar.CustomerClass = 'EC' then '(EC) Ecommerce'when ar.CustomerClass = 'OT' then '(OT) Other'when ar.CustomerClass = 'SC' then '(SC) Specialty chain'when ar.CustomerClass = 'SA' then '(SA) Samples'when ar.CustomerClass = 'DN' then '(DN) Distributer Natural'when ar.CustomerClass = 'HY' then '(HY) Hybrid'when ar.CustomerClass = 'TR' then '(TR) Tradeshows'when ar.CustomerClass = 'AG' then '(AG) Agent'when ar.CustomerClass = 'GR' then '(GR) Grocery'when ar.CustomerClass = 'PH' then '(PH) Pharmacy'when ar.CustomerClass = 'WH' then '(WH) Wholesale'else ar.CustomerClass end as CustomerClass
,case when [Branch]='NY' then 'New York'else [Branch]end as Branch
,case when [TermsCode]='00' then '(00) PRE-PAID' when [TermsCode]='05' then '(05) 2% NET 60 DAYS'when [TermsCode]='06' then '(06) NET 21 DAYS'
when [TermsCode]='20' then '(20) 2 % 20 NET 31'when [TermsCode]='22' then '(22) 2% 20 NET 30'
when[TermsCode]='01' then '(01) C.O.D.'when[TermsCode]='02' then '(02) EOM'when[TermsCode]='10' then '(10) NET 10 DAYS'when[TermsCode]='15' then '(15) NET 15 DAYS'when[TermsCode]='21' then '(21) 2 % 30 NET 31'when[TermsCode]='23' then '(23) 2% NET 30 DAYS'when[TermsCode]='3' then '(3) CHECK'when[TermsCode]='30' then '(30) NET 30 DAYS'when[TermsCode]='31' then '(31) 1%10 NET 31'when[TermsCode]='32' then '(32) 2% 10 DAYS/30'when[TermsCode]='4' then '(4) 60 DAYS/EOM'when[TermsCode]='42' then '(42) 2% NET 40 DAYS'when[TermsCode]='45' then '(45) NET 45 DAYS'when[TermsCode]='46' then '(46) 1% 45 NET 46'when[TermsCode]='60' then '(60) NET 60 DAYS'when[TermsCode]='75' then '(75) NET 75 DAYS'when[TermsCode]='90' then '(90) NET 90 DAYS'when[TermsCode]='CC' then '(CC) Credit Card'when[TermsCode]='PP' then '(PP) PAYPAL'else [TermsCode]end as TermsCode
,case when [TaxStatus]='E' then 'Exempt'when [TaxStatus]='N' then 'Non-Exempt'else [TaxStatus]end as TaxStatus
,[TaxExemptNumber],[DateLastSale],[DateLastPay],[OutstOrdVal],[NumOutstOrd],[Currency]
,case when [BackOrdReqd]='Y' then 'true' else 'false' end as BackOrdReqd,[ShippingInstrs],SpecialInstrs
,[DateCustAdded]
,case when [PaymentStatus] = '' then 'tbd'else [PaymentStatus]end as PaymentStatus
,HighestBalance
,case when [CustomerOnHold] = 'Y' then 'Yes'when [CustomerOnHold] = 'N' then 'No'else [CustomerOnHold]end as CustomerOnHold
,case when [ApplyOrdDisc]='Y' then 'true' else 'false' end as ApplyOrdDisc,case when [ApplyLineDisc]='Y' then 'true' else 'false' end as ApplyLineDisc,[HighInvDays],CONVERT(INT,HighInv) As HighInv,[DocFax]
,[SoldToAddr1],[SoldToAddr2]
,[SoldToAddr3],[SoldToAddr4],[SoldToAddr5] ,[SoldPostalCode] ,[ShipToAddr1],[ShipToAddr2],[ShipToAddr3]
,[ShipToAddr4] ,[ShipToAddr5] ,[ShipPostalCode] ,case when [PoNumberMandatory] ='Y' then 'true' else 'false' end as PoNumberMandatory , CONCAT(Branch,CONCAT('-',Salesperson)) as Salesperson,
case when [CreditCheckFlag] = 'B' then 'B - Credit Limit and Terms will be checked' when [CreditCheckFlag] = 'T'
then 'T-Terms will be checked' when [CreditCheckFlag] = 'N' then 'N - Neither will be checked' else [CreditCheckFlag] end as
CreditCheckFlag ,[CompanyTaxNumber],CorpAcctCode, case when [SalesWarehouse]<>'' then SalesWarehouse else null end as SalesWarehouse

, case when [StatementReqd]='Y' then 'true' else 'false' end as StatementReqd FROM ArCustomer ar left join View_ArCust_GroupingData4KPI_New arc on ar.Customer=arc.Customer
where Salesperson<>'RH' and Salesperson<>'10' and (ar.CustomerClass<>'RT' or ar.CustomerClass is null)
and year(DateCustAdded)=year(getdate()) 
and month(DateCustAdded)=month(getdate())
order by Customer
"

"SELECT CONVERT(varchar,CONVERT(INT,ar.Customer)) As Customer,
[Name], 'Customer' As Type
,case when ar.MasterAccount<>'' then CONVERT(varchar,CONVERT(INT,ar.MasterAccount)) else NULL end as MasterAccount
,case when ar.CustomerType = 'A' then 'Associated'when ar.CustomerType = 'M' then 'Master'when ar.CustomerType = 'S' then 'Subaccount'else ar.CustomerType end as CustomerType
,[StoreNumber]
,case when [CreditStatus] ='0' then '0 - Indicates only current invoices'when [CreditStatus] ='1' then '1 - Indicates at least one invoice which is 30 days or over'when [CreditStatus] ='2' then '2 - Indicates at least one invoice which is 60 days or over'when [CreditStatus] ='3' then '3 - Indicates at least one invoice which is 90 days or over'when [CreditStatus] ='4' then '4 - Indicates at least one invoice which is 120 days or over'when [CreditStatus] ='5' then '5 - Indicates at least one invoice which is 180 days or over'when [CreditStatus] ='6' then '6 - Indicates a manual hold on the account which suspends all credit for the customer'else [CreditStatus] end as CreditStatus
,[CreditLimit]
,case when [PriceCode]='' then NULL else PriceCode end as PriceCode,case when [PriceCode]='AH' then '(AH) Ahold'when [PriceCode]='AS' then '(AS) Aafes'when [PriceCode]='BF' then '(BF) Beautyfly'when [PriceCode]='BL' then '(BL) Beautyland'when [PriceCode]='BM' then '(BM) Beautymaster'when [PriceCode]='BR' then '(BR) Brashae''s'when [PriceCode]='CJ' then '(CJ) C & J Beauty'when [PriceCode]='CV' then '(CV) CVS'when [PriceCode]='DB' then '(DB) Beauty Distributor'when [PriceCode]='DH' then '(DH) Hybrid distributor'when [PriceCode]='DN' then '(DN) Natural distributor'when [PriceCode]='DO' then '(DO) Direct'when [PriceCode]='DS' then '(DS) Drugstore'when [PriceCode]='DV' then '(DV) Nicholas'when [PriceCode]='EM' then '(EM) Emerson'when [PriceCode]='FC' then '(FC) Fulton'when [PriceCode]='HB' then '(HB) Hunters Beauty'when [PriceCode]='HE' then '(HE) HEB'when [PriceCode]='HR' then '(HR) Harmon'when [PriceCode]='HY' then '(HY) Hybrid'when [PriceCode]='IB' then '(IB) International Beauty Trade'when [PriceCode]='M1' then '(M1) Quidsi'when [PriceCode]='MI' then '(MI) Meijer'when [PriceCode]='NI' then '(NI) Nicholas'when [PriceCode]='NS' then '(NS) New Star'when [PriceCode]='NX' then '(NX) Nexcom'when [PriceCode]='RA' then '(RA) Rite Aid'when [PriceCode]='RT' then '(RT) Retail'when [PriceCode]='SB' then '(SB) Sally beauty'when [PriceCode]='SV' then '(SV) Supervalu'when [PriceCode]='SW' then '(SW) Safeway'when [PriceCode]='TA' then '(TA) Taz aroma'when [PriceCode]='TB' then '(TB) Target Beauty'when [PriceCode]='TC' then '(TC) Target.com'when [PriceCode]='TG' then '(TG) Target'when [PriceCode]='TW' then '(TW) TWT'when [PriceCode]='UF' then '(UL) Ulta'when [PriceCode]='UN' then '(UN) Union supply'when [PriceCode]='UW' then '(UW) USA Washington'when [PriceCode]='UX' then '(UX) Utonics'when [PriceCode]='VS' then '(VS) Vitamin shoppe'when [PriceCode]='WE' then '(WE) Wholesale'when [PriceCode]='WG' then '(WG) Walgreens'when [PriceCode]='WH' then '(WH) Wholesale'when [PriceCode]='WK' then '(WK) Wakefern'when [PriceCode]='WM' then '(WM) Wal-mart'else [PriceCode]end as PriceCodePicklist
,case when ar.CustomerClass = 'MR' then '(MR) Mass Retail'when ar.CustomerClass = 'DH' then '(DH) Distributer Hybrid'when ar.CustomerClass = 'DB' then '(DB) Beauty distributor'when ar.CustomerClass = 'EC' then '(EC) Ecommerce'when ar.CustomerClass = 'OT' then '(OT) Other'when ar.CustomerClass = 'SC' then '(SC) Specialty chain'when ar.CustomerClass = 'SA' then '(SA) Samples'when ar.CustomerClass = 'DN' then '(DN) Distributer Natural'when ar.CustomerClass = 'HY' then '(HY) Hybrid'when ar.CustomerClass = 'TR' then '(TR) Tradeshows'when ar.CustomerClass = 'AG' then '(AG) Agent'when ar.CustomerClass = 'GR' then '(GR) Grocery'when ar.CustomerClass = 'PH' then '(PH) Pharmacy'when ar.CustomerClass = 'WH' then '(WH) Wholesale'else ar.CustomerClass end as CustomerClass
,case when [Branch]='NY' then 'New York'else [Branch]end as Branch
,case when [TermsCode]='00' then '(00) PRE-PAID' when [TermsCode]='05' then '(05) 2% NET 60 DAYS'when [TermsCode]='06' then '(06) NET 21 DAYS'
when [TermsCode]='20' then '(20) 2 % 20 NET 31'when [TermsCode]='22' then '(22) 2% 20 NET 30'
when[TermsCode]='01' then '(01) C.O.D.'when[TermsCode]='02' then '(02) EOM'when[TermsCode]='10' then '(10) NET 10 DAYS'when[TermsCode]='15' then '(15) NET 15 DAYS'when[TermsCode]='21' then '(21) 2 % 30 NET 31'when[TermsCode]='23' then '(23) 2% NET 30 DAYS'when[TermsCode]='3' then '(3) CHECK'when[TermsCode]='30' then '(30) NET 30 DAYS'when[TermsCode]='31' then '(31) 1%10 NET 31'when[TermsCode]='32' then '(32) 2% 10 DAYS/30'when[TermsCode]='4' then '(4) 60 DAYS/EOM'when[TermsCode]='42' then '(42) 2% NET 40 DAYS'when[TermsCode]='45' then '(45) NET 45 DAYS'when[TermsCode]='46' then '(46) 1% 45 NET 46'when[TermsCode]='60' then '(60) NET 60 DAYS'when[TermsCode]='75' then '(75) NET 75 DAYS'when[TermsCode]='90' then '(90) NET 90 DAYS'when[TermsCode]='CC' then '(CC) Credit Card'when[TermsCode]='PP' then '(PP) PAYPAL'else [TermsCode]end as TermsCode
,case when [TaxStatus]='E' then 'Exempt'when [TaxStatus]='N' then 'Non-Exempt'else [TaxStatus]end as TaxStatus
,[TaxExemptNumber],[DateLastSale],[DateLastPay],[OutstOrdVal],[NumOutstOrd],[Currency]
,case when [BackOrdReqd]='Y' then 'true' else 'false' end as BackOrdReqd,[ShippingInstrs],SpecialInstrs
,[DateCustAdded]
,case when [PaymentStatus] = '' then 'tbd'else [PaymentStatus]end as PaymentStatus
,HighestBalance
,case when [CustomerOnHold] = 'Y' then 'Yes'when [CustomerOnHold] = 'N' then 'No'else [CustomerOnHold]end as CustomerOnHold
,case when [ApplyOrdDisc]='Y' then 'true' else 'false' end as ApplyOrdDisc,case when [ApplyLineDisc]='Y' then 'true' else 'false' end as ApplyLineDisc,[HighInvDays],CONVERT(INT,HighInv) As HighInv,[DocFax]
,[SoldToAddr1],[SoldToAddr2]
,[SoldToAddr3],[SoldToAddr4],[SoldToAddr5] ,[SoldPostalCode] ,[ShipToAddr1],[ShipToAddr2],[ShipToAddr3]
,[ShipToAddr4] ,[ShipToAddr5] ,[ShipPostalCode] ,case when [PoNumberMandatory] ='Y' then 'true' else 'false' end as PoNumberMandatory , CONCAT(Branch,CONCAT('-',Salesperson)) as Salesperson,
case when [CreditCheckFlag] = 'B' then 'B - Credit Limit and Terms will be checked' when [CreditCheckFlag] = 'T'
then 'T-Terms will be checked' when [CreditCheckFlag] = 'N' then 'N - Neither will be checked' else [CreditCheckFlag] end as
CreditCheckFlag ,[CompanyTaxNumber],CorpAcctCode, case when [SalesWarehouse]<>'' then SalesWarehouse else null end as SalesWarehouse

, case when [StatementReqd]='Y' then 'true' else 'false' end as StatementReqd FROM ArCustomer ar left join View_ArCust_GroupingData4KPI_New arc on ar.Customer=arc.Customer
where Salesperson<>'RH' and Salesperson<>'10' and (ar.CustomerClass<>'RT' or ar.CustomerClass is null)
and year(DateCustAdded)=year(getdate()) 
and month(DateCustAdded)=month(getdate())
and day(DateCustAdded)=day(getdate()
order by Customer
