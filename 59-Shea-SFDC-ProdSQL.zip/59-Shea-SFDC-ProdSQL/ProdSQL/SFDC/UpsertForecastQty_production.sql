--UpsertForecastQty_production


SELECT CONCAT(CONCAT(CONCAT(RTRIM(CorpAcctCode),'-2017-'),DateName( month , DateAdd( month , TrnMonth , -1 ) )),CONCAT('-',RTRIM(StockCode))) as ExternalID,
StockCode,TrnMonth,SUM(ForecastQty) as ForecastQty,Reference,ForecastWh,
CONCAT(CONCAT(RTRIM(CorpAcctCode),'-2017-'),DateName( month , DateAdd( month , TrnMonth , -1 ) )) as Month_Id from
(SELECT 
  CASE WHEN c.CorpAcctCode is null then (case when LEFT(a.Reference,2)='DB' then 'BEATCH' 
  when LEFT(a.Reference,2)='HY' then 'HYBRD'
  when LEFT(a.Reference,2)='RT' then 'RETWEB'
  when LEFT(a.Reference,2)='DN' then 'NATCH'
  when LEFT(a.Reference,2)='GR' then 'GROCY' 
  when LEFT(a.Reference,2)='WH' then 'WHOLSL' 
  when LEFT(a.Reference,2)='SA' then 'SAMP'
  when LEFT(a.Reference,2)='EC' then 'ECOMM'
  when LEFT(a.Reference,2)='RB' then 'DUMMY'
  when LEFT(a.Reference,2)='SC' then 'SPECCH'
  else c.CorpAcctCode end) else c.CorpAcctCode end As CorpAcctCode, a.StockCode, a.Reference,a.ForecastWh,
  month(a.ForecastDate) As TrnMonth,
  SUM(a.ForecastQty) AS ForecastQty
   from
(SELECT
  case when StockUom='CS' and ConvFactAltUom>1 and RIGHT(RTRIM(mrp.StockCode),3) NOT in ('200','150','OMO')
then CONCAT(LEFT(mrp.StockCode,len(mrp.StockCode)-3),'-01') 
when StockUom='CS' and ConvFactAltUom>1 and RIGHT(RTRIM(mrp.StockCode),3) in ('200','150')
then CONCAT(LEFT(mrp.StockCode,len(mrp.StockCode)-4),'    ')
when StockUom='CS' and ConvFactAltUom>1 and RIGHT(RTRIM(mrp.StockCode),3) in ('OMO')
then CONCAT(LEFT(mrp.StockCode,len(mrp.StockCode)-8),'01-PROMO')
else mrp.StockCode end as StockCode,
  mrp.ForecastDate,
  (case when StockUom='CS' then (ForecastQtyOutst+QtyInvoiced)*ConvFactAltUom else (ForecastQtyOutst+QtyInvoiced) end) as ForecastQty,
  mrp.Description,
  mrp.Reference,
  mrp.Customer,
  mrp.ForecastWh,
  CASE
    WHEN (PriceCode IS NULL OR
      PriceCode = '') THEN LEFT(Reference, 2)
    ELSE PriceCode
  END AS PriceCode
FROM [SysproCompanyB].[dbo].[MrpForecast] mrp
LEFT JOIN [SysproCompanyB].[dbo].[ArCustomer] arc
  ON mrp.Customer = arc.Customer
  LEFT JOIN InvMaster iv on iv.StockCode=mrp.StockCode
WHERE mrp.ForecastType = 'S' and year(ForecastDate)=2017 and month(ForecastDate)>=1 ) a 
LEFT OUTER JOIN dbo.InvPrice
  ON a.StockCode = dbo.InvPrice.StockCode
  AND a.PriceCode = dbo.InvPrice.PriceCode
LEFT JOIN 
			View_ArCust_GroupingData4KPI_New c on c.Customer=a.Customer
		
	GROUP By 
  c.CorpAcctCode,
  a.Reference,
  a.StockCode,
  month(a.ForecastDate),a.ForecastWh) final where CorpAcctCode is not null and StockCode in (select StockCode from InvMaster) 
group by CorpAcctCode,Reference,ForecastWh,
StockCode,TrnMonth 