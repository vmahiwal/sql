--JOb   vwKPI2_FGBulkProduction_stg0_pxf



SELECT  ROW_NUMBER() OVER (ORDER BY Sequence) AS ID, GETDATE() as time,Sequence, 
 Description, 
TodayProduction, WTDProduction ,[MTDProduction],[QTDProduction] ,[YTDProduction] 
FROM (SELECT '01' as Sequence
  , 'Units Produced' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jr.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jr.QtySupplied ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN DATEPART(week,jr.TrnDate) = DATEPART(week,GETDATE()) THEN jr.QtySupplied ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN DATEPART(month,jr.TrnDate) = DATEPART(month,GETDATE()) THEN jr.QtySupplied ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN DATEPART(quarter,jr.TrnDate) = DATEPART(quarter,GETDATE()) THEN jr.QtySupplied ELSE 0 END) as QTDProduction
  , SUM(jr.QtySupplied) as YTDProduction
FROM WipPartBook jr INNER JOIN WipMaster jm ON jr.Job = jm.Job
     INNER JOIN InvMaster im on jm.StockCode = im.StockCode
WHERE jm.Warehouse IN ('F1','F2','F3','QC') 
  AND DATEPART(year,jr.TrnDate) = DATEPART(year,GETDATE()) 
  AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
  AND LEFT(im.ProductClass, 2) <> 'SO'
  AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))

UNION ALL

SELECT '02' as Sequence
  , 'Matl Issue Value FG' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jt.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jt.TrnValue ELSE 0 END) as TodayMatlIssue
  , SUM(CASE WHEN DATEPART(week,jt.TrnDate) = DATEPART(week,GETDATE()) THEN jt.TrnValue ELSE 0 END) as WTDMatlIssue
  , SUM(CASE WHEN DATEPART(month,jt.TrnDate) = DATEPART(month,GETDATE()) THEN jt.TrnValue ELSE 0 END) as MTDMatlIssue
  , SUM(CASE WHEN DATEPART(quarter,jt.TrnDate) = DATEPART(quarter,GETDATE()) THEN jt.TrnValue ELSE 0 END) as QTDMatlIssue
  , SUM(jt.TrnValue) as YTDMatlIssue
FROM WipJobPost jt INNER JOIN WipMaster jm ON jt.Job = jm.Job
     INNER JOIN InvMaster im on jm.StockCode = im.StockCode

WHERE       jt.TrnType = 'R' 
   AND DATEPART(year,jt.TrnDate) = DATEPART(year,GETDATE()) 
   AND jm.Warehouse IN ('F1','F2','F3','QC')
   AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
   AND LEFT(im.ProductClass, 2) <> 'SO'
   AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
UNION ALL

SELECT '03' as Sequence
  , 'Labor Issue Value FG' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jt.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jt.TrnValue ELSE 0 END) as TodayLabIssue
  , SUM(CASE WHEN DATEPART(week,jt.TrnDate) = DATEPART(week,GETDATE()) THEN jt.TrnValue ELSE 0 END) as WTDLabIssue
  , SUM(CASE WHEN DATEPART(month,jt.TrnDate) = DATEPART(month,GETDATE()) THEN jt.TrnValue ELSE 0 END) as MTDLabIssue
  , SUM(CASE WHEN DATEPART(quarter,jt.TrnDate) = DATEPART(quarter,GETDATE()) THEN jt.TrnValue ELSE 0 END) as QTDLabIssue
  , SUM(jt.TrnValue) as YTDLabIssue
FROM WipJobPost jt INNER JOIN WipMaster jm ON jt.Job = jm.Job
     INNER JOIN InvMaster im on jm.StockCode = im.StockCode
WHERE       jt.TrnType = 'L' 
   AND DATEPART(year,jt.TrnDate) = DATEPART(year,GETDATE()) 
   AND jm.Warehouse IN ('F1','F2','F3','QC')
   AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
   AND LEFT(im.ProductClass, 2) <> 'SO'
   AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
UNION ALL

SELECT '04' as Sequence
  , 'Matl Value Produced FG' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jr.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN DATEPART(week,jr.TrnDate) = DATEPART(week,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN DATEPART(month,jr.TrnDate) = DATEPART(month,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN DATEPART(quarter,jr.TrnDate) = DATEPART(quarter,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as QTDProduction
  , SUM(jr.MaterialValue + jr.LabourValue) as YTDProduction
FROM WipPartBook jr INNER JOIN WipMaster jm ON jr.Job = jm.Job
INNER JOIN InvMaster im on jm.StockCode = im.StockCode

WHERE jm.Warehouse IN ('F1','F2','F3','QC')
  AND DATEPART(year,jr.TrnDate) = DATEPART(year,GETDATE()) 
  AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
  AND LEFT(im.ProductClass, 2) <> 'SO'
  AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
  AND jr.Reference <> 'Billing')t1






union �

select ROW_NUMBER() OVER (ORDER BY Sequence) AS ID, GETDATE() as time,
* FROM (SELECT '01' as Sequence
  , 'Kilos Produced' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jr.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jr.QtySupplied ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN DATEPART(week,jr.TrnDate) = DATEPART(week,GETDATE()) THEN jr.QtySupplied ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN DATEPART(month,jr.TrnDate) = DATEPART(month,GETDATE()) THEN jr.QtySupplied ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN DATEPART(quarter,jr.TrnDate) = DATEPART(quarter,GETDATE()) THEN jr.QtySupplied ELSE 0 END) as QTDProduction
  , SUM(jr.QtySupplied) as YTDProduction
FROM WipPartBook jr INNER JOIN WipMaster jm ON jr.Job = jm.Job
WHERE jm.Warehouse = 'W1' and DATEPART(year,jr.TrnDate) = DATEPART(year,GETDATE())

UNION ALL

SELECT '02' as Sequence
  , 'Matl Issue Value' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jt.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jt.TrnValue ELSE 0 END) as TodayMatlIssue
  , SUM(CASE WHEN DATEPART(week,jt.TrnDate) = DATEPART(week,GETDATE()) THEN jt.TrnValue ELSE 0 END) as WTDMatlIssue
  , SUM(CASE WHEN DATEPART(month,jt.TrnDate) = DATEPART(month,GETDATE()) THEN jt.TrnValue ELSE 0 END) as MTDMatlIssue
  , SUM(CASE WHEN DATEPART(quarter,jt.TrnDate) = DATEPART(quarter,GETDATE()) THEN jt.TrnValue ELSE 0 END) as QTDMatlIssue
  , SUM(jt.TrnValue) as YTDMatlIssue
FROM WipJobPost jt INNER JOIN WipMaster jm ON jt.Job = jm.Job
WHERE       jt.TrnType = 'R' AND DATEPART(year,jt.TrnDate) = DATEPART(year,GETDATE()) AND jm.Warehouse = 'W1'

UNION ALL

SELECT '03' as Sequence
  , 'Labor Issue Value' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jt.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jt.TrnValue ELSE 0 END) as TodayLabIssue
  , SUM(CASE WHEN DATEPART(week,jt.TrnDate) = DATEPART(week,GETDATE()) THEN jt.TrnValue ELSE 0 END) as WTDLabIssue
  , SUM(CASE WHEN DATEPART(month,jt.TrnDate) = DATEPART(month,GETDATE()) THEN jt.TrnValue ELSE 0 END) as MTDLabIssue
  , SUM(CASE WHEN DATEPART(quarter,jt.TrnDate) = DATEPART(quarter,GETDATE()) THEN jt.TrnValue ELSE 0 END) as QTDLabIssue
  , SUM(jt.TrnValue) as YTDLabIssue
FROM WipJobPost jt INNER JOIN WipMaster jm ON jt.Job = jm.Job
WHERE       jt.TrnType = 'L' AND DATEPART(year,jt.TrnDate) = DATEPART(year,GETDATE()) AND jm.Warehouse = 'W1'

UNION ALL

SELECT '04' as Sequence
  , 'Matl Value Produced' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jr.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN DATEPART(week,jr.TrnDate) = DATEPART(week,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN DATEPART(month,jr.TrnDate) = DATEPART(month,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN DATEPART(quarter,jr.TrnDate) = DATEPART(quarter,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as QTDProduction
  , SUM(jr.MaterialValue + jr.LabourValue) as YTDProduction
FROM WipPartBook jr INNER JOIN WipMaster jm ON jr.Job = jm.Job
WHERE jm.Warehouse = 'W1' and DATEPART(year,jr.TrnDate) = DATEPART(year,GETDATE()) and jr.Reference <> 'Billing')t2



union 
SELECT ROW_NUMBER() OVER (ORDER BY Sequence) AS ID, GETDATE() as time,'05' As Sequence, 
'Bulk Production Variance' as Description, (t02.TodayProduction - t01.TodayProduction) AS TodayProduction, 
(t02.WTDProduction - t01.WTDProduction) AS WTDProduction,(t02.MTDProduction - t01.MTDProduction) AS MTDProduction, 
(t02.QTDProduction - t01.QTDProduction) AS QTDProduction,(t02.YTDProduction - t01.YTDProduction) AS YTDProduction 
FROM (


select sum(t011.TodayProduction) as TodayProduction, sum(t011.WTDProduction) as WTDProduction,sum(t011.MTDProduction) as MTDProduction, 
sum(t011.QTDProduction) as QTDProduction,sum(t011.YTDProduction) as YTDProduction 
from (SELECT '02' as Sequence
  , 'Matl Issue Value' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jt.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jt.TrnValue ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN DATEPART(week,jt.TrnDate) = DATEPART(week,GETDATE()) THEN jt.TrnValue ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN DATEPART(month,jt.TrnDate) = DATEPART(month,GETDATE()) THEN jt.TrnValue ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN DATEPART(quarter,jt.TrnDate) = DATEPART(quarter,GETDATE()) THEN jt.TrnValue ELSE 0 END) as QTDProduction
  , SUM(jt.TrnValue) as YTDProduction
FROM WipJobPost jt INNER JOIN WipMaster jm ON jt.Job = jm.Job
WHERE       jt.TrnType = 'R' AND DATEPART(year,jt.TrnDate) = DATEPART(year,GETDATE()) AND jm.Warehouse = 'W1'

UNION ALL

SELECT '03' as Sequence
  , 'Labor Issue Value' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jt.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jt.TrnValue ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN DATEPART(week,jt.TrnDate) = DATEPART(week,GETDATE()) THEN jt.TrnValue ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN DATEPART(month,jt.TrnDate) = DATEPART(month,GETDATE()) THEN jt.TrnValue ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN DATEPART(quarter,jt.TrnDate) = DATEPART(quarter,GETDATE()) THEN jt.TrnValue ELSE 0 END) as QTDProduction
  , SUM(jt.TrnValue) as YTDProduction
FROM WipJobPost jt INNER JOIN WipMaster jm ON jt.Job = jm.Job
WHERE       jt.TrnType = 'L' AND DATEPART(year,jt.TrnDate) = DATEPART(year,GETDATE()) AND jm.Warehouse = 'W1')t011


) t01 


CROSS JOIN (SELECT '04' as Sequence
  , 'Matl Value Produced' as Description
  , SUM(CASE WHEN DATEPART(dayofyear,jr.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN DATEPART(week,jr.TrnDate) = DATEPART(week,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN DATEPART(month,jr.TrnDate) = DATEPART(month,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN DATEPART(quarter,jr.TrnDate) = DATEPART(quarter,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as QTDProduction
  , SUM(jr.MaterialValue + jr.LabourValue) as YTDProduction
FROM WipPartBook jr INNER JOIN WipMaster jm ON jr.Job = jm.Job
WHERE jm.Warehouse = 'W1' and DATEPART(year,jr.TrnDate) = DATEPART(year,GETDATE()) and jr.Reference <> 'Billing') t02 



UNION 


SELECT ROW_NUMBER() OVER (ORDER BY Sequence) AS ID, GETDATE() as time,Sequence, 
'Finished Goods Production Variance' as Description, (t2.TodayProduction - t1.TodayProduction) AS TodayProduction, 
(t2.WTDProduction - t1.WTDProduction) AS WTDProduction, (t2.MTDProduction - t1.MTDProduction) AS MTDProduction, 
(t2.QTDProduction - t1.QTDProduction) AS QTDProduction,(t2.YTDProduction - t1.YTDProduction) AS YTDProduction 
FROM (
select '05' As Sequence,sum(t11.TodayProduction) as TodayProduction,sum(t11.WTDProduction) as WTDProduction,sum(t11.MTDProduction) as MTDProduction, 
sum(t11.QTDProduction) as QTDProduction,sum(t11.YTDProduction) as YTDProduction from (

SELECT   SUM(CASE WHEN DATEPART(dayofyear,jt.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jt.TrnValue ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN DATEPART(week,jt.TrnDate) = DATEPART(week,GETDATE()) THEN jt.TrnValue ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN DATEPART(month,jt.TrnDate) = DATEPART(month,GETDATE()) THEN jt.TrnValue ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN DATEPART(quarter,jt.TrnDate) = DATEPART(quarter,GETDATE()) THEN jt.TrnValue ELSE 0 END) as QTDProduction
  , SUM(jt.TrnValue) as YTDProduction
FROM WipJobPost jt INNER JOIN WipMaster jm ON jt.Job = jm.Job
     INNER JOIN InvMaster im on jm.StockCode = im.StockCode

WHERE       jt.TrnType = 'R' 
   AND DATEPART(year,jt.TrnDate) = DATEPART(year,GETDATE()) 
   AND jm.Warehouse IN ('F1','F2','F3','QC')
   AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
   AND LEFT(im.ProductClass, 2) <> 'SO'
   AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
UNION ALL

SELECT  SUM(CASE WHEN DATEPART(dayofyear,jt.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jt.TrnValue ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN DATEPART(week,jt.TrnDate) = DATEPART(week,GETDATE()) THEN jt.TrnValue ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN DATEPART(month,jt.TrnDate) = DATEPART(month,GETDATE()) THEN jt.TrnValue ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN DATEPART(quarter,jt.TrnDate) = DATEPART(quarter,GETDATE()) THEN jt.TrnValue ELSE 0 END) as QTDProduction
  , SUM(jt.TrnValue) as YTDProduction
FROM WipJobPost jt INNER JOIN WipMaster jm ON jt.Job = jm.Job
     INNER JOIN InvMaster im on jm.StockCode = im.StockCode

WHERE       jt.TrnType = 'L' 
   AND DATEPART(year,jt.TrnDate) = DATEPART(year,GETDATE()) 
   
   
   AND jm.Warehouse IN ('F1','F2','F3','QC')
   AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
   AND LEFT(im.ProductClass, 2) <> 'SO'
   AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
) t11 )
 t1 
CROSS JOIN (SELECT '05' As Sequence1, SUM(CASE WHEN DATEPART(dayofyear,jr.TrnDate) = DATEPART(dayofyear,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN DATEPART(week,jr.TrnDate) = DATEPART(week,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN DATEPART(month,jr.TrnDate) = DATEPART(month,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN DATEPART(quarter,jr.TrnDate) = DATEPART(quarter,GETDATE()) THEN jr.MaterialValue + jr.LabourValue ELSE 0 END) as QTDProduction
  , SUM(jr.MaterialValue + jr.LabourValue) as YTDProduction
FROM WipPartBook jr INNER JOIN WipMaster jm ON jr.Job = jm.Job
INNER JOIN InvMaster im on jm.StockCode = im.StockCode

WHERE jm.Warehouse IN ('F1','F2','F3','QC')
  AND DATEPART(year,jr.TrnDate) = DATEPART(year,GETDATE()) 
  AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
  AND LEFT(im.ProductClass, 2) <> 'SO'
  AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
  AND jr.Reference <> 'Billing') t2