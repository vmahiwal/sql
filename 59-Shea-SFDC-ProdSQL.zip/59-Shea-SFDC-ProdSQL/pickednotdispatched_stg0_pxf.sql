--Job --pickednotdispatched_stg0_pxf



SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,bo.WH,bo.ShipQty,
 SUBSTRING(od.SalesOrder, PATINDEX('%[^0 ]%', od.SalesOrder + ''), LEN(od.SalesOrder)) as SalesOrder,
od.MStockCode,od.SalesOrderLine,
SUBSTRING(om.Customer, PATINDEX('%[^0 ]%', om.Customer + ''), LEN(om.Customer)) as Customer,
CorpAcctName,od.MPrice,om.CustomerPoNumber
FROM              Barcode.dbo.Orders bo INNER JOIN SysproCompanyB.dbo.SorDetail od 
             ON 
           SUBSTRING(od.SalesOrder, PATINDEX('%[^0 ]%', od.SalesOrder + ''), LEN(od.SalesOrder)) = SUBSTRING(bo.OrderNo, PATINDEX('%[^0 ]%', bo.OrderNo + ''), LEN(bo.OrderNo))  COLLATE Latin1_General_BIN 
           AND od.MStockCode = bo.ItemNo COLLATE Latin1_General_BIN 
           AND od.SalesOrderLine = bo.LineNumber
          INNER JOIN SysproCompanyB.dbo.SorMaster om
           ON od.SalesOrder = om.SalesOrder
           left join View_ArCust_GroupingData4KPI_New a on a.Customer=om.Customer
WHERE (NOT(om.Branch IN ('TR', 'CO', 'SM')))
    AND NOT (om.Customer IN ('000000000048869','000000000049870'))