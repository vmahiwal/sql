--Job- CurrentYearOrder_stg0



SELECT ROW_NUMBER() OVER (ORDER BY om.SalesOrder) AS ID, GETDATE() as time,cacm.CorpAcctName, 
SUBSTRING(om.Customer, PATINDEX('%[^0 ]%', om.Customer + ' '), LEN(om.Customer))�as Customer,
SUBSTRING(om.SalesOrder, PATINDEX('%[^0 ]%', om.SalesOrder + ' '), LEN(om.SalesOrder))�as SalesOrder,
SalesOrderLine, OrderStatus, Salesperson, CustomerPoNumber, OrderDate, EntrySystemDate, ReqShipDate, om.DiscPct1,om.DiscPct2,om.DiscPct3,  MStockCode, MStockDes, MWarehouse, 
od.MOrderQty, od.MPrice, od.MShipQty,od.MBackOrderQty
  ,  od.MDiscValFlag ,od.MDiscValue,od.MDiscPct1,od.MDiscPct2,od.MDiscPct3, om.InterWhSale, om.Branch, MLineShipDate,om.ShipAddress3,om.ShipPostalCode,om.CancelledFlag, od.LineType, om.DocumentType, od.MProductClass, om.CustomerName
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder LEFT JOIN (SELECT REPLACE(KeyField,' ','') as Customer
         , AlphaValue as CorpAcctCode
        FROM AdmFormData
        WHERE FormType = 'CUS' and FieldName = 'COR002') cac ON om.Customer = cac.Customer
     LEFT JOIN (SELECT Item as CorpAcctCode
         , Description as CorpAcctName
        FROM AdmFormValidation
        WHERE FormType = 'CUS' and FieldName = 'COR002') cacm on cac.CorpAcctCode = cacm.CorpAcctCode
WHERE (od.LineType = '1')
  AND DATEPART(YEAR,om.EntrySystemDate) = DATEPART(YEAR,GETDATE())