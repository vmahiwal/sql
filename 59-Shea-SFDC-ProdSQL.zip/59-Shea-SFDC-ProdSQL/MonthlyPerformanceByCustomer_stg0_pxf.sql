--MonthlyPerformanceByCustomer_stg0_pxf



select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, a.* from 
(SELECT 
'Ordered' as RecordType, CorpAcctName,CASE WHEN Month(om.ReqShipDate) = 1 and year( om.ReqShipDate) = 2017 then '2017-01-01'
    WHEN Month(om.ReqShipDate) = 2 and year( om.ReqShipDate) = 2017 then  '2017-02-01'
    WHEN Month(om.ReqShipDate) = 3 and year( om.ReqShipDate) = 2017 then '2017-03-01'
    WHEN Month(om.ReqShipDate) = 4 and year( om.ReqShipDate) = 2017 then  '2017-04-01'
    WHEN Month(om.ReqShipDate) = 5 and year( om.ReqShipDate) = 2017 then '2017-05-01'
    WHEN Month(om.ReqShipDate) = 6 and year( om.ReqShipDate) = 2017 then  '2017-06-01'
WHEN Month(om.ReqShipDate) = 7 and year( om.ReqShipDate) = 2017 then  '2017-07-01'
    WHEN Month(om.ReqShipDate) = 8 and year( om.ReqShipDate) = 2017 then '2017-08-01'
    WHEN Month(om.ReqShipDate) = 9 and year( om.ReqShipDate) = 2017 then  '2017-09-01'
    WHEN Month(om.ReqShipDate) = 10 and year( om.ReqShipDate) = 2017 then '2017-10-01'
    WHEN Month(om.ReqShipDate) = 11 and year( om.ReqShipDate) = 2017 then  '2017-11-01'
    WHEN Month(om.ReqShipDate) = 12 and year( om.ReqShipDate) = 2017 then  '2017-12-01'
    
    WHEN Month(om.ReqShipDate) = 1 and year( om.ReqShipDate) = 2016 then'2016-01-01'
    WHEN Month(om.ReqShipDate) = 2 and year( om.ReqShipDate) = 2016 then  '2016-02-01'
    WHEN Month(om.ReqShipDate) = 3 and year( om.ReqShipDate) = 2016 then'2016-03-01'
    WHEN Month(om.ReqShipDate) = 4 and year( om.ReqShipDate) = 2016 then'2016-04-01'
    WHEN Month(om.ReqShipDate) = 5 and year( om.ReqShipDate) = 2016 then '2016-05-01'
    WHEN Month(om.ReqShipDate) = 6 and year( om.ReqShipDate) = 2016 then  '2016-06-01'
    WHEN Month(om.ReqShipDate) = 7 and year( om.ReqShipDate) = 2016 then '2016-07-01'
    WHEN Month(om.ReqShipDate) = 8 and year( om.ReqShipDate) = 2016 then '2016-08-01'
    WHEN Month(om.ReqShipDate) = 9 and year( om.ReqShipDate) = 2016 then'2016-09-01'
    WHEN Month(om.ReqShipDate) = 10 and year( om.ReqShipDate) = 2016 then  '2016-10-01'
    WHEN Month(om.ReqShipDate) = 11 and year( om.ReqShipDate) = 2016 then '2016-11-01'
    WHEN Month(om.ReqShipDate) = 12 and year( om.ReqShipDate) = 2016 then '2016-12-01' end as Date,
   SUM(od.MOrderQty * od.MPrice) as Value
  
  
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder left join View_ArCust_GroupingData4KPI_New arc on arc.Customer=om.Customer
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
  AND (om.CancelledFlag <> 'Y')
  AND (om.InterWhSale <> 'Y') 
  AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
  AND (od.LineType = '1')
  --Added following condition to eliminate credit notes 2016-06-07
  AND (om.DocumentType) <> 'C'
  --2016-12-14 Next Line To Exclude Raw Material Customers
    AND NOT (om.Customer IN ('000000000048869','000000000049870'))
  AND DATEPART(year,ReqShipDate) in ( DATEPART(year,GETDATE()),DATEPART(year,GETDATE())-1)
  group by CorpAcctName,month(ReqShipDate), year(ReqShipDate)
  
UNION ALL
SELECT 'Invoiced' as RecordType, CorpAcctName,
   case when TrnYear=2017 and TrnMonth=1 then '2017-01-01' 
  when TrnYear=2017 and TrnMonth=2 then '2017-02-01'
when TrnYear=2017 and TrnMonth=3 then '2017-03-01' 
  when TrnYear=2017 and TrnMonth=4 then '2017-04-01'
  when TrnYear=2017 and TrnMonth=5 then '2017-05-01' 
  when TrnYear=2017 and TrnMonth=6 then '2017-06-01'
  when TrnYear=2017 and TrnMonth=7 then '2017-07-01'
  when TrnYear=2017 and TrnMonth=8 then '2017-08-01' 
  when TrnYear=2017 and TrnMonth=9 then '2017-09-01'
  when TrnYear=2017 and TrnMonth=10 then '2017-10-01' 
  when TrnYear=2017 and TrnMonth=11 then '2017-11-01'
  when TrnYear=2017 and TrnMonth=12 then '2017-12-01'
  
  when TrnYear=2016 and TrnMonth=1 then '2016-01-01' 
  when TrnYear=2016 and TrnMonth=2 then '2016-02-01'
  when TrnYear=2016 and TrnMonth=3 then '2016-03-01' 
  when TrnYear=2016 and TrnMonth=4 then '2016-04-01'
  when TrnYear=2016 and TrnMonth=5 then '2016-05-01' 
  when TrnYear=2016 and TrnMonth=6 then '2016-06-01'
  when TrnYear=2016 and TrnMonth=7 then '2016-07-01' 
  when TrnYear=2016 and TrnMonth=8 then '2016-08-01'
  when TrnYear=2016 and TrnMonth=9 then '2016-09-01' 
  when TrnYear=2016 and TrnMonth=10 then '2016-10-01'
  when TrnYear=2016 and TrnMonth=11 then '2016-11-01' 
  when TrnYear=2016 and TrnMonth=12 then '2016-12-01'
   end as Date
  
  --, SUM(NetSalesValue) as MonthlySales
  , SUM(NetSalesValue + DiscValue) as Value
FROM ArTrnDetail art left join View_ArCust_GroupingData4KPI_New arc on arc.Customer=art.Customer
WHERE TrnYear in ( DATEPART(year,GETDATE()),DATEPART(year,GETDATE())-1) and (LineType = '1') and (NOT(Branch IN ('TR', 'CO', 'SM')))
--Added following condition to eliminate credit notes 2016-06-07
  AND (DocumentType) <> 'C'
  --2016-12-14 Next Line To Exclude Raw Material Customers
    AND NOT (art.Customer IN ('000000000048869','000000000049870'))

GROUP BY CorpAcctName,TrnYear
  , TrnMonth

UNION ALL
SELECT 'Forecast' as RecordType,
  CASE WHEN c.CorpAcctName is null then (case when LEFT(a.Reference,2)='DB' then 'BEAUTY CHANNEL ALL OTHER                ' 
  when LEFT(a.Reference,2)='HY' then 'HYBRID ALL OTHER                        '
  when LEFT(a.Reference,2)='RT' then 'RETAIL and WEB CUSTOMER                 '
  when LEFT(a.Reference,2)='DN' then 'NATURAL CHANNEL ALL OTHER               '
  when LEFT(a.Reference,2)='GR' then 'GROCERY ALL OTHER                       ' 
  when LEFT(a.Reference,2)='WH' then 'CUST CLASS WHOLE SALE                   ' 
  when LEFT(a.Reference,2)='SA' then 'SAMPLES                                 '
  else c.CorpAcctName end) else c.CorpAcctName end As CorpAcctName , ForecastDate as Date,

  SUM(InvPrice.SellingPrice*a.ForecastQtyOutst + InvPrice.SellingPrice*a.QtyInvoiced) AS Value
   from
(SELECT
  mrp.StockCode,
  mrp.ForecastDate,
  mrp.ForecastQtyOutst,
  mrp.ForecastType,
  mrp.Description,
  mrp.Reference,
  mrp.Customer,
  mrp.QtyInvoiced,
  mrp.OrigQtyOutst,
 CASE
    WHEN Name IS NULL THEN LEFT(Reference, 2)
    ELSE Name
  END AS CustomerName,
  CASE
    WHEN CustomerClass IS NULL THEN LEFT(Reference, 2)
    ELSE CustomerClass
  END AS CustomerClass,
  CASE
    WHEN (PriceCode IS NULL OR
      PriceCode = '') THEN LEFT(Reference, 2)
    ELSE PriceCode
  END AS PriceCode
FROM [SysproCompanyB].[dbo].[MrpForecast] mrp
LEFT JOIN [SysproCompanyB].[dbo].[ArCustomer] arc
  ON mrp.Customer = arc.Customer
  
WHERE mrp.ForecastType = 'S' and year(ForecastDate)in ( DATEPART(year,GETDATE()),DATEPART(year,GETDATE())-1)) a 
LEFT OUTER JOIN dbo.InvPrice
  ON a.StockCode = dbo.InvPrice.StockCode
  AND a.PriceCode = dbo.InvPrice.PriceCode
LEFT JOIN 
                        View_ArCust_GroupingData4KPI_New c on c.Customer=a.Customer

        GROUP By 
  CASE WHEN c.CorpAcctName is null then (case when LEFT(a.Reference,2)='DB' then 'BEAUTY CHANNEL ALL OTHER                ' 
  when LEFT(a.Reference,2)='HY' then 'HYBRID ALL OTHER                        '
  when LEFT(a.Reference,2)='RT' then 'RETAIL and WEB CUSTOMER                 '
  when LEFT(a.Reference,2)='DN' then 'NATURAL CHANNEL ALL OTHER               '
  when LEFT(a.Reference,2)='GR' then 'GROCERY ALL OTHER                       ' 
  when LEFT(a.Reference,2)='WH' then 'CUST CLASS WHOLE SALE                   ' 
  when LEFT(a.Reference,2)='SA' then 'SAMPLES                                 '
  else c.CorpAcctName end) else c.CorpAcctName end,ForecastDate )a