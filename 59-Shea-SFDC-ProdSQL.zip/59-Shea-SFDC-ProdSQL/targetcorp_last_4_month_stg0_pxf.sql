--targetcorp_last_4_month_stg0_pxf


select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time
,od.SalesOrder,od.SalesOrderLine,art.Invoice,om.Customer,CorpAcctName,
InvoiceDate,od.MStockCode,od.MStockDes,EntrySystemDate,CustomerPoNumber
,MLineShipDate,OrderStatus,FirstDelDate.ActualDeliveryDate FirstDelDate,LastDelDate.ActualDeliveryDate LastDelDate,
SUM(QtyInvoiced) as QtyInvoiced,SUM(MOrderQty) as QtyOrdered ,MPrice ,SUM(GrossInvoiced) as GrossInvoiced
,SUM(MOrderQty*MPrice) as GrossOrdered 
from SorDetail od inner join SorMaster om on om.SalesOrder=od.SalesOrder 
left join 
(SELECT * FROM( select SalesOrder,Invoice,SalesOrderLine,Customer,InvoiceDate
,SUM(QtyInvoiced) as QtyInvoiced, SUM(NetSalesValue+DiscValue) as GrossInvoiced 
,RANK() OVER (PARTITION BY SalesOrder ORDER BY Invoice ASC) AS xRank from ArTrnDetail where (LineType = '1') 
and (NOT(Branch IN ('TR', 'CO', 'SM'))) AND (DocumentType) <> 'C' and InvoiceDate> =dateadd(day,-124,getdate())
group by SalesOrder,Invoice,SalesOrderLine,Customer,InvoiceDate)hello where xRank=1 )art 
on od.SalesOrder=art.SalesOrder and od.SalesOrderLine=art.SalesOrderLine 
left join
(SELECT * FROM( select SalesOrder,ActualDeliveryDate,Invoice,InvoiceCreatedDate
,RANK() OVER (PARTITION BY SalesOrder ORDER BY Invoice ASC) AS xRank from MdnMaster where 
 (NOT(Branch IN ('TR', 'CO', 'SM'))) and InvoiceCreatedDate> =dateadd(day,-124,getdate())
group by SalesOrder,ActualDeliveryDate,Invoice,InvoiceCreatedDate)delDate where xRank=1 )FirstDelDate 
on FirstDelDate.SalesOrder = od.SalesOrder
left join
(SELECT * FROM( select SalesOrder,ActualDeliveryDate,Invoice,InvoiceCreatedDate
,RANK() OVER (PARTITION BY SalesOrder ORDER BY Invoice DESC) AS xRank from MdnMaster where 
 (NOT(Branch IN ('TR', 'CO', 'SM'))) and InvoiceCreatedDate> =dateadd(day,-124,getdate())
group by SalesOrder,ActualDeliveryDate,Invoice,InvoiceCreatedDate)delDate where xRank=1 )LastDelDate
on LastDelDate.SalesOrder = od.SalesOrder
left join View_ArCust_GroupingData4KPI_New vw on vw.Customer=om.Customer where EntrySystemDate>=dateadd(day,-124,getdate()) 
AND (od.LineType = '1') AND (om.CancelledFlag <> 'Y') and om.OrderStatus<>'' AND (om.InterWhSale <> 'Y') 
AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) AND (od.LineType = '1') AND (om.DocumentType) <> 'C'  
and CorpAcctName like '%TARGET%' group by od.SalesOrder,od.SalesOrderLine,art.Invoice,om.Customer,CorpAcctName,InvoiceDate,od.MStockCode
,od.MStockDes,MPrice,EntrySystemDate,CustomerPoNumber,MLineShipDate,OrderStatus,FirstDelDate.ActualDeliveryDate,LastDelDate.ActualDeliveryDate