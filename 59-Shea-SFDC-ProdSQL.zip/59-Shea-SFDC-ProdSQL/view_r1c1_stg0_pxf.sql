--job view_r1c1_stg0_pxf

Select  ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, * from View_R1C1_MinMax_POHistory




------full query of view--------------

SELECT        dbo.InvMaster.StockCode, dbo.InvMaster.Description, dbo.InvMaster.WarehouseToUse, dbo.InvMaster.LeadTime, dbo.InvWarehouse.QtyOnOrder, 
                         dbo.InvWarehouse.QtyOnHand, dbo.InvWarehouse.QtyAllocatedWip, dbo.InvWarehouse.SafetyStockQty, 
                         dbo.View_InvWarehouse_SumByStockCode.C2QtyOnHand + dbo.View_InvWarehouse_SumByStockCode.R2QtyOnHand AS C2R2QtyOnHand, 
                         dbo.View_InvWarehouse_SumByStockCode.QtyOnHand AS QtyOnHandAllWHs, dbo.View_InvWarehouse_SumByStockCode.QtyOnOrder AS QtyOnOrderAllWhs, 
                         dbo.InvWarehouse.QtyOnHand + dbo.InvWarehouse.QtyOnOrder - dbo.InvWarehouse.QtyAllocatedWip AS FutureFree, 
                         dbo.InvWarehouse.QtyOnHand - dbo.InvWarehouse.QtyAllocatedWip AS [OH<WP], 
                         CASE WHEN dbo.View_InvWarehouse_SumByStockCode.QtyOnHand < dbo.InvWarehouse.SafetyStockQty THEN 1 ELSE 0 END AS [NEED FOR STOCK], 
                         CASE WHEN (dbo.InvWarehouse.QtyOnHand + dbo.InvWarehouse.QtyOnOrder - dbo.InvWarehouse.QtyAllocatedWip) 
                         < dbo.InvWarehouse.SafetyStockQty THEN 2 ELSE 0 END AS [FF<SS], CASE WHEN (dbo.InvWarehouse.QtyOnHand > dbo.InvWarehouse.SafetyStockQty) AND 
                         (dbo.InvWarehouse.QtyOnHand + dbo.InvWarehouse.QtyOnOrder - dbo.InvWarehouse.QtyAllocatedWip) 
                         > dbo.InvWarehouse.SafetyStockQty THEN 0 ELSE 3 END AS Column2, 
                         CASE WHEN (dbo.View_InvWarehouse_SumByStockCode.QtyOnHand + dbo.InvWarehouse.QtyOnOrder) 
                         < dbo.InvWarehouse.SafetyStockQty THEN 'PLACE PO' ELSE 'NO' END AS [NEED PO], CASE WHEN CurrMnt IS NULL THEN 0 ELSE CurrMnt END AS CurrMnt, 
                         CASE WHEN FutMnt1 IS NULL THEN 0 ELSE FutMnt1 END AS FutMnt1, CASE WHEN FutMnt2 IS NULL THEN 0 ELSE FutMnt2 END AS FutMnt2, 
                         CASE WHEN Last30Days IS NULL THEN 0 ELSE Last30Days END AS I30Days, CASE WHEN Last60Days IS NULL THEN 0 ELSE Last60Days END AS I60Days, 
                         CASE WHEN Last90Days IS NULL THEN 0 ELSE Last90Days END AS I90Days, CASE WHEN Last120Days IS NULL THEN 0 ELSE Last120Days END AS I120Days, 
                         CASE WHEN Last365Days IS NULL THEN 0 ELSE Last365Days END AS I365Days, CASE WHEN Last730Days IS NULL THEN 0 ELSE Last730Days END AS I730Days,
                          CASE WHEN dbo.View_GrnDetails_SumByStockCode.QtyReceived IS NULL THEN 0 ELSE dbo.View_GrnDetails_SumByStockCode.QtyReceived END AS QtyReceived,
                          CASE WHEN ToDate IS NULL THEN 0 ELSE ToDate END AS IToDate, CASE WHEN [30Days] IS NULL THEN 0 ELSE [30Days] END AS [30Days], 
                         CASE WHEN [60Days] IS NULL THEN 0 ELSE [60Days] END AS [60Days], CASE WHEN [90Days] IS NULL THEN 0 ELSE [90Days] END AS [90Days], 
                         CASE WHEN [120Days] IS NULL THEN 0 ELSE [120Days] END AS [120Days], CASE WHEN [365Days] IS NULL THEN 0 ELSE [365Days] END AS [365Days], 
                         dbo.View_GrnDetails_RankByStockCode.PurchaseOrder, dbo.View_GrnDetails_RankByStockCode.PurchaseOrderLin, 
                         dbo.View_GrnDetails_RankByStockCode.GrnCost AS LatestReceiptCost, dbo.View_GrnDetails_RankByStockCode.OrigReceiptDate, 
                         dbo.View_GrnDetails_RankByStockCode.MPrice, dbo.View_WipRequirements_OSQtyNeeded_ByWeek.QtyNeeded, 
                         dbo.View_WipRequirements_OSQtyNeeded_ByWeek.ThisWeek, dbo.View_WipRequirements_OSQtyNeeded_ByWeek.NextWeek, 
                         dbo.View_WipRequirements_OSQtyNeeded_ByWeek.[2ndWeek], dbo.View_WipRequirements_OSQtyNeeded_ByWeek.[3rdWeeknFut], 
                         CASE WHEN dbo.View_MrpSugReqs_3Mnts.OrderQty IS NULL THEN 0 ELSE dbo.View_MrpSugReqs_3Mnts.OrderQty END AS MrpTotQty, dbo.InvMaster.StockUom, 
                         dbo.InvMaster.AlternateUom, dbo.InvMaster.ConvFactAltUom, dbo.InvMaster.ConvMulDiv, dbo.InvWarehouse.MinimumQty, dbo.InvWarehouse.MaximumQty, 
                         dbo.InvWarehouse.ReOrderQty, PoInfo.DueDt, CASE WHEN FirstPO IS NULL THEN '' ELSE FirstPO END AS FirstPO, 
                         dbo.View_GrnDetails_RankByStockCode.Supplier, dbo.View_GrnDetails_RankByStockCode.SupplierName, 
                         dbo.View_WipRequirements_OSQtyNeeded_ByWeek.PastDue, dbo.InvWarehouse.Warehouse
FROM            dbo.InvMaster LEFT OUTER JOIN
                         dbo.View_InvWarehouse_SumByStockCode ON dbo.InvMaster.StockCode = dbo.View_InvWarehouse_SumByStockCode.StockCode LEFT OUTER JOIN
                         dbo.View_WipRequirements_OSQtyNeeded_ByWeek ON 
                         dbo.InvMaster.StockCode = dbo.View_WipRequirements_OSQtyNeeded_ByWeek.StockCode LEFT OUTER JOIN
                             (SELECT        dbo.PorMasterDetail.MStockCode, MIN(dbo.PorMasterDetail.MLatestDueDate) AS DueDt, MIN(dbo.PorMasterHdr.PurchaseOrder) AS FirstPO
                               FROM            dbo.PorMasterDetail INNER JOIN
                                                         dbo.PorMasterHdr ON dbo.PorMasterDetail.PurchaseOrder = dbo.PorMasterHdr.PurchaseOrder
                               WHERE        (dbo.PorMasterDetail.LineType = '1') AND (dbo.PorMasterHdr.OrderStatus <> '*')
                               GROUP BY dbo.PorMasterDetail.MStockCode) AS PoInfo ON dbo.InvMaster.StockCode = PoInfo.MStockCode LEFT OUTER JOIN
                         dbo.View_MrpSugReqs_3Mnts ON dbo.InvMaster.StockCode = dbo.View_MrpSugReqs_3Mnts.StockCode LEFT OUTER JOIN
                         dbo.View_GrnDetails_RankByStockCode ON 1 = dbo.View_GrnDetails_RankByStockCode.cnt AND 
                         dbo.InvMaster.StockCode = dbo.View_GrnDetails_RankByStockCode.StockCode LEFT OUTER JOIN
                         dbo.View_WipJobPost_SumByStockCode ON dbo.InvMaster.StockCode = dbo.View_WipJobPost_SumByStockCode.MStockCode LEFT OUTER JOIN
                         dbo.View_GrnDetails_SumByStockCode ON dbo.InvMaster.WarehouseToUse = dbo.View_GrnDetails_SumByStockCode.Warehouse AND 
                         dbo.InvMaster.StockCode = dbo.View_GrnDetails_SumByStockCode.StockCode LEFT OUTER JOIN
                         dbo.InvWarehouse ON dbo.InvMaster.StockCode = dbo.InvWarehouse.StockCode AND dbo.InvMaster.WarehouseToUse = dbo.InvWarehouse.Warehouse
WHERE        (dbo.InvMaster.WarehouseToUse = 'R1') AND (dbo.InvWarehouse.Warehouse <> 'Z8') OR
                         (dbo.InvMaster.WarehouseToUse = 'C1') OR
                         (dbo.InvMaster.WarehouseToUse = 'C2') OR
                         (dbo.InvMaster.WarehouseToUse = 'S4') OR
                         (dbo.InvMaster.WarehouseToUse = 'E2') OR
                         (dbo.InvMaster.WarehouseToUse = 'W1') OR
                         (dbo.InvMaster.WarehouseToUse = 'R3') OR
                         (dbo.InvMaster.WarehouseToUse = 'C3')

