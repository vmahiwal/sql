--job walmart_inventoryavailability_stg0_pxf


select 
ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,
RTRIM(invm.StockCode) as StockCode,a.QtyOnHand,iw2.QCOnHand,iw3.XFGOnHand,iw4.XQCOnHand,iw3.XFGInTrnasit,iw4.XQCInTrnasit
,wmtfcst.CurrentMonthForecastWMT,wmtfcst.NextMonthForecastWMT,CurrentMonthForecastQty,NextMonthForecastQty,DrawOfficeNum from InvMaster invm
left join (Select StockCode,Sum(QtyOnHand) as QtyOnHand from InvWarehouse iw1 where Warehouse not in ('QC','E4','Z9') group by StockCode)a
on invm.StockCode = a.StockCode
left join ( select StockCode,SUM(QtyOnHand) as QCOnHand from InvWarehouse where Warehouse='QC' group by StockCode) iw2 on invm.StockCode=iw2.StockCode
left join ( select StockCode,SUM(QtyOnHand) as XFGOnHand,Sum(QtyInTransit) XFGInTrnasit from InvWarehouse where Warehouse='XFG' group by StockCode) iw3 on invm.StockCode=iw3.StockCode
left join ( select StockCode,SUM(QtyOnHand) as XQCOnHand,Sum(QtyInTransit) XQCInTrnasit from InvWarehouse where Warehouse='XQC' group by StockCode) iw4 on invm.StockCode=iw4.StockCode


left join
(SELECT [StockCode]
, SUM(CAST(CASE WHEN ForecastType = 'S' AND (year(ForecastDate)=year(getdate()) and month(ForecastDate)=month(getdate()))
THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS CurrentMonthForecastWMT
, SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 1, GETDATE())),
101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 2, GETDATE())), 101))
THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS NextMonthForecastWMT
FROM dbo.MrpForecast left join View_ArCust_GroupingData4KPI_New vw on vw.Customer=dbo.MrpForecast.Customer where CorpAcctName like '%WAL-MART%'
group by StockCode) wmtfcst on wmtfcst.StockCode=invm.StockCode
left join
(SELECT [StockCode]
, SUM(CAST(CASE WHEN ForecastType = 'S' AND (year(ForecastDate)=year(getdate()) and month(ForecastDate)=month(getdate()))
THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS CurrentMonthForecastQty
, SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 1, GETDATE())),
101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 2, GETDATE())), 101))
THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS NextMonthForecastQty
FROM dbo.MrpForecast
group by StockCode) fcst on fcst.StockCode=invm.StockCode