--DeerPark

SELECT
Case when MStockCode is null Then iw.StockCode else MStockCode end StockCode
,MStockDes,
case when ((Case when OpenQtyForF2 is null then 0 else OpenQtyForF2 end)- (iw.F2) )>0 THEN 'YES' ELSE 'NO' END as NeedForF6,
Case when iw.F2 is null then 0 else iw.F2 end as QtyOnHandF2, 
Case when OpenQtyForF2 is null then 0 else OpenQtyForF2 end OpenQtyForF2,
iw.F2-(Case when OpenQtyForF2 is null then 0 else OpenQtyForF2 end  )as DiffNeedForF6,
Case when iw.F6 is null then 0 else iw.F6 end as QtyOnHandF6,
Case when iw.QC is null then 0 else iw.QC end as QtyOnHandQC,
Case when OpenValue is null then 0 else OpenValue end OpenValue 
from
(select od.MStockCode,od.MStockDes,SUM(od.MShipQty+od.MBackOrderQty) as OpenQtyForF2,
SUM((od.MShipQty + od.MBackOrderQty) * od.MPrice) as OpenValue
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder WHERE (om.OrderStatus in ('0','1','2','3','4','S'))
AND (om.CancelledFlag <> 'Y')
AND (om.InterWhSale <> 'Y')
AND (od.LineType = '1')
AND ((od.MShipQty + MBackOrderQty) <> 0)
AND (od.MWarehouse='F2' or om.Warehouse='F2')
group by od.MStockCode,od.MStockDes)oo
full JOIN (Select * from(
select iw.StockCode,QtyOnHand,Warehouse
from InvWarehouse iw where iw.Warehouse in ('F2','F6','QC') ) as s
PIVOT
(
Sum(QtyOnHand) FOR Warehouse IN (F2,F6,QC)
) as pvt

)iw on iw.StockCode=oo.MStockCode
where (iw.F2 >0 or iw.F6>0 or iw.QC>0 or OpenQtyForF2>0)
    order by DiffNeedForF6
    
    
