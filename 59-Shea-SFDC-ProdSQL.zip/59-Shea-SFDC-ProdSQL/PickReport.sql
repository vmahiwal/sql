--PickReport

select vw.CorpAcctName,om.ReqShipDate as SysproShipDate,

SUBSTRING(om.Customer, PATINDEX('%[^0 ]%', om.Customer + ''), LEN(om.Customer)) as Customer
,om.CustomerName,
SUBSTRING(om.SalesOrder, PATINDEX('%[^0 ]%', om.SalesOrder + ''), LEN(om.SalesOrder)) as SalesOrder
,OrderStatus,CustomerPoNumber,OrderDate,
a.DateValue As MABD ,
Case when vw.CorpAcctName='CVS CORP' then DATEADD(day,-3,a.DateValue)
when vw.CorpAcctName='HARMON' then DATEADD(day,-14,a.DateValue)
when vw.CorpAcctName='MEIJER CORP' then DATEADD(day,-7,a.DateValue)
when vw.CorpAcctName='WAL-MART CORP' then DATEADD(day,-3,a.DateValue) end as DNDB
,
substring(om.ShipPostalCode,PATINDEX('%[^0 ]%',om.ShipPostalCode + ' '),LEN(om.ShipPostalCode)) as PostalCode
,om.ShipAddress4 as ShipState,SUM(MBackOrderQty+MShipQty) as OrderQty,SUM(MPrice*(MBackOrderQty+MShipQty)) as OrderValue,DispatchCount,b.AlphaValue

from SorMaster om inner join SorDetail od on om.SalesOrder=od.SalesOrder
left join (select * from AdmFormData where FieldName='DEL001')a on a.KeyField=om.SalesOrder
left join View_ArCust_GroupingData4KPI_New vw on om.Customer=vw.Customer left join InvMaster im on

od.MStockCode=im.StockCode
left join (select SalesOrder,count(DispatchNote) as DispatchCount from MdnMaster group by SalesOrder)mm on

mm.SalesOrder=om.SalesOrder
left join (select * from AdmFormData where FieldName='WHCOMM' and FormType = 'ORD')b on b.KeyField=om.SalesOrder
where
(om.OrderStatus in ('0','1','2','3','4','S')) AND (om.DocumentType) <> 'C'
and (om.CancelledFlag <> 'Y')
AND (om.InterWhSale <> 'Y')
AND (od.LineType = '1')
AND ((od.MShipQty + MBackOrderQty) <> 0)
AND (NOT(vw.CorpAcctName IN ('SAMPLES ', 'TRADE SHOWS ', 'RETAIL and WEB CUSTOMER ')))
AND StockUom='CS'
AND MWarehouse='F2'
AND LEFT(MStockCode,4) not in ('DISP','FIXT')
group by vw.CorpAcctName,
om.Customer,om.CustomerName,om.SalesOrder,OrderStatus,CustomerPoNumber,OrderDate,EntrySystemDate,

ReqShipDate,a.DateValue,Case when vw.CorpAcctName='CVS CORP' then DATEADD(day,-3,a.DateValue)
when vw.CorpAcctName='HARMON' then DATEADD(day,-14,a.DateValue)
when vw.CorpAcctName='MEIJER CORP' then DATEADD(day,-7,a.DateValue)
when vw.CorpAcctName='WAL-MART CORP' then DATEADD(day,-3,a.DateValue) end,om.ShipPostalCode,om.ShipAddress4,DispatchCount,b.AlphaValue

order by om.Customer,om.SalesOrder