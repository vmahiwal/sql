-- job view_podetails_stg0_pxf


SELECT      ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,  rtrim(dbo.PorMasterDetail.PurchaseOrder) as PurchaseOrder, rtrim(dbo.PorMasterHdr.Supplier) as Supplier, rtrim(dbo.ApSupplier.SupplierName) as SupplierName, dbo.PorMasterDetail.Line, dbo.PorMasterDetail.LineType,
rtrim(dbo.PorMasterDetail.MStockCode) AS StockCode, rtrim(dbo.PorMasterDetail.MStockDes) AS StockDes, rtrim(dbo.PorMasterDetail.MProductClass) AS ProductClass,
rtrim(dbo.PorMasterDetail.MWarehouse) AS Wh, dbo.PorMasterDetail.MOrderUom AS OrdUom, dbo.PorMasterDetail.MOrderQty AS OrdQty,
dbo.PorMasterDetail.MReceivedQty AS ReceivedQty,
CASE WHEN PorMasterDetail.MCompleteFlag = 'Y' THEN 0 ELSE MOrderQty - MReceivedQty END AS OutstandingQty,
dbo.PorMasterDetail.MLatestDueDate AS LatestDueDt, dbo.PorMasterDetail.MPrice AS UnitPrice, rtrim(dbo.AdmFormData.AlphaValue) AS [Special Comment],
dbo.PorMasterHdr.OrderStatus, dbo.PorMasterHdr.OrderEntryDate, rtrim(dbo.PorMasterHdr.ShippingInstrs) as ShippingInstrs, dbo.PorMasterHdr.DatePoCompleted,
dbo.PorMasterDetail.MLastReceiptDat
FROM            dbo.PorMasterDetail INNER JOIN
dbo.PorMasterHdr ON dbo.PorMasterDetail.PurchaseOrder = dbo.PorMasterHdr.PurchaseOrder INNER JOIN
dbo.ApSupplier ON dbo.PorMasterHdr.Supplier = dbo.ApSupplier.Supplier LEFT OUTER JOIN
dbo.AdmFormData ON dbo.PorMasterDetail.PurchaseOrder = dbo.AdmFormData.KeyField