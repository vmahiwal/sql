--Job kpi_revenue_stg0_pxf


select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, tmp.* from (SELECT CorpAcctName
		, '2016-01-01' as BudgetDate 
		, SUM(gb.BudMnt1) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer 
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 1
		 group by Customer)a on a.Customer=gb.Customer 
group by CorpAcctName
UNION SELECT CorpAcctName
		, '2016-02-01' as BudgetDate 
		, SUM(gb.BudMnt2) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer 
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 2
		 group by Customer)a on a.Customer=gb.Customer 
group by CorpAcctName
UNION SELECT CorpAcctName
		, '2016-03-01' as BudgetDate 
		, SUM(gb.BudMnt3) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 3
		 group by Customer)a on a.Customer=gb.Customer 
group by CorpAcctName
UNION SELECT CorpAcctName
		, '2016-04-01' as BudgetDate 
		, SUM(gb.BudMnt4) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer 
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 4
		 group by Customer)a on a.Customer=gb.Customer 
group by CorpAcctName
UNION SELECT CorpAcctName
		, '2016-05-01' as BudgetDate 
		, SUM(gb.BudMnt5) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 5
		 group by Customer)a on a.Customer=gb.Customer 
 group by CorpAcctName
UNION SELECT CorpAcctName
		, '2016-06-01' as BudgetDate 
		, SUM(gb.BudMnt6) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 6
		 group by Customer)a on a.Customer=gb.Customer 
 group by CorpAcctName
UNION SELECT CorpAcctName
		, '2016-07-01' as BudgetDate 
		, SUM(gb.BudMnt7) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer 
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 7
		 group by Customer)a on a.Customer=gb.Customer 
group by CorpAcctName
UNION SELECT CorpAcctName
		, '2016-08-01' as BudgetDate 
		, SUM(gb.BudMnt8) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 8
		 group by Customer)a on a.Customer=gb.Customer 
 group by CorpAcctName
UNION SELECT CorpAcctName
		, '2016-09-01' as BudgetDate 
		, SUM(gb.BudMnt9) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer 
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 9
		 group by Customer)a on a.Customer=gb.Customer 
group by CorpAcctName
UNION SELECT CorpAcctName
		, '2016-10-01' as BudgetDate 
		, SUM(gb.BudMnt10) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer 
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 10
		 group by Customer)a on a.Customer=gb.Customer 
group by CorpAcctName
UNION SELECT CorpAcctName
		, '2016-11-01' as BudgetDate 
		, SUM(gb.BudMnt11) as Budget
		, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer 
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 11
		 group by Customer)a on a.Customer=gb.Customer 
group by CorpAcctName
UNION
SELECT CorpAcctName
		, '2016-12-01' as BudgetDate 
		, SUM(gb.BudMnt12) as Budget
, SUM(a.OrderValue) as OrderValue
FROM View_ArCust_Budgets_AdmFormData gb INNER JOIN  dbo.View_ArCust_GroupingData4KPI_New at ON gb.Customer = at.Customer
left join (select Customer,Sum(MOrderQty*MPrice) as OrderValue FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om.OrderStatus in ('0','1','2','3','4','8','9','S'))
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		--Added following condition to eliminate credit notes 2016-06-07
		AND (om.DocumentType) <> 'C'
		AND DATEPART(year,om.EntrySystemDate) = DATEPART(year,GETDATE())
		AND MONTH(om.EntrySystemDate) = 10
		 group by Customer)a on a.Customer=gb.Customer 
group by CorpAcctName
)tmp