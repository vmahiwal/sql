--Job  BTP_vwKPI_Inventory_stg0_pxf

"SELECT ROW_NUMBER() OVER (ORDER BY iw.Warehouse) AS ID, GETDATE() as time,iw.Warehouse
		, iwc.Description
		, CASE WHEN RIGHT(im.ProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(im.ProductClass,2) = '02' THEN 'SM' ELSE 'OT' END as Brand
		, CASE WHEN ISNULL(invtyp.ProductClass,'') <> '' THEN invtyp.InvType ELSE 'OTHER' END as InvType
		, SUM(ROUND(iw.OpenBalQty4 * iw.OpenBalCost4,2)) as [04PeriodsBack]
		, SUM(ROUND(iw.OpenBalQty3 * iw.OpenBalCost3,2)) as [03PeriodsBack]
		, SUM(ROUND(iw.OpenBalQty2 * iw.OpenBalCost2,2)) as [02PeriodsBack]
		, SUM(ROUND(iw.OpenBalQty1 * iw.OpenBalCost1,2)) as [01PeriodsBack]
		, SUM(ROUND(iw.QtyOnHand * iw.UnitCost,2)) as CurrPeriodCost
FROM InvWarehouse iw INNER JOIN InvWhControl iwc ON iw.Warehouse = iwc.Warehouse
					 INNER JOIN InvMaster im ON iw.StockCode = im.StockCode
					 LEFT JOIN (SELECT REPLACE(KeyField,' ','') as ProductClass
										, AlphaValue as InvType
								FROM AdmFormData 
								WHERE FormType = 'ARPCL' and FieldName = 'KPI001') invtyp on im.ProductClass = invtyp.ProductClass
GROUP BY iw.Warehouse
		, iwc.Description
		, CASE WHEN RIGHT(im.ProductClass,2) ='01' THEN 'NH'
				WHEN RIGHT(im.ProductClass,2) = '02' THEN 'SM' ELSE 'OT' END
		, CASE WHEN ISNULL(invtyp.ProductClass,'') <> '' THEN invtyp.InvType ELSE 'OTHER' END"