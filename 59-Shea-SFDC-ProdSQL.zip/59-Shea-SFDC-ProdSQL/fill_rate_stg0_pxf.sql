--Fill_rate_stg0_pxf


SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, od.SalesOrder,od.SalesOrderLine,Invoice,om.Customer,CorpAcctName,InvoiceDate,od.MStockCode,od.MStockDes,EntrySystemDate,MLineShipDate,CustomerPoNumber
,SUM(QtyInvoiced) as QtyInvoiced,SUM(MOrderQty) as QtyOrdered
,MPrice
,SUM(GrossInvoiced) as GrossInvoiced,SUM(MOrderQty*MPrice) as GrossOrdered
from SorDetail od inner join SorMaster om on om.SalesOrder=od.SalesOrder
left join 
(SELECT * FROM(
select SalesOrder,Invoice,SalesOrderLine,Customer,InvoiceDate,SUM(QtyInvoiced) as QtyInvoiced, SUM(NetSalesValue+DiscValue) as GrossInvoiced
,RANK() OVER (PARTITION BY SalesOrder ORDER BY Invoice ASC) AS xRank from ArTrnDetail 
where (LineType = '1') and (NOT(Branch IN ('TR', 'CO', 'SM')))  AND (DocumentType) <> 'C' and TrnYear in (2016,2017) 
group by SalesOrder,Invoice,SalesOrderLine,Customer,InvoiceDate)hello where  xRank=1 )art  on od.SalesOrder=art.SalesOrder and od.SalesOrderLine=art.SalesOrderLine 
left join View_ArCust_GroupingData4KPI_New vw on vw.Customer=om.Customer 
where (year(EntrySystemDate)=year(getdate()) or year(EntrySystemDate)=year(getdate())-1)  AND (od.LineType = '1')  and om.OrderStatus in ('8','9') AND (om.CancelledFlag <> 'Y')
  AND (om.InterWhSale <> 'Y') 
  AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
  AND (od.LineType = '1') AND (om.DocumentType) <> 'C'

group by od.SalesOrder,od.SalesOrderLine,Invoice,om.Customer,CorpAcctName,InvoiceDate,od.MStockCode,od.MStockDes,MPrice,EntrySystemDate,MLineShipDate,CustomerPoNumber