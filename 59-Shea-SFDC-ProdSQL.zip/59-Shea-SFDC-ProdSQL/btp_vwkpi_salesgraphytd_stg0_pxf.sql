--Job - btp_vwkpi_salesgraphytd_stg0_pxf

SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, tmp.* from 
( select RecordType, TrnYear, SUM(MonthlySales) as AnnualSales
FROM BTP_vwKPI_SalesGraphMonthly
WHERE RecordType = 'A'
--WHERE RecordType = 'A' AND TrnMonth <=DATEPART(month, GETDATE())
GROUP BY RecordType, TrnYear

UNION ALL

SELECT RecordType, TrnYear, SUM(MonthlySales) as AnnualSales
FROM BTP_vwKPI_SalesGraphMonthly
WHERE RecordType = 'B'
--WHERE RecordType = 'B' AND TrnMonth <=DATEPART(month, GETDATE())
GROUP BY RecordType, TrnYear

UNION ALL

SELECT RecordType, TrnYear, SUM(MonthlySales) as AnnualSales
FROM BTP_vwKPI_SalesGraphMonthly
WHERE RecordType = 'R'
--WHERE RecordType = 'R' AND TrnMonth <=DATEPART(month, GETDATE())
GROUP BY RecordType, TrnYear

UNION ALL

SELECT 'Y', TrnYear, SUM(MonthlySales) as AnnualSales
FROM BTP_vwKPI_SalesGraphMonthly CROSS JOIN ArControl  
--WHERE RecordType = 'B' AND TrnMonth <= (CASE WHEN DATEPART(day,GETDATE()) < 25 THEN FinPeriod -1 ELSE FinPeriod END)
WHERE RecordType = 'B' AND TrnMonth <=DATEPART(month, GETDATE())
GROUP BY RecordType, TrnYear
)tmp