--Job bomsales_lab_stg0_pxf


select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,
[ParentPart]
,[Route]
,SUM(QtyPer*a.LabourCost) as WPLBR ,SUM(SetupCost+RunTimeCost) as DL ,SUM(FixOHCost) as FOH ,SUM(QtyPer*a.FixOverhead) as WPOH
,SUM(LineCost) as TotBomC
,SUM(QtyPer*a.MaterialCost) as WPMAT ,SUM((QtyPer*a.LabourCost)
+SetupCost+RunTimeCost
+FixOHCost
+(QtyPer*a.FixOverhead)) as TotLabOHC
,iv.ProductClass,iv.ProductGroup,iv.Description From View_BomCosting a
left join InvMaster iv on a.ParentPart = iv.StockCode
where StockUom='EA'
group by ParentPart,Route,ProductClass,ProductGroup,iv.Description

