--Job - Cut_Orders_stg0_pxf


SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, temp.* from(

SELECT 
'LostSales' as Grouping,CorpAcctName,ar.* from (
SELECT        dbo.SorDetail.SalesOrder, dbo.SorDetail.SalesOrderLine, dbo.SorDetail.MStockCode, dbo.SorDetail.MStockDes, 
                         dbo.SorDetail.MOrderQty, dbo.SorDetail.MPrice, case when OrderStatus in ('0','1','2','3','4') then '1' else dbo.SorMaster.OrderStatus end as OrderStatus, CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END AS DispQty, CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END AS QtyInvoiced, 
                         (CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END) AS QtyShipped, dbo.SorDetail.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) AS QtyLost, 
                         (dbo.SorDetail.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END))) * dbo.SorDetail.MPrice AS LostSales, dbo.SorMaster.Branch, dbo.SorMaster.Customer, 
                         dbo.SorMaster.CustomerName, dbo.SorMaster.OrderDate,dbo.SorMaster.EntrySystemDate, dbo.SorDetail.MLineShipDate, '' as CancelledReason
FROM            dbo.SorDetail INNER JOIN
                         dbo.SorMaster ON dbo.SorDetail.SalesOrder = dbo.SorMaster.SalesOrder LEFT OUTER JOIN
                         dbo.ArCustomer ON dbo.SorMaster.Customer = dbo.ArCustomer.Customer LEFT OUTER JOIN
                             (SELECT        SalesOrder, SalesOrderLine, SUM(QtyInvoiced) AS QtyInvoiced
                               FROM            dbo.ArTrnDetail
                               GROUP BY SalesOrder, SalesOrderLine) AS derivedtbl_2 ON dbo.SorDetail.SalesOrder = derivedtbl_2.SalesOrder AND 
                         dbo.SorDetail.SalesOrderLine = derivedtbl_2.SalesOrderLine LEFT OUTER JOIN
                             (SELECT        dbo.MdnDetail.SalesOrder, dbo.MdnDetail.SalesOrderLine, SUM(dbo.MdnDetail.MQtyToDispatch) AS DispQty
                               FROM            dbo.MdnDetail INNER JOIN
                                                         dbo.MdnMaster ON dbo.MdnDetail.DispatchNote = dbo.MdnMaster.DispatchNote
                               WHERE        (NOT (dbo.MdnMaster.DispatchNoteStatus IN ('9', '*')))
                               GROUP BY dbo.MdnDetail.SalesOrder, dbo.MdnDetail.SalesOrderLine) AS derivedtbl_1 ON dbo.SorDetail.SalesOrder = derivedtbl_1.SalesOrder AND 
                         dbo.SorDetail.SalesOrderLine = derivedtbl_1.SalesOrderLine
WHERE        (dbo.SorDetail.LineType = '1') AND (dbo.SorMaster.OrderStatus = '9') AND InterWhSale<>'Y' AND (dbo.SorDetail.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) > 0) AND 
                         (NOT (dbo.SorMaster.OrderType IN ('C', 'D'))) AND year(dbo.SorDetail.MLineShipDate) in ( year(GETDATE()),year(getdate())-1)

) ar
LEFT JOIN 
			View_ArCust_GroupingData4KPI_New c on c.Customer=ar.Customer 

			UNION
			SELECT 'Cancelled Order' as Grouping,cacm.CorpAcctName,om.SalesOrder,od.SalesOrderLine, MStockCode, MStockDes,od.MOrderQty,
			od.MPrice, case when Reason in ('1','12','6') then 'Customer Request(CR)' when Reason in ('10','17') then 'No Inventory(NI)' when Reason in ('2','TEST') then 'EDI Reprocessed(ER)' else 'OTHER/Historical' end as OrderStatus,0 as DispQty,0 as QtyInvoiced,0 as QtyShipped,0 as QtyLost,MOrderQty*MPrice as LostSales,
			om.Branch,om.Customer,om.CustomerName, OrderDate, EntrySystemDate,   MLineShipDate, tr.Description as CancelledReason
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder 
LEFT JOIN 
			View_ArCust_GroupingData4KPI_New cacm on cacm.Customer=om.Customer left join [SysproCompanyB].[dbo].[SorCancelled] on om.SalesOrder=SorCancelled.SalesOrder and od.SalesOrderLine=SorCancelled.SalesOrderLine
  left join TblSoReason tr on tr.ReasonCode=SorCancelled.Reason
WHERE 
   (om.CancelledFlag = 'Y') AND InterWhSale<>'Y' 
  AND (od.LineType = '1')
  AND year(MLineShipDate)in ( year(GETDATE()),year(getdate())-1)
  UNION
			SELECT 'Back Order' as Grouping,cacm.CorpAcctName,om.SalesOrder,od.SalesOrderLine, MStockCode, MStockDes,od.MOrderQty,
			od.MPrice, case when OrderStatus in ('0','1','2','3','4') then '1' else OrderStatus end as OrderStatus,CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END AS DispQty, CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END AS QtyInvoiced, 
                         (CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END) AS QtyShipped, od.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) AS QtyLost, 
                         (od.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END))) * od.MPrice AS LostSales,
			om.Branch,om.Customer,om.CustomerName, OrderDate, EntrySystemDate,   MLineShipDate, '' as CancelledReason
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder LEFT OUTER JOIN
                             (SELECT        SalesOrder, SalesOrderLine, SUM(QtyInvoiced) AS QtyInvoiced
                               FROM            dbo.ArTrnDetail
                               GROUP BY SalesOrder, SalesOrderLine) AS derivedtbl_2 ON od.SalesOrder = derivedtbl_2.SalesOrder AND 
                         od.SalesOrderLine = derivedtbl_2.SalesOrderLine LEFT OUTER JOIN
                             (SELECT        dbo.MdnDetail.SalesOrder, dbo.MdnDetail.SalesOrderLine, SUM(dbo.MdnDetail.MQtyToDispatch) AS DispQty
                               FROM            dbo.MdnDetail INNER JOIN
                                                         dbo.MdnMaster ON dbo.MdnDetail.DispatchNote = dbo.MdnMaster.DispatchNote
                               WHERE        (NOT (dbo.MdnMaster.DispatchNoteStatus IN ('9', '*')))
                               GROUP BY dbo.MdnDetail.SalesOrder, dbo.MdnDetail.SalesOrderLine) AS derivedtbl_1 ON od.SalesOrder = derivedtbl_1.SalesOrder AND 
                         od.SalesOrderLine = derivedtbl_1.SalesOrderLine
LEFT JOIN 
(select SalesOrder,count(DispatchNote) as DispatchCount from MdnMaster group by SalesOrder)mm on mm.SalesOrder=om.SalesOrder 
LEFT JOIN 
			View_ArCust_GroupingData4KPI_New cacm on cacm.Customer=om.Customer
			WHERE 
   (om.CancelledFlag <> 'Y') AND InterWhSale<>'Y' 
  AND (od.LineType = '1')  AND om.OrderStatus in ('0','1','2','3','4','S')
   and mm.DispatchCount>=1
  AND (od.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) > 0)

						 UNION
			SELECT 'Past Due' as Grouping,cacm.CorpAcctName,om.SalesOrder,od.SalesOrderLine, MStockCode, MStockDes,od.MOrderQty,
			od.MPrice, case when OrderStatus in ('0','1','2','3','4') then '1' else OrderStatus end as OrderStatus,CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END AS DispQty, CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END AS QtyInvoiced, 
                         (CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END) AS QtyShipped, od.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) AS QtyLost, 
                         (od.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END))) * od.MPrice AS LostSales,
			om.Branch,om.Customer,om.CustomerName, OrderDate, EntrySystemDate,   MLineShipDate, '' as CancelledReason
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder LEFT OUTER JOIN
                             (SELECT        SalesOrder, SalesOrderLine, SUM(QtyInvoiced) AS QtyInvoiced
                               FROM            dbo.ArTrnDetail
                               GROUP BY SalesOrder, SalesOrderLine) AS derivedtbl_2 ON od.SalesOrder = derivedtbl_2.SalesOrder AND 
                         od.SalesOrderLine = derivedtbl_2.SalesOrderLine LEFT OUTER JOIN
                             (SELECT        dbo.MdnDetail.SalesOrder, dbo.MdnDetail.SalesOrderLine, SUM(dbo.MdnDetail.MQtyToDispatch) AS DispQty
                               FROM            dbo.MdnDetail INNER JOIN
                                                         dbo.MdnMaster ON dbo.MdnDetail.DispatchNote = dbo.MdnMaster.DispatchNote
                               WHERE        (NOT (dbo.MdnMaster.DispatchNoteStatus IN ('9', '*')))
                               GROUP BY dbo.MdnDetail.SalesOrder, dbo.MdnDetail.SalesOrderLine) AS derivedtbl_1 ON od.SalesOrder = derivedtbl_1.SalesOrder AND 
                         od.SalesOrderLine = derivedtbl_1.SalesOrderLine
LEFT JOIN 
(select SalesOrder,count(DispatchNote) as DispatchCount from MdnMaster group by SalesOrder)mm on mm.SalesOrder=om.SalesOrder 
LEFT JOIN 
			View_ArCust_GroupingData4KPI_New cacm on cacm.Customer=om.Customer
			WHERE 
   (om.CancelledFlag <> 'Y') AND InterWhSale<>'Y' 
  AND (od.LineType = '1')  AND om.OrderStatus in ('0','1','2','3','4','S')
  AND (MLineShipDate <= GETDATE()-1) and mm.DispatchCount is null
  AND (od.MOrderQty - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) > 0)
  
  
  )temp