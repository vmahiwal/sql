--Target_openVsavailable_stg0_pxf

SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,
StockUom,im.StockCode,DrawOfficeNum,Description,im.AbcClass as ProductClass,StockOnHold,
SUM(OpenOrderQty) as OpenOrderQty, SUM(OpenOrderValue) as OpenOrderValue,SUM(TotalOpenOrderQty) as TotalOpenOrderQty, SUM(TotalOpenOrderValue) as TotalOpenOrderValue,
SUM(OrdersThisWeek) as OrdersThisWeek, SUM(OrdersThisWeekValue) as OrdersThisWeekValue,
SUM(OrdersLastWeek) as OrdersLastWeek, SUM(OrdersLastWeekValue) as OrdersLastWeekValue,
SUM(QtyOnHand) as QtyOnHand,SUM(QCOnHand) as QCOnHand,
SUM(E4OnHand) as EmersonOnHand, 
Sum(XFGOnHand) as XFGOnHand,Sum(XFG.XFGQtyInTransit) as XFGQtyInTransit,
Sum(XQCOnHand) as XQCOnHand,Sum(XQC.XQCQtyInransit) as XQCQtyInTransit,
SUM(fcst.FcstQtyMnt1) as FcstQtyMnt1,
SUM(fcst.FcstQtyMnt2) as FcstQtyMnt2,
SUM(fcst.FcstQtyMnt3) as FcstQtyMnt3,

SUM(fcst.JanJunNextYear) as JanJunNextYear
,Component as WP,SUM(WP.WPOnHand) as WPQtyOnHand,SUM(WPQtyOnOrder) as WPQtyOnOrder, WarehouseToUse,im.AbcClass
 from InvMaster im  
 left join (select StockCode,SUM(QtyOnHand) as QCOnHand from InvWarehouse where Warehouse='QC' group by StockCode) QC on QC.StockCode=im.StockCode
 left join (select StockCode,SUM(QtyOnHand) as QtyOnHand from InvWarehouse where Warehouse not in ('QC','Z9','E4') group by StockCode) F2 on F2.StockCode=im.StockCode
 left join (select StockCode,SUM(QtyOnHand) as E4OnHand from InvWarehouse where Warehouse='E4' group by StockCode) E4 on E4.StockCode=im.StockCode
 left join ( select StockCode,SUM(QtyOnHand) as XFGOnHand,  Sum(QtyInTransit) as XFGQtyInTransit from InvWarehouse where Warehouse='XFG' group by StockCode) XFG on XFG.StockCode=im.StockCode
left join ( select StockCode,SUM(QtyOnHand) as XQCOnHand,  Sum(QtyInTransit) as XQCQtyInransit from InvWarehouse where Warehouse='XQC' group by StockCode) XQC on XQC.StockCode=im.StockCode

 left join (select MStockCode,SUM(od.MShipQty + od.MBackOrderQty) as OpenOrderQty,SUM((od.MShipQty + od.MBackOrderQty)*MPrice) as OpenOrderValue,
  SUM(case when datepart(week,EntrySystemDate)=datepart(week,getdate())
 then (od.MShipQty + od.MBackOrderQty) else 0 end) as OrdersThisWeek,SUM(case when datepart(week,EntrySystemDate)=datepart(week,getdate())
 then (od.MShipQty + od.MBackOrderQty)*MPrice else 0 end) as OrdersThisWeekValue,
  SUM(case when datepart(week,EntrySystemDate)=datepart(week,getdate())-1
 then (od.MShipQty + od.MBackOrderQty) else 0 end) as OrdersLastWeek,  SUM(case when datepart(week,EntrySystemDate)=datepart(week,getdate())-1
 then (od.MShipQty + od.MBackOrderQty)*MPrice else 0 end) as OrdersLastWeekValue
  
 from SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
 left join View_ArCust_GroupingData4KPI_New arc on arc.Customer=om.Customer
 where (om.OrderStatus in ('0','1','2','3','4','S')) 
AND (om.CancelledFlag <> 'Y')
AND (om.InterWhSale <> 'Y') 
AND (od.LineType = '1')
AND (om.DocumentType) <> 'C'
AND ((od.MShipQty + MBackOrderQty) <> 0 and CorpAcctName like '%TARGET%') group by MStockCode)BO on BO.MStockCode=im.StockCode 

left join (select MStockCode,SUM(od.MShipQty + od.MBackOrderQty) as TotalOpenOrderQty,SUM((od.MShipQty + od.MBackOrderQty)*MPrice) as TotalOpenOrderValue
 from SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder
 where (om.OrderStatus in ('0','1','2','3','4','S')) 
AND (om.CancelledFlag <> 'Y')
AND (om.InterWhSale <> 'Y') 
AND (od.LineType = '1')
AND (om.DocumentType) <> 'C'
AND ((od.MShipQty + MBackOrderQty) <> 0) group by MStockCode)AllOpenOrders on AllOpenOrders.MStockCode=im.StockCode 

 left join (select distinct ParentPart, Component from BomStructure where left(Component,2)='WP') BM on BM.ParentPart=im.StockCode
 left join (SELECT [StockCode]
      , SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(GETDATE())), GETDATE()), 101) AND 
                      ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 1, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt1
      , SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 1, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 2, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt2
      ,SUM(CAST(CASE WHEN ForecastType = 'S' AND (ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 2, GETDATE())), 
                      101) AND ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 3, GETDATE())), 101)) 
                      THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt3
    
,   SUM(CAST(CASE WHEN ForecastType = 'S' AND Year(ForecastDate) = Year(Getdate())+1 AND Month(ForecastDate) 
                      <=6 THEN dbo.MrpForecast.ForecastQtyOutst + dbo.MrpForecast.QtyInvoiced ELSE 0 END AS Decimal(12, 0))) AS JanJunNextYear
  FROM dbo.MrpForecast left join View_ArCust_GroupingData4KPI_New arc on arc.Customer=dbo.MrpForecast.Customer
  where CorpAcctName like '%TARGET%' and 
   (dbo.MrpForecast.ForecastDate > CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(M, - 12, GETDATE()))), DATEADD(M, - 12, GETDATE())), 101)) AND 
                      (dbo.MrpForecast.ForecastDate <= CONVERT(varchar, DATEADD(d, - (1 * DAY(DATEADD(m, 1, GETDATE()))), DATEADD(m, 12, GETDATE())), 101)) group by StockCode) fcst on fcst.StockCode=im.StockCode

  left join (select StockCode,SUM(QtyOnHand) as WPOnHand,SUM(QtyOnOrder) as WPQtyOnOrder from InvWarehouse group by StockCode) WP on WP.StockCode=BM.Component
 where 
  (OpenOrderQty>0 or OrdersLastWeek>0 or OrdersThisWeek>0  or FcstQtyMnt1>0 or FcstQtyMnt2>0 )
 group by StockUom,im.StockCode,DrawOfficeNum, Description,im.ProductClass,StockOnHold,Component,WarehouseToUse,im.AbcClass