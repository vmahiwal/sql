--Job --kpi_production8week_stg0_pxf


SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,
jr.TrnDate, sum(jr.QtySupplied) as Production,jm.Warehouse
FROM WipPartBook jr INNER JOIN WipMaster jm ON jr.Job = jm.Job
INNER JOIN InvMaster im on jm.StockCode = im.StockCode
--Modified 2016-08-29 based on email from Paul Biondi forwarded by Avani Patel
--WHERE jm.Warehouse IN ('F1','F2','F3')
-- AND DATEPART(year,jr.TrnDate) = DATEPART(year,GETDATE())
-- AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
-- AND LEFT(im.ProductClass, 2) <> 'SO'
-- AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'HC03', 'SC03', 'SC04', 'S001', 'S002'))
WHERE jm.Warehouse IN ('F1','F2','F3','QC')
AND jr.TrnDate>=dateadd(DAY,-90,GETDATE())
AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
AND LEFT(im.ProductClass, 2) <> 'SO'
AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
group by jr.TrnDate,jm.Warehouse