--Job : BTP_vwKPI_OrdersByCorpAcct_stg0_pxf


SELECT GETDATE() as time,cacm.CorpAcctName
    	, SUM(CASE WHEN od.MLineShipDate <= GETDATE() 
			THEN ROUND(((od.MShipQty + od.MBackOrderQty) * od.MPrice) ,2)
			ELSE 0 END) as CurrMonthToDate
		, SUM(CASE WHEN (DATEPART(day,od.MLineShipDate) <= 25 AND DATEPART(month, od.MLineShipDate) = DATEPART(month, GETDATE()) AND DATEPART(year, od.MLineShipDate) = DATEPART(year, GETDATE()))
			THEN ROUND(((od.MShipQty + od.MBackOrderQty) * od.MPrice) ,2)
			ELSE 0 END) as CurrMonthThru25
		, SUM(CASE WHEN od.MLineShipDate > GETDATE() AND DATEPART(year, od.MLineShipDate) = DATEPART(year, GETDATE()) and DATEPART(month, od.MLineShipDate) = DATEPART(month, GETDATE())
		    THEN ROUND(((od.MShipQty + od.MBackOrderQty) * od.MPrice) ,2)
			ELSE 0 END) as CurrMonthRemain
		, SUM(CASE WHEN (DATEPART(year, od.MLineShipDate) = DATEPART(year, GETDATE()) and DATEPART(month, od.MLineShipDate) = DATEPART(month, GETDATE())) or (od.MLineShipDate <= GETDATE())
		    THEN ROUND(((od.MShipQty + od.MBackOrderQty) * od.MPrice) ,2)
			ELSE 0 END) as CurrMonthTotal
		, SUM(CASE WHEN od.MLineShipDate > EOMONTH(GETDATE()) THEN ROUND(((od.MShipQty + od.MBackOrderQty) * od.MPrice) ,2) ELSE 0 END) as FutureMonthTotal
		, 0 as Picked
		, SUM(ROUND(((od.MShipQty + od.MBackOrderQty) * od.MPrice) ,2)) as TotalOpenOrders
		, EOMONTH(GETDATE()) as MonthEnd
	
FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder 
					LEFT JOIN (SELECT KeyField as Customer
									, AlphaValue as CorpAcctCode
								FROM AdmFormData
								WHERE FormType = 'CUS' and FieldName = 'COR002') cac ON om.Customer = cac.Customer
					LEFT JOIN (SELECT Item as CorpAcctCode
									, Description as CorpAcctName
								FROM AdmFormValidation
								WHERE FormType = 'CUS' and FieldName = 'COR002') cacm on cac.CorpAcctCode = cacm.CorpAcctCode

WHERE (om.OrderStatus in ('0','1','2','3','4','S')) 
		AND (om.CancelledFlag <> 'Y')
		AND (om.InterWhSale <> 'Y') 
		AND (NOT(om.Branch IN ('TR', 'CO', 'SM'))) 
		AND (od.LineType = '1')
		
		AND (om.DocumentType) <> 'C'
	
				AND NOT (om.Customer IN ('000000000048869','000000000049870'))
		AND ((od.MShipQty + MBackOrderQty) <> 0)
GROUP BY cacm.CorpAcctName

UNION ALL

SELECT GETDATE() as time,cacm.CorpAcctName
		, 0 as Today
		, 0 as Thru25
		, 0 as WTD
		, 0 as MTD
		, 0 as QTD
		, SUM(ROUND(bo.ShipQty * od.MPrice, 2)) as Picked
		, 0 as YTD
		, EOMONTH(GETDATE()) as MonthEnd
FROM              Barcode.dbo.Orders bo INNER JOIN SysproCompanyB.dbo.SorDetail od 
								ON SUBSTRING(od.SalesOrder, PATINDEX('%[^0 ]%', od.SalesOrder + ' '), LEN(od.SalesOrder)) = SUBSTRING(bo.OrderNo, PATINDEX('%[^0 ]%', bo.OrderNo + ' '), LEN(bo.OrderNo)) COLLATE Latin1_General_BIN 
														AND od.MStockCode = bo.ItemNo COLLATE Latin1_General_BIN 
											AND od.SalesOrderLine = bo.LineNumber
										INNER JOIN SysproCompanyB.dbo.SorMaster om
											ON od.SalesOrder = om.SalesOrder
										LEFT JOIN (SELECT REPLACE(KeyField,' ','') as Customer
															, AlphaValue as CorpAcctCode
													FROM AdmFormData
													WHERE FormType = 'CUS' and FieldName = 'COR002') cac ON om.Customer = cac.Customer
										LEFT JOIN (SELECT Item as CorpAcctCode
															, Description as CorpAcctName
													FROM AdmFormValidation
													WHERE FormType = 'CUS' and FieldName = 'COR002') cacm on cac.CorpAcctCode = cacm.CorpAcctCode
WHERE (NOT(om.Branch IN ('TR', 'CO', 'SM')))

				AND NOT (om.Customer IN ('000000000048869','000000000049870'))
GROUP BY cacm.CorpAcctName