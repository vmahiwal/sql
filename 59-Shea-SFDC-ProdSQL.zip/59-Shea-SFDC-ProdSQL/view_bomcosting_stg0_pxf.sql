--Job view_bomcosting_stg0_pxf


select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,
[ParentPart]
,[Route]
,[Comp/Wc]
,a.Description as CompDescription
,[QtyPer] ,a.[MaterialCost]
,iv.ProductClass,iv.ProductGroup,iv.Description
From View_BomCosting a
left join InvMaster iv on a.ParentPart = iv.StockCode
where StockUom='EA'