select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
    "ShipAddress4","EntrySystemDate","CorpAcctName","Customer","CustomerName", "SalesOrder","OrderStatus","MStockCode",ShipPostalCode,
     "CustomerPoNumber","OrderDate","ReqShipDate",	"DateValue",MOrderQty,"MPrice","CustomerClass","ProductClass",	"ProductGroup",
	 "StockUom",DispatchCount,"MWarehouse", "AlphaValue"  
from
    (select 
     om."ShipAddress4","EntrySystemDate","CorpAcctName", om."Customer", om."CustomerName", om."SalesOrder", "OrderStatus", od."MStockCode",
	 case when (ltrim(om."ShipPostalCode",0) ~'^([0-9]+.?[0-9]*|.[0-9]+)$' )= 't' 
	 then  ltrim(om."ShipPostalCode",0)else 'f' end as ShipPostalCode,
     "CustomerPoNumber","OrderDate","ReqShipDate" ,a."DateValue",	("MBackOrderQty"+"MShipQty") as MOrderQty,"MPrice","CustomerClass",
	 "ProductClass","ProductGroup","StockUom",DispatchCount,od."MWarehouse",b."AlphaValue"  from sysprocompanyb.sormastermain_stg0_gp  om 
   left join sysprocompanyb.sordetailmain_stg0_gp  od on om."SalesOrder"=od."SalesOrder" left join 
   (select * from sysprocompanyb.admformdatamain_stg0_gp  where "FieldName"='DEL001')a on a."KeyField"=om."SalesOrder" 
   left join sysprocompanyb.arcustomermain_stg0_gp  vw on om."Customer"=vw."Customer" 
   left join sysprocompanyb.invmastermain_stg0_gp  im on od."MStockCode"=im."StockCode" 
   left join (select "SalesOrder",count("DispatchNote") as DispatchCount from sysprocompanyb.mdnmastermain_stg0_gp group by "SalesOrder")mm on mm."SalesOrder"=om."SalesOrder" 
   left join (select * from sysprocompanyb.admformdatamain_stg0_gp  where "FieldName"='WHCOMM' and "FormType" = 'ORD')b on b."KeyField"=om."SalesOrder"
    where (om."OrderStatus" in ('0','1','2','3','4','S')) 
	AND (om."DocumentType") is distinct from 'C' and (om."CancelledFlag" is distinct from 'Y') 
    AND (om."InterWhSale" is distinct from 'Y') AND (od."LineType" = '1') 
    AND ((od."MShipQty" + "MBackOrderQty") is distinct from 0) and "CorpAcctName" not like  '%SAMPLES%'
    
    
union all (select 'NY' as ShipAddress4, CURRENT_DATE as EntrySystemDate,Description as CorpAcctName,'0000000' as Customer,'Invoiced' as CustomerName,
	  '000000' as SalesOrder,'*' as OrderStatus, '' as MStockCode, null as ShipPostalCode, '' as CustomerPoNumber, CURRENT_DATE as OrderDate,  CURRENT_DATE as ReqShipDate,
	  CURRENT_DATE as DateValue, MTD as MOrderQty, 1 as MPrice,  'XX' as CustomerClass, 'ABC' as ProductClass, 'XYZ' as ProductGroup,  'CS' as StockUom,
	  null as DispatchCount, 'F2' as MWarehouse, '' as AlphaValue
      from  
     (SELECT '01' as Sequence
		, 'Dispatched:Awaiting Invoicing' as Description
		, SUM(ROUND(dd."MQtyToDispatch" * dd."MPrice",2)) as Today
		, SUM(ROUND(dd."MQtyToDispatch" * dd."MPrice",2)) as WTD
		, SUM(ROUND(dd."MQtyToDispatch" * dd."MPrice",2)) as MTD
		, SUM(ROUND(dd."MQtyToDispatch" * dd."MPrice",2)) as QTD
		, SUM(ROUND(dd."MQtyToDispatch" * dd."MPrice",2)) as YTD
FROM            sysprocompanyb.mdndetailmain_stg0_gp   dd INNER JOIN
                       sysprocompanyb.mdnmastermain_stg0_gp  dm ON dd."DispatchNote" = dm."DispatchNote"
WHERE        (dd."LineType" = '1') AND (dm."DispatchNoteStatus" is distinct from '*') AND (dm."DispatchNoteStatus" is distinct from '9') 
AND (dd."DispatchStatus" is distinct from '*') and ("Branch" is distinct from  'TR' and "Branch" is distinct from 'CO' and "Branch" is distinct from 'SM')
				--2016-12-14 Next Line To Exclude Raw Material Customers
				AND (dm."Customer" is distinct from '000000000048869'and dm."Customer" is distinct from '000000000049870')

UNION ALL

--Removed Net section 2016-03-08
SELECT '02' as Sequence
		, 'Invoiced Before Chargebacks' as Description
		, SUM(CASE WHEN DATE_PART('doy',"InvoiceDate") = DATE_PART('doy',now()) THEN ("NetSalesValue" + "DiscValue") ELSE 0 END) as TodayGross
		--, SUM(CASE WHEN DATEPART(dayofyear,InvoiceDate) = DATEPART(dayofyear,GETDATE()) THEN NetSalesValue ELSE 0 END) as TodayNet
		, SUM(CASE WHEN DATE_PART('week',"InvoiceDate") = DATE_PART('week',now()) THEN ("NetSalesValue" + "DiscValue") ELSE 0 END) as WTDGross
		--, SUM(CASE WHEN DATEPART(week,InvoiceDate) = DATEPART(week,GETDATE()) THEN NetSalesValue ELSE 0 END) as WTDNet
		--, SUM(CASE WHEN DATEPART(month,InvoiceDate) = DATEPART(month,GETDATE()) THEN (NetSalesValue + DiscValue) ELSE 0 END) as MTDGross
		, SUM(CASE WHEN "TrnMonth" = DATE_PART('month',now()) THEN ("NetSalesValue" + "DiscValue") ELSE 0 END) as MTDGross
		--, SUM(CASE WHEN DATEPART(month,InvoiceDate) = DATEPART(month,GETDATE()) THEN NetSalesValue ELSE 0 END) as MTDNet
		--, SUM(CASE WHEN TrnMonth = DATEPART(month,GETDATE()) THEN NetSalesValue ELSE 0 END) as MTDNet
		--, SUM(CASE WHEN DATEPART(quarter,InvoiceDate) = DATEPART(quarter,GETDATE()) THEN (NetSalesValue + DiscValue) ELSE 0 END) as QTDGross
		, SUM(CASE WHEN (CASE WHEN "TrnMonth" BETWEEN 1 AND 3 THEN 1
					WHEN "TrnMonth" BETWEEN 4 AND 6 THEN 2
					WHEN "TrnMonth" BETWEEN 7 AND 9 THEN 3
					WHEN "TrnMonth" BETWEEN 10 and 12 THEN 4 ELSE 0 END) = DATE_PART('quarter',now()) THEN ("NetSalesValue" + "DiscValue") ELSE 0 END) as QTDGross
		--, SUM(CASE WHEN DATEPART(quarter,InvoiceDate) = DATEPART(quarter,GETDATE()) THEN NetSalesValue ELSE 0 END) as QTDNet
		--, SUM(CASE WHEN (CASE WHEN TrnMonth BETWEEN 1 AND 3 THEN 1
		--			WHEN TrnMonth BETWEEN 4 AND 6 THEN 2
		--			WHEN TrnMonth BETWEEN 7 AND 9 THEN 3
		--			WHEN TrnMonth BETWEEN 10 and 12 THEN 4 ELSE 0 END) = DATEPART(quarter,GETDATE()) THEN NetSalesValue ELSE 0 END) as QTDNet
		, SUM(("NetSalesValue" + "DiscValue")) as YTDGross
		--, SUM(NetSalesValue) as YTDNet
FROM sysprocompanyb.artrndetailmain_stg0_gp 
--WHERE (LineType = '1') AND (DATEPART(year, InvoiceDate) = DATEPART(year,GETDATE())) AND (NOT(Branch IN ('TR', 'CO', 'SM')))
WHERE ("LineType" = '1') AND ("TrnYear" = DATE_PART('year',now())) AND ("Branch" is distinct from  'TR' and "Branch" is distinct from 'CO' and "Branch" is distinct from 'SM') 
		--Added following condition to eliminate credit notes 2016-06-07
		AND ("DocumentType") is distinct from 'C'
		--2016-12-14 Next Line To Exclude Raw Material Customers
				AND ("Customer" is distinct from '000000000048869'and "Customer" is distinct from '000000000049870'))a1))a
