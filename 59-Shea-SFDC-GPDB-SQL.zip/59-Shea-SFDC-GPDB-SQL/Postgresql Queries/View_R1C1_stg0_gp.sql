select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time
,    InvM."StockCode", 
              InvM."Description", 
	      InvM."WarehouseToUse", 
              InvM."LeadTime", 
              InvWh."QtyOnOrder", 
              InvWh."QtyOnHand", 
	      InvWh."QtyAllocatedWip", 
	      InvWh."SafetyStockQty", 
              InvWarehouse_SumByStockCode .C2QtyOnHand + InvWarehouse_SumByStockCode.R2QtyOnHand AS C2R2QtyOnHand, 
              InvWarehouse_SumByStockCode .QtyOnHand AS QtyOnHandAllWHs, 
	      InvWarehouse_SumByStockCode .QtyOnOrder AS QtyOnOrderAllWhs, 
              InvWh."QtyOnHand" +InvWh."QtyOnOrder" -InvWh."QtyAllocatedWip" AS FutureFree, 
              InvWh."QtyOnHand" -InvWh."QtyAllocatedWip" AS "[OH<WP]", 
              CASE WHEN InvWarehouse_SumByStockCode.QtyOnHand <InvWh."SafetyStockQty" THEN 1 
              ELSE 0 END AS "[NEED FOR STOCK]", 
              CASE WHEN (InvWh."QtyOnHand" +InvWh."QtyOnOrder" -InvWh."QtyAllocatedWip") <InvWh."SafetyStockQty" THEN 2 
              ELSE 0 END AS "[FF<SS]", 
              CASE WHEN (InvWh."QtyOnHand" >InvWh."SafetyStockQty") AND 
              (InvWh."QtyOnHand" +InvWh."QtyOnOrder" -InvWh."QtyAllocatedWip") >InvWh."SafetyStockQty" THEN 0 
              ELSE 3 END AS Column2, 
              CASE WHEN (InvWarehouse_SumByStockCode.QtyOnHand +InvWh."QtyOnOrder") 
              <InvWh."SafetyStockQty" THEN 'PLACE PO' ELSE 'NO' END AS "[NEED PO]",
              CASE WHEN CurrMnt IS NULL THEN 0 ELSE CurrMnt END AS CurrMnt, 
              CASE WHEN FutMnt1 IS NULL THEN 0 ELSE FutMnt1 END AS FutMnt1, 
              CASE WHEN FutMnt2 IS NULL THEN 0 ELSE FutMnt2 END AS FutMnt2, 
              CASE WHEN Last30Days IS NULL THEN 0 ELSE Last30Days END AS I30Days, 
              CASE WHEN Last60Days IS NULL THEN 0 ELSE Last60Days END AS I60Days, 
              CASE WHEN Last90Days IS NULL THEN 0 ELSE Last90Days END AS I90Days, 
              CASE WHEN Last120Days IS NULL THEN 0 ELSE Last120Days END AS I120Days, 
              CASE WHEN Last365Days IS NULL THEN 0 ELSE Last365Days END AS I365Days, 
              CASE WHEN Last730Days IS NULL THEN 0 ELSE Last730Days END AS I730Days,
              CASE WHEN GrnDetails_SumByStockCode.QtyReceived IS NULL THEN 0 
              ELSE GrnDetails_SumByStockCode.QtyReceived END AS QtyReceived,
              CASE WHEN ToDate IS NULL THEN 0 ELSE ToDate END AS IToDate, 
              CASE WHEN "[30Days]" IS NULL THEN 0 ELSE "[30Days]" END AS "[30Days]", 
              CASE WHEN "[60Days]" IS NULL THEN 0 ELSE "[60Days]" END AS "[60Days]", 
              CASE WHEN "[90Days]" IS NULL THEN 0 ELSE "[90Days]" END AS "[90Days]", 
              CASE WHEN "[120Days]" IS NULL THEN 0 ELSE "[120Days]" END AS "[120Days]", 
              CASE WHEN "[365Days]" IS NULL THEN 0 ELSE "[365Days]" END AS "[365Days]", 
              GrnDetails_RankByStockCode."PurchaseOrder",
	      GrnDetails_RankByStockCode."PurchaseOrderLin", 
              GrnDetails_RankByStockCode.GrnCost AS LatestReceiptCost, 
	      GrnDetails_RankByStockCode."OrigReceiptDate", 
              GrnDetails_RankByStockCode."MPrice", 
       	      WipReq_OSQtyNeeded_ByWeek.QtyNeeded, 
              WipReq_OSQtyNeeded_ByWeek.ThisWeek, 
              WipReq_OSQtyNeeded_ByWeek.NextWeek, 
              WipReq_OSQtyNeeded_ByWeek."[2ndWeek]", 
              WipReq_OSQtyNeeded_ByWeek."[3rdWeeknFut]", 
              CASE WHEN MrpSugReqs_3Mnts.OrderQty IS NULL THEN 0 ELSE MrpSugReqs_3Mnts.OrderQty END AS MrpTotQty, 
              InvM."StockUom", 
              InvM."AlternateUom", 
	      InvM."ConvFactAltUom", 
	      InvM."ConvMulDiv", 
	      InvWh."MinimumQty", 
              InvWh."MaximumQty", 
              InvWh."ReOrderQty", 
	      PoInfo.DueDt, 
	      CASE WHEN FirstPO IS NULL THEN '' ELSE FirstPO END AS FirstPO, 
              GrnDetails_RankByStockCode."Supplier", 
	      GrnDetails_RankByStockCode."SupplierName", 
              WipReq_OSQtyNeeded_ByWeek.PastDue, 
	      InvWh."Warehouse"
FROM            

              sysprocompanyb.invmastermain_stg0_gp as InvM

 LEFT OUTER JOIN  /*View_InvWarehouse_SumByStockCode in syspro*/


         (SELECT        "StockCode", 
						 SUM("QtyOnHand") AS QtyOnHand, 
						 SUM("QtyOnOrder") AS QtyOnOrder, 
						 SUM(CAST(CASE WHEN substring(RTRIM("StockCode") from '..$')  <> '01' THEN "QtyOnHand" - ("QtyAllocated" + "QtyAllocatedWip") ELSE 0 END AS Decimal(12, 0))) AS Available,
						 SUM("QtyAllocated") AS OSOrderQty, 
                                                 SUM(CAST(CASE WHEN "Warehouse" = 'F2' THEN "UnitCost" ELSE 0 END AS Decimal(12, 4))) AS F2STDCost,
						 SUM(CAST(CASE WHEN substring(RTRIM("StockCode") from '..$') <> '01' THEN "QtyOnOrder" ELSE 0 END AS Decimal(12, 0))) AS QtyOnOrderCases,
						 SUM(CAST(CASE WHEN substring(RTRIM("StockCode") from '..$') <> '01' THEN "QtyOnHand" - "QtyAllocated" ELSE 0 END AS Decimal(12, 0))) AS AvailableCases,
						 SUM("MinimumQty") AS MinimumQty,
						 SUM("SafetyStockQty")  AS SafetyStockQty, 
						 SUM(CAST(CASE WHEN "Warehouse" = 'F1' THEN "QtyOnHand" ELSE 0 END AS Decimal(12, 4))) AS F1QtyOnHand, 
                         SUM(CAST(CASE WHEN "Warehouse" = 'F2' THEN "QtyOnHand" ELSE 0 END AS Decimal(12, 4))) AS F2QtyOnHand, 
                         SUM(CAST(CASE WHEN "Warehouse" = 'F3' THEN "QtyOnHand" ELSE 0 END AS Decimal(12, 4))) AS F3QtyOnHand, 
                         SUM(CAST(CASE WHEN "Warehouse" = 'C2' THEN "QtyOnHand" ELSE 0 END AS Decimal(12, 4))) AS C2QtyOnHand, 
                         SUM(CAST(CASE WHEN "Warehouse" = 'R2' THEN "QtyOnHand" ELSE 0 END AS Decimal(12, 4))) AS R2QtyOnHand
FROM        
 
             sysprocompanyb.invwarehousemain_stg0_gp

         WHERE        ("Warehouse" <> 'Z9') AND ("Warehouse" <> 'S4') AND ("Warehouse" <> 'Z8')
                        GROUP BY "StockCode") AS InvWarehouse_SumByStockCode     
                        ON InvM."StockCode" = InvWarehouse_SumByStockCode ."StockCode" 
                        
LEFT OUTER JOIN
                       /*View_WipRequirements_OSQtyNeeded_ByWeek*/
                 
	(SELECT     wjoballm."StockCode", 
		    SUM(CAST((CASE WHEN ("QtyToMake" - "QtyManufactured") > 0 THEN (("QtyToMake" - "QtyManufactured") * wjoballm."UnitQtyReqd") 
                             - wjoballm."QtyIssued" ELSE ("QtyToMake" * wjoballm."UnitQtyReqd") - wjoballm."QtyIssued" END) AS Decimal(12, 2))) AS QtyNeeded, 
                    SUM(CAST(CASE WHEN "JobStartDate" < date_trunc('day', current_date)-'1day'::interval 
                              THEN (CASE WHEN ("QtyToMake" - "QtyManufactured") > 0 THEN (("QtyToMake" - "QtyManufactured") * wjoballm."UnitQtyReqd") 
                             - wjoballm."QtyIssued" ELSE ("QtyToMake" * wjoballm."UnitQtyReqd") - wjoballm."QtyIssued" END) ELSE 0 END AS decimal(12, 2))) AS PastDue, 
                    SUM(CAST(CASE WHEN "JobStartDate" >= date_trunc('day', current_date)-'1day'::interval  
		             AND "JobStartDate" < date_trunc('week', current_date)+'1week'-'1day'::interval THEN (CASE WHEN ("QtyToMake" - "QtyManufactured") > 0 
			     THEN (("QtyToMake" - "QtyManufactured") * wjoballm."UnitQtyReqd") - wjoballm."QtyIssued" 
                    ELSE ("QtyToMake" * wjoballm."UnitQtyReqd") - wjoballm."QtyIssued" END) 
                    ELSE 0 END AS Decimal(12, 2))) AS ThisWeek, SUM(CAST(CASE WHEN "JobStartDate" >= date_trunc('week', current_date)+'1week'-'1day'::interval 
                    AND   "JobStartDate" < date_trunc('week', current_date)+'2week'-'1day'::interval 
                            THEN (CASE WHEN ("QtyToMake" - "QtyManufactured") > 0 
                            THEN (("QtyToMake" - "QtyManufactured") * wjoballm."UnitQtyReqd") - wjoballm."QtyIssued" 
                    ELSE ("QtyToMake" * wjoballm."UnitQtyReqd") - wjoballm."QtyIssued" END) 
                    ELSE 0 END AS Decimal(12, 2))) AS NextWeek, 
                    SUM(CAST(CASE WHEN "JobStartDate">= date_trunc('week', current_date)+'2week'-'1day'::interval 
		            AND "JobStartDate" < date_trunc('week', current_date)+'3week'-'1day'::interval
                            THEN (CASE WHEN ("QtyToMake" - "QtyManufactured") > 0 
                            THEN (("QtyToMake" - "QtyManufactured") * wjoballm."UnitQtyReqd") - wjoballm."QtyIssued" 
                    ELSE ("QtyToMake" * wjoballm."UnitQtyReqd") - wjoballm."QtyIssued" END) 
                    ELSE 0 END AS Decimal(12, 2))) AS "[2ndWeek]", 
                    SUM(CAST(CASE WHEN "JobStartDate" >= date_trunc('week', current_date)+'3week'-'1day'::interval 
                            THEN (CASE WHEN ("QtyToMake" - "QtyManufactured") > 0 
                            THEN (("QtyToMake" - "QtyManufactured") * wjoballm."UnitQtyReqd") - wjoballm."QtyIssued" 
                    ELSE ("QtyToMake" * wjoballm."UnitQtyReqd") - wjoballm."QtyIssued" END) ELSE 0 END AS Decimal(12, 2))) AS "[3rdWeeknFut]"
                   
FROM  sysprocompanyb.wipjoballmatmain_stg0_gp as wjoballm INNER JOIN sysprocompanyb.wipmastermain_stg0_gp as WipM ON wjoballm."Job" = WipM."Job"
                    
		WHERE  (WipM."Complete" <> 'Y') AND (wjoballm."AllocCompleted" <> 'Y')
                 GROUP BY wjoballm."StockCode") AS WipReq_OSQtyNeeded_ByWeek 
                        ON InvM."StockCode" = WipReq_OSQtyNeeded_ByWeek."StockCode" 
       
LEFT OUTER JOIN
                     
		(SELECT        Pmd."MStockCode", 
		               MIN(Pmd."MLatestDueDate") AS DueDt, 
					   MIN(Pmh."PurchaseOrder") AS FirstPO
       FROM            sysprocompanyb.pormasterdetailmain_stg0_gp  as Pmd
INNER JOIN
                                                         sysprocompanyb.pormasterhdrmain_stg0_gp  as Pmh ON Pmd."PurchaseOrder" = Pmh."PurchaseOrder"
                               WHERE        (Pmd."LineType" = '1') AND (Pmh."OrderStatus" <> '*')
                         GROUP BY Pmd."MStockCode") AS PoInfo ON InvM."StockCode" = PoInfo."MStockCode" 
LEFT OUTER JOIN  
            /*View_MrpSugReqs_3Mnts*/
            
(  SELECT     "StockCode",
	      SUM("OrderQty") AS OrderQty,
	      SUM(CAST(CASE WHEN extract('month' from now()) = extract('month' from "DueDate") 
		      AND extract('Year' from current_date) = extract('Year' from "DueDate") 
                      THEN "OrderQty" ELSE 0 END AS Decimal(12, 2))) AS CurrMnt,
	      SUM(CAST(CASE WHEN date_part('month', current_date)+'1' = extract('month' from "DueDate") 
	              AND date_part('year', date_trunc('day',current_date)+'1month'::interval) = date_part('year', "DueDate") THEN "OrderQty" ELSE 0 END AS Decimal(12, 2))) AS FutMnt1,
	      SUM(CAST(CASE WHEN date_part('month', current_date)+'2' = extract('month' from "DueDate") AND
                      date_part('year', date_trunc('day',current_date)+'2month'::interval) = date_part('year',"DueDate") THEN "OrderQty" ELSE 0 END AS Decimal(12, 2))) AS FutMnt2

 FROM        
                 sysprocompanyb.mrpsugreqdetailmain_stg0_gp  
                 GROUP BY "StockCode")     AS MrpSugReqs_3Mnts 

  ON            InvM."StockCode" = MrpSugReqs_3Mnts."StockCode" 

  LEFT OUTER JOIN /*View_GrnDetails_RankByStockCode*/


                       (SELECT     ROW_NUMBER() OVER (PARTITION BY "StockCode"
                        ORDER BY "StockCode", "OrigReceiptDate" DESC) AS cnt, grndet."Grn",grndet."OrigGrnValue", case when grndet."QtyReceived" = 0 then 0 else 
                        cast((grndet."OrigGrnValue"/grndet."QtyReceived") as Decimal(12,4)) end as GrnCost,
                        grndet."QtyReceived", grndet."OrigReceiptDate", grndet."PurchaseOrder", grndet."PurchaseOrderLin", 
                        grndet."StockCode", pmd."MPrice", grndet."Supplier", apsup."SupplierName"
                        FROM         sysprocompanyb.grndetailsmain_stg0_gp as grndet INNER JOIN
                      sysprocompanyb.pormasterdetailmain_stg0_gp pmd ON grndet."PurchaseOrder" = pmd."PurchaseOrder" AND 
                      grndet."PurchaseOrderLin" = pmd."Line" INNER JOIN
                     sysprocompanyb.apsuppliermain_stg0_gp apsup ON grndet."Supplier" = apsup."Supplier") AS GrnDetails_RankByStockCode 
                    ON 1 = GrnDetails_RankByStockCode."cnt" AND 
                    InvM."StockCode" = GrnDetails_RankByStockCode."StockCode" 
                


LEFT OUTER JOIN  /*View_WipJobPost_SumByStockCode*/


                 (SELECT    "MStockCode", 
            SUM(CAST(CASE WHEN "TrnDate" >= date_trunc('day', current_date)-'30day'::interval THEN "MQtyIssued" ELSE 0 END AS Decimal(12, 0)))AS Last30Days, 
            SUM(CAST(CASE WHEN "TrnDate" >=  date_trunc('day', current_date)-'60day'::interval AND "TrnDate" <= date_trunc('day', current_date)-'31day'::interval THEN "MQtyIssued" ELSE 0 END AS Decimal(12, 0))) AS Last60Days, 
            SUM(CAST(CASE WHEN "TrnDate" >= date_trunc('day', current_date)-'90day'::interval AND "TrnDate" <= date_trunc('day', current_date)-'61day'::interval THEN "MQtyIssued" ELSE 0 END AS Decimal(12, 0))) AS Last90Days, 
            SUM(CAST(CASE WHEN "TrnDate" >=  date_trunc('day', current_date)-'120day'::interval AND "TrnDate" <=date_trunc('day', current_date)-'91day'::interval THEN "MQtyIssued" ELSE 0 END AS Decimal(12, 0))) AS Last120Days, 
            SUM(CAST(CASE WHEN "TrnDate" >= date_trunc('day', current_date)-'365day'::interval THEN "MQtyIssued" ELSE 0 END AS Decimal(12, 0))) AS Last365Days, 
            SUM(CAST(CASE WHEN "TrnDate" >= date_trunc('day', current_date)-'730day'::interval THEN "MQtyIssued" ELSE 0 END AS Decimal(12, 0))) AS Last730Days, SUM("MQtyIssued") AS ToDate
                        FROM   sysprocompanyb.wipjobpostmain_stg0_gp
                        WHERE  ("TrnType" = 'R')
                        GROUP BY "MStockCode")
    					AS WipJobPost_SumByStockCode 
                    ON InvM."StockCode" = WipJobPost_SumByStockCode."MStockCode"

LEFT OUTER JOIN /*View_GrnDetails_SumByStockCode */
					
							
                    (SELECT    -- TOP (100) PERCENT 
                                    "StockCode", 
			            MIN("StockDescription") AS StockDescription, 
				    "Warehouse", 
			            SUM("QtyReceived") AS QtyReceived, 
                SUM(CAST(CASE WHEN "OrigReceiptDate" >= date_trunc('day', current_date)-'30day'::interval THEN "QtyReceived" ELSE 0 END AS Decimal(12, 2))) AS "[30Days]", 
                SUM(CAST(CASE WHEN "OrigReceiptDate" BETWEEN date_trunc('day', current_date)-'60day'::interval
				AND date_trunc('day', current_date)-'31day'::interval THEN "QtyReceived" ELSE 0 END AS Decimal(12, 2))) AS "[60Days]", 
                SUM(CAST(CASE WHEN "OrigReceiptDate" BETWEEN date_trunc('day', current_date)-'90day'::interval AND date_trunc('day', current_date)-'61day'::interval 
                               THEN "QtyReceived" ELSE 0 END AS Decimal(12, 2))) AS "[90Days]", 
	        SUM(CAST(CASE WHEN "OrigReceiptDate" BETWEEN date_trunc('day', current_date)-'120day'::interval
				AND date_trunc('day', current_date)-'91day'::interval THEN "QtyReceived" ELSE 0 END AS Decimal(12, 2))) AS "[120Days]",
		SUM(CAST(CASE WHEN "OrigReceiptDate" BETWEEN date_trunc('day', current_date)-'365day'::interval AND
                                date_trunc('day', current_date)-'121day'::interval THEN "QtyReceived" ELSE 0 END AS Decimal(12, 2))) AS "[365Days]", 
		SUM(CAST(CASE WHEN "OrigReceiptDate" >= date_trunc('day', current_date)-'30day'::interval 
			       THEN "OrigGrnValue" ELSE 0 END AS Decimal(12, 2))) AS "[30DaysV]", 
		SUM(CAST(CASE WHEN "OrigReceiptDate" BETWEEN date_trunc('day', current_date)-'60day'::interval AND 
                                date_trunc('day', current_date)-'31day'::interval THEN "OrigGrnValue" ELSE 0 END AS Decimal(12, 2))) AS "[60DaysV]",
		SUM(CAST(CASE WHEN "OrigReceiptDate" BETWEEN date_trunc('day', current_date)-'90day'::interval and
				date_trunc('day', current_date)-'61day'::interval THEN "OrigGrnValue" ELSE 0 END AS Decimal(12, 2))) AS "[90DaysV]", 
	        SUM(CAST(CASE WHEN "OrigReceiptDate" BETWEEN date_trunc('day', current_date)-'120day'::interval AND date_trunc('day', current_date)-'91day'::interval
				THEN "OrigGrnValue" ELSE 0 END AS Decimal(12, 2))) AS "[120DaysV]", 
                SUM(CAST(CASE WHEN "OrigReceiptDate" BETWEEN date_trunc('day', current_date)-'365day'::interval AND date_trunc('day', current_date)-'121day'::interval 
                               THEN "OrigGrnValue" ELSE 0 END AS Decimal(12, 2))) AS "[365DaysV]"
FROM        

                 sysprocompanyb.grndetailsmain_stg0_gp 

        WHERE     ("OrigReceiptDate" >= date_trunc('day', current_date)-'365day'::interval)
        GROUP BY "StockCode",
            	 "Warehouse"
        HAVING      ("Warehouse" <> '**')

       ) AS GrnDetails_SumByStockCode 
                ON InvM."WarehouseToUse" = GrnDetails_SumByStockCode."Warehouse" AND InvM."StockCode" = GrnDetails_SumByStockCode."StockCode" 
                   
LEFT OUTER JOIN

             sysprocompanyb.invwarehousemain_stg0_gp InvWh ON InvM."StockCode" = InvWh."StockCode" AND InvM."WarehouseToUse" = InvWh."Warehouse"
WHERE                    (InvM."WarehouseToUse" = 'R1') AND 
                         (InvWh."Warehouse" <> 'Z8')  OR
                         (InvM."WarehouseToUse" = 'C1') OR
                         (InvM."WarehouseToUse" = 'C2') OR
                         (InvM."WarehouseToUse" = 'S4') OR
                         (InvM."WarehouseToUse" = 'E2') OR
                         (InvM."WarehouseToUse" = 'W1') OR
                         (InvM."WarehouseToUse" = 'R3') OR
                         (InvM."WarehouseToUse" = 'C3')
