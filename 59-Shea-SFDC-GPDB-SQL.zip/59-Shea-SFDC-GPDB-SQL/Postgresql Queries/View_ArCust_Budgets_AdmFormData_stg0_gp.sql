SELECT  ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, tmp.* from ( select
ArCustomer."Customer",ArCustomer."Name", ArCustomer."MasterAccount", ArCustomer."CustomerClass", ArCustomer."Salesperson1",
                      CASE WHEN AdmFormData_1."NumericValue" IS NULL THEN 0 ELSE AdmFormData_1."NumericValue" END AS BudMnt1, 
                      CASE WHEN AdmFormData_2."NumericValue" IS NULL THEN 0 ELSE AdmFormData_2."NumericValue" END AS BudMnt2, 
                      CASE WHEN AdmFormData_3."NumericValue" IS NULL THEN 0 ELSE AdmFormData_3."NumericValue" END AS BudMnt3, 
                      CASE WHEN AdmFormData_4."NumericValue" IS NULL THEN 0 ELSE AdmFormData_4."NumericValue" END AS BudMnt4, 
                      CASE WHEN AdmFormData_5."NumericValue" IS NULL THEN 0 ELSE AdmFormData_5."NumericValue" END AS BudMnt5, 
                      CASE WHEN AdmFormData_6."NumericValue" IS NULL THEN 0 ELSE AdmFormData_6."NumericValue" END AS BudMnt6, 
                      CASE WHEN AdmFormData_7."NumericValue" IS NULL THEN 0 ELSE AdmFormData_7."NumericValue" END AS BudMnt7, 
                      CASE WHEN AdmFormData_8."NumericValue" IS NULL THEN 0 ELSE AdmFormData_8."NumericValue" END AS BudMnt8, 
                      CASE WHEN AdmFormData_9."NumericValue" IS NULL THEN 0 ELSE AdmFormData_9."NumericValue" END AS BudMnt9, 
                      CASE WHEN AdmFormData_10."NumericValue" IS NULL THEN 0 ELSE AdmFormData_10."NumericValue" END AS BudMnt10, 
                      CASE WHEN AdmFormData_11."NumericValue" IS NULL THEN 0 ELSE AdmFormData_11."NumericValue" END AS BudMnt11, 
                      CASE WHEN sysprocompanyb.admformdatamain_stg0_gp."NumericValue" IS NULL THEN 0 ELSE sysprocompanyb.admformdatamain_stg0_gp  ."NumericValue" END AS BudMnt12
FROM        sysprocompanyb.arcustomermain_stg0_gp ArCustomer LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   ON 'BUD012' = sysprocompanyb.admformdatamain_stg0_gp  ."FieldName" AND 'CUS' = sysprocompanyb.admformdatamain_stg0_gp."FormType" AND 
                      ArCustomer."Customer" = sysprocompanyb.admformdatamain_stg0_gp."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_11 ON 'BUD011' = AdmFormData_11."FieldName" AND 'CUS' = AdmFormData_11."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_11."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_10 ON 'BUD010' = AdmFormData_10."FieldName" AND 'CUS' = AdmFormData_10."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_10."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_9 ON 'BUD009' = AdmFormData_9."FieldName" AND 'CUS' = AdmFormData_9."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_9."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_8 ON 'BUD008' = AdmFormData_8."FieldName" AND 'CUS' = AdmFormData_8."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_8."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_7 ON 'BUD007' = AdmFormData_7."FieldName" AND 'CUS' = AdmFormData_7."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_7."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_6 ON 'BUD006' = AdmFormData_6."FieldName" AND 'CUS' = AdmFormData_6."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_6."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_5 ON 'BUD005' = AdmFormData_5."FieldName" AND 'CUS' = AdmFormData_5."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_5."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_4 ON 'BUD004' = AdmFormData_4."FieldName" AND 'CUS' = AdmFormData_4."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_4."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_3 ON 'BUD003' = AdmFormData_3."FieldName" AND 'CUS' = AdmFormData_3."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_3."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_2 ON 'BUD002' = AdmFormData_2."FieldName" AND 'CUS' = AdmFormData_2."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_2."KeyField" LEFT OUTER JOIN
                      sysprocompanyb.admformdatamain_stg0_gp   AS AdmFormData_1 ON 'BUD001' = AdmFormData_1."FieldName" AND 'CUS' = AdmFormData_1."FormType" AND 
                      ArCustomer."Customer" = AdmFormData_1."KeyField"
UNION ALL
SELECT     'GL' AS GL,
 'Revenue Budget' AS Descr,
 '', '', '' as Salesperson1,
SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget1") AS JanBud, SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget2") AS FebBud, SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget3") 
                      AS MarBud, SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget4") AS AprBud, SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget5") AS MayBud, SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget6") AS JunBud, 
                      SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget7") AS JulBud, SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget8") AS AugBud, SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget9") AS SepBud, SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget10") 
                      AS OctBud, SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget11") AS NovBud, SUM(sysprocompanyb.genbudgetsmain_stg0_gp."Budget12") AS DecBud
FROM         sysprocompanyb.genbudgetsmain_stg0_gp INNER JOIN
                      sysprocompanyb.genmastermain_stg0_gp ON sysprocompanyb.genbudgetsmain_stg0_gp."Company" = sysprocompanyb.genmastermain_stg0_gp."Company" AND sysprocompanyb.genbudgetsmain_stg0_gp."GlCode" = sysprocompanyb.genmastermain_stg0_gp."GlCode"
WHERE     (sysprocompanyb.genbudgetsmain_stg0_gp."BudgetType" = 'C') AND (sysprocompanyb.genmastermain_stg0_gp."AccountType" = 'R')
GROUP BY sysprocompanyb.genmastermain_stg0_gp."AccountType" limit all
)tmp