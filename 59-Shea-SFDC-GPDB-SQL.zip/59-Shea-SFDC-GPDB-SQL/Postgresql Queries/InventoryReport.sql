
---- Inventory Report

select  ld."StockCode",im."Description","Warehouse","Lot","Bin","CreationDate","ExpiryDate", "StockUom",im."ProductClass",--sum("QtyOnHand")
Sum(case when "Warehouse" in( 'Z9','XZ9') then "QtyOnHand" end) as Restricted,
Sum(case when "Warehouse" in ('QC','XQC') then "QtyOnHand" end) as QI ,
Sum(case when "Warehouse" not in ('Z9','XZ9','XQC','QC') then "QtyOnHand" end) as UnRestricted
from sysprocompanyb.lotdetailmain_stg0_gp ld left join sysprocompanyb.invmastermain_stg0_gp im on ld."StockCode" = im."StockCode"
LEFT JOIN (SELECT REPLACE("KeyField",' ','') as ProductClass
, "AlphaValue" as InvType
FROM  sysprocompanyb.admformdatamain_stg0_gp
WHERE "FormType" = 'ARPCL' and "FieldName" = 'KPI001') invtyp on im."ProductClass" = invtyp.ProductClass

group by ld."StockCode", im."Description",
"Warehouse","Lot","Bin","ExpiryDate","StockUom","CreationDate" ,im."ProductClass"

having sum("QtyOnHand") > 0
