----ytd_orders1_stg0_gp


SELECT ROW_NUMBER() OVER (ORDER BY om."SalesOrder") AS ID, now() as time,
cacm."CorpAcctName",--

LTRIM(om."Customer",0) as Customer,
LTRIM(om."SalesOrder",0)  as SalesOrder
,
"SalesOrderLine", "OrderStatus",
LTRIM(om."Salesperson",0) as SalesPerson
,
"CustomerPoNumber", "OrderDate", "EntrySystemDate", "ReqShipDate", om."DiscPct1",
om."DiscPct2",om."DiscPct3", "MStockCode", "MStockDes", "MWarehouse",
od."MOrderQty", od."MPrice", od."MShipQty",od."MBackOrderQty"
, od."MDiscValFlag" ,od."MDiscValue",od."MDiscPct1",od."MDiscPct2",od."MDiscPct3", om."InterWhSale", om."Branch", "MLineShipDate",
om."ShipAddress3",om."ShipPostalCode",om."CancelledFlag", od."LineType", om."DocumentType", od."MProductClass", om."CustomerName"
,a."DateValue" As MABD
FROM sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp   od ON om."SalesOrder" = od."SalesOrder" 
LEFT JOIN sysprocompanyb.arcustomermain_stg0_gp cacm
on cacm."Customer" = om."Customer"
LEFT JOIN (select * from sysprocompanyb.admformdatamain_stg0_gp  where "FieldName"='DEL001')a on a."KeyField"=om."SalesOrder"
WHERE (od."LineType" = '1')
AND om."EntrySystemDate"> '01/01/2017'
AND  (om."Customer" is distinct from '000000000048869' and om."Customer" is distinct from '000000000049870')