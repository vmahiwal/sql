
SELECT ROW_NUMBER() OVER (ORDER BY iw."Warehouse") AS ID, now() as time,iw."Warehouse"
		, iwc."Description"
		, CASE WHEN im."ProductClass" like '%01' THEN 'NH'
				WHEN im."ProductClass" like '%02' THEN 'SM' ELSE 'OT' END as Brand
		, CASE WHEN coalesce(invtyp.ProductClass,' ') IS DISTINCT FROM ' ' THEN invtyp.InvType ELSE 'OTHER' END as InvType
		, SUM(ROUND(iw."OpenBalQty4" * iw."OpenBalCost4",2)) as "[04PeriodsBack]"
		, SUM(ROUND(iw."OpenBalQty3" * iw."OpenBalCost3",2)) as "[03PeriodsBack]"
		, SUM(ROUND(iw."OpenBalQty2" * iw."OpenBalCost2",2)) as "[02PeriodsBack]"
		, SUM(ROUND(iw."OpenBalQty1" * iw."OpenBalCost1",2)) as "[01PeriodsBack]"
		, SUM(ROUND(iw."QtyOnHand" * iw."UnitCost",2)) as CurrPeriodCost
FROM sysprocompanyb.invwarehousemain_stg0_gp iw INNER JOIN sysprocompanyb.invwhcontrolmain_stg0_gp iwc ON iw."Warehouse" = iwc."Warehouse"
					 INNER JOIN sysprocompanyb.invmastermain_stg0_gp im ON iw."StockCode" = im."StockCode"
					 LEFT JOIN (SELECT REPLACE("KeyField",' ','') as ProductClass
										, "AlphaValue" as InvType
								FROM sysprocompanyb.admformdatamain_stg0_gp
								WHERE "FormType" = 'ARPCL' and "FieldName" = 'KPI001') invtyp on im."ProductClass" = invtyp.ProductClass
GROUP BY iw."Warehouse"
		, iwc."Description"
		, CASE WHEN im."ProductClass" like '%01' THEN 'NH'
				WHEN im."ProductClass" like '%02' THEN 'SM' ELSE 'OT' END
		, CASE WHEN coalesce(invtyp.ProductClass,' ') IS DISTINCT FROM ' ' THEN invtyp.InvType ELSE 'OTHER' END
		
