
SELECT  ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, tmp.* from( 
select 'LostSales' as Grouping,"CorpAcctName",ar.* from (
SELECT        sysprocompanyb.sordetailmain_stg0_gp  ."SalesOrder", sysprocompanyb.sordetailmain_stg0_gp  ."SalesOrderLine", sysprocompanyb.sordetailmain_stg0_gp  ."MStockCode", sysprocompanyb.sordetailmain_stg0_gp  ."MStockDes", 
                         sysprocompanyb.sordetailmain_stg0_gp  ."MOrderQty", sysprocompanyb.sordetailmain_stg0_gp  ."MPrice", sysprocompanyb.sormastermain_stg0_gp."OrderStatus", CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END AS DispQty, CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END AS QtyInvoiced, 
                         (CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END) AS QtyShipped, sysprocompanyb.sordetailmain_stg0_gp  ."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) AS QtyLost, 
                         (sysprocompanyb.sordetailmain_stg0_gp  ."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END))) * sysprocompanyb.sordetailmain_stg0_gp  ."MPrice" AS LostSales, sysprocompanyb.sormastermain_stg0_gp."Branch", sysprocompanyb.sormastermain_stg0_gp."Customer", 
                         sysprocompanyb.sormastermain_stg0_gp."CustomerName", sysprocompanyb.sormastermain_stg0_gp."OrderDate",sysprocompanyb.sormastermain_stg0_gp."EntrySystemDate", sysprocompanyb.sordetailmain_stg0_gp  ."MLineShipDate"
FROM            sysprocompanyb.sordetailmain_stg0_gp   INNER JOIN
                         sysprocompanyb.sormastermain_stg0_gp ON sysprocompanyb.sordetailmain_stg0_gp  ."SalesOrder" = sysprocompanyb.sormastermain_stg0_gp."SalesOrder" 
						 LEFT OUTER JOIN
                         sysprocompanyb.arcustomermain_stg0_gp ON sysprocompanyb.sormastermain_stg0_gp."Customer" = sysprocompanyb.arcustomermain_stg0_gp."Customer" 
						 LEFT OUTER JOIN
                             (SELECT        "SalesOrder", "SalesOrderLine", SUM("QtyInvoiced") AS QtyInvoiced
                               FROM            sysprocompanyb.artrndetailmain_stg0_gp
                               GROUP BY "SalesOrder", "SalesOrderLine") AS derivedtbl_2 ON sysprocompanyb.sordetailmain_stg0_gp  ."SalesOrder" = derivedtbl_2."SalesOrder" AND 
                         sysprocompanyb.sordetailmain_stg0_gp  ."SalesOrderLine" = derivedtbl_2."SalesOrderLine" LEFT OUTER JOIN
                             (SELECT        sysprocompanyb.mdndetailmain_stg0_gp."SalesOrder", sysprocompanyb.mdndetailmain_stg0_gp."SalesOrderLine", SUM(sysprocompanyb.mdndetailmain_stg0_gp."MQtyToDispatch") AS DispQty
                               FROM            sysprocompanyb.mdndetailmain_stg0_gp INNER JOIN
                                                        sysprocompanyb.mdnmastermain_stg0_gp ON sysprocompanyb.mdndetailmain_stg0_gp."DispatchNote" =sysprocompanyb.mdnmastermain_stg0_gp."DispatchNote"
                               WHERE        (sysprocompanyb.mdnmastermain_stg0_gp."DispatchNoteStatus" is distinct from '9' and sysprocompanyb.mdnmastermain_stg0_gp."DispatchNoteStatus" is distinct from '*')
                               GROUP BY sysprocompanyb.mdndetailmain_stg0_gp."SalesOrder", sysprocompanyb.mdndetailmain_stg0_gp."SalesOrderLine") AS derivedtbl_1 ON sysprocompanyb.sordetailmain_stg0_gp  ."SalesOrder" = derivedtbl_1."SalesOrder" AND 
                         sysprocompanyb.sordetailmain_stg0_gp  ."SalesOrderLine" = derivedtbl_1."SalesOrderLine"
WHERE        (sysprocompanyb.sordetailmain_stg0_gp  ."LineType" = '1') AND (sysprocompanyb.sormastermain_stg0_gp."OrderStatus" = '9') AND "InterWhSale" is distinct from 'Y' AND (sysprocompanyb.sordetailmain_stg0_gp  ."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) > 0) AND 
                         (sysprocompanyb.sormastermain_stg0_gp."OrderType" is distinct from 'C' and sysprocompanyb.sormastermain_stg0_gp."OrderType" is distinct from 'D') AND (sysprocompanyb.sordetailmain_stg0_gp  ."MLineShipDate" >= date_trunc('month', current_date)-'124day'::interval)

) ar
LEFT JOIN 
    		sysprocompanyb.arcustomermain_stg0_gp c on c."Customer"=ar."Customer" where extract('month' from "MLineShipDate")=extract('month' from now())

			UNION
			SELECT 'Cancelled Order' as Grouping,cacm.CorpAcctName,om."SalesOrder","SalesOrderLine", "MStockCode", "MStockDes",od."MOrderQty",
			od."MPrice", "OrderStatus",0 as DispQty,0 as QtyInvoiced,0 as QtyShipped,0 as QtyLost,"MOrderQty"*"MPrice" as LostSales,
			om."Branch",om."Customer",om."CustomerName", "OrderDate", "EntrySystemDate",   "MLineShipDate"
FROM sysprocompanyb.sormastermain_stg0_gp om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp od ON om."SalesOrder" = od."SalesOrder" LEFT JOIN (SELECT "KeyField" as Customer
         , "AlphaValue" as CorpAcctCode
        FROM sysprocompanyb.admformdatamain_stg0_gp
        WHERE "FormType" = 'CUS' and "FieldName" = 'COR002') cac ON om."Customer" = cac.Customer
     LEFT JOIN (SELECT "Item" as CorpAcctCode
         , "Description" as CorpAcctName
        FROM sysprocompanyb.admformvalidationmain_stg0_gp 
        WHERE "FormType" = 'CUS' and "FieldName" = 'COR002') cacm on cac.CorpAcctCode = cacm.CorpAcctCode
WHERE 
   (om."CancelledFlag" = 'Y') AND "InterWhSale" is distinct from 'Y' 
  AND (od."LineType" = '1')
  AND extract('year' from om."EntrySystemDate") = extract('year' from now()) and extract('month' from om."EntrySystemDate") = extract('month' from now())
  )tmp
