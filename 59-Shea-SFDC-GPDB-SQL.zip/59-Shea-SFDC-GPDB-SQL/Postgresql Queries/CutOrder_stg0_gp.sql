

SELECT ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, temp.* from(

SELECT 
'LostSales' as Grouping,
"CorpAcctName",ar.* from (
SELECT       
 SorDetail."SalesOrder",
 SorDetail."SalesOrderLine",
 SorDetail."MStockCode", 
 SorDetail."MStockDes",
 SorDetail."MOrderQty",
 SorDetail."MPrice",
 case  when "OrderStatus" in ('0','1','2','3','4') then '1' else SorMaster."OrderStatus" end as OrderStatus,
 CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END AS DispQty,
 CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END AS QtyInvoiced, 
 (CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + 
 (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL  THEN 0 ELSE derivedtbl_2.QtyInvoiced END) AS QtyShipped,
 SorDetail."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL  THEN 0 ELSE derivedtbl_1.DispQty END) + 
 (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) AS QtyLost, 
 (SorDetail."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + 
 (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL  THEN 0 ELSE derivedtbl_2.QtyInvoiced END))) * SorDetail."MPrice" AS LostSales, 
 SorMaster."Branch",
 SorMaster."Customer", 
 SorMaster."CustomerName",
 SorMaster."OrderDate",
 SorMaster."EntrySystemDate", 
 SorDetail."MLineShipDate",
 '' as CancelledReason
FROM           sysprocompanyb.sordetailmain_stg0_gp  as SorDetail
INNER JOIN
                         sysprocompanyb.sormastermain_stg0_gp as SorMaster
						 ON SorDetail."SalesOrder" = SorMaster."SalesOrder" 
						 LEFT OUTER JOIN
                        sysprocompanyb.arcustomermain_stg0_gp 
						 ON SorMaster."Customer" = sysprocompanyb.arcustomermain_stg0_gp ."Customer" 
						 LEFT OUTER JOIN
                             (SELECT        "SalesOrder", "SalesOrderLine", SUM("QtyInvoiced") AS QtyInvoiced
                               FROM           sysprocompanyb.artrndetailmain_stg0_gp   
                               GROUP BY "SalesOrder", "SalesOrderLine") AS derivedtbl_2 ON SorDetail."SalesOrder" = derivedtbl_2."SalesOrder" AND 
                         SorDetail."SalesOrderLine" = derivedtbl_2."SalesOrderLine" 
						 LEFT OUTER JOIN
                             (SELECT        MdnDetail."SalesOrder", MdnDetail."SalesOrderLine", SUM(MdnDetail."MQtyToDispatch") AS DispQty
                               FROM            sysprocompanyb.mdndetailmain_stg0_gp  as MdnDetail INNER JOIN
                                                         sysprocompanyb.mdnmastermain_stg0_gp  as MdnMaster 
														 ON MdnDetail."DispatchNote" = MdnMaster."DispatchNote"
                               WHERE        (MdnMaster."DispatchNoteStatus" is distinct from  '9'  and MdnMaster."DispatchNoteStatus" is distinct from   '*')
                               GROUP BY MdnDetail."SalesOrder", MdnDetail."SalesOrderLine") AS derivedtbl_1 ON SorDetail."SalesOrder" = derivedtbl_1."SalesOrder" AND 
                         SorDetail."SalesOrderLine" = derivedtbl_1."SalesOrderLine"
WHERE        (SorDetail."LineType" = '1') AND (SorMaster."OrderStatus" = '9') 
AND "InterWhSale" is distinct from 'Y' AND (SorDetail."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) > 0) AND 
                         (SorMaster."OrderType" is distinct from 'C' and SorMaster."OrderType" is distinct from 'D') AND extract(year from SorDetail."MLineShipDate") in ( extract(year from(now())),extract(year from (now()))-1)

) ar
LEFT JOIN 
			sysprocompanyb.arcustomermain_stg0_gp c on c."Customer"=ar."Customer" 

			UNION
			SELECT 'Cancelled Order' as Grouping,
			cacm."CorpAcctName",
			om."SalesOrder",
			od."SalesOrderLine",
			"MStockCode", 
			"MStockDes",
			od."MOrderQty",
			od."MPrice",
			case when "Reason" in ('1','12','6') then 'Customer Request(CR)' 
			when "Reason" in ('10','17') then 'No Inventory(NI)' 
			when "Reason" in ('2','TEST') then 'EDI Reprocessed(ER)' 
			else 'OTHER/Historical' end as OrderStatus,
			0 as DispQty,
			0 as QtyInvoiced,
			0 as QtyShipped,
			0 as QtyLost,
			"MOrderQty"*"MPrice" as LostSales,
			om."Branch",
			om."Customer",
			om."CustomerName",
			"OrderDate",
			"EntrySystemDate", 
			"MLineShipDate",
			tr."Description" as CancelledReason
FROM sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp  od ON om."SalesOrder" = od."SalesOrder" 
LEFT JOIN 
			sysprocompanyb.arcustomermain_stg0_gp cacm on cacm."Customer"=om."Customer" 
			left join 
			sysprocompanyb.sorcancelledmain_stg0_gp on om."SalesOrder"=sysprocompanyb.sorcancelledmain_stg0_gp."SalesOrder" and od."SalesOrderLine"=sysprocompanyb.sorcancelledmain_stg0_gp."SalesOrderLine"
  left join sysprocompanyb.tblsoreasonmain_stg0_gp tr on tr."ReasonCode"=sysprocompanyb.sorcancelledmain_stg0_gp."Reason"
WHERE 
   (om."CancelledFlag" = 'Y') AND "InterWhSale" is distinct from 'Y' 
  AND (od."LineType" = '1')
  AND year("MLineShipDate")in ( year(now()),year(now())-1)
  UNION
			SELECT 'Back Order' as Grouping,
			cacm."CorpAcctName",om."SalesOrder",od."SalesOrderLine", "MStockCode", "MStockDes",od."MOrderQty",
			od."MPrice", 
			case when "OrderStatus" in ('0','1','2','3','4') then '1' else "OrderStatus" end as OrderStatus,
			CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END AS DispQty, CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 
						 ELSE derivedtbl_2.QtyInvoiced END AS QtyInvoiced, 
                         (CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END) AS QtyShipped, od."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) AS QtyLost, 
                         (od."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END))) * od."MPrice" AS LostSales,
			om."Branch",om."Customer",om."CustomerName", "OrderDate", "EntrySystemDate",   "MLineShipDate", '' as CancelledReason
FROM sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp  od ON om."SalesOrder" = od."SalesOrder" LEFT OUTER JOIN
                             (SELECT        "SalesOrder", "SalesOrderLine", SUM("QtyInvoiced") AS QtyInvoiced
                               FROM            sysprocompanyb.artrndetailmain_stg0_gp  
                               GROUP BY "SalesOrder", "SalesOrderLine") AS derivedtbl_2 ON od."SalesOrder" = derivedtbl_2."SalesOrder" AND 
                         od."SalesOrderLine" = derivedtbl_2."SalesOrderLine" LEFT OUTER JOIN
                             (SELECT        MdnDetail."SalesOrder", MdnDetail."SalesOrderLine", SUM(MdnDetail."MQtyToDispatch") AS DispQty
                               FROM           sysprocompanyb.mdndetailmain_stg0_gp as MdnDetail  INNER JOIN
                                                         sysprocompanyb.mdnmastermain_stg0_gp  as MdnMaster ON MdnDetail."DispatchNote" = MdnMaster."DispatchNote"
                               WHERE        (MdnMaster."DispatchNoteStatus" is distinct from '9' and MdnMaster."DispatchNoteStatus" is distinct from  '*')
                               GROUP BY MdnDetail."SalesOrder", MdnDetail."SalesOrderLine") AS derivedtbl_1 ON od."SalesOrder" = derivedtbl_1."SalesOrder" AND 
                         od."SalesOrderLine" = derivedtbl_1."SalesOrderLine"
LEFT JOIN 
(select "SalesOrder",count("DispatchNote") as DispatchCount from sysprocompanyb.mdnmastermain_stg0_gp group by "SalesOrder")mm on mm."SalesOrder"=om."SalesOrder" 
LEFT JOIN 
			sysprocompanyb.arcustomermain_stg0_gp cacm on cacm."Customer"=om."Customer"
			WHERE 
   (om."CancelledFlag" is distinct from 'Y') AND "InterWhSale" is distinct from 'Y' 
  AND (od."LineType" = '1')  AND om."OrderStatus" in ('0','1','2','3','4','S')
   and mm.DispatchCount>=1
  AND (od."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) > 0)

						 UNION
			SELECT 'Past Due' as Grouping,cacm."CorpAcctName",om."SalesOrder",od."SalesOrderLine", "MStockCode", "MStockDes",od."MOrderQty",
			od."MPrice", case when "OrderStatus" in ('0','1','2','3','4') then '1' else "OrderStatus" end as OrderStatus,
			CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END AS DispQty, CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 
						 ELSE derivedtbl_2.QtyInvoiced END AS QtyInvoiced, 
                         (CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END) AS QtyShipped, od."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) AS QtyLost, 
                         (od."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL 
                         THEN 0 ELSE derivedtbl_2.QtyInvoiced END))) * od."MPrice" AS LostSales,
			om."Branch",
			om."Customer",
			om."CustomerName",
			"OrderDate",
			"EntrySystemDate",   
			"MLineShipDate", 
			'' as CancelledReason
FROM sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp   od ON om."SalesOrder" = od."SalesOrder" LEFT OUTER JOIN
                             (SELECT        "SalesOrder", "SalesOrderLine", SUM("QtyInvoiced") AS QtyInvoiced
                               FROM            sysprocompanyb.artrndetailmain_stg0_gp 
                               GROUP BY "SalesOrder", "SalesOrderLine") AS derivedtbl_2 ON od."SalesOrder" = derivedtbl_2."SalesOrder" AND 
                         od."SalesOrderLine" = derivedtbl_2."SalesOrderLine" LEFT OUTER JOIN
                             (SELECT        MdnDetail."SalesOrder", MdnDetail."SalesOrderLine", SUM(MdnDetail."MQtyToDispatch") AS DispQty
                               FROM            sysprocompanyb.mdndetailmain_stg0_gp as MdnDetail INNER JOIN
                                                        sysprocompanyb.mdnmastermain_stg0_gp as MdnMaster ON MdnDetail."DispatchNote" = MdnMaster."DispatchNote"
                               WHERE        (MdnMaster."DispatchNoteStatus" is distinct from '9' and MdnMaster."DispatchNoteStatus" is distinct from '*')
                               GROUP BY MdnDetail."SalesOrder",MdnDetail."SalesOrderLine") AS derivedtbl_1 ON od."SalesOrder" = derivedtbl_1."SalesOrder" AND 
                         od."SalesOrderLine" = derivedtbl_1."SalesOrderLine"
LEFT JOIN 
(select "SalesOrder",count("DispatchNote") as DispatchCount from sysprocompanyb.mdnmastermain_stg0_gp  group by "SalesOrder")mm on mm."SalesOrder"=om."SalesOrder" 
LEFT JOIN 
			sysprocompanyb.arcustomermain_stg0_gp cacm on cacm."Customer"= om."Customer"
			WHERE 
   (om."CancelledFlag" is distinct from  'Y') AND "InterWhSale" is distinct from 'Y' 
  AND (od."LineType" = '1')  AND om."OrderStatus" in ('0','1','2','3','4','S')
  AND ("MLineShipDate" <= date_trunc('day', current_date)-'1day'::interval) and mm.DispatchCount is null
  AND (od."MOrderQty" - ((CASE WHEN derivedtbl_1.DispQty IS NULL 
                         THEN 0 ELSE derivedtbl_1.DispQty END) + (CASE WHEN derivedtbl_2.QtyInvoiced IS NULL THEN 0 ELSE derivedtbl_2.QtyInvoiced END)) > 0)
  
  
  )temp



