------Next 12 Month Forecast ------
SELECT 
ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
"StockUom",
InvType,
case when BO."CorpAcctName" is null then fcst."CorpAcctName" else BO."CorpAcctName" end as CorpAcctName,
case when im."StockCode" is null then fcst."StockCode" else im."StockCode" end as StockCode,
im."Description" as Description,im."AbcClass" as ProductClass,
"StockOnHold",
SUM(OpenOrderQty) as OpenOrderQty, SUM(OpenOrderValue) as OpenOrderValue,
SUM(BoQty) as BoQty, SUM(BoValue) as BoValue,
SUM(PastDueQty) as PastDueQty, SUM(PastDueValue) as PastDueValue,
SUM(QtyOnHand) as QtyOnHand,SUM(QCOnHand) as QCOnHand,
SUM(E4OnHand) as EmersonOnHand, SUM(iw.QtyOnOrder) as QtyOnOrder, SUM(SafetyStockQty) as SafetyStockQty,
SUM(fcst.FcstQtyMnt1) as FcstQtyMnt1, SUM(ForecastValMnt1) ForecastValMnt1,
SUM(fcst.FcstQtyMnt2) as FcstQtyMnt2, SUM(ForecastValMnt2) ForecastValMnt2,
SUM(fcst.FcstQtyMnt3) as FcstQtyMnt3, SUM(ForecastValMnt3) ForecastValMnt3,
SUM(fcst.FcstQtyMnt4) as FcstQtyMnt4, SUM(ForecastValMnt4) ForecastValMnt4,
SUM(fcst.FcstQtyMnt5) as FcstQtyMnt5, SUM(ForecastValMnt5) ForecastValMnt5,
SUM(fcst.FcstQtyMnt6) as FcstQtyMnt6, SUM(ForecastValMnt6) ForecastValMnt6,
SUM(fcst.FcstQtyMnt7) as FcstQtyMnt7, SUM(ForecastValMnt7) ForecastValMnt7,
SUM(fcst.FcstQtyMnt8) as FcstQtyMnt8, SUM(ForecastValMnt8) ForecastValMnt8,
SUM(fcst.FcstQtyMnt9) as FcstQtyMnt9, SUM(ForecastValMnt9) ForecastValMnt9,
SUM(fcst.FcstQtyMnt10) as FcstQtyMnt10, SUM(ForecastValMnt10) ForecastValMnt10,
SUM(fcst.FcstQtyMnt11) as FcstQtyMnt11, SUM(ForecastValMnt11) ForecastValMnt11,
SUM(fcst.FcstQtyMnt12) as FcstQtyMnt12, SUM(ForecastValMnt12) ForecastValMnt12
--,SUM(fcst.JanJunNextYear) as JanJunNextYear
--,Component as WP,SUM(WP.WPOnHand) as WPQtyOnHand,SUM(WPQtyOnOrder) as WPQtyOnOrder, WarehouseToUse,im.AbcClass
 from sysprocompanyb.invmastermain_stg0_gp im left join (select "StockCode", SUM("QtyOnOrder") as QtyOnOrder,SUM("SafetyStockQty") as SafetyStockQty 
 from sysprocompanyb.invwarehousemain_stg0_gp group by "StockCode") iw   on im."StockCode"=iw."StockCode" 
 left join (SELECT "KeyField" as ProductClass
                                        , "AlphaValue" as InvType
                                FROM sysprocompanyb.admformdatamain_stg0_gp 
                                WHERE "FormType" = 'ARPCL' and "FieldName" = 'KPI001') invtyp on im."ProductClass" = invtyp.ProductClass
 left join (select "StockCode",SUM("QtyOnHand") as QCOnHand from sysprocompanyb.invwarehousemain_stg0_gp where "Warehouse"='QC' group by "StockCode") QC on QC."StockCode"=im."StockCode"
 left join (select "StockCode",SUM("QtyOnHand") as QtyOnHand from sysprocompanyb.invwarehousemain_stg0_gp where ("Warehouse" IS DISTINCT FROM 'QC' AND "Warehouse" IS DISTINCT FROM  'Z9' AND "Warehouse" IS DISTINCT FROM 'E4') group by "StockCode") F2 on F2."StockCode"=im."StockCode"
 left join (select "StockCode",SUM("QtyOnHand") as E4OnHand from sysprocompanyb.invwarehousemain_stg0_gp where "Warehouse"='E4' group by "StockCode") E4 on E4."StockCode"=im."StockCode"
 left join (select "CorpAcctName", "MStockCode",SUM(od."MShipQty" + od."MBackOrderQty") as OpenOrderQty,SUM((od."MShipQty"+ od."MBackOrderQty")*"MPrice") as OpenOrderValue,
  SUM(case when DispatchCount>=1
 then (od."MShipQty" + od."MBackOrderQty") else 0 end) as BoQty,SUM(case when DispatchCount>=1
 then (od."MShipQty" + od."MBackOrderQty")*"MPrice" else 0 end) as BoValue,
  SUM(case when "MLineShipDate"<NOW() and DispatchCount  IS NULL
 then (od."MShipQty" + od."MBackOrderQty") else 0 end) as PastDueQty,  SUM(case when "MLineShipDate"<NOW() and DispatchCount IS NULL
 then (od."MShipQty" + od."MBackOrderQty")*"MPrice" else 0 end) as PastDueValue
  
 from sysprocompanyb.sormastermain_stg0_gp  om inner JOIN sysprocompanyb.sordetailmain_stg0_gp od ON om."SalesOrder" = od."SalesOrder"
 left join (select "Customer", "SalesOrder",count("DispatchNote") as DispatchCount from sysprocompanyb.mdnmastermain_stg0_gp group by "SalesOrder","Customer")mm on mm."SalesOrder"=om."SalesOrder" 
 and mm."Customer" = om."Customer"
left join sysprocompanyb.arcustomermain_stg0_gp vw on vw."Customer" = om."Customer" 

 where (om."OrderStatus" in ('0','1','2','3','4','S')) 
AND (om."CancelledFlag" is distinct from 'Y')
AND (om."InterWhSale" is distinct from 'Y') 
AND (od."LineType" = '1')
AND (om."DocumentType") is distinct from 'C'
AND ((od."MShipQty" + "MBackOrderQty") is distinct from 0) group by "MStockCode","CorpAcctName")BO on BO."MStockCode"=im."StockCode" 
--left join View_ArCust_GroupingData4KPI_New vw on vw.Customer = BO.Customer 
-- full join (select distinct ParentPart, Component from BomStructure where left(Component,2)='WP') BM on BM.ParentPart=im.StockCode
 full outer join (select "CorpAcctName",fc."StockCode",
Sum(fc.FcstQtyMnt1) FcstQtyMnt1,    SUM(fc.ForecastRevenue1) AS ForecastValMnt1,
Sum(fc.FcstQtyMnt2) FcstQtyMnt2,    SUM(fc.ForecastRevenue2) AS ForecastValMnt2,
Sum(fc.FcstQtyMnt3) FcstQtyMnt3,    SUM(fc.ForecastRevenue3) AS ForecastValMnt3,
Sum(fc.FcstQtyMnt4) FcstQtyMnt4,    SUM(fc.ForecastRevenue4) AS ForecastValMnt4,
Sum(fc.FcstQtyMnt5) FcstQtyMnt5,    SUM(fc.ForecastRevenue5) AS ForecastValMnt5,
Sum(fc.FcstQtyMnt6) FcstQtyMnt6,    SUM(fc.ForecastRevenue6) AS ForecastValMnt6,
Sum(fc.FcstQtyMnt7) FcstQtyMnt7,    SUM(fc.ForecastRevenue7) AS ForecastValMnt7,
Sum(fc.FcstQtyMnt8) FcstQtyMnt8,    SUM(fc.ForecastRevenue8) AS ForecastValMnt8,
Sum(fc.FcstQtyMnt9) FcstQtyMnt9,    SUM(fc.ForecastRevenue9) AS ForecastValMnt9,
Sum(fc.FcstQtyMnt10) FcstQtyMnt10,    SUM(fc.ForecastRevenue10) AS ForecastValMnt10,
Sum(fc.FcstQtyMnt11) FcstQtyMnt11,    SUM(fc.ForecastRevenue11) AS ForecastValMnt11,
Sum(fc.FcstQtyMnt12) FcstQtyMnt12,    SUM(fc.ForecastRevenue12) AS ForecastValMnt12
 from (SELECT "CorpAcctName","StockCode"
      , SUM(CAST(CASE WHEN  ("ForecastDate" > date_trunc('month', now())-'1day'::interval AND 
                      "ForecastDate" <= date_trunc('month', now())+'1month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt1
      , SUM(CAST(CASE WHEN  ("ForecastDate" >  date_trunc('month', now())+'1month'-'1day'::interval 
      AND "ForecastDate" <= date_trunc('month', now())+'2month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt2
      ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'2month'-'1day'::interval 
      AND "ForecastDate" <= date_trunc('month', now())+'3month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt3
      ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'3month'-'1day'::interval
      AND "ForecastDate" <= date_trunc('month', now())+'4month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt4
     ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'4month'-'1day'::interval 
     AND "ForecastDate" <= date_trunc('month', now())+'5month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt5
     ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'5month'-'1day'::interval
     AND "ForecastDate" <= date_trunc('month', now())+'6month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt6
       ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'6month'-'1day'::interval 
       AND "ForecastDate" <= date_trunc('month', now())+'7month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt7
        ,SUM(CAST(CASE WHEN ("ForecastDate"> date_trunc('month', now())+'7month'-'1day'::interval 
        AND "ForecastDate" <= date_trunc('month', now())+'8month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt8
     ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'8month'-'1day'::interval
     AND "ForecastDate" <= date_trunc('month', now())+'9month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt9
     ,SUM(CAST(CASE WHEN  ("ForecastDate" > date_trunc('month', now())+'9month'-'1day'::interval
     AND "ForecastDate" <= date_trunc('month', now())+'10month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt10
      ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'10month'-'1day'::interval 
      AND "ForecastDate" <= date_trunc('month', now())+'11month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt11
     ,SUM(CAST(CASE WHEN ("ForecastDate" >date_trunc('month', now())+'11month'-'1day'::interval 
     AND "ForecastDate" <= date_trunc('month', now())+'12month'-'1day'::interval) 
                      THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS FcstQtyMnt12
        
,   SUM(CAST(CASE WHEN extract('Year' from "ForecastDate") = extract('Year' from now())+1 AND extract('Month' from "ForecastDate") 
                      <=6 THEN salesforecast."ForecastQty" ELSE 0 END AS Decimal(12, 0))) AS JanJunNextYear
,
 SUM(CAST(CASE WHEN  ("ForecastDate" > date_trunc('month', now())-'1day'::interval AND 
                      "ForecastDate" <= date_trunc('month', now())+'1month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue1
      , SUM(CAST(CASE WHEN  ("ForecastDate" >  date_trunc('month', now())+'1month'-'1day'::interval 
      AND "ForecastDate" <= date_trunc('month', now())+'2month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue2
      ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'2month'-'1day'::interval 
      AND "ForecastDate" <= date_trunc('month', now())+'3month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue3
      ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'3month'-'1day'::interval
      AND "ForecastDate" <= date_trunc('month', now())+'4month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue4
     ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'4month'-'1day'::interval 
     AND "ForecastDate" <= date_trunc('month', now())+'5month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue5
     ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'5month'-'1day'::interval
     AND "ForecastDate" <= date_trunc('month', now())+'6month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue6
       ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'6month'-'1day'::interval 
       AND "ForecastDate" <= date_trunc('month', now())+'7month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue7
        ,SUM(CAST(CASE WHEN ("ForecastDate"> date_trunc('month', now())+'7month'-'1day'::interval 
        AND "ForecastDate" <= date_trunc('month', now())+'8month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue8
     ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'8month'-'1day'::interval
     AND "ForecastDate" <= date_trunc('month', now())+'9month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue9
     ,SUM(CAST(CASE WHEN  ("ForecastDate" > date_trunc('month', now())+'9month'-'1day'::interval
     AND "ForecastDate" <= date_trunc('month', now())+'10month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue10
      ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', now())+'10month'-'1day'::interval 
      AND "ForecastDate" <= date_trunc('month', now())+'11month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue11
     ,SUM(CAST(CASE WHEN ("ForecastDate" >date_trunc('month', now())+'11month'-'1day'::interval 
     AND "ForecastDate" <= date_trunc('month', now())+'12month'-'1day'::interval) 
                      THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS ForecastRevenue12
        
,   SUM(CAST(CASE WHEN extract('Year' from "ForecastDate") = extract('Year' from now())+1 AND extract('Month' from "ForecastDate") 
                      <=6 THEN salesforecast."ForecastRevenue" ELSE 0 END AS Decimal(12, 0))) AS JanJunNextYear
                   
  FROM sysprocompanyb.salesforecast_month_stg0_gp salesforecast
  where
   (salesforecast."ForecastDate" > date_trunc('month', now())-'12month'::interval-'1day'::interval) AND 
                      (salesforecast."ForecastDate" <= date_trunc('month', now())+'12month'::interval-'1day'::interval)
                      group by "CorpAcctName","StockCode"
           )fc
                   
                    
                      group by "CorpAcctName",fc."StockCode") 
                      fcst on fcst."StockCode"=BO."MStockCode"
                      and fcst."CorpAcctName"= BO."CorpAcctName"
                  --    and fcst."Description" = im."Description"
 --  full join (select StockCode,SUM(QtyOnHand) as WPOnHand,SUM(QtyOnOrder) as WPQtyOnOrder from InvWarehouse group by StockCode) WP on WP.StockCode=BM.Component
 where --InvType='FG' and 
 (QtyOnHand>0 or QCOnHand>0 or E4OnHand>0 or OpenOrderQty>0 or BoQty>0 or PastDueQty>0 or QtyOnOrder>0 or FcstQtyMnt1>0 or FcstQtyMnt2>0 or FcstQtyMnt3>0 or
 FcstQtyMnt4>0 or FcstQtyMnt5>0 or FcstQtyMnt6>0 or FcstQtyMnt7>0 or FcstQtyMnt8>0 or FcstQtyMnt9>0 or FcstQtyMnt10>0
 or FcstQtyMnt11>0 or FcstQtyMnt12>0)
 group by 
 "StockUom",BO."CorpAcctName",iw."StockCode", im."Description"
 --,fcst."Description"
 ,im."ProductClass","StockOnHold"--,Component
 ,"WarehouseToUse",im."AbcClass"
 ,fcst."StockCode",im."StockCode",fcst."CorpAcctName",
 InvType
