SELECT ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, od."SalesOrder",od."SalesOrderLine","Invoice",om."Customer","CorpAcctName","InvoiceDate",
trim(od."MStockCode"),od."MStockDes","EntrySystemDate","MLineShipDate","CustomerPoNumber"
,SUM(QtyInvoiced) as QtyInvoiced,SUM("MOrderQty") as QtyOrdered
,"MPrice"
,SUM(GrossInvoiced) as GrossInvoiced,SUM("MOrderQty"*"MPrice") as GrossOrdered
from sysprocompanyb.sordetailmain_stg0_gp od inner join sysprocompanyb.sormastermain_stg0_gp om on om."SalesOrder"=od."SalesOrder"
left join 
(SELECT * FROM(
select "SalesOrder","Invoice","SalesOrderLine","Customer","InvoiceDate",
SUM("QtyInvoiced") as QtyInvoiced, SUM("NetSalesValue"+"DiscValue") as GrossInvoiced
,RANK() OVER (PARTITION BY "SalesOrder" ORDER BY "Invoice" ASC) AS xRank from sysprocompanyb.artrndetailmain_stg0_gp 
where ("LineType" = '1') 
and ("Branch" is distinct from 'TR' and "Branch" is distinct from 'CO' and "Branch" is distinct from 'SM')  AND ("DocumentType") is distinct from 'C' 
and ("TrnYear"=extract(year from now()) or "TrnYear"= extract(year from now())-1 )
group by "SalesOrder","Invoice","SalesOrderLine","Customer","InvoiceDate")hello where  xRank=1 )art  on od."SalesOrder"=art."SalesOrder" and od."SalesOrderLine"=art."SalesOrderLine" 
left join sysprocompanyb.arcustomermain_stg0_gp vw on vw."Customer"=om."Customer" 
where (extract(year from "EntrySystemDate")=extract(year from now()) or extract(year from "EntrySystemDate")= extract(year from now())-1 ) AND (od."LineType" = '1')  and om."OrderStatus" in ('8','9') 
AND (om."CancelledFlag" is distinct from 'Y')
  AND (om."InterWhSale" is distinct from 'Y') 
  AND (om."Branch" is distinct from 'TR' and om."Branch" is distinct from  'CO' and om."Branch" is distinct from  'SM') 
  AND (od."LineType" = '1') AND (om."DocumentType") is distinct from 'C'

group by od."SalesOrder",od."SalesOrderLine","Invoice",om."Customer","CorpAcctName","InvoiceDate",od."MStockCode",
od."MStockDes","MPrice","EntrySystemDate","MLineShipDate","CustomerPoNumber"
