
select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, tmp.* from(
select a.*,"StockCode" from
(
SELECT  		 "DrawOfficeNum",art."TrnMonth",art."TrnYear",
			  SUM(case when "StockUom"='CS' then art."QtyInvoiced"*"ConvFactAltUom" else "QtyInvoiced" end) AS QtyInvoiced
			, SUM(art."NetSalesValue") AS NetSalesValue
			, SUM(art."CostValue") AS CostValue
			, SUM(art."DiscValue") AS DiscountValue
			, SUM(art."NetSalesValue" + art."DiscValue") as GrossSalesValue
FROM  sysprocompanyb.artrndetailmain_stg0_gp art  LEFT OUTER JOIN
                        sysprocompanyb.invmastermain_stg0_gp ON art."StockCode" = sysprocompanyb.invmastermain_stg0_gp."StockCode" 
                         
WHERE        (art."LineType" = '1')
AND (art."DocumentType") is distinct from  'C'
and  "TrnYear">= extract(year from now())-1  and "DrawOfficeNum" is distinct from ' '
GROUP BY 
     "DrawOfficeNum", art."TrnYear", art."TrnMonth"
	 , case when "StockUom"='CS' then art."QtyInvoiced"*"ConvFactAltUom" else "QtyInvoiced" end
                       )a left join sysprocompanyb.invmastermain_stg0_gp im on im."DrawOfficeNum"=a."DrawOfficeNum"
						  and im."StockUom"='EA'
 )tmp