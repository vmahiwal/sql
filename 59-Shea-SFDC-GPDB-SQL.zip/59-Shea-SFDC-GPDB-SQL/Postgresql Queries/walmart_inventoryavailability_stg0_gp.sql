--walmart_inventoryavailability_stg0_gp.sql


SELECT ROW_NUMBER() OVER (ORDER BY now()) AS ID,now() as time,
RTRIM(invm."StockCode") as StockCode,
a.QtyOnHand,
iw2.QCOnHand,
 iw3.XQCOnHand, 
 iw4.XFGOnHand,
 iw3.XQCInTrnasit,
 iw4.XFGInTransit,
tarfcst.CurrentMonthForecastTAR,
tarfcst.NextMonthForecastTAR,
CurrentMonthForecastQty,
NextMonthForecastQty,
"DrawOfficeNum" 
from sysprocompanyb.invmastermain_stg0_gp  invm
left join 
(Select "StockCode",
Sum("QtyOnHand") as QtyOnHand
from sysprocompanyb.invwarehousemain_stg0_gp  iw1 
where ("Warehouse" is distinct from 'QC' and "Warehouse" is distinct from 'E4' and "Warehouse" is distinct from 'Z9') group by "StockCode")a
on invm."StockCode" = a."StockCode"
left join 
( select "StockCode",
SUM("QtyOnHand") as QCOnHand from sysprocompanyb.invwarehousemain_stg0_gp  where "Warehouse"='QC' group by "StockCode") iw2 
on 
invm."StockCode"=iw2."StockCode"
left join ( select "StockCode",SUM("QtyOnHand") as XQCOnHand,Sum("QtyInTransit") XQCInTrnasit from sysprocompanyb.invwarehousemain_stg0_gp where "Warehouse"='XQC' group by "StockCode") iw3 on invm."StockCode"=iw3."StockCode"
left join ( select "StockCode",SUM("QtyOnHand") as XFGOnHand,Sum("QtyInTransit") XFGInTransit from sysprocompanyb.invwarehousemain_stg0_gp where "Warehouse"='XFG' group by "StockCode") iw4 on invm."StockCode"=iw4."StockCode"


left join
(SELECT "StockCode"
, SUM(CAST(CASE WHEN 
 Extract(year from "ForecastDate")= extract(year from (now()))  
and extract(month from "ForecastDate")=  extract (month from now())
THEN sfm."ForecastQty"
ELSE 0 END AS Decimal(12, 2))) AS CurrentMonthForecastTAR
, SUM(CAST(CASE WHEN  ("ForecastDate" > date_trunc('month', current_date))
 AND "ForecastDate" < date_trunc('month', current_date)+'2month'::interval
THEN sfm."ForecastQty"
ELSE 0 END AS Decimal(12, 2))) AS NextMonthForecastTAR
FROM sysprocompanyb.salesforecast_month_stg0_gp sfm
 where "CorpAcctName" like '%WAL-MART%' 
group by "StockCode") tarfcst 
on tarfcst."StockCode"=invm."StockCode"
left join
(SELECT "StockCode"
, SUM(CAST(CASE WHEN 
extract(year from "ForecastDate") =extract(year from now()) and extract(month from "ForecastDate")=extract(month from now())
THEN sfm."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS CurrentMonthForecastQty
, SUM(CAST(CASE WHEN  ("ForecastDate" > date_trunc('month', current_date))
 AND "ForecastDate" < date_trunc('month', current_date)+'2month'::interval
THEN sfm."ForecastQty"
ELSE 0 END AS Decimal(12, 2))) AS NextMonthForecastQty
FROM sysprocompanyb.salesforecast_month_stg0_gp sfm
group by "StockCode") fcst 
on 
fcst."StockCode"=invm."StockCode"