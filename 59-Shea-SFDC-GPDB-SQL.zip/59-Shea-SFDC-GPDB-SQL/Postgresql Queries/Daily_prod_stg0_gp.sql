
SELECT ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,jm."StockCode","StockDescription",jr."TrnDate", SUM(jr."QtySupplied") as DailyProduction
  FROM sysprocompanyb.wippartbookmain_stg0_gp jr INNER JOIN sysprocompanyb.wipmastermain_stg0_gp jm ON jr."Job" = jm."Job"
					INNER JOIN  sysprocompanyb.invmastermain_stg0_gp im on jm."StockCode" = im."StockCode"

WHERE jm."Warehouse" IN ('F1','F2','F3','QC') 
		AND DATE_PART('year',jr."TrnDate") >= DATE_PART('year',now()) -1
		AND (RTRIM(jm."StockCode") like '%01')
		AND SUBSTR(im."ProductClass",0, 3) is distinct from 'SO'
		AND (im."ProductClass" is distinct from 'BA03' and im."ProductClass" is distinct from 'BY03' and im."ProductClass" is distinct from 'CC'
and im."ProductClass" is distinct from		'FC03' and im."ProductClass" is distinct from 'FC04' and im."ProductClass" is distinct from 'HC03' 
and im."ProductClass" is distinct from 'SC03' and im."ProductClass" is distinct from 'SC04' and im."ProductClass" is distinct from 'SH04' 
and im."ProductClass" is distinct from 'S001' and im."ProductClass" is distinct from 'S002')
		group by jm."StockCode","StockDescription",jr."TrnDate"