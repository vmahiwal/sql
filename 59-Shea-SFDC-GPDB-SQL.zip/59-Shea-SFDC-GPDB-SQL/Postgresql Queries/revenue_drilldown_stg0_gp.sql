
select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,UnitStockCode,StockCode,DrawOfficeNum,Description,CorpAcctName,GrossSales,QtyInvoiced,TrnDate from 
(select case when (im.StockUom='CS' or im.StockUom='cs') 
then CONCAT(LEFT(art.StockCode,LEN(RTRIM(art.StockCode))-2),'01') 
else art.StockCode end as UnitStockCode
,SUM(NetSalesValue+DiscValue) as GrossSales, vw.CorpAcctName
, SUM(CASE WHEN im.StockUom='CS' then QtyInvoiced*im.ConvFactAltUom else QtyInvoiced end) as QtyInvoiced
, str(TrnYear)+'-'+'01'+'-'+'01' as TrnDate
from ArTrnDetail art
left join InvMaster im on im.StockCode=art.StockCode
left join View_ArCust_GroupingData4KPI_New vw on art.Customer = vw.Customer
where 
(LineType = '1') and DATEPART("dayofyear",InvoiceDate)<=DATEPART("dayofyear",getdate()) 
AND (NOT(Branch IN ('TR', 'CO', 'SM'))) 
        --Added following condition to eliminate credit notes 2016-06-07
        AND (DocumentType) <> 'C'
        and (art.TrnYear between 2012 and Getdate())
        AND LEFT(art.StockCode,4) NOT IN ('DISP','FIXT','GIFT','FBX-','CAP-','LBL-') and StockUom<>'KG'
                AND NOT (art.Customer IN ('0048869','0049870')) group by case when (im.StockUom='CS' or im.StockUom='cs') then CONCAT(LEFT(art.StockCode,LEN(RTRIM(art.StockCode))-2),'01') else art.StockCode end,TrnYear,vw.CorpAcctName
                )x
                
left join InvMaster im1 on RTRIM(im1.StockCode)=RTRIM(x.UnitStockCode) and (im1.StockUom='EA' or im1.StockUom='ea')
