SELECT arc."CorpAcctName",
"StockCode",
"ReqShipDate", "MOrderQty","OpenOrderQty","OpenOrderValue"
from sysprocompanyb.arcustomermain_stg0_gp arc 
right join(select om."SalesOrder" as SalesOrder , od."SalesOrderLine" as SalesOrderLine,trim("MStockCode")as "StockCode","Customer","ReqShipDate",
Sum(od."MOrderQty") as "MOrderQty",
SUM(od."MShipQty" + od."MBackOrderQty")as "OpenOrderQty",
SUM((od."MShipQty" + od."MBackOrderQty") * od."MPrice")as "OpenOrderValue"
from sysprocompanyb.sormastermain_stg0_gp om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp od ON om."SalesOrder" = od."SalesOrder"
where (om."OrderStatus" in ('0','1','2','3','4','S')) AND  (om."CancelledFlag" is distinct from 'Y')
        AND (om."InterWhSale" is distinct from 'Y')  AND (NOT(om."Branch" IN ('TR', 'CO', 'SM')))
AND (od."LineType" = '1') AND (om."DocumentType") <> 'C'
and  ((od."MShipQty" + od."MBackOrderQty") <> 0)
group by om."SalesOrder" , od."SalesOrderLine",trim("MStockCode"),"Customer","ReqShipDate") opn 
on opn."Customer" = arc."Customer"
