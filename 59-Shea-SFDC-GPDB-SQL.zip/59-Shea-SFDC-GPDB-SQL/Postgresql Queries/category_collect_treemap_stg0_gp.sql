
select * from(
select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,"StockCode","Description",x."DrawOfficeNum",GrossSales,QtyInvoiced,TrnDate 
, Row_Number() Over (Partition by x."DrawOfficeNum",TrnDate order by "StockCode") a
from 
(select im."DrawOfficeNum"
,SUM("NetSalesValue"+"DiscValue") as GrossSales
, SUM(CASE WHEN im."StockUom"='CS' then "QtyInvoiced"*im."ConvFactAltUom" else "QtyInvoiced" end) as QtyInvoiced
, case 

when "TrnYear"=year(now())-3 then year(now())-3||'-'||'01'||'-'||'01' 
when "TrnYear"=year(now())-2 then year(now())-2||'-'||'01'||'-'||'01'
when "TrnYear"=year(now())-1 then year(now())-1||'-'||'01'||'-'||'01'
when "TrnYear"=year(now()) then year(now())||'-'||'01'||'-'||'01' end as TrnDate
from sysprocompanyb.artrndetailmain_stg0_gp art
left join sysprocompanyb.invmastermain_stg0_gp im on im."StockCode"=art."StockCode"
where 
("LineType" = '1') AND "TrnYear" IN  (year(now())-3,year(now())-2,year(now())-1,year(now())) 
AND ("Branch" is distinct from 'TR' and "Branch" is distinct from 'CO' and "Branch" is distinct from 'SM')  
        --Added following condition to eliminate credit notes 2016-06-07
        AND ("DocumentType") is distinct from 'C'
        AND SUBSTR(art."StockCode",0,5) NOT IN ('DISP','FIXT','GIFT','FBX-')
        AND ("Customer" is distinct from '0048869' and "Customer" is distinct from '0049870') group by im."DrawOfficeNum","TrnYear")x
                
left join sysprocompanyb.invmastermain_stg0_gp im1 on im1."DrawOfficeNum"=x."DrawOfficeNum" where
 --im1."StockUom"='EA' and 
 im1."DrawOfficeNum" is distinct from ' '
AND 
SUBSTR("StockCode",0,5) NOT IN ('DISP','FIXT','GIFT','FBX-') 
 --and im1."DrawOfficeNum" = '764302106104'
 )b where a = 1

