
select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, tmp.* from (

SELECT '01-On Time' as Grouping
		, '01' as Sequence
		, 'Shipments' as Description
		, '' as SubDescription
		, '' as Brand
		, AVG(DATE_PART('day',   dnm."PlannedDeliverDate" - sod."MLineShipDate" )) AS Today
		, 0 as Thru25
		, 0 AS WTD
		, 0 AS MTD
		, 0 AS QTD
		, AVG(DATE_PART('day', dnm."PlannedDeliverDate"  - (CASE WHEN dnsd.DntShipDt ::date IS NULL THEN sod."MLineShipDate" ELSE dnsd.DntShipDt ::date END))) AS YTD
FROM            sysprocompanyb.MdnDetailmain_stg0_gp dnd INNER JOIN
                         sysprocompanyb.MdnMastermain_stg0_gp dnm ON dnd."DispatchNote" = dnm."DispatchNote" INNER JOIN
                         sysprocompanyb.SorDetailmain_stg0_gp sod ON dnd."SalesOrder" = sod."SalesOrder" AND dnd."SalesOrderLine" = sod."SalesOrderLine" INNER JOIN
						 sysprocompanyb.SorMastermain_stg0_gp som ON dnd."SalesOrder" = som."SalesOrder" LEFT OUTER JOIN
                         (
						 SELECT    sd."SalesOrder", 
CASE 
WHEN sd."NComment" LIKE 'Deliver by date%' AND sd."NComment" LIKE '%00:00' 
THEN min(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -16 for 10 )) 
WHEN sd."NComment" LIKE 'Walgreens deliver date%' AND sd."NComment" LIKE '%-_________' 
THEN MIN(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -8)) 
ELSE MIN(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -9)) 
END  AS DntShipDt
 							FROM        sysprocompanyb.SorDetailmain_stg0_gp sd INNER JOIN
										sysprocompanyb.SorMastermain_stg0_gp sm ON sd."SalesOrder"= sm."SalesOrder"
							WHERE     (sd."LineType" = '6') 
										AND (sd."NComment" LIKE 'Do not ship after%' OR
											sd."NComment" LIKE 'Ship No Later=Req Ship Date%' OR
											sd."NComment" LIKE 'Requested ship date%%' OR
											sd."NComment" LIKE 'Walgreens deliver date%' OR
											sd."NComment" LIKE 'Deliver by date%' OR
											sd."NComment" LIKE 'Do Not Deliver After%') 
										AND (sm."DocumentType" = 'O') 
										
										AND (
										is_date(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -16 for 10 ))='t' 
										OR is_date(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -8))='t' 
										OR is_date(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -9))='t' 
										)										
										AND NOT(sm."OrderStatus" IN ('*','\\\\','8'))
							GROUP BY sd."SalesOrder", sm."OrderStatus" 	, sd."NComment"
						 ) dnsd ON dnd."SalesOrder"= dnsd."SalesOrder"
WHERE        dnd."LineType" = '1' 
				AND DATE_PART('year', dnm."PlannedDeliverDate" ) = DATE_PART('year', now()) 
				AND som."InterWhSale" <> 'Y' 
				AND NOT(som."Branch" IN ('TR', 'CO', 'SM'))
				AND NOT (som."Customer" IN ('000000000048869','000000000049870'))
UNION ALL

SELECT '01-On Time' as Grouping
		, '02' as Sequence
		, 'Open Orders' as Description
		, '' as SubDescription
		, '' as Brand
		, AVG(DATE_PART('day',  now() - sod."MLineShipDate" )) AS Today
		, 0 as Thru25
		, 0 AS WTD
		, 0 AS MTD
		, 0 AS QTD
	    , AVG(DATE_PART('day',  now()- (CASE WHEN dnsd.DntShipDt ::date IS NULL THEN sod."MLineShipDate" ELSE dnsd.DntShipDt ::date END))) AS YTD
FROM            sysprocompanyb.SorDetailmain_stg0_gp sod INNER JOIN
                sysprocompanyb.SorMastermain_stg0_gp som ON sod."SalesOrder"= som."SalesOrder" LEFT OUTER JOIN
                  ( SELECT     sd."SalesOrder", 
				
					CASE 
					WHEN sd."NComment" LIKE 'Deliver by date%' AND sd."NComment" LIKE '%00:00' 
					THEN min(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -16 for 10 )) 
					WHEN sd."NComment" LIKE 'Walgreens deliver date%' AND sd."NComment" LIKE '%-_________' 
					THEN MIN(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -8)) 
					ELSE MIN(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -9)) 
					END  AS DntShipDt
							FROM        sysprocompanyb.SorDetailmain_stg0_gp sd INNER JOIN
											 sysprocompanyb.SorMastermain_stg0_gp sm ON sd."SalesOrder"= sm."SalesOrder"
							WHERE     extract ('year' from sm."EntrySystemDate") =2017 
							AND extract ('month' from sm."EntrySystemDate")=7
									AND(sd."LineType" = '6') 
										AND (sd."NComment" LIKE 'Do not ship after%' OR
											sd."NComment" LIKE 'Ship No Later=Req Ship Date%' OR
											sd."NComment" LIKE 'Requested ship date%%' OR
											sd."NComment" LIKE 'Walgreens deliver date%' OR
											sd."NComment" LIKE 'Deliver by date%' OR
											sd."NComment" LIKE 'Do Not Deliver After%') 
										AND (sm."DocumentType" = 'O') 
										AND (
									is_date(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -16 for 10 ))='t' 
										OR is_date(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -8))='t' 
										OR is_date(SUBSTRING(RTRIM(sd."NComment") from char_length(RTRIM(sd."NComment")) -9))='t'
										)
										AND NOT(sm."OrderStatus" IN ('*','\\\\','8'))
							GROUP BY sd."SalesOrder", sm."OrderStatus", sd."NComment"
							) dnsd ON som."SalesOrder"= dnsd."SalesOrder"
WHERE       sod."LineType" = '1' 
			AND NOT (som."OrderStatus" IN ('*', '\\\\', '9', '8')) 
			AND sod."MBackOrderQty" + sod."MShipQty" <> 0 
			AND "MLineShipDate" <= now()
			AND som."InterWhSale" is distinct from 'Y' 
			AND NOT(som."Branch" IN ('TR', 'CO', 'SM'))
			AND (som."DocumentType") is distinct from 'C'
				AND NOT (som."Customer" IN ('000000000048869','000000000049870'))

		
UNION ALL
SELECT '02-Stats' as Grouping
		, '01' as Sequence
		, 'Cases To Ship' as Description
		, 'Qty' as SubDescription
		, CASE WHEN RTRIM("MProductClass") like '%01' THEN 'NH'
				WHEN RTRIM("MProductClass") like '%02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN "MLineShipDate" <= now() THEN BoQty ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATE_PART('month', "MLineShipDate") = DATE_PART('month', now()) AND DATE_PART('year' , "MLineShipDate") = DATE_PART('year', now()) AND DATE_PART('day', "MLineShipDate") <= 25 THEN BoQty ELSE 0 END) as Thru25
		, SUM(CASE WHEN "MLineShipDate" > now() AND DATE_PART('month',"MLineShipDate") = DATE_PART('month',now()) THEN BoQty ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATE_PART('month',"MLineShipDate") = DATE_PART('month', now()) AND DATE_PART('year', "MLineShipDate") = DATE_PART('year',now()) THEN BoQty ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN "MLineShipDate" > date_trunc('month', current_date)+'1month'-'1day'::interval THEN BoQty ELSE 0 END ) as FutureMonths
		, SUM(BoQty) as TotalOpen        
FROM (SELECT som."SalesOrder"
		, sod."SalesOrderLine" 
		, sod."MLineShipDate"
		, sod."MStockCode"
		, sod."MStockDes"
		, sod."MOrderQty" AS OrderQty
		, sod."MBackOrderQty" + sod."MShipQty" AS BoQty
		, sod."MPrice"
		, sod."MDiscValFlag"
		, sod."MDiscValue"
		, sod."MDiscPct1"
		, sod."MDiscPct2"
		, sod."MDiscPct3"
		, sod."MProductClass"
		, som."Customer"
		, cm."Name"
		, cm."CustomerClass"
		, som."Branch"
		, som."InterWhSale"
		, som."DiscPct1"
		, som."DiscPct2"
		, som."DiscPct3"
FROM         sysprocompanyb.SorDetailmain_stg0_gp sod INNER JOIN sysprocompanyb.SorMastermain_stg0_gp som ON sod."SalesOrder"= som."SalesOrder"
							INNER JOIN sysprocompanyb.ArCustomermain_stg0_gp cm ON som."Customer" = cm."Customer"
WHERE     sod."LineType" = '1'
			AND NOT(som."OrderStatus" IN ('*','\\\\','8','9'))
			AND (sod."MShipQty" + sod."MBackOrderQty" <> 0)
			AND ("DocumentType") <> 'C'
		AND NOT (som."Customer" IN ('000000000048869','000000000049870'))) bol
WHERE       RTRIM("MStockCode") NOT LIKE '%01'
				AND "InterWhSale" <> 'Y' 
				AND NOT("Branch" IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RTRIM("MProductClass") like '%01' THEN 'NH'
				WHEN RTRIM("MProductClass") like '%02' THEN 'SM' ELSE 'OT' END
				
UNION ALL

SELECT '02-Stats' as Grouping
		, '01' as Sequence
		, 'Cases To Ship' as Description
		, 'Gross Sales' as SubDescription
		, CASE WHEN RTRIM("MProductClass")  LIKE '%01' THEN 'NH'
				WHEN RTRIM("MProductClass")  LIKE '%02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN "MLineShipDate" <= now() THEN BoQty * "MPrice" ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATE_PART('month', "MLineShipDate" ) = DATE_PART('month',  now()) AND DATE_PART('year',  "MLineShipDate" ) = DATE_PART('year', now()) AND DATE_PART( 'day' , "MLineShipDate" ) <= 25 THEN BoQty * "MPrice" ELSE 0 END) as Thru25
		, SUM(CASE WHEN "MLineShipDate" > now() AND DATE_PART('month', "MLineShipDate" ) = DATE_PART('month', now()) THEN BoQty * "MPrice" ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATE_PART('month', "MLineShipDate" ) = DATE_PART('month',  now()) AND DATE_PART('year',  "MLineShipDate" ) = DATE_PART('year', now()) THEN BoQty * "MPrice" ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN "MLineShipDate" > date_trunc('month', current_date)+'1month'-'1day'::interval THEN BoQty * "MPrice" ELSE 0 END) as FutureMonths
		, SUM(BoQty * "MPrice") as TotalOpen        
FROM (SELECT som."SalesOrder"
		, sod."SalesOrderLine" 
		, sod."MLineShipDate"
		, sod."MStockCode"
		, sod."MStockDes"
		, sod."MOrderQty" AS OrderQty
		, sod."MBackOrderQty" + sod."MShipQty" AS BoQty
		, sod."MPrice"
		, sod."MDiscValFlag"
		, sod."MDiscValue"
		, sod."MDiscPct1"
		, sod."MDiscPct2"
		, sod."MDiscPct3"
		, sod."MProductClass"
		, som."Customer"
		, cm."Name"
		, cm."CustomerClass"
		, som."Branch"
		, som."InterWhSale"
		, som."DiscPct1"
		, som."DiscPct2"
		, som."DiscPct3"
FROM         sysprocompanyb.SorDetailmain_stg0_gp sod INNER JOIN sysprocompanyb.SorMastermain_stg0_gp som ON sod."SalesOrder"= som."SalesOrder"
							INNER JOIN sysprocompanyb.ArCustomermain_stg0_gp cm ON som."Customer" = cm."Customer"
WHERE     sod."LineType" = '1'
			AND NOT(som."OrderStatus" IN ('*','\\\\','8','9'))
			AND (sod."MShipQty" + sod."MBackOrderQty" <> 0)
			AND ("DocumentType") <> 'C'
				AND NOT (som."Customer" IN ('000000000048869','000000000049870'))) bol
WHERE        RTRIM("MStockCode")  NOT LIKE  '%01'
				AND "InterWhSale" <> 'Y' 
				AND NOT("Branch" IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RTRIM("MProductClass")  LIKE '%01' THEN 'NH'
				WHEN RTRIM("MProductClass")  LIKE '%02' THEN 'SM' ELSE 'OT' END
				
				
UNION ALL


SELECT '02-Stats' as Grouping
		, '01' as Sequence
		, 'Cases To Ship' as Description
		, 'Net Sales' as SubDescription
		, CASE WHEN RTRIM("MProductClass")  LIKE '%01' THEN 'NH'
				WHEN RTRIM("MProductClass")  LIKE '%02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN "MLineShipDate"  <= now() THEN NetValue ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATE_PART('month',  "MLineShipDate" ) = DATE_PART('month',  now()) AND DATE_PART('year',   "MLineShipDate" ) = DATE_PART('year', now()) AND DATE_PART( 'day' , "MLineShipDate" ) <= 25 THEN NetValue ELSE 0 END) as Thru25
		, SUM(CASE WHEN  "MLineShipDate" > now() AND DATE_PART('month', "MLineShipDate" ) = DATE_PART('month', now()) THEN NetValue ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATE_PART('month',  "MLineShipDate" ) = DATE_PART('month',  now()) AND DATE_PART('year',   "MLineShipDate" ) = DATE_PART('year', now()) THEN NetValue ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN "MLineShipDate" > date_trunc('month', current_date)+'1month'-'1day'::interval THEN NetValue ELSE 0 END) as FutureMonths
		, SUM(NetValue) as TotalOpen        
FROM (SELECT som."SalesOrder"
		, sod."SalesOrderLine" 
		, sod."MLineShipDate"
		, sod."MStockCode"
		, sod."MStockDes"
		, sod."MOrderQty" AS OrderQty
		, sod."MBackOrderQty" + sod."MShipQty" AS BoQty
		, sod."MPrice"
		, sod."MDiscValFlag"
		, sod."MDiscValue"
		, sod."MDiscPct1"
		, sod."MDiscPct2"
		, sod."MDiscPct3"
		, sod."MProductClass"
		, som."Customer"
		, cm."Name"
		, cm."CustomerClass"
		, som."Branch"
		, som."InterWhSale"
		, som."DiscPct1"
		, som."DiscPct2"
		, som."DiscPct3"
		, CASE WHEN sod."MDiscValFlag" = 'V' THEN ROUND((((sod."MBackOrderQty" + sod."MShipQty") * sod."MPrice") - sod."MDiscValue") * ((100 - som."DiscPct1")/100) * ((100 - som."DiscPct2")/100) * ((100 - som."DiscPct3")/100) ,2)
			   WHEN sod."MDiscValFlag" = 'U' THEN ROUND((((sod."MBackOrderQty" + sod."MShipQty") * sod."MPrice") - ((sod."MBackOrderQty" + sod."MShipQty") * sod."MDiscValue")) * ((100 - som."DiscPct1")/100) * ((100 - som."DiscPct2")/100) * ((100 - som."DiscPct3")/100),2)
			   ELSE ROUND(((sod."MBackOrderQty" + sod."MShipQty") * sod."MPrice") * ((100 - sod."MDiscPct1")/100) * ((100 - sod."MDiscPct2")/100) * ((100 - sod."MDiscPct3")/100) * ((100 - som."DiscPct1")/100) * ((100 - som."DiscPct2")/100) * ((100 - som."DiscPct3")/100) ,2) END as NetValue
FROM         sysprocompanyb.SorDetailmain_stg0_gp sod INNER JOIN sysprocompanyb.SorMastermain_stg0_gp som ON sod."SalesOrder"= som."SalesOrder"
							INNER JOIN sysprocompanyb.ArCustomermain_stg0_gp cm ON som."Customer" = cm."Customer"
WHERE     sod."LineType" = '1'
			AND NOT(som."OrderStatus" IN ('*','\\\\','8','9'))
			AND (sod."MShipQty" + sod."MBackOrderQty" <> 0)
			AND ("DocumentType") <> 'C'
				AND NOT (som."Customer" IN ('000000000048869','000000000049870'))) bol
WHERE        RTRIM("MStockCode")  NOT LIKE  '%01'
				AND "InterWhSale" <> 'Y' 
				AND NOT("Branch" IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RTRIM("MProductClass") LIKE '%01' THEN 'NH'
				WHEN RTRIM("MProductClass") LIKE '%02' THEN 'SM' ELSE 'OT' END
				
				
UNION ALL

SELECT '02-Stats' as Grouping
		, '02' as Sequence
		, 'Pieces To Ship' as Description
		, 'Qty' as SubDescription
		, CASE WHEN RTRIM("MProductClass") LIKE'%01' THEN 'NH'
				WHEN RTRIM("MProductClass") LIKE '%02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN "MLineShipDate" <= now() THEN bol.BoQty ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATE_PART('month', "MLineShipDate" ) = DATE_PART('month',  now()) AND DATE_PART('year',  "MLineShipDate" ) = DATE_PART('year', now()) AND DATE_PART('day', "MLineShipDate")  <= 25 THEN bol.BoQty ELSE 0 END) as Thru25
		, SUM(CASE WHEN "MLineShipDate" > now() AND DATE_PART('month', "MLineShipDate" ) = DATE_PART('month', now()) THEN bol.BoQty ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATE_PART('month', "MLineShipDate" ) = DATE_PART('month',  now()) AND DATE_PART('year',  "MLineShipDate" ) = DATE_PART('year', now()) THEN BoQty ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN "MLineShipDate" > DATE_TRUNC('MONTH', now()::date ) + INTERVAL '1 MONTH' THEN bol.BoQty ELSE 0 END) as FutureMonths
		, SUM(BoQty) as TotalOpen        
FROM (SELECT som."SalesOrder"
		, sod."SalesOrderLine" 
		, sod."MLineShipDate"
		, sod."MStockCode"
		, sod."MStockDes"
		, sod."MOrderQty" AS OrderQty
		, sod."MBackOrderQty" + sod."MShipQty" AS BoQty
		, sod."MProductClass"
		, som."Customer"
		, cm."Name"
		, cm."CustomerClass"
		, som."Branch"
		, som."InterWhSale"
FROM         sysprocompanyb.SorDetailmain_stg0_gp sod INNER JOIN sysprocompanyb.SorMastermain_stg0_gp som ON sod."SalesOrder"= som."SalesOrder"
							INNER JOIN sysprocompanyb.ArCustomermain_stg0_gp cm ON som."Customer" = cm."Customer"
							WHERE     sod."LineType" = '1'
			AND NOT(som."OrderStatus" IN ('*','\\\\','8','9'))
			AND (sod."MShipQty" + sod."MBackOrderQty" <> 0)
			AND ("DocumentType") <> 'C'
				AND NOT (som."Customer" IN ('000000000048869','000000000049870'))) bol
WHERE        RTRIM("MStockCode") LIKE '%01'
				AND "InterWhSale" <> 'Y' 
				AND NOT("Branch" IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RTRIM("MProductClass") LIKE '%01' THEN 'NH'
				WHEN RTRIM("MProductClass") LIKE '%02' THEN 'SM' ELSE 'OT' END

UNION ALL
SELECT '02-Stats' as Grouping
		, '02' as Sequence
		, 'Pieces To Ship' as Description
		, 'Gross Sales' as SubDescription
		, CASE WHEN RTRIM("MProductClass") LIKE '%01' THEN 'NH'
				WHEN RTRIM("MProductClass") LIKE '%02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN "MLineShipDate" <= now() THEN BoQty * "MPrice" ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATE_PART('month', "MLineShipDate" ) = DATE_PART('month',  now()) AND DATE_PART('year',  "MLineShipDate" ) = DATE_PART('year', now()) AND DATE_PART('day',"MLineShipDate") <= 25 THEN BoQty * "MPrice" ELSE 0 END) as Thru25
		, SUM(CASE WHEN "MLineShipDate" > now() AND DATE_PART('month', "MLineShipDate") = DATE_PART('month', now()) THEN BoQty * "MPrice" ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATE_PART('month', "MLineShipDate" ) = DATE_PART('month',  now()) AND DATE_PART('year',  "MLineShipDate" ) = DATE_PART('year', now()) THEN BoQty * "MPrice" ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN "MLineShipDate" > DATE_TRUNC('MONTH', now()::date ) + INTERVAL '1 MONTH' THEN BoQty * "MPrice" ELSE 0 END) as FutureMonths
		, SUM(BoQty * "MPrice") as TotalOpen        
FROM (SELECT som."SalesOrder"
		, sod."SalesOrderLine" 
		, sod."MLineShipDate"
		, sod."MStockCode"
		, sod."MStockDes"
		, sod."MOrderQty" AS OrderQty
		, sod."MBackOrderQty" + sod."MShipQty" AS BoQty
		, sod."MPrice"
		, sod."MDiscValFlag"
		, sod."MDiscValue"
		, sod."MDiscPct1"
		, sod."MDiscPct2"
		, sod."MDiscPct3"
		, sod."MProductClass"
		, som."Customer"
		, cm."Name"
		, cm."CustomerClass"
		, som."Branch"
		, som."InterWhSale"
		, som."DiscPct1"
		, som."DiscPct2"
		, som."DiscPct3"
FROM         sysprocompanyb.SorDetailmain_stg0_gp sod INNER JOIN sysprocompanyb.SorMastermain_stg0_gp som ON sod."SalesOrder"= som."SalesOrder"
							INNER JOIN sysprocompanyb.ArCustomermain_stg0_gp cm ON som."Customer" = cm."Customer"
WHERE     sod."LineType" = '1'
			AND NOT(som."OrderStatus" IN ('*','\\\\','8','9'))
			AND (sod."MShipQty" + sod."MBackOrderQty" <> 0)
			AND ("DocumentType") <> 'C'
				AND NOT (som."Customer" IN ('000000000048869','000000000049870'))) bol
WHERE        RTRIM("MStockCode") LIKE '%01'
				AND "InterWhSale" <> 'Y' 
				AND NOT("Branch" IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RTRIM("MProductClass") LIKE '%01' THEN 'NH'
				WHEN RTRIM("MProductClass") LIKE '%02' THEN 'SM' ELSE 'OT' END
				
				
UNION ALL
SELECT '02-Stats' as Grouping
		, '02' as Sequence
		, 'Pieces To Ship' as Description
		, 'Net Sales' as SubDescription
		, CASE WHEN RTRIM("MProductClass") LIKE '%01' THEN 'NH'
		  WHEN RTRIM("MProductClass") LIKE '%02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN "MLineShipDate"<= now() THEN NetValue ELSE 0 END) AS ThruToday
		, SUM(CASE WHEN DATE_PART('month', "MLineShipDate") = DATE_PART('month', now()) AND DATE_PART('year', "MLineShipDate") = DATE_PART('year',now()) AND DATE_PART('day',"MLineShipDate") <= 25 THEN NetValue ELSE 0 END) as Thru25
		, SUM(CASE WHEN "MLineShipDate" > now() AND DATE_PART('month',"MLineShipDate") = DATE_PART('month',now()) THEN NetValue ELSE 0 END) as RemainderCurrMonth 
		, SUM(CASE WHEN DATE_PART('month',"MLineShipDate") = DATE_PART('month', now()) AND DATE_PART('year', "MLineShipDate") = DATE_PART('year',now()) THEN NetValue ELSE 0 END) as CurrMonth
		, SUM(CASE WHEN "MLineShipDate" > DATE_TRUNC('MONTH', now()::date ) + INTERVAL '1 MONTH' THEN NetValue ELSE 0 END) as FutureMonths
		, SUM(NetValue) as TotalOpen        
FROM (SELECT som."SalesOrder"
		, sod."SalesOrderLine"
		, sod."MLineShipDate"
		, sod."MStockCode"
		, sod."MStockDes"
		, sod."MOrderQty" AS OrderQty
		, sod."MBackOrderQty" + sod."MShipQty" AS BoQty
		, sod."MPrice"
		, sod."MDiscValFlag"
		, sod."MDiscValue"
		, sod."MDiscPct1"
		, sod."MDiscPct2"
		, sod."MDiscPct3"
		, sod."MProductClass"
		, som."Customer"
		, cm."Name"
		, cm."CustomerClass"
		, som."Branch"
		, som."InterWhSale"
		, som."DiscPct1"
		, som."DiscPct2"
		, som."DiscPct3"
		, CASE WHEN sod."MDiscValFlag" = 'V' THEN ROUND((((sod."MBackOrderQty" + sod."MShipQty") * sod."MPrice") - sod."MDiscValue") * ((100 - som."DiscPct1")/100) * ((100 - som."DiscPct2")/100) * ((100 - som."DiscPct3")/100) ,2)
			   WHEN sod."MDiscValFlag" = 'U' THEN ROUND((((sod."MBackOrderQty" + sod."MShipQty") * sod."MPrice") - ((sod."MBackOrderQty" + sod."MShipQty") * sod."MDiscValue")) * ((100 - som."DiscPct1")/100) * ((100 - som."DiscPct2")/100) * ((100 - som."DiscPct3")/100),2)
			   ELSE ROUND(((sod."MBackOrderQty" + sod."MShipQty") * sod."MPrice") * ((100 - sod."MDiscPct1")/100) * ((100 - sod."MDiscPct2")/100) * ((100 - sod."MDiscPct3")/100) * ((100 - som."DiscPct1")/100) * ((100 - som."DiscPct2")/100) * ((100 - som."DiscPct3")/100) ,2) END as NetValue
FROM         sysprocompanyb.SorDetailmain_stg0_gp sod INNER JOIN sysprocompanyb.SorMastermain_stg0_gp som ON sod."SalesOrder" = som."SalesOrder" 
							INNER JOIN sysprocompanyb.ArCustomermain_stg0_gp cm ON som."Customer" = cm."Customer"
WHERE     				sod."LineType" = '1'
			AND NOT(som."OrderStatus" IN ('*','\\\\','8','9'))
			AND (sod."MShipQty" + sod."MBackOrderQty" <> 0)
		AND ("DocumentType") <> 'C'
				AND NOT (som."Customer" IN ('000000000048869','00000000049870'))) bol
WHERE        RTRIM("MStockCode") LIKE '%01'
				AND "InterWhSale" <> 'Y' 
				AND NOT("Branch" IN ('TR', 'CO', 'SM'))
GROUP BY CASE WHEN RTRIM("MProductClass") LIKE '%01' THEN 'NH'
				WHEN RTRIM("MProductClass") LIKE '%02' THEN 'SM' ELSE 'OT' END



UNION ALL


SELECT '03-Stats' as Grouping
		, '01' as Sequence
		, 'Cases Dispatched' as Description
		, 'Qty' as SubDescription
		, CASE WHEN RTRIM(dnd."MProductClass") LIKE '%01' THEN 'NH'
				WHEN RTRIM(dnd."MProductClass") LIKE '%02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN DATE_PART('doy', dnm."PlannedDeliverDate" ) = DATE_PART('doy', now()) THEN dnd."MQtyToDispatch" ELSE 0 END) as TodayCsShip
		, SUM(CASE WHEN DATE_PART('month', dnm."PlannedDeliverDate" ) = DATE_PART('month', now()) AND DATE_PART('day',dnm."PlannedDeliverDate" ) <=25 THEN dnd."MQtyToDispatch" ELSE 0 END) as Thru25
		, SUM(CASE WHEN DATE_PART('week',dnm."PlannedDeliverDate" ) = DATE_PART('week', now()) THEN dnd."MQtyToDispatch" ELSE 0 END) as WTDCsShip
		, SUM(CASE WHEN DATE_PART('month',dnm."PlannedDeliverDate" ) = DATE_PART('month', now()) THEN dnd."MQtyToDispatch" ELSE 0 END) as MTDCsShip
		, SUM(CASE WHEN DATE_PART('quarter',dnm."PlannedDeliverDate" ) = DATE_PART('quarter', now()) THEN dnd."MQtyToDispatch" ELSE 0 END) as QTDCsShip
		, SUM(CASE WHEN DATE_PART('year', dnm."PlannedDeliverDate" ) = DATE_PART('year',  now()) THEN dnd."MQtyToDispatch" ELSE 0 END) as YTDCsShip
FROM            sysprocompanyb.MdnDetailmain_stg0_gp dnd INNER JOIN sysprocompanyb.MdnMastermain_stg0_gp dnm ON dnd."DispatchNote" = dnm."DispatchNote"
								INNER JOIN sysprocompanyb.SorMastermain_stg0_gp som on dnd."SalesOrder"= som."SalesOrder"
WHERE        dnd."LineType" = '1' 
				AND DATE_PART('year', dnm."PlannedDeliverDate" ) = DATE_PART('year', now()) 
				AND dnm."DispatchNoteStatus" <> '*'
				AND som."InterWhSale" <>'Y'
				AND NOT(som."Branch" IN ('TR', 'CO', 'SM'))
				AND RTRIM(dnd."MStockCode") NOT LIKE '%01'
					AND NOT (som."Customer" IN ('000000000048869','000000000049870'))
GROUP BY CASE WHEN RTRIM(dnd."MProductClass") LIKE  '%01' THEN 'NH'
				WHEN RTRIM(dnd."MProductClass") LIKE '%02' THEN 'SM' ELSE 'OT' END
UNION ALL

SELECT '03-Stats' as Grouping
		, '01' as Sequence
		, 'Cases Dispatched' as Description
		, 'Gross Sales' as SubDescription
		, CASE WHEN RTRIM(dnd."MProductClass") like '%01' THEN 'NH'
		 WHEN RTRIM(dnd."MProductClass") like '%02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN DATE_PART('doy' , dnm."PlannedDeliverDate" ) = DATE_PART('doy',now()) THEN dnd."MQtyToDispatch" * dnd."MPrice" ELSE 0 END) as TodayCsShip
		, SUM(CASE WHEN DATE_PART('month', dnm."PlannedDeliverDate" ) = DATE_PART('month',now()) AND DATE_PART('day',dnm."PlannedDeliverDate" ) <=25 THEN dnd."MQtyToDispatch" * dnd."MPrice" ELSE 0 END) as Thru25
		, SUM(CASE WHEN DATE_PART('week', dnm."PlannedDeliverDate" ) = DATE_PART('week', now()) THEN dnd."MQtyToDispatch" * dnd."MPrice" ELSE 0 END) as WTDCsShip
		, SUM(CASE WHEN DATE_PART('month', dnm."PlannedDeliverDate" ) = DATE_PART('month',now()) THEN dnd."MQtyToDispatch" * dnd."MPrice" ELSE 0 END) as MTDCsShip
		, SUM(CASE WHEN DATE_PART('quarter', dnm."PlannedDeliverDate" ) = DATE_PART('quarter', now()) THEN dnd."MQtyToDispatch" * dnd."MPrice" ELSE 0 END) as QTDCsShip
		, SUM(CASE WHEN DATE_PART('year', dnm."PlannedDeliverDate" ) = DATE_PART('year',  now()) THEN dnd."MQtyToDispatch" * dnd."MPrice" ELSE 0 END) as YTDCsShip
FROM     sysprocompanyb.MdnDetailmain_stg0_gp dnd INNER JOIN sysprocompanyb.MdnMastermain_stg0_gp dnm ON dnd."DispatchNote" = dnm."DispatchNote"
								INNER JOIN sysprocompanyb.SorMastermain_stg0_gp som on dnd."SalesOrder"= som."SalesOrder"
WHERE        dnd."LineType" = '1' 
				AND DATE_PART('year' , dnm."PlannedDeliverDate") = DATE_PART('year', now()) 
				AND dnm."DispatchNoteStatus" <> '*'
				AND som."InterWhSale" <> 'Y'
				AND NOT(som."Branch" IN ('TR', 'CO', 'SM'))
				AND RTRIM(dnd."MStockCode") not LIKE '%01' 
				AND NOT (som."Customer" IN ('000000000048869','000000000049870'))
GROUP BY CASE WHEN RTRIM(dnd."MProductClass") LIKE '%01' THEN 'NH'
				WHEN RTRIM(dnd."MProductClass") LIKE '%02' THEN 'SM' ELSE 'OT' END
UNION ALL


SELECT '03-Stats' as Grouping
		, '01' as Sequence
		, 'Cases Dispatched' as Description
		, 'Net Sales' as SubDescription
		, CASE WHEN RTRIM(dnd."MProductClass") like '%01' THEN 'NH'
				WHEN RTRIM(dnd."MProductClass") like '%02' THEN 'SM' ELSE 'OT' END as Brand
		, SUM(CASE WHEN (DATE_PART('doy',  dnm."PlannedDeliverDate") = DATE_PART('doy',  (now())) AND dnd."MDiscValFlag" = 'V') THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - dnd."MDiscValue") * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2)
				   WHEN ((DATE_PART('doy',  dnm."PlannedDeliverDate") = DATE_PART('doy',  (now())) AND dnd."MDiscValFlag" = 'U')) THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - (dnd."MQtyToDispatch" * dnd."MDiscValue")) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100),2)
				   WHEN DATE_PART('doy',  dnm."PlannedDeliverDate") = DATE_PART('doy',  (now())) THEN ROUND((dnd."MQtyToDispatch" * dnd."MPrice") * ((100 - dnd."MDiscPct1")/100) * ((100 - dnd."MDiscPct2")/100) * ((100 - dnd."MDiscPct3")/100) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2) ELSE 0 END) As TodayCsShip
		, SUM(CASE WHEN (DATE_PART('month',   dnm."PlannedDeliverDate") = DATE_PART('month',    now())) AND (DATE_PART('day',dnm."PlannedDeliverDate") <=25 AND dnd."MDiscValFlag" = 'V') THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - dnd."MDiscValue") * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2)
				   WHEN ((DATE_PART('month',   dnm."PlannedDeliverDate") = DATE_PART('month',    now()) AND (DATE_PART('day',dnm."PlannedDeliverDate") <=25 AND dnd."MDiscValFlag" = 'U'))) THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - (dnd."MQtyToDispatch" * dnd."MDiscValue")) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100),2)
				   WHEN DATE_PART('month',   dnm."PlannedDeliverDate") = DATE_PART('month',    now()) AND DATE_PART('day',dnm."PlannedDeliverDate") <=25 THEN ROUND((dnd."MQtyToDispatch" * dnd."MPrice") * ((100 - dnd."MDiscPct1")/100) * ((100 - dnd."MDiscPct2")/100) * ((100 - dnd."MDiscPct3")/100) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2) ELSE 0 END) As Thru25
		, SUM(CASE WHEN (DATE_PART('week',   dnm."PlannedDeliverDate") = DATE_PART('week',   (now())) AND dnd."MDiscValFlag" = 'V') THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - dnd."MDiscValue") * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2)
				   WHEN ((DATE_PART('week',   dnm."PlannedDeliverDate") = DATE_PART('week',   (now())) AND dnd."MDiscValFlag" = 'U')) THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - (dnd."MQtyToDispatch" * dnd."MDiscValue")) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100),2)
				   WHEN DATE_PART('week',   dnm."PlannedDeliverDate") = DATE_PART('week',   (now())) THEN ROUND((dnd."MQtyToDispatch" * dnd."MPrice") * ((100 - dnd."MDiscPct1")/100) * ((100 - dnd."MDiscPct2")/100) * ((100 - dnd."MDiscPct3")/100) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2) ELSE 0 END) As WTDCsShip
		, SUM(CASE WHEN (DATE_PART('month',   dnm."PlannedDeliverDate") = DATE_PART('month',   (now())) AND dnd."MDiscValFlag" = 'V') THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - dnd."MDiscValue") * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2)
				   WHEN ((DATE_PART('month',   dnm."PlannedDeliverDate") = DATE_PART('month',   (now())) AND dnd."MDiscValFlag" = 'U')) THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - (dnd."MQtyToDispatch" * dnd."MDiscValue")) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100),2)
				   WHEN DATE_PART('month',   dnm."PlannedDeliverDate") = DATE_PART('month',   (now())) THEN ROUND((dnd."MQtyToDispatch" * dnd."MPrice") * ((100 - dnd."MDiscPct1")/100) * ((100 - dnd."MDiscPct2")/100) * ((100 - dnd."MDiscPct3")/100) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2) ELSE 0 END) As MTDCsShip
		, SUM(CASE WHEN (DATE_PART('quarter',   dnm."PlannedDeliverDate") = DATE_PART('quarter',   (now())) AND dnd."MDiscValFlag" = 'V') THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - dnd."MDiscValue") * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2)
				   WHEN ((DATE_PART('quarter',   dnm."PlannedDeliverDate") = DATE_PART('quarter',   (now())) AND dnd."MDiscValFlag" = 'U')) THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - (dnd."MQtyToDispatch" * dnd."MDiscValue")) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100),2)
				   WHEN DATE_PART('quarter',   dnm."PlannedDeliverDate") = DATE_PART('quarter',   (now())) THEN ROUND((dnd."MQtyToDispatch" * dnd."MPrice") * ((100 - dnd."MDiscPct1")/100) * ((100 - dnd."MDiscPct2")/100) * ((100 - dnd."MDiscPct3")/100) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2) ELSE 0 END) As QTDCsShip
		, SUM(CASE WHEN (DATE_PART('year',   dnm."PlannedDeliverDate") = DATE_PART('year',   (now())) AND dnd."MDiscValFlag" = 'V') THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - dnd."MDiscValue") * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2)
				   WHEN ((DATE_PART('year',   dnm."PlannedDeliverDate") = DATE_PART('year',   (now())) AND dnd."MDiscValFlag" = 'U')) THEN ROUND(((dnd."MQtyToDispatch" * dnd."MPrice") - (dnd."MQtyToDispatch" * dnd."MDiscValue")) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100),2)
				   WHEN DATE_PART('year',   dnm."PlannedDeliverDate") = DATE_PART('year',   (now())) THEN ROUND((dnd."MQtyToDispatch" * dnd."MPrice") * ((100 - dnd."MDiscPct1")/100) * ((100 - dnd."MDiscPct2")/100) * ((100 - dnd."MDiscPct3")/100) * ((100 - dnm."DiscPct1")/100) * ((100 - dnm."DiscPct2")/100) * ((100 - dnm."DiscPct3")/100) ,2) ELSE 0 END) As YTDCsShip

FROM            sysprocompanyb.MdnDetailmain_stg0_gp dnd INNER JOIN sysprocompanyb.MdnMastermain_stg0_gp dnm ON dnd."DispatchNote" = dnm."DispatchNote"
								INNER JOIN sysprocompanyb.SorMastermain_stg0_gp som on dnd."SalesOrder"= som."SalesOrder"
WHERE        dnd."LineType" = '1' 
				AND DATE_PART('year', dnm."PlannedDeliverDate") = DATE_PART('year',now()) 
				AND dnm."DispatchNoteStatus" <> '*'
				AND som."InterWhSale" <>'Y'
				AND NOT(som."Branch" IN ('TR', 'CO', 'SM'))
				AND RTRIM(dnd."MStockCode") NOT LIKE '%01'
				AND NOT (som."Customer" IN ('000000000048869','000000000049870'))
GROUP BY CASE WHEN RTRIM(dnd."MProductClass") like '%01' THEN 'NH'
				WHEN RTRIM(dnd."MProductClass") like '%02' THEN 'SM' ELSE 'OT' END

)tmp
