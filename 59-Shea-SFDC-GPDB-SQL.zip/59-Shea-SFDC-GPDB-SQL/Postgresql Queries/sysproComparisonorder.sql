select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
om."SalesOrder", om."OrderStatus", od."SalesOrderLine", od."LineType", od."MStockCode", od."MStockDes",om."Customer", om."OrderDate", om."EntrySystemDate", om."Branch",
od."MWarehouse", od."MOrderQty", od."MShipQty", od."MBackOrderQty", od."MUnitCost", od."MOrderUom", od."MPrice"

from sysprocompanyb.sormastermain_stg0_gp om inner join sysprocompanyb.sordetailmain_stg0_gp od on od."SalesOrder" = om."SalesOrder"
where --(om."OrderStatus" in  ('0','1','2','3','4','8','9','S'))
--AND (om."CancelledFlag" is distinct from 'Y')
--AND (om."InterWhSale" is distinct from 'Y')
---AND (om."Branch" is distinct from 'TR' or om."Branch" is distinct from 'CO' or om."Branch" is distinct from 'SM')
---AND (od."LineType" = '1')
---AND (om."DocumentType") is distinct from 'C'
--AND ((od."MShipQty" + "MBackOrderQty") is distinct from '0')
Extract('year' from om."EntrySystemDate") =Extract('year' from current_date);