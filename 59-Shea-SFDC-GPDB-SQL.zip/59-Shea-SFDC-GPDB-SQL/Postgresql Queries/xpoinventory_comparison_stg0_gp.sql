
Select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
case when xpo.AllStockCode is null then sys.AllStockCode else xpo.AllStockCode end as AllStockCode,
case when xpo.AllLot is null then sys.AllLot else xpo.AllLot end as AllLot,
case when xpo.AllWarehouse is null then sys.AllWarehouse else xpo.AllWarehouse end as AllWarehouse,
xpo.QtyDispatched XpoQtyDispatched,xpo.TotalQtyOnHand XpoQtyOnHand, sys.DispatchQty SysproQyDispatched,sys.QtyOnHand SysproQtyOnHand
from 
--xpo part
(
SELECT  dis.QtyDispatched,test1.TotalQtyOnHand ,test1."WAREHOUSE",
case when dis."MSTOCKCODE" is null then test1.LOD_STOCKCODE else dis."MSTOCKCODE" end as AllStockCode,
case when dis.MLOT is null then test1."LOT" else dis.MLOT end as AllLot,
case when dis."MWAREHOUSE" is null then test1."WAREHOUSE" else dis."MWAREHOUSE" end as AllWarehouse

from(
(
select
"MSTOCKCODE","MWAREHOUSE",
mdl."LOT" AS MLOT, 
SUM(mdl."QTYDISPATCHED") QtyDispatched
from (select distinct * from sysprocompanyb.xpomdndetail_stg0_gp) md inner join sysprocompanyb.xpomdndetaillot_stg0_gp mdl on md."SALESORDER" = mdl."SALESORDER"
and md."SALESORDERLINE" = mdl."SALESORDERLINE" and md."OBORDER" = mdl."OBORDER" and md."XPOWHORDER" = mdl."WHORDER"
--and "ORDERSTATUS" = 'SHIPPED'
group by "MSTOCKCODE",
mdl."LOT","MWAREHOUSE"

) dis
full outer join(select LOD."STOCKCODE" as LOD_STOCKCODE, LOD."LOT" , LOD."WAREHOUSE", case when LOD."WAREHOUSE"='XQC' then sum("QTYONHAND") end as XQCQtyOnHand,
case when LOD."WAREHOUSE"='XFG' then sum("QTYONHAND") end as XFGQtyOnHand , sum("QTYONHAND")  as TotalQtyOnHand 
FROM sysprocompanyb.xpolotdetail_stg0_gp LOD
--where  "LOT" like '%011J7%'
group by LOD."LOT", LOD."STOCKCODE", LOD."WAREHOUSE"

)test1 on dis."MSTOCKCODE"= test1.LOD_STOCKCODE and dis.MLOT = test1."LOT" and dis."MWAREHOUSE" = test1."WAREHOUSE")) xpo

full outer join
---syspro  part

(select  dis.*,test1.*,
case when dis."MStockCode" is null then test1.LOD_STOCKCODE else dis."MStockCode" end as AllStockCode,
case when dis.mlot is null then test1."Lot" else dis.mlot end as AllLot,
case when dis."MWarehouse" is null then test1."Warehouse" else dis."MWarehouse" end as AllWarehouse
from
(select

"MStockCode",md."MWarehouse",
mdl."Lot" AS mlot,

Sum(mdl."StockQtyToShip") DispatchQty from sysprocompanyb.mdndetailmain_stg0_gp md right  join  sysprocompanyb.mdndetaillotmain_stg0_gp mdl
on
md."SalesOrder"=mdl."SalesOrder" and md."SalesOrderLine"=mdl."SalesOrderLine" and md."DispatchNote" = mdl."DispatchNote" and md."DispatchNoteLine" = mdl."DispatchNoteLine"

where  md."LineType"='1'
and "DispatchStatus" <> '*'

group by 
"MStockCode",
mdl."Lot",
md."MWarehouse"

)dis
full outer join
(select lod."StockCode" as LOD_STOCKCODE, lod."Lot","Warehouse", case when lod."Warehouse"='XQC' then sum("QtyOnHand") end as XQCQtyOnHand,
case when LOD."Warehouse"='XFG' then sum("QtyOnHand") end as XFGQtyOnHand ,
Sum("QtyOnHand") QtyOnHand
from 
sysprocompanyb.lotdetailmain_stg0_gp lod 
group by lod."Lot",lod."StockCode",lod."Warehouse")test1 on dis."MStockCode"=test1.LOD_STOCKCODE and dis.mlot=test1."Lot" and dis."MWarehouse" = test1."Warehouse") sys
on xpo.AllStockCode = sys.AllStockCode and xpo.AllLot = sys.AllLot and xpo.AllWarehouse = sys.AllWarehouse
--where (sys.AllWarehouse = 'XFG' or xpo.AllWarehouse = 'XFG')
--and (sys.AllStockCode like '%ABBL-NHO-13OZ-12%'
--or xpo.AllStockCode like '%ABBL-NHO-13OZ-12%')
