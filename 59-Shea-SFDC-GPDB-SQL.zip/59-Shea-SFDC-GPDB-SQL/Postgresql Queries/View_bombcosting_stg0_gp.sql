-----NOTE :- NOT IN USE------------- 20Nov18 Vinit

select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, tmp.* from ( select        'B' AS Section,
              'M' AS Source,
			  BomS."ParentPart",
			  InvM."Ebq" AS Ebq, 
			  BomS."Route", 
            BomS."OperationOffset",
			BomS."Component" AS "[Comp/Wc]",
			InvM_1."Description", 
			BomS."QtyPer", 
			'0' AS SetUpTime,
			'0' AS EffSetupTime,
			'0' AS SetupRate,
			'0' AS SetupCost, 
                        '0' AS RunTime, 
			'0' AS RunTimeRate, 
			'0' AS RunTimeCost, 
			'0' AS Time4FixOH, 
			'0' AS FixOHRate, 
			'0' AS FixOHCost, 
            InvWh."UnitCost" AS CurWhCost, 
            InvM_1."MaterialCost",
			InvM_1."LabourCost", 
			InvM_1."FixOverhead", 
            InvM_1."MaterialCost" + InvM_1."LabourCost" + InvM_1."FixOverhead" AS TotCIUnitCost, 
            (InvM_1."MaterialCost" + InvM_1."LabourCost" + InvM_1."FixOverhead") * BomS."QtyPer" AS LineCost, 
            derivedtbl_1.Comp AS "[Bulk]"

			
FROM           sysprocompanyb.bomstructuremain_stg0_gp as BomS
LEFT OUTER JOIN
                         sysprocompanyb.InvMastermain_stg0_gp as InvM ON BomS."ParentPart" = InvM."StockCode" 
						 
LEFT OUTER JOIN
                         sysprocompanyb.InvMastermain_stg0_gp AS InvM_1 ON BomS."Component" = InvM_1."StockCode" 
LEFT OUTER JOIN
                (SELECT        "ParentPart", 
				 MIN("Component") AS Comp
 FROM            sysprocompanyb.bomstructuremain_stg0_gp AS BomS_1
                WHERE        (substr("Component",0, 2) = 'WP') AND ("Route" = '0')
                GROUP BY "ParentPart") AS derivedtbl_1 ON BomS."ParentPart" = derivedtbl_1."ParentPart" 
LEFT OUTER JOIN
                         sysprocompanyb.InvWarehousemain_stg0_gp as InvWh  ON InvM_1."StockCode" = InvWh."StockCode" AND InvM_1."WarehouseToUse" = InvWh."Warehouse"
                WHERE        (BomS."Route" = '0')

				
				
UNION ALL




SELECT        'B' AS Section, 
              'L' AS Source, 
			  BomOp."StockCode", 
			  InvM."Ebq", 
			  BomOp."Route", 
			  BomOp."Operation", 
              BomOp."WorkCentre" AS "[Comp/WC]", 
			  Bomwc."Description",  '1' AS QtyPer,
			  BomOp."ISetUpTime" AS SetupTime, 
              CASE WHEN "Ebq" = '0' THEN "ISetUpTime" ELSE "ISetUpTime" / "Ebq" END AS EffSetupTime, 
			  Bomwc."SetUpRate1", 
              (CASE WHEN "Ebq" = '0' THEN "ISetUpTime" ELSE "ISetUpTime" / "Ebq" END) * Bomwc."SetUpRate1" AS SetupCost, 
			  BomOp."IRunTime" AS RunTime, 
              Bomwc."RunTimeRate1", 
			  BomOp."IRunTime" * Bomwc."RunTimeRate1" AS RunTimeCost, 
             (CASE WHEN "Ebq" = '0' THEN "ISetUpTime" ELSE "ISetUpTime" / "Ebq" END) + BomOp."IRunTime" AS Time4FixOH, 
			  Bomwc."FixOverRate1" AS FixOHRate, 
              Cast(((CASE WHEN "Ebq" = '0' THEN "ISetUpTime" ELSE "ISetUpTime" / "Ebq" END) + BomOp."IRunTime") * Bomwc."FixOverRate1" AS float) AS FixOHCost, 
              '0' AS CurWhCost, 
			  BomOp."SubOpUnitValue" AS MaterialCost, 
			  '0' AS LabourCost, 
			  '0' AS FixOverhead, 
			  '0' AS TotUnitCost, 
			  ((CASE WHEN "Ebq" = '0' THEN "ISetUpTime" ELSE "ISetUpTime" / "Ebq" END) 
              * Bomwc."SetUpRate1" + BomOp."IRunTime" * Bomwc."RunTimeRate1") + ((CASE WHEN "Ebq" = '0' THEN "ISetUpTime" ELSE "ISetUpTime" / "Ebq" END)
              + BomOp."IRunTime") * Bomwc."FixOverRate1" AS LineCost, 
			  derivedtbl_1.Comp

FROM         sysprocompanyb.bomoperationsmain_stg0_gp as  BomOp 
              INNER JOIN
             sysprocompanyb.bomworkcentermain_stg0_gp as  Bomwc ON BomOp."WorkCentre" = Bomwc."WorkCentre" 
			  INNER JOIN
             sysprocompanyb.InvMastermain_stg0_gp   as  InvM ON BomOp."StockCode" = InvM."StockCode" 
			  LEFT OUTER JOIN
                             (SELECT        "ParentPart",
                              MIN("Component") AS Comp
                               FROM            sysprocompanyb.bomstructuremain_stg0_gp  AS BomS_1
                               WHERE        (substr("Component",0, 2) = 'WP') AND ("Route" = '0')
                               GROUP BY "ParentPart") AS derivedtbl_1 ON BomOp."StockCode" = derivedtbl_1."ParentPart"
WHERE        (BomOp."Route" = '0')


UNION ALL


SELECT        'J'::text AS Section, 
              'R'::text AS Source,
              JobReceipts_Rank_InvMovements."StockCode", 
              JobReceipts_Rank_InvMovements."Job":: numeric AS Ebq, 
              JobReceipts_Rank_InvMovements."rn":: bpchar AS Route,
              '0'::numeric AS Operation, 
			  JobReceipts_Rank_InvMovements."StockCode" AS "[Comp/Wc]", 
              WipM."StockDescription", 
			  WipM."QtyManufactured", 
			  WipJobPost_LaborCost.SetupHrs, 
              WipJobPost_LaborCost.SetupHrs AS EffSetupTime, 
              WipJobPost_LaborCost.SetupRate, 
			  WipJobPost_LaborCost.SetupCost, 
			  WipJobPost_LaborCost.RunTimeHrs, 
              WipJobPost_LaborCost.RunTimeRate, 
			  WipJobPost_LaborCost.RunTimeCost, 
			  WipJobPost_LaborCost.FixOHRate, 
              WipJobPost_LaborCost.FixOHCost, 
			  WipJobPost_LaborCost.LabCost, 
			  WipM."MatCostToDate1", 
              CASE WHEN WipM."QtyManufactured" = '0' THEN '0' ELSE WipM."MatCostToDate1" / WipM."QtyManufactured" END AS UnitMatCost, 
              CASE WHEN WipM."QtyManufactured" = '0' THEN '0' ELSE WipJobPost_LaborCost.LabCost / WipM."QtyManufactured" END AS UnitLabCost, 
              CASE WHEN WipM."QtyManufactured" = '0' THEN '0' ELSE WipJobPost_LaborCost.FixOHCost / WipM."QtyManufactured" END AS UnitFixOHCost, 
              '0' AS TotCICost, 
              CASE WHEN WipM."QtyManufactured" = '0' THEN '0' ELSE WipM."MatCostToDate1" / WipM."QtyManufactured" END + CASE WHEN WipM."QtyManufactured"= '0' 
              THEN '0' ELSE WipJobPost_LaborCost.LabCost / WipM."QtyManufactured" END + CASE WHEN WipM."QtyManufactured" = '0' THEN '0' ELSE WipJobPost_LaborCost.FixOHCost/ WipM."QtyManufactured" END AS LineCost,
						  derivedtbl_1.Comp AS Bulk

FROM                /* JobReceipts_Rank_InvMovements*/
                    
			(SELECT        Row_Number() OVER (Partition BY "StockCode"
            ORDER BY "EntryDate" DESC) AS rn, 
			"StockCode", 
			"EntryDate", 
			"Job", 
			"TrnQty"
FROM            
          sysprocompanyb.invmovementsmain_stg0_gp 
            WHERE        "TrnType" = 'R' AND "Source" = 'J')   as JobReceipts_Rank_InvMovements 
                   
 LEFT OUTER JOIN
                     
			(SELECT        "ParentPart", MIN("Component") AS Comp
FROM            sysprocompanyb.bomstructuremain_stg0_gp  AS BomS_1
            WHERE        (substr("Component",0, 2) = 'WP') AND ("Route" = '0')
                        GROUP BY "ParentPart") AS derivedtbl_1 ON JobReceipts_Rank_InvMovements."StockCode" = derivedtbl_1."ParentPart" 
LEFT OUTER JOIN
                       sysprocompanyb.Wipmastermain_stg0_gp  as  WipM ON JobReceipts_Rank_InvMovements."Job" = WipM."Job" 
LEFT OUTER JOIN  
                    /*View_WipJobPost_LaborCost*/
            (SELECT    -- TOP (100) PERCENT 
            "Job", 
			SUM("LRunTimeHours") AS RunTimeHrs, 
			MAX("LRunTimeRate") AS RunTimeRate, 
			SUM("LRunTimeHours" * "LRunTimeRate") AS RunTimeCost, 
            SUM("LSetUpHours") AS SetupHrs, 
			MAX("LSetUpTimeRate") AS SetupRate, 
			SUM("LSetUpHours" * "LSetUpTimeRate") AS SetupCost, 
			AVG("LFixedTimeRate") AS FixOHRate, 
            SUM("LFixedTimeRate" * ("LRunTimeHours" + "LSetUpHours")) AS FixOHCost, 
			SUM("TrnValue") AS LabCost
FROM         sysprocompanyb.wipjobpostmain_stg0_gp  
           WHERE     ("TrnType" = 'L') GROUP BY "Job")  as WipJobPost_LaborCost
                          ON JobReceipts_Rank_InvMovements."Job" = WipJobPost_LaborCost."Job"
WHERE        (JobReceipts_Rank_InvMovements."rn" <= 3)
)tmp
