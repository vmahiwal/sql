
----Actual Order Report

select "CorpAcctName",trim(art."StockCode") as StockCode,"TrnYear","TrnMonth" ,"InvoiceDate" 
,SUM("NetSalesValue") as NetSalesValue,SUM("NetSalesValue"+"DiscValue") as GrossSales ,SUM("QtyInvoiced") as QtyInvoiced
from sysprocompanyb.artrndetailmain_stg0_gp art
left join sysprocompanyb.arcustomermain_stg0_gp ar on ar."Customer" = art."Customer"
where
(
(("TrnYear"=year(now())-2) and "TrnMonth">='10')  or ("TrnYear"=year(now())-1) or ("TrnYear"=year(now())) 
)
and (art."LineType"='1' or art."LineType"='7') --and "DocumentType"<>'C'
and (art."Branch" is distinct from 'TR' and art."Branch" is distinct from 'CO' and art."Branch" is distinct from 'SM')
and ("TransactionGlCode" like '%-4000' or "TransactionGlCode" like '%-4001' or "TransactionGlCode" like '%-4002')
group by "InvoiceDate","CorpAcctName",art."StockCode","TrnYear","TrnMonth", "InvoiceDate"
