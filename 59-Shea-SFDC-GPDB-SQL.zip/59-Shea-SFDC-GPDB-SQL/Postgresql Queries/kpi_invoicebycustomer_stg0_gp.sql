
SELECT ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
"CorpAcctName",a."Customer","InvoiceDate",SUM("NetSalesValue"+"DiscValue") as GrossInvoice
FROM sysprocompanyb.artrndetailmain_stg0_gp  a
left join sysprocompanyb.arcustomermain_stg0_gp b on a."Customer"=b."Customer"
WHERE ("LineType" = '1') AND ("TrnYear" = DATE_PART('year',now())) AND (a."Branch" is distinct from 'TR' and a."Branch" is distinct from 'CO' and a."Branch" is distinct from 'SM')
group by "CorpAcctName",a."Customer","InvoiceDate"
