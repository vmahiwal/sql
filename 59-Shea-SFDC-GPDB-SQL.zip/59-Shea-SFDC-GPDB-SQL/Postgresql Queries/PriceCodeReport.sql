
---Price Code Report

select "StockCode",inv."PriceCode","SellingPrice","CorpAcctName" from sysprocompanyb.invpricemain_stg0_gp  inv left join
(   select "PriceCode","CorpAcctCode","CorpAcctName"
    from sysprocompanyb.arcustomermain_stg0_gp ar
     group by "PriceCode","CorpAcctCode","CorpAcctName"  ) t
on t."PriceCode" = inv."PriceCode" where inv."PriceCode" is not null and inv."PriceCode" !=' '