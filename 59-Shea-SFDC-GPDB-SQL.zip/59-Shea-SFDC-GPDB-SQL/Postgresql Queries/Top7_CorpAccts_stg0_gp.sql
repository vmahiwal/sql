select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time
,od."SalesOrder",od."SalesOrderLine","Invoice",om."Customer","CorpAcctName",
"InvoiceDate",od."MStockCode",od."MStockDes","EntrySystemDate","CustomerPoNumber"
,"MLineShipDate","OrderStatus" ,SUM(QtyInvoiced) as QtyInvoiced,
SUM("MOrderQty") as QtyOrdered ,"MPrice" ,SUM(GrossInvoiced) as GrossInvoiced
,SUM("MOrderQty"*"MPrice") as GrossOrdered 
from sysprocompanyb.sordetailmain_stg0_gp   od inner join sysprocompanyb.sormastermain_stg0_gp  om on om."SalesOrder"=od."SalesOrder" 
left join 
(SELECT * FROM( select "SalesOrder","Invoice","SalesOrderLine","Customer","InvoiceDate"
,SUM("QtyInvoiced") as QtyInvoiced, SUM("NetSalesValue"+"DiscValue") as GrossInvoiced 
,RANK() OVER (PARTITION BY "SalesOrder" ORDER BY "Invoice" ASC) AS xRank from sysprocompanyb.artrndetailmain_stg0_gp   where ("LineType" = '1') 
and ("Branch" is distinct from  'TR' and  "Branch" is distinct from  'CO' and "Branch" is distinct from  'SM') AND ("DocumentType") is distinct from 'C' and extract(Year from ("InvoiceDate")) >= extract(Year from (now()))-2
group by "SalesOrder","Invoice","SalesOrderLine","Customer","InvoiceDate")hello where xRank=1 )art 
on od."SalesOrder"=art."SalesOrder" and od."SalesOrderLine"=art."SalesOrderLine" 
left join sysprocompanyb.arcustomermain_stg0_gp vw on vw."Customer"=om."Customer" where extract(Year from ("EntrySystemDate"))>=extract(Year from (now()))-2
AND (od."LineType" = '1') AND (om."CancelledFlag" is distinct from  'Y') and om."OrderStatus" is distinct from '' AND (om."InterWhSale" is distinct from 'Y') 
AND (om."Branch" is distinct from 'TR' and om."Branch" is distinct from 'CO' and om."Branch" is distinct from 'SM') AND (od."LineType" = '1')
 AND (om."DocumentType") is distinct from 'C'  
and ("CorpAcctName" in (
select  "CorpAcctName" from  sysprocompanyb.artrndetailmain_stg0_gp ar
left join sysprocompanyb.arcustomermain_stg0_gp vw on ar."Customer" = vw."Customer"
where
 extract(Year from ("InvoiceDate")) >= extract(Year from (now()))-2 and
("LineType" = '1') 
and (ar."Branch" is distinct from  'TR' and  ar."Branch" is distinct from  'CO' and ar."Branch" is distinct from  'SM') AND ("DocumentType") is distinct from 'C'
group by "CorpAcctName"
order by Sum("NetSalesValue") desc Limit 7
)) group by od."SalesOrder",od."SalesOrderLine","Invoice",om."Customer","CorpAcctName","InvoiceDate",od."MStockCode"
,od."MStockDes","MPrice","EntrySystemDate","CustomerPoNumber","MLineShipDate","OrderStatus"



