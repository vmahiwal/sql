
SELECT ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
 bo."WH",
 bo."ShipQty",
-- SUBSTRING(od.SalesOrder, PATINDEX('%[^0 ]%', od.SalesOrder + ''), LEN(od.SalesOrder)) as SalesOrder,
LTRIM (od."SalesOrder",0) as SalesOrder,
od."MStockCode",od."SalesOrderLine", LTRIM(om."Customer",0) As Customer,
"CorpAcctName",od."MPrice",om."CustomerPoNumber"

FROM              sysprocompanyb.barcodeordersmain_stg0_gp  bo INNER JOIN sysprocompanyb.sordetailmain_stg0_gp od 
             ON 
           --SUBSTRING(od."SalesOrder", PATINDEX('%[^0 ]%', od."SalesOrder" + ''), LEN(od."SalesOrder")) = SUBSTRING(bo."OrderNo", PATINDEX('%[^0 ]%', bo."OrderNo" + ''), LEN(bo."OrderNo"))  
		   --COLLATE Latin1_General_BIN 
		 LTRIM (od."SalesOrder",0)=LTRIM(bo."OrderNo",0)
           AND od."MStockCode" = bo."ItemNo" --COLLATE Latin1_General_BIN 
           AND od."SalesOrderLine" = bo."LineNumber"
          INNER JOIN sysprocompanyb.sormastermain_stg0_gp  om
           ON od."SalesOrder" = om."SalesOrder"
           left join sysprocompanyb.arcustomermain_stg0_gp  a on a."Customer"=om."Customer"
WHERE (om."Branch" is distinct from 'TR' and om."Branch" is distinct from  'CO' and om."Branch" is distinct from  'SM')
    AND (om."Customer" is distinct from '000000000048869' and om."Customer" is distinct from '000000000049870');
