
SELECT      ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,  
rtrim (sysprocompanyb.pormasterdetailmain_stg0_gp."PurchaseOrder") as PurchaseOrder, 
rtrim (sysprocompanyb.pormasterhdrmain_stg0_gp."Supplier") as Supplier, 
rtrim (sysprocompanyb.apsuppliermain_stg0_gp."SupplierName") as SupplierName,
 sysprocompanyb.pormasterdetailmain_stg0_gp."Line", sysprocompanyb.pormasterdetailmain_stg0_gp."LineType",
rtrim(sysprocompanyb.pormasterdetailmain_stg0_gp."MStockCode") AS StockCode, rtrim

(sysprocompanyb.pormasterdetailmain_stg0_gp."MStockDes") AS StockDes, rtrim

(sysprocompanyb.pormasterdetailmain_stg0_gp."MProductClass") AS ProductClass,
rtrim(sysprocompanyb.pormasterdetailmain_stg0_gp."MWarehouse") AS Wh, sysprocompanyb.pormasterdetailmain_stg0_gp."MOrderUom" AS 

OrdUom, sysprocompanyb.pormasterdetailmain_stg0_gp."MOrderQty" AS OrdQty,
sysprocompanyb.pormasterdetailmain_stg0_gp."MReceivedQty" AS ReceivedQty,
CASE WHEN sysprocompanyb.pormasterdetailmain_stg0_gp."MCompleteFlag" = 'Y' THEN 0 ELSE "MOrderQty" - "MReceivedQty" END AS 

OutstandingQty,
sysprocompanyb.pormasterdetailmain_stg0_gp."MLatestDueDate"AS LatestDueDt, sysprocompanyb.pormasterdetailmain_stg0_gp."MPrice" AS 

UnitPrice, rtrim(sysprocompanyb.admformdatamain_stg0_gp."AlphaValue") AS "[Special Comment]",
sysprocompanyb.pormasterhdrmain_stg0_gp."OrderStatus", sysprocompanyb.pormasterhdrmain_stg0_gp."OrderEntryDate", rtrim

(sysprocompanyb.pormasterhdrmain_stg0_gp."ShippingInstrs") as ShippingInstrs, 

sysprocompanyb.pormasterhdrmain_stg0_gp."DatePoCompleted",
sysprocompanyb.pormasterdetailmain_stg0_gp."MLastReceiptDat"
FROM            sysprocompanyb.pormasterdetailmain_stg0_gp INNER JOIN
sysprocompanyb.pormasterhdrmain_stg0_gp ON sysprocompanyb.pormasterdetailmain_stg0_gp."PurchaseOrder" = 

sysprocompanyb.pormasterhdrmain_stg0_gp."PurchaseOrder" INNER JOIN
sysprocompanyb.apsuppliermain_stg0_gp ON sysprocompanyb.pormasterhdrmain_stg0_gp."Supplier" = 

sysprocompanyb.apsuppliermain_stg0_gp."Supplier" LEFT OUTER JOIN
sysprocompanyb.admformdatamain_stg0_gp   ON sysprocompanyb.pormasterdetailmain_stg0_gp."PurchaseOrder" = 

sysprocompanyb.admformdatamain_stg0_gp  ."KeyField"
