
SELECT ROW_NUMBER() OVER (ORDER BY NOW()) AS ID, NOW() as time,
jr."TrnDate", sum(jr."QtySupplied") as "Production",jm."Warehouse"
FROM sysprocompanyb.wippartbookmain_stg0_gp jr INNER JOIN sysprocompanyb.wipmastermain_stg0_gp jm ON jr."Job" = jm."Job"
INNER JOIN sysprocompanyb.invmastermain_stg0_gp  im on jm."StockCode" = im."StockCode"
--Modified 2016-08-29 based on email from Paul Biondi forwarded by Avani Patel
--WHERE jm.Warehouse IN ('F1','F2','F3')
-- AND DATEPART(year,jr.TrnDate) = DATEPART(year,GETDATE())
-- AND RIGHT(RTRIM(jm.StockCode), 2) = '01'
-- AND LEFT(im.ProductClass, 2) <> 'SO'
-- AND NOT(im.ProductClass IN ('BA03', 'BY03', 'CC', 'HC03', 'SC03', 'SC04', 'S001', 'S002'))
WHERE jm."Warehouse" IN ('F1','F2','F3','QC')
AND jr."TrnDate">= date_trunc('DAY', current_date)-'89DAY'::interval
AND RTRIM(jm."StockCode") LIKE '%01'
AND substr(im."ProductClass",0, 3) IS DISTINCT FROM 'SO'
AND (im."ProductClass" IS DISTINCT FROM 'BA03' AND im."ProductClass" IS DISTINCT FROM 'BY03'AND im."ProductClass" IS DISTINCT FROM 'CC'AND
im."ProductClass" IS DISTINCT FROM 'FC03' AND im."ProductClass" IS DISTINCT FROM 'FC04' AND im."ProductClass" IS DISTINCT FROM 'HC03'
AND im."ProductClass" IS DISTINCT FROM 'SC03' AND im."ProductClass" IS DISTINCT FROM 'SC04' AND im."ProductClass" IS DISTINCT FROM 'SH04'
AND im."ProductClass" IS DISTINCT FROM 'S001' AND im."ProductClass" IS DISTINCT FROM 'S002')
group by  jr."TrnDate", jm."Warehouse"

