--------------------Monthly_performanybyCustomer_stg0_gp--------------------
select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, a.* from 
(SELECT 
'Ordered' as RecordType, "CorpAcctName",CASE WHEN Extract(month from om."ReqShipDate") = 1 and Extract(year from om."ReqShipDate") = year(now()) then (year(now()))||'-'||'01'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 2 and Extract(year from om."ReqShipDate") = year(now()) then  year(now())||'-'||'02'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 3 and Extract(year from om."ReqShipDate") = year(now()) then year(now())||'-'||'03'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 4 and Extract(year from om."ReqShipDate") = year(now()) then  year(now())||'-'||'04'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 5 and Extract(year from om."ReqShipDate") = year(now()) then year(now())||'-'||'05'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 6 and Extract(year from om."ReqShipDate") = year(now()) then  year(now())||'-'||'06'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 7 and Extract(year from om."ReqShipDate") = year(now()) then  year(now())||'-'||'07'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 8 and Extract(year from om."ReqShipDate") = year(now()) then year(now())||'-'||'08'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 9 and Extract(year from om."ReqShipDate") = year(now()) then  year(now())||'-'||'09'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 10 and Extract(year from om."ReqShipDate") = year(now()) then year(now())||'-'||'10'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 11 and Extract(year from om."ReqShipDate") = year(now()) then year(now())||'-'||'11'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 12 and Extract(year from om."ReqShipDate") = year(now()) then year(now())||'-'||'12'||'-'||'01'
    
    WHEN Extract(month from om."ReqShipDate") = 1 and Extract(year from om."ReqShipDate") = year(now())-1 then year(now())-1||'-'||'01'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 2 and Extract(year from om."ReqShipDate") = year(now())-1 then  year(now())-1||'-'||'02'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 3 and Extract(year from om."ReqShipDate") = year(now())-1 then year(now())-1||'-'||'03'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 4 and Extract(year from om."ReqShipDate") = year(now())-1 then year(now())-1||'-'||'04'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 5 and Extract(year from om."ReqShipDate") = year(now())-1 then year(now())-1||'-'||'05'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 6 and Extract(year from om."ReqShipDate") = year(now())-1 then  year(now())-1||'-'||'06'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 7 and Extract(year from om."ReqShipDate") = year(now())-1 then year(now())-1||'-'||'07'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 8 and Extract(year from om."ReqShipDate") = year(now())-1 then year(now())-1||'-'||'08'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 9 and Extract(year from om."ReqShipDate") = year(now())-1 then year(now())-1||'-'||'09'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 10 and Extract(year from om."ReqShipDate") = year(now())-1 then  year(now())-1||'-'||'10'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 11 and Extract(year from om."ReqShipDate") = year(now())-1 then year(now())-1||'-'||'11'||'-'||'01'
    WHEN Extract(month from om."ReqShipDate") = 12 and Extract(year from om."ReqShipDate") = year(now())-1 then year(now())-1||'-'||'12'||'-'||'01' end as Date,
   SUM(od."MOrderQty" * od."MPrice") as Value
  
  
FROM sysprocompanyb.sormastermain_stg0_gp om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp od ON om."SalesOrder" = od."SalesOrder" left join sysprocompanyb.arcustomermain_stg0_gp arc on arc."Customer"=om."Customer"

WHERE (om."OrderStatus" in ('0','1','2','3','4','8','9','S'))
  AND (om."CancelledFlag" is distinct from 'Y')
  AND (om."InterWhSale" is distinct from 'Y') 
  AND (om."Branch" is distinct from 'TR' and om."Branch" is distinct from 'CO' and om."Branch" is distinct from 'SM')
  AND (od."LineType" = '1')
  --Added following condition to eliminate credit notes 
  AND (om."DocumentType") is distinct from 'C'
  -- Next Line To Exclude Raw Material Customers
    AND  (om."Customer" is distinct from '000000000048869' and om."Customer" is distinct from '000000000049870')
  AND extract(year from "ReqShipDate") in ( Extract(year from now()),Extract(year from current_date)-1)
  group by "CorpAcctName",Extract(month from "ReqShipDate"), Extract(year from "ReqShipDate")
  
UNION ALL
SELECT 'Invoiced' as RecordType, "CorpAcctName",
   case when "TrnYear"=year(now()) and "TrnMonth"=1 then  year(now())||'-'||'01'||'-'||'01'
  when "TrnYear"=year(now()) and "TrnMonth"=2 then  year(now())||'-'||'02'||'-'||'01'
when "TrnYear"=year(now()) and "TrnMonth"=3 then  year(now())||'-'||'03'||'-'||'01'
  when "TrnYear"=year(now()) and "TrnMonth"=4 then  year(now())||'-'||'04'||'-'||'01'
  when "TrnYear"=year(now()) and "TrnMonth"=5 then  year(now())||'-'||'05'||'-'||'01'
  when "TrnYear"=year(now()) and "TrnMonth"=6 then  year(now())||'-'||'06'||'-'||'01'
  when "TrnYear"=year(now()) and "TrnMonth"=7 then  year(now())||'-'||'07'||'-'||'01'
  when "TrnYear"=year(now()) and "TrnMonth"=8 then  year(now())||'-'||'08'||'-'||'01'
  when "TrnYear"=year(now()) and "TrnMonth"=9 then  year(now())||'-'||'09'||'-'||'01'
  when "TrnYear"=year(now()) and "TrnMonth"=10 then  year(now())||'-'||'10'||'-'||'01'
  when "TrnYear"=year(now()) and "TrnMonth"=11 then  year(now())||'-'||'11'||'-'||'01'
  when "TrnYear"=year(now()) and "TrnMonth"=12 then  year(now())||'-'||'12'||'-'||'01'
  
  when "TrnYear"=year(now())-1 and "TrnMonth"=1 then  year(now())-1||'-'||'01'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=2 then  year(now())-1||'-'||'02'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=3 then  year(now())-1||'-'||'03'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=4 then  year(now())-1||'-'||'04'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=5 then  year(now())-1||'-'||'05'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=6 then  year(now())-1||'-'||'06'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=7 then  year(now())-1||'-'||'07'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=8 then  year(now())-1||'-'||'08'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=9 then  year(now())-1||'-'||'09'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=10 then  year(now())-1||'-'||'10'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=11 then  year(now())-1||'-'||'11'||'-'||'01'
  when "TrnYear"=year(now())-1 and "TrnMonth"=12 then  year(now())-1||'-'||'12'||'-'||'01'
   end as Date
  
  --, SUM(NetSalesValue) as MonthlySales
  , SUM("NetSalesValue" + "DiscValue") as Value
FROM sysprocompanyb.artrndetailmain_stg0_gp art left join sysprocompanyb.arcustomermain_stg0_gp arc on arc."Customer"=art."Customer"
WHERE "TrnYear" in ( Extract(year from now()),Extract(year from now())-1) and ("LineType" = '1') and (art."Branch" is distinct from 'TR' and  art."Branch" is distinct from 'CO' and art."Branch" is distinct from  'SM')
--Added following condition to eliminate credit notes year(now())-1-06-07
  AND ("DocumentType") is distinct from 'C'
  --year(now())-1-12-14 Next Line To Exclude Raw Material Customers
    AND  (art."Customer" is distinct from '000000000048869' and art."Customer" is distinct from '000000000049870')

GROUP BY "CorpAcctName","TrnYear"
  , "TrnMonth"

UNION ALL
       
select 'Forecast' as RecordType,"CorpAcctName", "ForecastDate" :: text,sum(value) as Value
from(
SELECT    "CorpAcctName"
       ,"StockCode"
       , "ForecastDate"
       , "ForecastQty", a.*, "ForecastRevenue" as value
      
 FROM proddata.sysprocompanyb.salesforecast_month_stg0_gp sf left join (select a."CorpAcctName" as CorpAcctName,a."StockCode" as StockCode from
(select "StockCode",inv."PriceCode","CorpAcctName" from sysprocompanyb.invpricemain_stg0_gp inv left join
(select "PriceCode","CorpAcctCode","CorpAcctName"
from sysprocompanyb.arcustomermain_stg0_gp
group by "PriceCode","CorpAcctCode","CorpAcctName") t
on t."PriceCode" = inv."PriceCode")a 
group by a."CorpAcctName",a."StockCode"
order by a."CorpAcctName",a."StockCode")a on a.StockCode=sf."StockCode" and sf."CorpAcctName"=a.CorpAcctName)a
group by a."CorpAcctName", "ForecastDate" 
)a
