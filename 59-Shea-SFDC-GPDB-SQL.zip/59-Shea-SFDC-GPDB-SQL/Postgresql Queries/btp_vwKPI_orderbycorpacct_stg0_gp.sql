
--Job : BTP_vwKPI_OrdersByCorpAcct_stg0_gp


SELECT now() as time,cacm.CorpAcctName
    	, SUM(CASE WHEN od."MLineShipDate" <= now() 
			THEN ROUND(((od."MShipQty" + od."MBackOrderQty") * od."MPrice") ,2)
			ELSE 0 END) as CurrMonthToDate
		, SUM(CASE WHEN (DATE_PART('day',od."MLineShipDate") <= 25 AND DATE_PART('month', od."MLineShipDate") = DATE_PART('month', now()) AND DATE_PART('year', od."MLineShipDate") = DATE_PART('year', now()))
			THEN ROUND(((od."MShipQty" + od."MBackOrderQty") * od."MPrice") ,2)
			ELSE 0 END) as CurrMonthThru25
		, SUM(CASE WHEN od."MLineShipDate" > now() AND DATE_PART('year', od."MLineShipDate") = DATE_PART('year',now()) and DATE_PART('month', od."MLineShipDate") = DATE_PART('month',now())
		    THEN ROUND(((od."MShipQty" + od."MBackOrderQty") * od."MPrice") ,2)
			ELSE 0 END) as CurrMonthRemain
		, SUM(CASE WHEN (DATE_PART('year', od."MLineShipDate") = DATE_PART('year', now()) and DATE_PART('month', od."MLineShipDate") = DATE_PART('month', now())) or (od."MLineShipDate" <= now())
		    THEN ROUND(((od."MShipQty" + od."MBackOrderQty") * od."MPrice") ,2)
			ELSE 0 END) as CurrMonthTotal
		, SUM(CASE WHEN od."MLineShipDate" > date_trunc('month', current_date)+'1month'::interval-'1day'::interval THEN ROUND(((od."MShipQty" + od."MBackOrderQty") * od."MPrice") ,2) ELSE 0 END) as FutureMonthTotal
		, 0 as Picked
		, SUM(ROUND(((od."MShipQty" + od."MBackOrderQty") * od."MPrice") ,2)) as TotalOpenOrders
		, date_trunc('month', now())+'1month'::interval-'1day'::interval as MonthEnd
	
FROM sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp od ON om."SalesOrder" = od."SalesOrder" 
					LEFT JOIN (SELECT "KeyField" as Customer
									, "AlphaValue" as CorpAcctCode
								FROM sysprocompanyb.admformdatamain_stg0_gp
								WHERE "FormType" = 'CUS' and "FieldName" = 'COR002') cac ON om."Customer" = cac.Customer
					LEFT JOIN (SELECT "Item" as CorpAcctCode
									, "Description" as CorpAcctName
								FROM sysprocompanyb.admformvalidationmain_stg0_gp 
								WHERE "FormType" = 'CUS' and "FieldName" = 'COR002') cacm on cac.CorpAcctCode = cacm.CorpAcctCode
 
WHERE (om."OrderStatus" in ('0','1','2','3','4','S')) 
		AND (om."CancelledFlag" is distinct from 'Y')
		AND (om."InterWhSale" is distinct from 'Y') 
		AND (om."Branch" is distinct from 'TR' and om."Branch" is distinct from 'CO' and om."Branch" is distinct from 'SM') 
		AND (od."LineType" = '1')
		
		AND (om."DocumentType") is distinct from 'C'
	
				AND  (om."Customer" is distinct from '000000000048869' and om."Customer" is distinct from '000000000049870')
		AND ((od."MShipQty" + "MBackOrderQty") is distinct from 0) 
GROUP BY cacm.CorpAcctName

UNION ALL

SELECT now() as time,cacm.CorpAcctName
		, 0 as Today
		, 0 as Thru25
		, 0 as WTD
		, 0 as MTD
		, 0 as QTD
		, SUM(ROUND(bo."ShipQty" * od."MPrice", 2)) as Picked
		, 0 as YTD
		, date_trunc('month', now())+'1month'::interval-'1day'::interval as MonthEnd
FROM             sysprocompanyb.barcodeordersmain_stg0_gp  bo 
INNER JOIN sysprocompanyb.sordetailmain_stg0_gp  od 
	ON LTRIM(od."SalesOrder",0) = LTRIM(bo."OrderNo",0) --COLLATE Latin1_General_BIN 
			AND od."MStockCode" = bo."ItemNo" --COLLATE Latin1_General_BIN 
	AND od."SalesOrderLine" = bo."LineNumber"
	INNER JOIN sysprocompanyb.sormastermain_stg0_gp  om
	ON od."SalesOrder" = om."SalesOrder"
	LEFT JOIN (SELECT REPLACE("KeyField",' ','') as Customer
			, "AlphaValue" as CorpAcctCode
FROM sysprocompanyb.admformdatamain_stg0_gp 
WHERE "FormType" = 'CUS' and "FieldName" = 'COR002') cac ON om."Customer" = cac.Customer
LEFT JOIN (SELECT "Item" as CorpAcctCode
, "Description" as CorpAcctName
	FROM sysprocompanyb.admformvalidationmain_stg0_gp 
	WHERE "FormType" = 'CUS' and "FieldName" = 'COR002') cacm on cac.CorpAcctCode = cacm.CorpAcctCode
WHERE (om."Branch" is distinct from 'TR' and om."Branch" is distinct from 'CO' and om."Branch" is distinct from 'SM')

				AND (om."Customer" is distinct from '000000000048869' and om."Customer" is distinct from '000000000049870')
GROUP BY cacm.CorpAcctName

