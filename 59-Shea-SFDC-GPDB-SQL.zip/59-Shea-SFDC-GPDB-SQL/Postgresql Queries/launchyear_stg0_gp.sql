select ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time, x.* from (
select art.StockCode,TrnYear as LaunchYear,RANK() OVER (PARTITION BY art.StockCode ORDER BY TrnYear ASC) as xRank from 
(select distinct case when im.StockUom='CS' then CONCAT(LEFT(ArTrnDetail.StockCode,LEN(RTRIM(ArTrnDetail.StockCode))-2),'01') else ArTrnDetail.StockCode end as StockCode
,TrnYear
from ArTrnDetail left join InvMaster im on im.StockCode=ArTrnDetail.StockCode
 where  (LineType = '1') AND (NOT(Branch IN ('TR', 'CO', 'SM'))) 
         --Added following condition to eliminate credit notes 2016-06-07
        AND (DocumentType) <> 'C'
        AND LEFT(ArTrnDetail.StockCode,4) NOT IN ('DISP','FIXT','GIFT','FBX-','CAP-','LBL-')
                AND NOT (Customer IN ('000000000048869','000000000049870'))) art) x where xRank=1
