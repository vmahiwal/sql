
select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, case when ltrim(bo."OrderNo" ,0) is null 
then ltrim(boh."OrderNo" ,0) else ltrim(bo."OrderNo",0) end,
case when bo."ItemNo" is null then boh."ItemNo" else bo."ItemNo" end as ItemNo,
case when bo."LineNumber" is null then boh."LineNumber" else bo."LineNumber" end as LineNumber,
SUM(case when bo."MStockQtyToShp" is null then boh."MStockQtyToShp"
when boh."MStockQtyToShp" is null then bo."MStockQtyToShp"
else bo."MStockQtyToShp"+boh."MStockQtyToShp" end) as MStockQtyToShp
from
sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp od 
ON om."SalesOrder" = od."SalesOrder"
left join sysprocompanyb.barcodeordersmain_stg0_gp  bo 
ON ltrim(od."SalesOrder",0) =ltrim(bo."OrderNo" ,0) -- COLLATE Latin1_General_BIN
AND od."MStockCode" = bo."ItemNo" --COLLATE Latin1_General_BIN
AND od."SalesOrderLine" = bo."LineNumber"
left join sysprocompanyb.barcodeorderhistorymain_stg0_gp boh ON  
ltrim(od."SalesOrder",0 ) =ltrim(boh."OrderNo" ,0)
--COLLATE Latin1_General_BIN
AND od."MStockCode" = boh."ItemNo"-- COLLATE Latin1_General_BIN
AND od."SalesOrderLine" = boh."LineNumber"
WHERE (om."OrderStatus" in ('0','1','2','3','4','S'))
AND (om."CancelledFlag" is distinct from 'Y')
AND (om."InterWhSale" is distinct from 'Y')
AND (om."Branch" is distinct from 'TR'and om."Branch" is distinct from 'CO' and om."Branch" is distinct from 'SM')
AND (od."LineType" = '1')
AND (om."DocumentType") is distinct from 'C'
AND ((od."MShipQty" + "MBackOrderQty") is distinct from '0')
group by case when ltrim(bo."OrderNo" ,0) is null then ltrim(boh."OrderNo" ,0) else ltrim(bo."OrderNo" ,0) end,
case when bo."ItemNo" is null then boh."ItemNo" else bo."ItemNo" end,
case when bo."LineNumber" is null then boh."LineNumber" else bo."LineNumber" end
