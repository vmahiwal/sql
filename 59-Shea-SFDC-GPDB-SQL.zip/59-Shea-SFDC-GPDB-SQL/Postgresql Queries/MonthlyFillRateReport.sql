--MonthlyFillRateReport.sql


SELECT 'Nubian Heritage' as Category, "CorpAcctName",od."MStockCode",od."MStockDes",SUM("MOrderQty") as QtyOrdered,SUM(QtyInvoiced) as QtyInvoiced,"MPrice",SUM(GrossInvoiced) as GrossInvoiced,SUM("MOrderQty"*"MPrice") as GrossOrdered
,CAST(Round((SUM(QtyInvoiced)/SUM("MOrderQty"))*100) as Decimal(5,2))|| '%' as "QTY Service Level",
(cast(CAST(Round((SUM(GrossInvoiced)/SUM("MOrderQty"*(case when "MPrice" =0 then 1 else "MPrice" end )))*100) as Decimal(5,2)) as TEXT) || '%')  as "$ ServiceLevel"
from sysprocompanyb.sordetailmain_stg0_gp od inner join sysprocompanyb.sormastermain_stg0_gp om on om."SalesOrder"=od."SalesOrder"
left join
(select ar."SalesOrder",ar."SalesOrderLine",ar."Customer",SUM(ar."QtyInvoiced") as QtyInvoiced, SUM(ar."NetSalesValue"+ar."DiscValue") as GrossInvoiced
from sysprocompanyb.artrndetailmain_stg0_gp ar
inner join sysprocompanyb.sordetailmain_stg0_gp om on om."SalesOrder"=ar."SalesOrder" and om."SalesOrderLine"=ar."SalesOrderLine"
where (ar."LineType" = '1')
and (ar."Branch" is distinct from 'TR' and ar."Branch" is distinct from 'CO' and ar."Branch" is distinct from 'SM')

AND (ar."DocumentType") is distinct from 'C'
and (om."MLineShipDate">date_trunc('month', CURRENT_DATE) - interval '1 month - 15 day'  and
om."MLineShipDate"<=date_trunc('month', CURRENT_DATE) - interval '0 month - 15 day')
group by ar."SalesOrder",ar."SalesOrderLine",ar."Customer")art  on od."SalesOrder"=art."SalesOrder" and od."SalesOrderLine"=art."SalesOrderLine"
left join sysprocompanyb.arcustomermain_stg0_gp vw on vw."Customer"=om."Customer"
where (od."MLineShipDate">date_trunc('month', CURRENT_DATE) - interval '1 month - 15 day'  and
od."MLineShipDate"<=date_trunc('month', CURRENT_DATE) - interval '0 month - 15 day') AND (od."LineType" = '1')  and om."OrderStatus" in ('8','9')
AND (om."CancelledFlag" is distinct from 'Y')
AND (om."InterWhSale" is distinct from 'Y')
AND (om."Branch" is distinct from 'TR' and om."Branch" is distinct from  'CO' and om."Branch" is distinct from  'SM')
AND (od."LineType" = '1') AND (om."DocumentType") is distinct from 'C'
and od."MStockCode" like '%-NH%'
--and  od."SalesOrder" like '%000000000367558%'
group by "CorpAcctName",od."MStockCode",od."MStockDes","MPrice"


union 
SELECT 'Shea Moisture' as Category, "CorpAcctName",od."MStockCode",od."MStockDes",SUM("MOrderQty") as QtyOrdered,SUM(QtyInvoiced) as QtyInvoiced,"MPrice",SUM("MOrderQty"*"MPrice") as GrossOrdered,SUM(GrossInvoiced) as GrossInvoiced
,case when ("MOrderQty") =0 then '0' else CAST(Round((SUM(QtyInvoiced)/SUM("MOrderQty"))*100) as Decimal(5,2))|| '%' end "QTY Service Level",
case when ("MOrderQty") =0 then '0' else (cast(CAST(Round((SUM(GrossInvoiced)/SUM("MOrderQty"*(case when "MPrice" =0 then 1 else "MPrice" end )))*100) as Decimal(5,2)) as TEXT) || '%')  end as "$ ServiceLevel"
from sysprocompanyb.sordetailmain_stg0_gp od inner join sysprocompanyb.sormastermain_stg0_gp om on om."SalesOrder"=od."SalesOrder"
right join sysprocompanyb.productitemmaster_fillrate_stg0_gp pif on pif."StockCode"=od."MStockCode"
left join
(select ar."SalesOrder",ar."SalesOrderLine",ar."Customer",SUM(ar."QtyInvoiced") as QtyInvoiced, SUM(ar."NetSalesValue"+ar."DiscValue") as GrossInvoiced
from sysprocompanyb.artrndetailmain_stg0_gp ar
inner join sysprocompanyb.sordetailmain_stg0_gp om on om."SalesOrder"=ar."SalesOrder" and om."SalesOrderLine"=ar."SalesOrderLine"
where (ar."LineType" = '1')
and (ar."Branch" is distinct from 'TR' and ar."Branch" is distinct from 'CO' and ar."Branch" is distinct from 'SM')

AND (ar."DocumentType") is distinct from 'C'
and (om."MLineShipDate">date_trunc('month', CURRENT_DATE) - interval '1 month - 15 day'  and
om."MLineShipDate"<=date_trunc('month', CURRENT_DATE) - interval '0 month - 15 day')
group by ar."SalesOrder",ar."SalesOrderLine",ar."Customer")art  on od."SalesOrder"=art."SalesOrder" and od."SalesOrderLine"=art."SalesOrderLine"
left join sysprocompanyb.arcustomermain_stg0_gp vw on vw."Customer"=om."Customer"
where (od."MLineShipDate">date_trunc('month', CURRENT_DATE) - interval '1 month - 15 day'  and
od."MLineShipDate"<=date_trunc('month', CURRENT_DATE) - interval '0 month - 15 day') AND (od."LineType" = '1')  and om."OrderStatus" in ('8','9')
AND (om."CancelledFlag" is distinct from 'Y')
AND (om."InterWhSale" is distinct from 'Y')
AND (om."Branch" is distinct from 'TR' and om."Branch" is distinct from  'CO' and om."Branch" is distinct from  'SM')
AND (od."LineType" = '1') AND (om."DocumentType") is distinct from 'C'
-- and  od."SalesOrder" like '%000000000367558%'
group by "CorpAcctName",od."MStockCode",od."MStockDes","MPrice","MOrderQty"
