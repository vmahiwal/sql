
Select "AllStockCode" as "StockCode","AllLot" as "Lot","AllWarehouse" as "Warehouse",
"SysproQtyOnHand","XPOQtyOnHand",
(case when "SysproQtyOnHand" is null then 0 else "SysproQtyOnHand" end - case when "XPOQtyOnHand" is null then 0 else "XPOQtyOnHand" end) as "QtyHandVariance",
"SysproQtyDispatched","XPOQtyDispatched",
(case when "SysproQtyDispatched" is null then 0 else "SysproQtyDispatched" end - case when "XPOQtyDispatched" is null then 0 else "XPOQtyDispatched" end) as "DispatchedVariance"
 from sysprocompanyb.xpoinventory_comparison_stg0_gp
