							---InventoryOnHand

select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, tmp.* from(
select InvWarehouse."StockCode","Description",SUM("QtyOnHand") as OnHandAcrossAllWH,SUM("YtdQtySold") as QtySoldAcrossAllWH 
,
case when SUM("YtdQtySold")<>0 then DATE_PART('day', now()-'2016-01-01')* (SUM("QtyOnHand")/SUM("YtdQtySold")) else 0 end as TotalDaysOfInventory
from sysprocompanyb.invwarehousemain_stg0_gp  InvWarehouse left join sysprocompanyb.invmastermain_stg0_gp InvMaster on InvWarehouse."StockCode"=InvMaster."StockCode" 
group by InvWarehouse."StockCode","Description")tmp																																																																																																																																																																																																																		