--inventoryavailability_stg0_gp.sql

select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
 RTRIM(invm."StockCode") as StockCode,
 a.QtyOnHand,
 iw2.QCOnHand,
 corpacntfcst.CurrentMonthForecast,
 corpacntfcst.NextMonthForecast,
 CurrentMonthForecastQty,
 NextMonthForecastQty,
 "DrawOfficeNum" 
 from sysprocompanyb.invmastermain_stg0_gp  invm
left join
(Select "StockCode",Sum("QtyOnHand") as QtyOnHand from sysprocompanyb.invwarehousemain_stg0_gp iw1 where ("Warehouse" is distinct from 'QC' and "Warehouse" is distinct from 'E4' and "Warehouse" is distinct from 'Z9') group by "StockCode")a
on invm."StockCode" = a."StockCode"
left join 
( select "StockCode",SUM("QtyOnHand") as QCOnHand from sysprocompanyb.invwarehousemain_stg0_gp where "Warehouse"='QC' group by "StockCode") iw2 on invm."StockCode"=iw2."StockCode"
left join
(SELECT "StockCode"
, SUM(CAST(CASE WHEN  extract(year from "ForecastDate")=extract(year from now()) and extract(month from "ForecastDate")=extract(month from now())
THEN sf."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS CurrentMonthForecast
, SUM(CAST(CASE WHEN  ("ForecastDate" > date_trunc('month', current_date)+'1month'-'1day'::interval AND "ForecastDate" <= date_trunc('month', current_date)+'2month'-'1day'::interval)
THEN sf."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS NextMonthForecast
FROM sysprocompanyb.salesforecast_month_stg0_gp sf  where
("CorpAcctName" like '%TARGET%'
or "CorpAcctName" like '%WAL-MART%'
or "CorpAcctName" like '%WALGREENS%'
or "CorpAcctName" like '%CVS%' or "CorpAcctName" like '%ULTA%' or "CorpAcctName" like '%SALLY BEAUTY%'
or "CorpAcctName" like '%RITE AID CORP%')
group by "StockCode") corpacntfcst on corpacntfcst."StockCode"=invm."StockCode"
left join
(SELECT "StockCode"
, SUM(CAST(CASE WHEN extract(year from ("ForecastDate"))=extract(year from(now())) and extract(month from("ForecastDate"))=extract(month from (now()))
THEN sf."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS CurrentMonthForecastQty
, SUM(CAST(CASE WHEN ("ForecastDate" > (date_trunc('month', now())+'1month'::interval-'1day'::interval)::date ) 
AND "ForecastDate" <= (date_trunc('month', now())+'2month'::interval-'1day'::interval)::date 
THEN sf."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS NextMonthForecastQty
FROM sysprocompanyb.salesforecast_month_stg0_gp sf
group by "StockCode"

) fcst on fcst."StockCode"=invm."StockCode"
