
SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,
 RevReporting.*
 --,[1/1/2017] Jan,[2/1/2017] Feb,[3/1/2017] March,[4/1/2017] April,[5/1/2017] May,[6/1/2017] June,[7/1/2017] July,[8/1/2017] Aug,[9/1/2017] Sep,[10/1/2017] Oct,[11/1/2017] Nov,[12/1/2017] Dec 
from
(SELECT     RevenueTrackingReport_ByCust.CorpAcctCode, RevenueTrackingReport_ByCust.CorpAcctName
        , case when month(getdate())=1 then SUM(RevenueTrackingReport_ByCust.BudMnt1)
            when month(getdate())=2 then SUM(RevenueTrackingReport_ByCust.BudMnt2)
            when month(getdate())=3 then SUM(RevenueTrackingReport_ByCust.BudMnt3)
            when month(getdate())=4 then SUM(RevenueTrackingReport_ByCust.BudMnt4)
            when month(getdate())=5 then SUM(RevenueTrackingReport_ByCust.BudMnt5)
            when month(getdate())=6 then SUM(RevenueTrackingReport_ByCust.BudMnt6)
            when month(getdate())=7 then SUM(RevenueTrackingReport_ByCust.BudMnt7)
            when month(getdate())=8 then SUM(RevenueTrackingReport_ByCust.BudMnt8)
            when month(getdate())=9 then SUM(RevenueTrackingReport_ByCust.BudMnt9)
            when month(getdate())=10 then SUM(RevenueTrackingReport_ByCust.BudMnt10)
            when month(getdate())=11 then SUM(RevenueTrackingReport_ByCust.BudMnt11)
            when month(getdate())=12 then SUM(RevenueTrackingReport_ByCust.BudMnt12)
                      end AS CurrMonthBudget,
                     case when month(getdate())=1 then 0
            when month(getdate())=2 then SUM(RevenueTrackingReport_ByCust.BudMnt1)
            when month(getdate())=3 then SUM(RevenueTrackingReport_ByCust.BudMnt2+RevenueTrackingReport_ByCust.BudMnt1)
            when month(getdate())=4 then SUM(RevenueTrackingReport_ByCust.BudMnt2+RevenueTrackingReport_ByCust.BudMnt1+RevenueTrackingReport_ByCust.BudMnt3)
            when month(getdate())=5 then SUM(RevenueTrackingReport_ByCust.BudMnt2+RevenueTrackingReport_ByCust.BudMnt1+RevenueTrackingReport_ByCust.BudMnt3+RevenueTrackingReport_ByCust.BudMnt4)
            when month(getdate())=6 then SUM(RevenueTrackingReport_ByCust.BudMnt2+RevenueTrackingReport_ByCust.BudMnt1+RevenueTrackingReport_ByCust.BudMnt3+RevenueTrackingReport_ByCust.BudMnt4+RevenueTrackingReport_ByCust.BudMnt5)
            when month(getdate())=7 then SUM(RevenueTrackingReport_ByCust.BudMnt2+RevenueTrackingReport_ByCust.BudMnt1+RevenueTrackingReport_ByCust.BudMnt3+RevenueTrackingReport_ByCust.BudMnt4+RevenueTrackingReport_ByCust.BudMnt5+RevenueTrackingReport_ByCust.BudMnt6)
            when month(getdate())=8 then SUM(RevenueTrackingReport_ByCust.BudMnt2+RevenueTrackingReport_ByCust.BudMnt1+RevenueTrackingReport_ByCust.BudMnt3+RevenueTrackingReport_ByCust.BudMnt4+RevenueTrackingReport_ByCust.BudMnt5+RevenueTrackingReport_ByCust.BudMnt6+RevenueTrackingReport_ByCust.BudMnt7)
            when month(getdate())=9 then SUM(RevenueTrackingReport_ByCust.BudMnt2+RevenueTrackingReport_ByCust.BudMnt1+RevenueTrackingReport_ByCust.BudMnt3+RevenueTrackingReport_ByCust.BudMnt4+RevenueTrackingReport_ByCust.BudMnt5+RevenueTrackingReport_ByCust.BudMnt6+RevenueTrackingReport_ByCust.BudMnt7+RevenueTrackingReport_ByCust.BudMnt8)
            when month(getdate())=10 then SUM(RevenueTrackingReport_ByCust.BudMnt2+RevenueTrackingReport_ByCust.BudMnt1+RevenueTrackingReport_ByCust.BudMnt3+RevenueTrackingReport_ByCust.BudMnt4+RevenueTrackingReport_ByCust.BudMnt5+RevenueTrackingReport_ByCust.BudMnt6+RevenueTrackingReport_ByCust.BudMnt7+RevenueTrackingReport_ByCust.BudMnt8+RevenueTrackingReport_ByCust.BudMnt9)
            when month(getdate())=11 then SUM(RevenueTrackingReport_ByCust.BudMnt2+RevenueTrackingReport_ByCust.BudMnt1+RevenueTrackingReport_ByCust.BudMnt3+RevenueTrackingReport_ByCust.BudMnt4+RevenueTrackingReport_ByCust.BudMnt5+RevenueTrackingReport_ByCust.BudMnt6+RevenueTrackingReport_ByCust.BudMnt7+RevenueTrackingReport_ByCust.BudMnt8+RevenueTrackingReport_ByCust.BudMnt9+RevenueTrackingReport_ByCust.BudMnt10)
            when month(getdate())=12 then SUM(RevenueTrackingReport_ByCust.BudMnt2+RevenueTrackingReport_ByCust.BudMnt1+RevenueTrackingReport_ByCust.BudMnt3+RevenueTrackingReport_ByCust.BudMnt4+RevenueTrackingReport_ByCust.BudMnt5+RevenueTrackingReport_ByCust.BudMnt6+RevenueTrackingReport_ByCust.BudMnt7+RevenueTrackingReport_ByCust.BudMnt8+RevenueTrackingReport_ByCust.BudMnt9+RevenueTrackingReport_ByCust.BudMnt10+RevenueTrackingReport_ByCust.BudMnt11)
                      end AS PrevMonthsBudget,
                     
                     SUM(RevenueTrackingReport_ByCust.OpenOrdersPastDueAsOfToday) 
                      AS OpenOrdersPastDueAsOfToday, SUM(RevenueTrackingReport_ByCust.OpenOrdersCurrMonthBroughtInFromLastMonth) AS OpenOrdersCurrMonthBroughtInFromLastMonth, 
                      SUM(RevenueTrackingReport_ByCust.OpenOrdersCurrMonth) AS OpenOrdersCurrMonth,
                      SUM(RevenueTrackingReport_ByCust.OpenOrdersMoreThan60Days) As OpenOrdersMoreThan60Days,
                     SUM(RevenueTrackingReport_ByCust.FutureOpenOrders) AS FutureOpenOrders, SUM(RevenueTrackingReport_ByCust.YTDInvoiced) 
                      AS YTDInvoiced, SUM(RevenueTrackingReport_ByCust.MTDInvoiced) AS MTDInvoiced, 
                     
                       SUM(RevenueTrackingReport_ByCust.TotalDispValue) AS TotalDispValue, SUM(RevenueTrackingReport_ByCust.CurrentMonthDispVal)   AS CurrentMonthDispVal, SUM(RevenueTrackingReport_ByCust.DispValYTD) AS DispValYTD,
                    
                       SUM(RevenueTrackingReport_ByCust.TotOrdValMTD) AS TotOrdValMTD, SUM(RevenueTrackingReport_ByCust.TotOrdValYTD) 
                      AS TotOrdValYTD, SUM(RevenueTrackingReport_ByCust.[1stQtrInvoiced]) AS [1stQtrInvoiced], 
                      SUM(RevenueTrackingReport_ByCust.[2stQtrInvoiced]) AS [2stQtrInvoiced], SUM(RevenueTrackingReport_ByCust.[3stQtrInvoiced]) 
                      AS [3stQtrInvoiced], SUM(RevenueTrackingReport_ByCust.[4thQtrInvoiced]) AS [4thQtrInvoiced], 
                      SUM(RevenueTrackingReport_ByCust.[1stQtrTotOrdVal]) AS [1stQtrTotOrdVal], SUM(RevenueTrackingReport_ByCust.[2stQtrTotOrdVal]) 
                      AS [2stQtrTotOrdVal], SUM(RevenueTrackingReport_ByCust.[3stQtrTotOrdVal]) AS [3stQtrTotOrdVal], 
                      SUM(RevenueTrackingReport_ByCust.[4thQtrTotOrdVal]) AS [4thQtrTotOrdVal], SUM(RevenueTrackingReport_ByCust.LostSalesMTD) 
                      AS LostSalesMTD, SUM(RevenueTrackingReport_ByCust.LostSalesYTD) AS LostSalesYTD, MIN(RevenueTrackingReport_ByCust.CustomerClass) AS CustomerClass, 
                      MIN(RevenueTrackingReport_ByCust.Salesperson1) AS Salesperson1
FROM  
(
SELECT     View_ArCust_GroupingData4KPI_New.Customer, View_ArCust_GroupingData4KPI_New.CustomerORClass, View_ArCust_GroupingData4KPI_New.GroupBy4KPI, View_ArCust_GroupingData4KPI_New.CorpAcctCode, View_ArCust_GroupingData4KPI_New.CorpAcctName,
                      CASE WHEN View_ArCust_Budgets_AdmFormData.January IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.January END AS BudMnt1, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.Februrary IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.Februrary END AS BudMnt2, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.March IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.March END AS BudMnt3, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.April IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.April END AS BudMnt4, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.May IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.May END AS BudMnt5, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.June IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.June END AS BudMnt6, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.July IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.July END AS BudMnt7, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.August IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.August END AS BudMnt8, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.September IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.September END AS BudMnt9, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.October IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.October END AS BudMnt10, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.November IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.November END AS BudMnt11, 
                      CASE WHEN View_ArCust_Budgets_AdmFormData.December IS NULL THEN 0 ELSE View_ArCust_Budgets_AdmFormData.December END AS BudMnt12, 
                     
                     
                     CASE WHEN OpenOrders.OpenOrdersPastDueAsOfToday IS NULL THEN 0 ELSE OpenOrders.OpenOrdersPastDueAsOfToday END AS OpenOrdersPastDueAsOfToday, 
                      CASE WHEN OpenOrders.OpenOrdersCurrMonthBroughtInFromLastMonth IS NULL THEN 0 ELSE OpenOrders.OpenOrdersCurrMonthBroughtInFromLastMonth END AS OpenOrdersCurrMonthBroughtInFromLastMonth,
                     CASE WHEN OpenOrders.OpenOrdersCurrMonth IS NULL THEN 0 ELSE OpenOrders.OpenOrdersCurrMonth END AS OpenOrdersCurrMonth,
                                         CASE WHEN OpenOrders.OpenOrdersMoreThan60Days IS NULL THEN 0 ELSE OpenOrders.OpenOrdersMoreThan60Days END AS OpenOrdersMoreThan60Days,

                      CASE WHEN OpenOrders.FutureOpenOrders IS NULL THEN 0 ELSE OpenOrders.FutureOpenOrders END AS FutureOpenOrders,
                     
                      
                      CASE WHEN Invoiced.YTDInvoiced IS NULL THEN 0 ELSE Invoiced.YTDInvoiced END AS YTDInvoiced, CASE WHEN Invoiced.MTDInvoiced IS NULL 
                      THEN 0 ELSE Invoiced.MTDInvoiced END AS MTDInvoiced, CASE WHEN Invoiced.[1stQtrInvoiced] IS NULL 
                      THEN 0 ELSE Invoiced.[1stQtrInvoiced] END AS [1stQtrInvoiced], CASE WHEN Invoiced.[2stQtrInvoiced] IS NULL 
                      THEN 0 ELSE Invoiced.[2stQtrInvoiced] END AS [2stQtrInvoiced], CASE WHEN Invoiced.[3stQtrInvoiced] IS NULL 
                      THEN 0 ELSE Invoiced.[3stQtrInvoiced] END AS [3stQtrInvoiced], CASE WHEN Invoiced.[4thQtrInvoiced] IS NULL 
                      THEN 0 ELSE Invoiced.[4thQtrInvoiced] END AS [4thQtrInvoiced], 

                     CASE WHEN Dispatched.TotalDispValue IS NULL THEN 0 ELSE Dispatched.TotalDispValue END AS TotalDispValue,
                     CASE WHEN Dispatched.CurrentMonthDispVal IS NULL THEN 0 ELSE Dispatched.CurrentMonthDispVal END AS CurrentMonthDispVal,
                     CASE WHEN Dispatched.DispValYTD IS NULL THEN 0 ELSE Dispatched.DispValYTD END AS DispValYTD,

     
                      CASE WHEN TotalOrders.OrdValMTD IS NULL THEN 0 ELSE TotalOrders.OrdValMTD END AS TotOrdValMTD, CASE WHEN TotalOrders.OrdValYTD IS NULL 
                      THEN 0 ELSE TotalOrders.OrdValYTD END AS TotOrdValYTD, CASE WHEN TotalOrders.[1stQtrOrdVal] IS NULL 
                      THEN 0 ELSE TotalOrders.[1stQtrOrdVal] END AS [1stQtrTotOrdVal], CASE WHEN TotalOrders.[2stQtrOrdVal] IS NULL 
                      THEN 0 ELSE TotalOrders.[2stQtrOrdVal] END AS [2stQtrTotOrdVal], CASE WHEN TotalOrders.[3stQtrOrdVal] IS NULL 
                      THEN 0 ELSE TotalOrders.[3stQtrOrdVal] END AS [3stQtrTotOrdVal], CASE WHEN TotalOrders.[4thQtrOrdVal] IS NULL 


                      THEN 0 ELSE [4thQtrOrdVal] END AS [4thQtrTotOrdVal], CASE WHEN LostSales.LostSalesMTD IS NULL THEN 0 ELSE LostSales.LostSalesMTD END AS LostSalesMTD,
                       CASE WHEN LostSales.LostSalesYTD IS NULL THEN 0 ELSE LostSales.LostSalesYTD END AS LostSalesYTD, 
                      View_ArCust_GroupingData4KPI_New.CustomerClass,                       View_ArCust_GroupingData4KPI_New.Salesperson1
FROM         View_ArCust_GroupingData4KPI_New LEFT OUTER JOIN
                          (SELECT     Customer, SUM(CAST(CASE WHEN (MONTH(MLineShipDate) = MONTH(GETDATE())) THEN LostSales ELSE 0 END AS decimal(12, 2))) AS LostSalesMTD, 
                                                   SUM(LostSales) AS LostSalesYTD
                            FROM          View_LostSales_YTD
                            WHERE      (Branch = 'NY')
                            GROUP BY Customer) AS LostSales ON View_ArCust_GroupingData4KPI_New.Customer = LostSales.Customer LEFT OUTER JOIN
                          (SELECT     SorMaster.Customer, SUM(CAST(CASE WHEN Month(SorMaster.EntrySystemDate) = Month(Getdate()) 
                                                   THEN SorDetail.MOrderQty * SorDetail.MPrice ELSE 0 END AS Decimal(12, 2))) AS OrdValMTD, SUM(CAST(CASE WHEN (Month(SorMaster.EntrySystemDate) 
                                                   IN (1, 2, 3)) THEN SorDetail.MOrderQty * SorDetail.MPrice ELSE 0 END AS Decimal(12, 2))) AS [1stQtrOrdVal], 
                                                   SUM(CAST(CASE WHEN (Month(SorMaster.EntrySystemDate) IN (4, 5, 6)) THEN SorDetail.MOrderQty * SorDetail.MPrice ELSE 0 END AS Decimal(12, 2))) 
                                                   AS [2stQtrOrdVal], SUM(CAST(CASE WHEN (Month(SorMaster.EntrySystemDate) IN (7, 8, 9)) 
                                                   THEN SorDetail.MOrderQty * SorDetail.MPrice ELSE 0 END AS Decimal(12, 2))) AS [3stQtrOrdVal], SUM(CAST(CASE WHEN (Month(SorMaster.EntrySystemDate) 
                                                   IN (10, 11, 12)) THEN SorDetail.MOrderQty * SorDetail.MPrice ELSE 0 END AS Decimal(12, 2))) AS [4thQtrOrdVal], 
                                                   SUM(SorDetail.MOrderQty * SorDetail.MPrice) AS OrdValYTD
                            FROM          SorDetail INNER JOIN
                                                   SorMaster ON SorDetail.SalesOrder = SorMaster.SalesOrder
                            WHERE    YEAR(SorMaster.EntrySystemDate) = YEAR(GETDATE())
                            AND (SorDetail.LineType = '1') AND (SorMaster.OrderStatus in ('0','1','2','3','4','8','9','S'))
        AND (SorMaster.CancelledFlag <> 'Y')
        AND (SorMaster.InterWhSale <> 'Y') 
        
                            GROUP BY SorMaster.Customer) AS TotalOrders ON View_ArCust_GroupingData4KPI_New.Customer = TotalOrders.Customer LEFT OUTER JOIN
                          (SELECT  Customer,
                      SUM(MdnDetail.MQtyToDispatch * MdnDetail.MPrice) AS TotalDispValue, 
                     SUM(CASE WHEN month(MdnMaster.PlannedDeliverDate) = month(getdate()) AND year(MdnMaster.PlannedDeliverDate) 
                      = Year(getdate()) THEN MQtyToDispatch * MPrice ELSE 0 END) AS CurrentMonthDispVal, 
                     SUM(CASE WHEN year(MdnMaster.PlannedDeliverDate) = Year(getdate()) 
                      THEN MQtyToDispatch * MPrice ELSE 0 END) AS DispValYTD
FROM         MdnDetail INNER JOIN
                      MdnMaster ON MdnDetail.DispatchNote = MdnMaster.DispatchNote 
                     WHERE    
                     (MdnMaster.DispatchNoteStatus <> '*' AND MdnMaster.DispatchNoteStatus <> '9')
                      AND (MdnDetail.LineType = '1') AND 
                      (MdnDetail.DispatchStatus <> '*') group by Customer) AS Dispatched ON View_ArCust_GroupingData4KPI_New.Customer = Dispatched.Customer LEFT OUTER JOIN
                          (SELECT     Customer, SUM((NetSalesValue + DiscValue)) AS YTDInvoiced, SUM(CAST(CASE WHEN TrnMonth = Month(getdate()) THEN (NetSalesValue + DiscValue) ELSE 0 END AS Decimal(12, 
                                                   2))) AS MTDInvoiced, SUM(CAST(CASE WHEN (TrnMonth IN (1, 2, 3)) THEN (NetSalesValue + DiscValue) ELSE 0 END AS Decimal(12, 2))) AS [1stQtrInvoiced], 
                                                   SUM(CAST(CASE WHEN (TrnMonth IN (4, 5, 6)) THEN (NetSalesValue + DiscValue) ELSE 0 END AS Decimal(12, 2))) AS [2stQtrInvoiced], 
                                                   SUM(CAST(CASE WHEN (TrnMonth IN (7, 8, 9)) THEN(NetSalesValue + DiscValue) ELSE 0 END AS Decimal(12, 2))) AS [3stQtrInvoiced], 
                                                   SUM(CAST(CASE WHEN (TrnMonth IN (10, 11, 12)) THEN (NetSalesValue + DiscValue) ELSE 0 END AS Decimal(12, 2))) AS [4thQtrInvoiced]
                            FROM ArTrnDetail
WHERE (LineType = '1') AND (TrnYear = DATEPART(year,GETDATE())) AND (NOT(Branch IN ('TP','TR', 'CO', 'SM'))) AND (DocumentType)<>'C' 
                            GROUP BY Customer) AS Invoiced ON View_ArCust_GroupingData4KPI_New.Customer = Invoiced.Customer LEFT OUTER JOIN
                          
                         (SELECT     Customer, SUM(CAST(CASE WHEN CONVERT(Date, od.MLineShipDate) <=  CONVERT(date, dateadd(d, - 1 * day(getdate()), getdate())) 
                                                   THEN (od.MShipQty + od.MBackOrderQty) * od.MPrice ELSE 0 END AS Decimal(12, 2))) AS OpenOrdersPastDueAsOfToday, --lastmonth
                                                  SUM(CAST(CASE WHEN CONVERT(Date, od.MLineShipDate) >  CONVERT(date, dateadd(d, - 1 * day(getdate()), getdate())) 
                          AND CONVERT(Date, MLineShipDate) <=  CONVERT(date, dateadd(d, - 1 * day(dateadd(m, 1, getdate())), 
                                                   dateadd(m, 1, getdate()))) --this month
                                                AND om.EntrySystemDate<=  CONVERT(date, dateadd(d, - 1 * day(getdate()), getdate())) --last month
                                                THEN (od.MShipQty + od.MBackOrderQty) * od.MPrice ELSE 0 END AS Decimal(12, 2))) AS OpenOrdersCurrMonthBroughtInFromLastMonth,
                                                  SUM(CAST(CASE WHEN CONVERT(Date, od.MLineShipDate) >  CONVERT(date, dateadd(d, - 1 * day(getdate()), getdate())) AND  CONVERT(Date, MLineShipDate) <=  CONVERT(date, dateadd(d, - 1 * day(dateadd(m, 1, getdate())), 
                                                   dateadd(m, 1, getdate()))) THEN (od.MShipQty + od.MBackOrderQty) * od.MPrice ELSE 0 END AS Decimal(12, 2))) AS OpenOrdersCurrMonth,
                                                   
                                                                                                  SUM(CAST(CASE WHEN DATEDIFF(d, od.MLineShipDate, getdate()) > 60   THEN (od.MShipQty + od.MBackOrderQty) * od.MPrice ELSE 0 END AS Decimal(12, 2))) AS OpenOrdersMoreThan60Days,
                                                   
                                                  SUM(CAST(CASE WHEN CONVERT(Date, od.MLineShipDate) > CONVERT(date, dateadd(d, - 1 * day(dateadd(m, 1, getdate())), dateadd(m, 1, getdate()))) THEN (od.MShipQty + od.MBackOrderQty) * od.MPrice ELSE 0 END AS Decimal(12, 2))) 
                                                   AS FutureOpenOrders
                            FROM SorMaster om INNER JOIN SorDetail od ON om.SalesOrder = od.SalesOrder 
WHERE (om.OrderStatus in ('0','1','2','3','4','S')) 
        AND (om.CancelledFlag <> 'Y')
        AND (om.InterWhSale <> 'Y')  
        AND (od.LineType = '1')
        AND ((od.MShipQty + MBackOrderQty) <> 0)

                            GROUP BY Customer) 
                            AS OpenOrders ON View_ArCust_GroupingData4KPI_New.Customer = OpenOrders.Customer LEFT OUTER JOIN
                      (select arc.Customer,arc.CorpAcctCode, arc.CorpAcctName
,sum(BUD001) as January ,sum(BUD002) as Februrary,sum(BUD003) as March,sum(BUD004) as April,
sum(BUD005) as May ,sum(BUD006) as June,sum(BUD007) as July,sum(BUD008) as August,
sum(BUD009) as September,sum(BUD010) as October,sum(BUD011) as November,sum(BUD012) as December
from
(select * from
(select  FormType, KeyField, FieldName, NumericValue from AdmFormData)adm
pivot
(sum(NumericValue)
for FieldName in ([BUD001],[BUD002],[BUD003],[BUD004],[BUD005],[BUD006],[BUD007],[BUD008],[BUD009],[BUD010],[BUD011],[BUD012])
)piv where FormType='CUS')adm
left join View_ArCust_GroupingData4KPI_New arc on arc.Customer=adm.KeyField
group by arc.Customer,arc.CorpAcctCode, arc.CorpAcctName) as View_ArCust_Budgets_AdmFormData ON View_ArCust_GroupingData4KPI_New.Customer = View_ArCust_Budgets_AdmFormData.Customer
and View_ArCust_GroupingData4KPI_New.CorpAcctName = View_ArCust_Budgets_AdmFormData.CorpAcctName
/*UNION ALL
SELECT     '' AS Customer, '2' AS CustomerORClass, View_ArCustClass_Budget_AdmFormData.Class, corpcode.CorpAcctCode, corpname.CorpAcctName,0 as BudMnt1,0 as BudMnt2,0 as BudMnt3,0 as BudMnt4,0 as BudMnt5,0 as BudMnt6,0 as BudMnt7,0 as BudMnt8,0 as BudMnt9,0 as BudMnt10,0 as BudMnt11, 
                  0 as    BudMnt12, 0 AS OpenOrdersPastDueAsOfToday, 0 AS OpenOrdersCurrMonthBroughtInFromLastMonth,0 AS OpenOrdersCurrMonth,0 As OpenOrdersMoreThan60Days, 0 AS FutureOpenOrders, 0 AS YTDInvoiced, 0 AS MTDInvoiced, 0 AS [1stQtrInvoiced], 
                      0 AS [2stQtrInvoiced], 0 AS [3stQtrInvoiced], 0 AS [4thQtrInvoiced], 0 AS TotalDispValue,0 AS CurrentMonthDispVal,0 as DispValYTD, 0 AS TotOrdValMTD, 0 AS TotOrdValYTD, 0 AS [1stQtrTotOrdVal], 
                      0 AS [2stQtrTotOrdVal], 0 AS [3stQtrTotOrdVal], 0 AS [4thQtrTotOrdVal], 0 AS LostSalesMTD, 0 AS LostSalesYTD, View_ArCustClass_Budget_AdmFormData.Class, Salesperson1
FROM         View_ArCustClass_Budget_AdmFormData LEFT JOIN (SELECT REPLACE(KeyField,' ','') as Class, AlphaValue as CorpAcctCode
                                                            FROM AdmFormData
                                                            WHERE FormType = 'CUS' and FieldName = 'COR002') corpcode ON View_ArCustClass_Budget_AdmFormData.Class = corpcode.Class
                                                LEFT JOIN (SELECT Item as CorpAcctCode, Description as CorpAcctName
                                                            FROM AdmFormValidation WHERE FormType = 'CUS' and FieldName = 'COR002') corpname ON corpcode.CorpAcctCode = corpname.CorpAcctCode

WHERE     View_ArCustClass_Budget_AdmFormData.Class <> 'GL'*/
) RevenueTrackingReport_ByCust

 LEFT OUTER JOIN
                      TblCustomerClass ON RevenueTrackingReport_ByCust.GroupBy4KPI = TblCustomerClass.Class LEFT OUTER JOIN
                      ArCustomer ON RevenueTrackingReport_ByCust.GroupBy4KPI = ArCustomer.Customer

                      where RevenueTrackingReport_ByCust.Customer not in ('000000000048869','000000000049870')
          --  and RevenueTrackingReport_ByCust.CorpAcctName not like '%ULTA%'
GROUP BY RevenueTrackingReport_ByCust.CorpAcctCode, RevenueTrackingReport_ByCust.CorpAcctName) RevReporting 
