--Openvsavilable -------------
SELECT
ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
 "StockUom",iw."StockCode","Description",im."AbcClass" as ProductClass,"StockOnHold",
SUM(OpenOrderQty) as OpenOrderQty, SUM(OpenOrderValue) as OpenOrderValue,
SUM(BoQty) as BoQty, SUM(BoValue) as BoValue,
SUM(PastDueQty) as PastDueQty, SUM(PastDueValue) as PastDueValue,
SUM(QtyOnHand) as QtyOnHand,SUM(QCOnHand) as QCOnHand,Sum(XQCOnHand) XQCOnHand,Sum(XFG.XFGOnHand) XFGOnHand,
Sum(XFG.XFGInTransit ) XFGInTransit,Sum(XQC.XQCInTrnasit ) XQCInTransit,
SUM(E4OnHand) as EmersonOnHand, SUM(iw.QtyOnOrder) as QtyOnOrder, SUM(SafetyStockQty) as SafetyStockQty,
SUM(fcst.FcstQtyMnt1) as FcstQtyMnt1,
SUM(fcst.FcstQtyMnt2) as FcstQtyMnt2,
SUM(fcst.FcstQtyMnt3) as FcstQtyMnt3,
SUM(fcst.FcstQtyMnt4) as FcstQtyMnt4,
SUM(fcst.JanJunNextYear) as JanJunNextYear
--,"Component" as WP,SUM(WP.WPOnHand) as WPQtyOnHand,SUM(WPQtyOnOrder) as WPQtyOnOrder
,
 "WarehouseToUse",im."AbcClass"
from sysprocompanyb.invmastermain_stg0_gp im 
left join 
(select "StockCode", SUM("QtyOnOrder") as QtyOnOrder,SUM("SafetyStockQty") as SafetyStockQty
from sysprocompanyb.invwarehousemain_stg0_gp group by "StockCode") iw on im."StockCode"=iw."StockCode" 
left join (SELECT REPLACE("KeyField" ,' ','') as ProductClass
, "AlphaValue" as InvType
FROM sysprocompanyb.admformdatamain_stg0_gp
WHERE "FormType" = 'ARPCL' and "FieldName" = 'KPI001') invtyp on im."ProductClass" = invtyp.ProductClass
left join (select "StockCode",SUM("QtyOnHand") as QCOnHand from sysprocompanyb.invwarehousemain_stg0_gp where "Warehouse"='QC' group by "StockCode") QC on QC."StockCode"=im."StockCode"
left join (select "StockCode",SUM("QtyOnHand") as QtyOnHand from sysprocompanyb.invwarehousemain_stg0_gp where ("Warehouse" is distinct from 'QC' and "Warehouse" is distinct from 'Z9' and "Warehouse" is distinct from 'E4') group by "StockCode") F2 on F2."StockCode"=im."StockCode"
left join (select "StockCode",SUM("QtyOnHand") as E4OnHand from sysprocompanyb.invwarehousemain_stg0_gp where "Warehouse"='E4' group by "StockCode") E4 on E4."StockCode"=im."StockCode"
left join ( select "StockCode",SUM("QtyOnHand") as XQCOnHand,Sum("QtyInTransit") XQCInTrnasit from sysprocompanyb.invwarehousemain_stg0_gp where "Warehouse"='XQC' group by "StockCode") XQC on XQC."StockCode"=im."StockCode"
left join ( select "StockCode",SUM("QtyOnHand") as XFGOnHand,Sum("QtyInTransit") XFGInTransit from sysprocompanyb.invwarehousemain_stg0_gp where "Warehouse"='XFG' group by "StockCode") XFG on XFG."StockCode"=im."StockCode"



left join (select "MStockCode",SUM(od."MShipQty" + od."MBackOrderQty") as OpenOrderQty,SUM((od."MShipQty" + od."MBackOrderQty")*"MPrice") as OpenOrderValue,
SUM(case when DispatchCount>=1
then (od."MShipQty" + od."MBackOrderQty") else 0 end) as BoQty,SUM(case when DispatchCount>=1
then (od."MShipQty" + od."MBackOrderQty")*"MPrice" else 0 end) as BoValue,
SUM(case when "MLineShipDate"<now() and DispatchCount IS NULL
then (od."MShipQty" + od."MBackOrderQty") else 0 end) as PastDueQty, SUM(case when "MLineShipDate"<now() and DispatchCount IS NULL
then (od."MShipQty" + od."MBackOrderQty")*"MPrice" else 0 end) as PastDueValue
from sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp   od ON om."SalesOrder" = od."SalesOrder"
left join (select "SalesOrder",count("DispatchNote") as DispatchCount from sysprocompanyb.mdnmastermain_stg0_gp group by "SalesOrder")mm on mm."SalesOrder"=om."SalesOrder"

where (om."OrderStatus" in ('0','1','2','3','4','S'))
AND (om."CancelledFlag" is distinct from 'Y')
AND (om."InterWhSale" is distinct from 'Y')
AND (od."LineType" = '1')
AND (om."DocumentType") is distinct from 'C'
AND ((od."MShipQty" + "MBackOrderQty") is distinct from 0) group by "MStockCode")BO on BO."MStockCode"=im."StockCode"
--left join (select distinct "ParentPart", "Component" from sysprocompanyb.bomstructuremain_stg0_gp where substr("Component",0,3)='WP') BM on BM."ParentPart"=im."StockCode"
left join (SELECT "StockCode"
, SUM(CAST(CASE WHEN --"ForecastType" = 'S' AND 
("ForecastDate" > date_trunc('month', current_date)-'1day'::interval AND
"ForecastDate" <=  date_trunc('month', current_date)+'1month'-'1day'::interval)
THEN forcast."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS FcstQtyMnt1
, SUM(CAST(CASE WHEN-- "ForecastType" = 'S' AND
("ForecastDate" >  date_trunc('month', current_date)+'1month'-'1day'::interval)
 AND "ForecastDate" <= date_trunc('month', current_date)+'2month'-'1day'::interval
THEN forcast."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS FcstQtyMnt2
,SUM(CAST(CASE WHEN --"ForecastType" = 'S' AND 
("ForecastDate" >date_trunc('month', current_date)+'2month'-'1day'::interval AND 
"ForecastDate" <= date_trunc('month', current_date)+'3month'-'1day'::interval)
THEN forcast."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS FcstQtyMnt3
,SUM(CAST(CASE WHEN --"ForecastType" = 'S' AND
("ForecastDate" > date_trunc('month', current_date)+'3month'-'1day'::interval
 AND "ForecastDate" <= date_trunc('month', current_date)+'4month'-'1day'::interval)
THEN forcast."ForecastQty" ELSE 0 END AS Decimal(12, 2)))  AS FcstQtyMnt4

, SUM(CAST(CASE WHEN --"ForecastType" = 'S' AND
extract(Year from "ForecastDate") = extract(Year from now())+1 AND extract(Month from "ForecastDate")<=6


 THEN forcast."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS JanJunNextYear
FROM sysprocompanyb.salesforecast_month_stg0_gp  forcast where
(forcast."ForecastDate" > date_trunc('month', current_date)-'12month'::interval-'1day'::interval) AND
(forcast."ForecastDate" <= date_trunc('month', current_date)+'12month'::interval-'1day'::interval) group by "StockCode") fcst on fcst."StockCode"=im."StockCode"

--left join 
--(select "StockCode",SUM("QtyOnHand") as WPOnHand,SUM("QtyOnOrder") as WPQtyOnOrder from sysprocompanyb.invwarehousemain_stg0_gp group by "StockCode") WP on WP."StockCode"=BM."Component"
where InvType='FG' and (QtyOnHand>0 or QCOnHand>0 or E4OnHand>0 or OpenOrderQty>0 or BoQty>0 or PastDueQty>0 or QtyOnOrder>0 or FcstQtyMnt1>0 or FcstQtyMnt2>0 or FcstQtyMnt3>0)
group by "StockUom",iw."StockCode", "Description",im."ProductClass","StockOnHold","WarehouseToUse",im."AbcClass"