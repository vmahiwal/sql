
select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
case when LTRIM(bo."OrderNo",0)  is null then LTRIM(boh."OrderNo",0) 
else LTRIM(bo."OrderNo",0) end as OrderNo,
case when bo."ItemNo" is null then boh."ItemNo" else bo."ItemNo" end as ItemNo,
case when bo."LineNumber" is null then boh."LineNumber" else bo."LineNumber" end as LineNumber,
SUM(case when bo."MStockQtyToShp" is null then boh."MStockQtyToShp"
when boh."MStockQtyToShp" is null then bo."MStockQtyToShp"
else bo."MStockQtyToShp"+boh."MStockQtyToShp" end) as MStockQtyToShp
from
sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp  od ON
om."SalesOrder" = od."SalesOrder"
left join sysprocompanyb.barcodeordersmain_stg0_gp bo ON
LTRIM(om."SalesOrder",0)  = LTRIM(bo."OrderNo",0) -- COLLATE Latin1_General_BIN
AND od."MStockCode" = bo."ItemNo" --COLLATE Latin1_General_BIN
AND od."SalesOrderLine" = bo."LineNumber"
left join sysprocompanyb.barcodeorderhistorymain_stg0_gp boh ON
LTRIM(om."SalesOrder",0) = LTRIM(boh."OrderNo",0)-- COLLATE Latin1_General_BIN
AND od."MStockCode" = boh."ItemNo" --COLLATE Latin1_General_BIN
AND od."SalesOrderLine" = boh."LineNumber"
WHERE (om."CancelledFlag" IS distinct from 'Y')
AND (om."InterWhSale" is distinct from 'Y')
AND (om."Branch" is distinct from 'TR' and om."Branch" is distinct from 'CO' and om."Branch" is distinct from 'SM')
AND (od."LineType" = '1')
AND (om."DocumentType") is distinct from 'C'
AND "EntrySystemDate">= date_trunc('day', now())-'123day'::interval
AND  (om."Customer" is distinct from '000000000048869' and om."Customer" is distinct from'000000000049870')
group by
case when LTRIM(bo."OrderNo",0)  is null then LTRIM(boh."OrderNo",0)  else LTRIM(bo."OrderNo",0)  end,
case when bo."ItemNo" is null then boh."ItemNo" else bo."ItemNo" end,
case when bo."LineNumber" is null then boh."LineNumber" else bo."LineNumber" end

