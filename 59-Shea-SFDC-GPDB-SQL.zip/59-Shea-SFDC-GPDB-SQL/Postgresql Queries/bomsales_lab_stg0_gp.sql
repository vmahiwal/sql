
select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
"ParentPart"
,"Route"
,SUM("QtyPer"* a."LabourCost") as WPLBR ,
SUM("SetupCost"+"RunTimeCost") as DL ,
SUM("FixOHCost") as FOH,
SUM("QtyPer"*a."FixOverhead") as WPOH
,SUM("LineCost") as TotBomC
,SUM("QtyPer"*a."MaterialCost") as WPMAT ,
SUM(("QtyPer"*a."LabourCost")+"SetupCost"+"RunTimeCost"+"FixOHCost"+("QtyPer"*a."FixOverhead")) as TotLabOHC
,iv."ProductClass",
iv."ProductGroup",
iv."Description" 

 From  sysprocompanyb.view_bomcosting_stg0_gp  a
left join sysprocompanyb.invmastermain_stg0_gp iv on a."ParentPart" = iv."StockCode"
where "StockUom"='EA'
group by "ParentPart","Route",iv."ProductClass",iv."ProductGroup",iv."Description"; 