select  ROW_NUMBER() OVER (ORDER BY now()) AS ID,now() as time,
case when a."EntryDate" is not null then a."EntryDate" else b."EntryDate" end as EntryDate,
case when a."WH" is not null then a."WH" else b."WH" end as WH,
case when a.ShipQty is null then b.ShipQty when b.ShipQty is null then a.ShipQty else a.ShipQty+b.ShipQty end as Cases,
case when a.Scans is null then b.Scans when b.Scans is null then a.Scans else a.Scans+b.Scans end as Scans
 from
(SELECT "EntryDate","WH",Sum("ShipQty") as ShipQty,Count("ShipQty") as Scans
  FROM sysprocompanyb.barcodeorderhistorymain_stg0_gp where "EntryDate">=date_trunc('day', current_date)-'124day'::interval
group by "EntryDate","WH")a
full outer join
(SELECT "EntryDate","WH",Sum("ShipQty") as ShipQty,Count("ShipQty") as Scans 
  FROM sysprocompanyb.barcodeordersmain_stg0_gp  where "EntryDate">= date_trunc('day', current_date)-'124day'::interval
group by "EntryDate","WH")b on a."EntryDate"=b."EntryDate"