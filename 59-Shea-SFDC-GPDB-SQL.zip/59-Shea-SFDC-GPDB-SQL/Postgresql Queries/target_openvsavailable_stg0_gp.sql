---target_openvsavailable_stg0_gp.sql

SELECT ROW_NUMBER() OVER (ORDER BY now()) AS ID,now() as time,
"StockUom",im."StockCode","DrawOfficeNum","Description",im."AbcClass" as ProductClass,"StockOnHold",
SUM(OpenOrderQty) as OpenOrderQty, SUM(OpenOrderValue) as OpenOrderValue,SUM(TotalOpenOrderQty) as TotalOpenOrderQty, SUM(TotalOpenOrderValue) as TotalOpenOrderValue,
SUM(OrdersThisWeek) as OrdersThisWeek, SUM(OrdersThisWeekValue) as OrdersThisWeekValue,
SUM(OrdersLastWeek) as OrdersLastWeek, SUM(OrdersLastWeekValue) as OrdersLastWeekValue,
SUM(QtyOnHand) as QtyOnHand,SUM(QCOnHand) as QCOnHand,
SUM(E4OnHand) as EmersonOnHand, 
Sum(XFGOnHand) as XFGOnHand,Sum(XFG.XFGQtyInTransit) as XFGQtyInTransit,
Sum(XQCOnHand) as XQCOnHand,Sum(XQC.XQCQtyInransit) as XQCQtyInTransit,
SUM(fcst.FcstQtyMnt1) as FcstQtyMnt1,
SUM(fcst.FcstQtyMnt2) as FcstQtyMnt2,
SUM(fcst.FcstQtyMnt3) as FcstQtyMnt3,

SUM(fcst.JanJunNextYear) as JanJunNextYear
,"Component" as WP,SUM(WP.WPOnHand) as WPQtyOnHand,SUM(WPQtyOnOrder) as WPQtyOnOrder, "WarehouseToUse",im."AbcClass"
 from sysprocompanyb.invmastermain_stg0_gp  im  
 left join (select "StockCode",SUM("QtyOnHand") as QCOnHand from sysprocompanyb.invwarehousemain_stg0_gp  where "Warehouse"='QC' group by "StockCode") QC on QC."StockCode"=im."StockCode"
 left join (select "StockCode",SUM("QtyOnHand") as QtyOnHand from sysprocompanyb.invwarehousemain_stg0_gp  where "Warehouse" not in ('QC','Z9','E4') group by "StockCode") F2 on F2."StockCode"=im."StockCode"
 left join (select "StockCode",SUM("QtyOnHand") as E4OnHand from sysprocompanyb.invwarehousemain_stg0_gp  where "Warehouse"='E4' group by "StockCode") E4 on E4."StockCode"=im."StockCode"
 left join ( select "StockCode",SUM("QtyOnHand") as XFGOnHand,  Sum("QtyInTransit") as XFGQtyInTransit from sysprocompanyb.invwarehousemain_stg0_gp  where "Warehouse"='XFG' group by "StockCode") XFG on XFG."StockCode"=im."StockCode"
left join ( select "StockCode",SUM("QtyOnHand") as XQCOnHand,  Sum("QtyInTransit") as XQCQtyInransit from sysprocompanyb.invwarehousemain_stg0_gp  where "Warehouse"='XQC' group by "StockCode") XQC on XQC."StockCode"=im."StockCode"

 left join (select "MStockCode",SUM(od."MShipQty" + od."MBackOrderQty") as OpenOrderQty,SUM((od."MShipQty" + od."MBackOrderQty")*"MPrice") as OpenOrderValue,
  SUM(case when Extract(week from "EntrySystemDate")=Extract(week from current_date)
 then (od."MShipQty" + od."MBackOrderQty") else 0 end) as OrdersThisWeek,SUM(case when Extract(week from "EntrySystemDate")=Extract(week from current_date)
 then (od."MShipQty" + od."MBackOrderQty")*"MPrice" else 0 end) as OrdersThisWeekValue,
  SUM(case when Extract(week from "EntrySystemDate")=Extract(week from current_date)-1
 then (od."MShipQty" + od."MBackOrderQty") else 0 end) as OrdersLastWeek,  SUM(case when Extract(week from "EntrySystemDate")=Extract(week from current_date)-1
 then (od."MShipQty" + od."MBackOrderQty")*"MPrice" else 0 end) as OrdersLastWeekValue
  
 from sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp  od ON om."SalesOrder" = od."SalesOrder"
 left join sysprocompanyb.arcustomermain_stg0_gp arc on arc."Customer"=om."Customer"
 where (om."OrderStatus" in ('0','1','2','3','4','S')) 
AND (om."CancelledFlag" is distinct from 'Y')
AND (om."InterWhSale" is distinct from 'Y') 
AND (od."LineType" = '1')
AND (om."DocumentType") is distinct from 'C'
AND ((od."MShipQty" + "MBackOrderQty") is distinct from '0' )
and "CorpAcctName" similar to '%TARGET%' 
group by "MStockCode")BO on BO."MStockCode"=im."StockCode" 

left join (select "MStockCode",SUM(od."MShipQty" + od."MBackOrderQty") as TotalOpenOrderQty,SUM((od."MShipQty" + od."MBackOrderQty")*"MPrice") as TotalOpenOrderValue
 from sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp od ON om."SalesOrder" = od."SalesOrder"
 where (om."OrderStatus" in ('0','1','2','3','4','S')) 
AND (om."CancelledFlag" is distinct from 'Y')
AND (om."InterWhSale" is distinct from 'Y') 
AND (od."LineType" = '1')
AND (om."DocumentType") is distinct from 'C'
AND ((od."MShipQty" + "MBackOrderQty") is distinct from '0')
 group by "MStockCode")AllOpenOrders on AllOpenOrders."MStockCode"=im."StockCode" 

 left join (select distinct "ParentPart", "Component" from sysprocompanyb.bomstructuremain_stg0_gp   where SUBSTR("Component", 0, 3)='WP') BM on BM."ParentPart"=im."StockCode"
 left join (SELECT "StockCode"
     , SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', current_date)-'1month'::interval) and ("ForecastDate" <= date_trunc('month', current_date))
    THEN sfm."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS FcstQtyMnt1
    , SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', current_date)
    AND "ForecastDate" <= date_trunc('month', current_date)+'1month'::interval)
    THEN sfm."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS FcstQtyMnt2
    ,SUM(CAST(CASE WHEN ("ForecastDate" > date_trunc('month', current_date)+'1month'::interval
    AND "ForecastDate" <= date_trunc('month', current_date)+'2month'::interval)
    THEN sfm."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS FcstQtyMnt3
    
,   SUM(CAST(CASE WHEN Extract (year from "ForecastDate") =  Extract(Year from current_date)+1 AND Extract( month from "ForecastDate") 
                      <=6 THEN sfm."ForecastQty" ELSE 0 END AS Decimal(12, 2))) AS JanJunNextYear
  FROM sysprocompanyb.salesforecast_month_stg0_gp sfm 
  where "CorpAcctName" like '%TARGET%' and 
   (sfm."ForecastDate" > date_trunc('month', current_date)-'1year'::interval) AND 
                      (sfm."ForecastDate" <=  date_trunc('month', current_date)+'1year'::interval) group by "StockCode") fcst on fcst."StockCode"=im."StockCode"

  left join (select "StockCode",SUM("QtyOnHand") as WPOnHand,SUM("QtyOnOrder") as WPQtyOnOrder from sysprocompanyb.invwarehousemain_stg0_gp  group by "StockCode") WP on WP."StockCode"=BM."Component"
 where 
  (OpenOrderQty>0 or OrdersLastWeek>0 or OrdersThisWeek>0  or FcstQtyMnt1>0 or FcstQtyMnt2>0
  )
 group by "StockUom",im."StockCode","DrawOfficeNum", "Description",im."ProductClass","StockOnHold","Component","WarehouseToUse",im."AbcClass"
 order by "DrawOfficeNum" asc