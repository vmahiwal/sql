
--- InnovationFinnancial_stg0.sql


select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, inv_fin.* from(
select inva.*, invfin."COGS", invfin."GMActual", invfin."GMPreliminary",invfin."ListPrice", invfin."UnitsInacase" from (SELECT inv."StockCode",
inv."TrnYear",inv."TrnMonth",inv.GrossSales,inv.QtyInvoiced,"LaunchYear"  , "InitailLaunchYear" , "Brand", "Category"  , "Collection" , "ProjectID"
       , "Status" , "CSStockCode", "ItemDescription"  , "LaunchCategory"  , "RevisedShipDate"
       , "EntryDate" , "InHouseOrThirdPartyMFG" , "PreliminaryPL" , "BOMStatus"   , "FormulaStatus"
       , "PackagingStatus"  , "LabelStatus"   , "CommittedStatus" , "ProductionStatus" , "RetailerOrNational"
 FROM sysprocompanyb.masterinnovationfinance_stg0_gp ms
left join
(
select "StockCode"
,"TrnYear","TrnMonth",Sum("NetSalesValue"+"DiscValue") GrossSales,Sum("QtyInvoiced") QtyInvoiced
--,case when "TrnYear" = date_part('year', CURRENT_DATE)-1 then Sum("NetSalesValue"+"DiscValue")  end 
from sysprocompanyb.artrndetailmain_stg0_gp art where 
("LineType" = '1') AND "TrnYear" >= '2017'--IN  (year(now())-3,year(now())-2,year(now())-1,year(now())) 
AND ("Branch" is distinct from 'TR' and "Branch" is distinct from 'CO' and "Branch" is distinct from 'SM')  
        --Added following condition to eliminate credit notes 2016-06-07
        AND ("DocumentType") is distinct from 'C'
        AND SUBSTR(art."StockCode",1,4) NOT IN ('DISP','FIXT','GIFT','FBX-','CAP-','LBL-')
        AND ("Customer" is distinct from '0048869' and "Customer" is distinct from '0049870')
        --and art."StockCode" like '%ABBL-NHO-13OZ%' 
        group by "StockCode","TrnYear","TrnMonth"
    
)inv
on ms."CSStockCode" = inv."StockCode")inva
left join sysprocompanyb.innovationfinance_stg0_gp invfin
on inva."StockCode"= invfin."CaseStockCode")inv_fin

