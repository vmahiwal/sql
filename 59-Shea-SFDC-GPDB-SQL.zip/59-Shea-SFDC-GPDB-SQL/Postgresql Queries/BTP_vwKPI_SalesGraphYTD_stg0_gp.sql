
SELECT ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, tmp.* from 
( select "RecordType", "TrnYear", SUM("MonthlySales") as AnnualSales
FROM sysprocompanyb.btp_vwkpi_salesgraphmonthly_stg0_gp
WHERE "RecordType" = 'A'
--WHERE "RecordType" = 'A' AND "TrnMonth" <=DATE_PART('month', now())
GROUP BY "RecordType", "TrnYear"

UNION ALL

SELECT "RecordType", "TrnYear", SUM("MonthlySales") as AnnualSales
FROM sysprocompanyb.btp_vwkpi_salesgraphmonthly_stg0_gp
WHERE "RecordType" = 'B'
--WHERE "RecordType" = 'B' AND TrnMonth <=DATE_PART('month', now())
GROUP BY "RecordType", "TrnYear"

UNION ALL

SELECT "RecordType", "TrnYear", SUM("MonthlySales") as AnnualSales
FROM sysprocompanyb.btp_vwkpi_salesgraphmonthly_stg0_gp
WHERE "RecordType" = 'R'
--WHERE "RecordType" = 'R' AND TrnMonth <=DATE_PART('month', now())
GROUP BY "RecordType", "TrnYear"

UNION ALL

SELECT 'Y', "TrnYear", SUM("MonthlySales") as AnnualSales
FROM sysprocompanyb.btp_vwkpi_salesgraphmonthly_stg0_gp CROSS JOIN sysprocompanyb.arcontrolmain_stg0_gp  
--WHERE "RecordType" = 'B' AND TrnMonth <= (CASE WHEN DATE_PART('day',now()) < 25 THEN FinPeriod -1 ELSE FinPeriod END)
WHERE "RecordType" = 'B'  AND "TrnMonth" <=DATE_PART('month' , now()) 
GROUP BY "RecordType", "TrnYear"
)tmp
