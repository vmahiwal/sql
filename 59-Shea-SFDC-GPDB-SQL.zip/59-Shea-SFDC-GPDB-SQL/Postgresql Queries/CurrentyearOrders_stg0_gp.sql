SELECT ROW_NUMBER() OVER (ORDER BY om."SalesOrder") AS ID, now() as time,cacm.CorpAcctName, 
ltrim(om."Customer",0) as Customer,
ltrim(om."SalesOrder",0) as SalesOrder,
"SalesOrderLine", "OrderStatus", "Salesperson", "CustomerPoNumber", "OrderDate", "EntrySystemDate",  
"ReqShipDate", om."DiscPct1",om."DiscPct2",om."DiscPct3",
  "MStockCode", "MStockDes","MWarehouse", 
od."MOrderQty", od."MPrice", od."MShipQty",od."MBackOrderQty",  a."DateValue" as MABD
  ,  od."MDiscValFlag" ,od."MDiscValue",od."MDiscPct1",od."MDiscPct2",od."MDiscPct3", 
om."InterWhSale", om."Branch", "MLineShipDate",om."ShipAddress3",om."ShipPostalCode",om."CancelledFlag", od."LineType"
  , om."DocumentType", od."MProductClass", om."CustomerName"
FROM sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp od 
ON om."SalesOrder" = od."SalesOrder" 

LEFT JOIN (SELECT REPLACE("KeyField",' ','')  as Customer
          , "AlphaValue" as CorpAcctCode
        FROM sysprocompanyb.admformdatamain_stg0_gp 
        WHERE ("FormType" = 'CUS' and "FieldName" = 'COR002')) cac ON om."Customer" = cac.Customer
        
LEFT JOIN (select * from sysprocompanyb.admformdatamain_stg0_gp  where "FieldName"='DEL001')a on a."KeyField"=om."SalesOrder"     
     
     LEFT JOIN (SELECT "Item" as CorpAcctCode
         , "Description" as CorpAcctName
         FROM sysprocompanyb.admformvalidationmain_stg0_gp
        WHERE "FormType" = 'CUS' and "FieldName" = 'COR002') cacm on cac.CorpAcctCode = cacm.CorpAcctCode
WHERE (od."LineType" = '1')   AND DATE_PART('YEAR',om."EntrySystemDate") = DATE_PART('YEAR',now())
OR (DATE_PART('YEAR',om."EntrySystemDate") = DATE_PART('YEAR',now())-1 AND DATE_PART('MONTH',om."EntrySystemDate")>=9)