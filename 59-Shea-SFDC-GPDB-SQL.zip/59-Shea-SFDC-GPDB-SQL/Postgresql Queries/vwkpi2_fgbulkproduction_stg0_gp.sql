
SELECT  ROW_NUMBER() OVER (ORDER BY Sequence) AS ID, now() as time,Sequence, Description, 
TodayProduction, WTDProduction ,MTDProduction,QTDProduction ,YTDProduction
FROM (
SELECT '01' as Sequence
  , 'Units Produced' as Description
  , SUM(CASE WHEN EXTRACT(doy from jr."TrnDate") = EXTRACT(doy from now()) THEN jr."QtySupplied" ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN TO_CHAR(jr."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN jr."QtySupplied" ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN EXTRACT(month from jr."TrnDate") = EXTRACT(month from now()) THEN jr."QtySupplied" ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN EXTRACT(quarter from jr."TrnDate") = EXTRACT(quarter from now()) THEN jr."QtySupplied" ELSE 0 END) as QTDProduction
  , SUM(jr."QtySupplied") as YTDProduction
FROM sysprocompanyb.WipPartBookmain_stg0_gp jr INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jr."Job" = jm."Job"
     INNER JOIN sysprocompanyb.InvMastermain_stg0_gp im on jm."StockCode" = im."StockCode"
WHERE jm."Warehouse" IN ('F1','F2','F3','QC') 
  AND EXTRACT(year from jr."TrnDate") = EXTRACT(year from now()) 
  AND rtrim(jm."StockCode") like '%01'  --right(RTRIM(jm."StockCode") like '%01')
  AND SUBSTR(im."ProductClass",0, 3) <> 'SO'  --left
  AND NOT(im."ProductClass" IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))

UNION ALL

SELECT '02' as Sequence
  , 'Matl Issue Value FG' as Description
  , SUM(CASE WHEN EXTRACT(doy from jt."TrnDate") = EXTRACT(doy from now()) THEN jt."TrnValue" ELSE 0 END) as TodayMatlIssue
  , SUM(CASE WHEN TO_CHAR(jt."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN jt."TrnValue" ELSE 0 END) as WTDMatlIssue
  , SUM(CASE WHEN EXTRACT(month from jt."TrnDate") = EXTRACT(month from now()) THEN jt."TrnValue" ELSE 0 END) as MTDMatlIssue
  , SUM(CASE WHEN EXTRACT(quarter from jt."TrnDate") = EXTRACT(quarter from now()) THEN jt."TrnValue" ELSE 0 END) as QTDMatlIssue
  , SUM(jt."TrnValue") as YTDMatlIssue
FROM sysprocompanyb.WipJobPostmain_stg0_gp jt INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jt."Job" = jm."Job"
     INNER JOIN sysprocompanyb.InvMastermain_stg0_gp im on jm."StockCode" = im."StockCode"

WHERE       jt."TrnType" = 'R' 
   AND EXTRACT(year from jt."TrnDate") = EXTRACT(year from now()) 
   AND jm."Warehouse" IN ('F1','F2','F3','QC')
   AND rtrim(jm."StockCode") like '%01'  --RIGHT(RTRIM(jm."StockCode"), 2) = '01'
   AND  SUBSTR(im."ProductClass",0, 3) <> 'SO' --LEFT(im."ProductClass", 2) <> 'SO'
   AND NOT(im."ProductClass" IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
UNION ALL

SELECT '03' as Sequence
  , 'Labor Issue Value FG' as Description
  , SUM(CASE WHEN EXTRACT(doy from jt."TrnDate") = EXTRACT(doy from now()) THEN jt."TrnValue" ELSE 0 END) as TodayLabIssue
  , SUM(CASE WHEN TO_CHAR(jt."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN jt."TrnValue" ELSE 0 END) as WTDLabIssue
  , SUM(CASE WHEN EXTRACT(month from jt."TrnDate") = EXTRACT(month from now()) THEN jt."TrnValue" ELSE 0 END) as MTDLabIssue
  , SUM(CASE WHEN EXTRACT(quarter from jt."TrnDate") = EXTRACT(quarter from now()) THEN jt."TrnValue" ELSE 0 END) as QTDLabIssue
  , SUM(jt."TrnValue") as YTDLabIssue
FROM sysprocompanyb.WipJobPostmain_stg0_gp jt INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jt."Job" = jm."Job"
     INNER JOIN sysprocompanyb.InvMastermain_stg0_gp im on jm."StockCode" = im."StockCode"
WHERE       jt."TrnType" = 'L' 
   AND EXTRACT(year from jt."TrnDate") = EXTRACT(year from now()) 
   AND jm."Warehouse" IN ('F1','F2','F3','QC')
   AND rtrim(jm."StockCode") like '%01' --RIGHT(RTRIM(jm."StockCode"), 2) = '01'
   AND SUBSTR(im."ProductClass",0, 3) <> 'SO' --LEFT(im."ProductClass", 2) <> 'SO'
   AND NOT(im."ProductClass" IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
UNION ALL

SELECT '04' as Sequence
  , 'Matl Value Produced FG' as Description
  , SUM(CASE WHEN EXTRACT(doy from jr."TrnDate") = EXTRACT(doy from now()) THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN TO_CHAR(jr."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN EXTRACT(month from jr."TrnDate") = EXTRACT(month from now()) THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN EXTRACT(quarter from jr."TrnDate") = EXTRACT(quarter from now()) THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as QTDProduction
  , SUM(jr."MaterialValue" + jr."LabourValue") as YTDProduction
FROM sysprocompanyb.WipPartBookmain_stg0_gp jr INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jr."Job" = jm."Job"
INNER JOIN sysprocompanyb.InvMastermain_stg0_gp im on jm."StockCode" = im."StockCode"

WHERE jm."Warehouse" IN ('F1','F2','F3','QC')
  AND EXTRACT(year from jr."TrnDate") = EXTRACT(year from now()) 
  AND rtrim(jm."StockCode") like '%01' --RIGHT(RTRIM(jm."StockCode"), 2) = '01'
  AND SUBSTR(im."ProductClass",0, 3) <> 'SO' --LEFT(im."ProductClass", 2) <> 'SO'
  AND NOT(im."ProductClass" IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
  AND jr."Reference" <> 'Billing')t1

 ----2-- 
UNION

select ROW_NUMBER() OVER (ORDER BY Sequence) AS ID, now() as time, * from
( SELECT '01' as Sequence
  , 'Kilos Produced' as Description
  , SUM(CASE WHEN  EXTRACT(doy from jr."TrnDate") =  EXTRACT(doy from now()) THEN jr."QtySupplied" ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN  TO_CHAR(jr."TrnDate",'WW') =  TO_CHAR(now(),'WW') THEN jr."QtySupplied" ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN  EXTRACT(month from jr."TrnDate") =  EXTRACT(month from now()) THEN jr."QtySupplied" ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN  EXTRACT(quarter from jr."TrnDate") =  EXTRACT(quarter from now()) THEN jr."QtySupplied" ELSE 0 END) as QTDProduction
  , SUM(jr."QtySupplied") as YTDProduction
FROM sysprocompanyb.WipPartBookmain_stg0_gp jr INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jr."Job" = jm."Job"
WHERE jm."Warehouse" = 'W1' and EXTRACT(year  from jr."TrnDate") = EXTRACT(year  from now())
UNION ALL
SELECT '02' as Sequence
  , 'Matl Issue Value' as Description
  , SUM(CASE WHEN  EXTRACT(doy from jt."TrnDate") =  EXTRACT(doy from now()) THEN jt."TrnValue" ELSE 0 END) as TodayMatlIssue
  , SUM(CASE WHEN  TO_CHAR(jt."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN jt."TrnValue" ELSE 0 END) as WTDMatlIssue
  , SUM(CASE WHEN  EXTRACT(month from jt."TrnDate") =  EXTRACT(month from now()) THEN jt."TrnValue" ELSE 0 END) as MTDMatlIssue
  , SUM(CASE WHEN  EXTRACT(quarter from jt."TrnDate") =  EXTRACT(quarter from now()) THEN jt."TrnValue" ELSE 0 END) as QTDMatlIssue
  , SUM(jt."TrnValue") as YTDMatlIssue
FROM sysprocompanyb.WipJobPostmain_stg0_gp jt INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jt."Job" = jm."Job"
WHERE       jt."TrnType" = 'R' AND EXTRACT(year  from jt."TrnDate") = EXTRACT(year  from now()) AND jm."Warehouse" = 'W1'
UNION ALL
SELECT '03' as Sequence
  , 'Labor Issue Value' as Description
  , SUM(CASE WHEN  EXTRACT(doy from jt."TrnDate") =  EXTRACT(doy from now()) THEN jt."TrnValue" ELSE 0 END) as TodayLabIssue
  , SUM(CASE WHEN  TO_CHAR(jt."TrnDate",'WW') =  TO_CHAR(now(),'WW') THEN jt."TrnValue" ELSE 0 END) as WTDLabIssue
  , SUM(CASE WHEN  EXTRACT(month from jt."TrnDate") =  EXTRACT(month from now()) THEN jt."TrnValue" ELSE 0 END) as MTDLabIssue
  , SUM(CASE WHEN  EXTRACT(quarter from jt."TrnDate") =  EXTRACT(quarter from now()) THEN jt."TrnValue" ELSE 0 END) as QTDLabIssue
  , SUM(jt."TrnValue") as YTDLabIssue
FROM sysprocompanyb.WipJobPostmain_stg0_gp jt INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jt."Job" = jm."Job"
WHERE       jt."TrnType" = 'L' AND EXTRACT(year  from jt."TrnDate") = EXTRACT(year  from now()) AND jm."Warehouse" = 'W1'

UNION ALL

SELECT '04' as Sequence
  , 'Matl Value Produced' as Description
  , SUM(CASE WHEN  EXTRACT(doy from jr."TrnDate") =  EXTRACT(doy from now()) THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN  TO_CHAR(jr."TrnDate",'WW') =  TO_CHAR(now(),'WW') THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN  EXTRACT(month from jr."TrnDate") =  EXTRACT(month from now()) THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN  EXTRACT(quarter from jr."TrnDate") =  EXTRACT(quarter from now()) THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as QTDProduction
  , SUM(jr."MaterialValue" + jr."LabourValue") as YTDProduction
FROM sysprocompanyb.WipPartBookmain_stg0_gp jr INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jr."Job" = jm."Job"
WHERE jm."Warehouse" = 'W1' and EXTRACT(year  from jr."TrnDate") = EXTRACT(year  from now()) and jr."Reference" <> 'Billing')t2

---3----
union  

SELECT ROW_NUMBER() OVER (ORDER BY Sequence) AS ID, now() as time,
'05' As Sequence, 
'Bulk Production Variance' as Description, (t02.TodayProduction - t01.TodayProduction) AS TodayProduction, 
(t02.WTDProduction - t01.WTDProduction) AS WTDProduction,(t02.MTDProduction - t01.MTDProduction) AS MTDProduction, 
(t02.QTDProduction - t01.QTDProduction) AS QTDProduction,(t02.YTDProduction - t01.YTDProduction) AS YTDProduction 
FROM (

select  
sum(t011.TodayProduction) as TodayProduction, sum(t011.WTDProduction) as WTDProduction,sum(t011.MTDProduction) as MTDProduction, 
sum(t011.QTDProduction) as QTDProduction,sum(t011.YTDProduction) as YTDProduction 
from (SELECT '02' as Sequence
  , 'Matl Issue Value' as Description
  , SUM(CASE WHEN EXTRACT(doy from jt."TrnDate") = EXTRACT(doy from now()) THEN jt."TrnValue" ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN TO_CHAR(jt."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN jt."TrnValue" ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN EXTRACT(month from jt."TrnDate") = EXTRACT(month from now()) THEN jt."TrnValue" ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN EXTRACT(quarter from jt."TrnDate") = EXTRACT(quarter from now()) THEN jt."TrnValue" ELSE 0 END) as QTDProduction
  , SUM(jt."TrnValue") as YTDProduction
FROM sysprocompanyb.WipJobPostmain_stg0_gp jt INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jt."Job" = jm."Job"
WHERE       jt."TrnType" = 'R' AND EXTRACT(year from jt."TrnDate") = EXTRACT(year from now()) AND jm."Warehouse" = 'W1'

UNION ALL

SELECT '03' as Sequence
  , 'Labor Issue Value' as Description
  , SUM(CASE WHEN EXTRACT(doy from jt."TrnDate") = EXTRACT(doy from now()) THEN jt."TrnValue" ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN TO_CHAR(jt."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN jt."TrnValue" ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN EXTRACT(month from jt."TrnDate") = EXTRACT(month from now()) THEN jt."TrnValue" ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN EXTRACT(quarter from jt."TrnDate") = EXTRACT(quarter from now()) THEN jt."TrnValue" ELSE 0 END) as QTDProduction
  , SUM(jt."TrnValue") as YTDProduction
FROM sysprocompanyb.WipJobPostmain_stg0_gp jt INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jt."Job" = jm."Job"
WHERE       jt."TrnType" = 'L' AND EXTRACT(year from jt."TrnDate") = EXTRACT(year from now()) AND jm."Warehouse" = 'W1'
)t011


) t01 


CROSS JOIN (SELECT '04' as Sequence
  , 'Matl Value Produced' as Description
  , SUM(CASE WHEN EXTRACT(doy from jr."TrnDate") = EXTRACT(doy from now()) THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN TO_CHAR(jr."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN EXTRACT(month from jr."TrnDate") = EXTRACT(month from now()) THEN jr."MaterialValue" 
+ jr."LabourValue" ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN EXTRACT(quarter from jr."TrnDate") = EXTRACT(quarter from now()) THEN jr."MaterialValue" 
+ jr."LabourValue" ELSE 0 END) as QTDProduction
  , SUM(jr."MaterialValue" + jr."LabourValue") as YTDProduction
FROM sysprocompanyb.WipPartBookmain_stg0_gp jr INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm ON jr."Job" = jm."Job"
WHERE jm."Warehouse" = 'W1' and EXTRACT(year from jr."TrnDate") = EXTRACT(year from now()) and jr."Reference" <> 'Billing') t02 


---4-----
UNION 
SELECT ROW_NUMBER() OVER (ORDER BY Sequence) AS ID, now() as time,Sequence, 
'Finished Goods Production Variance' as Description, (t2.TodayProduction - t1.TodayProduction) AS TodayProduction, 
(t2.WTDProduction - t1.WTDProduction) AS WTDProduction, (t2.MTDProduction - t1.MTDProduction) AS MTDProduction, 
(t2.QTDProduction - t1.QTDProduction) AS QTDProduction,(t2.YTDProduction - t1.YTDProduction) AS YTDProduction 
FROM (
select '05' As Sequence,sum(t11.TodayProduction) as TodayProduction,sum(t11.WTDProduction) as WTDProduction,sum(t11.MTDProduction) as MTDProduction, 
sum(t11.QTDProduction) as QTDProduction,sum(t11.YTDProduction) as YTDProduction from 
(
SELECT   SUM(CASE WHEN EXTRACT(doy from jt."TrnDate") = EXTRACT(doy from now()) THEN jt."TrnValue" ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN TO_CHAR(jt."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN jt."TrnValue" ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN EXTRACT(month from jt."TrnDate") = EXTRACT(month from now()) THEN jt."TrnValue" ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN EXTRACT(quarter from jt."TrnDate") = EXTRACT(quarter from now()) THEN jt."TrnValue" ELSE 0 END) as QTDProduction
  , SUM(jt."TrnValue") as YTDProduction
FROM sysprocompanyb.WipJobPostmain_stg0_gp jt INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm 
ON jt."Job" = jm."Job" INNER JOIN sysprocompanyb.InvMastermain_stg0_gp im on jm."StockCode" = im."StockCode"

WHERE       jt."TrnType" = 'R' 
   AND EXTRACT(year from jt."TrnDate") = EXTRACT(year from now()) 
   AND jm."Warehouse" IN ('F1','F2','F3','QC')
 AND rtrim(jm."StockCode") like '%01' --RIGHT(RTRIM(jm."StockCode"), 2) = '01'
  AND SUBSTR(im."ProductClass",0, 3) <> 'SO' --LEFT(im."ProductClass", 2) <> 'SO'
   AND NOT(im."ProductClass" IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))

UNION ALL

SELECT  SUM(CASE WHEN EXTRACT(doy from jt."TrnDate") = EXTRACT(doy from now()) THEN jt."TrnValue" ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN TO_CHAR(jt."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN jt."TrnValue" ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN EXTRACT(month from jt."TrnDate") = EXTRACT(month from now()) THEN jt."TrnValue" ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN EXTRACT(quarter from jt."TrnDate") = EXTRACT(quarter from now()) THEN jt."TrnValue" ELSE 0 END) as QTDProduction
  , SUM(jt."TrnValue") as YTDProduction
FROM sysprocompanyb.WipJobPostmain_stg0_gp jt INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm 
ON jt."Job" = jm."Job"
     INNER JOIN sysprocompanyb.InvMastermain_stg0_gp im on jm."StockCode" = im."StockCode"

WHERE       jt."TrnType" = 'L' 
   AND EXTRACT(year from jt."TrnDate") = EXTRACT(year from now()) 
   
   AND jm."Warehouse" IN ('F1','F2','F3','QC')
 AND rtrim(jm."StockCode") like '%01' --RIGHT(RTRIM(jm."StockCode"), 2) = '01'
  AND SUBSTR(im."ProductClass",0, 3) <> 'SO' --LEFT(im."ProductClass", 2) <> 'SO'
   AND NOT(im."ProductClass" IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
) t11 ) t1 
CROSS JOIN (SELECT '05' As Sequence1, SUM(CASE WHEN EXTRACT(doy from jr."TrnDate") = EXTRACT(doy from now()) THEN jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as TodayProduction
  , SUM(CASE WHEN TO_CHAR(jr."TrnDate",'WW') = TO_CHAR(now(),'WW') THEN 
jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as WTDProduction
  , SUM(CASE WHEN EXTRACT(month from jr."TrnDate") = EXTRACT(month from now()) THEN 
jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as MTDProduction
  , SUM(CASE WHEN EXTRACT(quarter from jr."TrnDate") = EXTRACT(quarter from now()) THEN
 jr."MaterialValue" + jr."LabourValue" ELSE 0 END) as QTDProduction
  , SUM(jr."MaterialValue" + jr."LabourValue") as YTDProduction
FROM sysprocompanyb.WipPartBookmain_stg0_gp jr INNER JOIN sysprocompanyb.WipMastermain_stg0_gp jm 
ON jr."Job" = jm."Job"
INNER JOIN sysprocompanyb.InvMastermain_stg0_gp im on jm."StockCode" = im."StockCode"

WHERE jm."Warehouse" IN ('F1','F2','F3','QC')
  AND EXTRACT(year from jr."TrnDate") = EXTRACT(year from now()) 
  AND rtrim(jm."StockCode") like '%01' --RIGHT(RTRIM(jm."StockCode"), 2) = '01'
  AND SUBSTR(im."ProductClass",0, 3) <> 'SO' --LEFT(im."ProductClass", 2) <> 'SO'
  AND NOT(im."ProductClass" IN ('BA03', 'BY03', 'CC', 'FC03', 'FC04', 'HC03', 'SC03', 'SC04', 'SH04', 'S001', 'S002'))
  AND jr."Reference" <> 'Billing') t2