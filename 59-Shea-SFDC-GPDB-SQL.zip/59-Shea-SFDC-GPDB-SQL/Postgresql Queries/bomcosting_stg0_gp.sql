
select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,
"ParentPart"
,"Route"
,"Comp/Wc"
,a."Description" as CompDescription
,"QtyPer" ,a."MaterialCost"
,iv."ProductClass",iv."ProductGroup",iv."Description"
From sysprocompanyb.view_bomcosting_stg0_gp  a
left join sysprocompanyb.invmastermain_stg0_gp iv on a."ParentPart" = iv."StockCode"
where "StockUom"='EA' ;