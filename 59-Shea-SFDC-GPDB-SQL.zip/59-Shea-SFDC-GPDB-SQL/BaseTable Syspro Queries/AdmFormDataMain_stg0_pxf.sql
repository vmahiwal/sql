
--AdmFormData


select
ROW_NUMBER() OVER (ORDER BY getdate()) AS ID,
GETDATE() as time,
FormType	,
KeyField	,
FieldName	,
REPLACE(Replace(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(AlphaValue, CHAR(10), ''), CHAR(13), ''), CHAR(9), ''))),'~',''),char(12),'') AS AlphaValue,
NumericValue	,
DateValue
from AdmFormData