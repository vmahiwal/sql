
SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time,
FormType,
FieldName, 
Item, 
Description, 
DefaultItem from AdmFormValidation;