Select
ROW_NUMBER() OVER (ORDER BY getdate()) AS ID,
GETDATE() as time,
Class,
Description ,
TimeStamp from TblCustomerClass;