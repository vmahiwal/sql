select 
ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, 
GETDATE() as time,
StockCode,
PriceCode,
SellingPrice,
PriceBasis,
CommissionCode
from InvPrice;