Select
ROW_NUMBER() OVER (ORDER BY getdate()) AS ID,
GETDATE() as time,
ReasonCode,
Description ,
IoLostSaleFlag ,
TimeStamp from TblSoReason;