__________BTP_vwKPI_SalesGraphMonthly_stg0_gp.sql_________

select ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time, tmp.* from(
SELECT 'A' as RecordType
    	, "TrnYear"	
		, "TrnMonth"
		--, SUM(NetSalesValue) as MonthlySales
		, SUM("NetSalesValue" + "DiscValue") as MonthlySales
FROM sysprocompanyb.artrndetailmain_stg0_gp

WHERE ("TrnYear" = DATE_PART('year', now())) and ("LineType" = '1') and ("Branch" is distinct from 'TR' and "Branch" is distinct from 'CO' and "Branch" is distinct from 'SM')
--Added following condition to eliminate credit notes 2016-06-07
		AND ("DocumentType") is distinct from  'C'
		--2016-12-14 Next Line To Exclude Raw Material Customers
				AND ("Customer" is distinct from  '000000000048869' and "Customer" is distinct from '000000000049870')
GROUP BY "TrnYear"
		, "TrnMonth"

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 1 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget1") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 2 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget2") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 3 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget3") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 4 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget4") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 5 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget5") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 6 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget6") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 7 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget7") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 8 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget8") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 9 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget9") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 10 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget10") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 11 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget11") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company")= 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'B' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 12 as TrnMonth
		--if Current Year Budget populated then use budget, else use 0
		, SUM(gb."Budget12") as MonthlySales
		--, SUM(1) as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'C'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 1 as TrnMonth
		, SUM(gb."Budget1") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 2 as TrnMonth
		, SUM(gb."Budget2") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 3 as TrnMonth
		, SUM(gb."Budget3") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 4 as TrnMonth
		, SUM(gb."Budget4") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode"= at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 5 as TrnMonth
		, SUM(gb."Budget5") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 6 as TrnMonth
		, SUM(gb."Budget6") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 7 as TrnMonth
		, SUM(gb."Budget7") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 8 as TrnMonth
		, SUM(gb."Budget8") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 9 as TrnMonth
		, SUM(gb."Budget9") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 10 as TrnMonth
		, SUM(gb."Budget10") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 11 as TrnMonth
		, SUM(gb."Budget11") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'

UNION ALL

SELECT 'R' as RecordType
		, DATE_PART('year', now()) as TrnYear
		, 12 as TrnMonth
		, SUM(gb."Budget12") as MonthlySales
FROM sysprocompanyb.genbudgetsmain_stg0_gp gb INNER JOIN (SELECT "KeyField" as GlCode, "AlphaValue" as Rollup
								FROM sysprocompanyb.admformdatamain_stg0_gp WHERE "FormType" = 'GEN' and "FieldName" = 'BUD001') at ON gb."GlCode" = at.GlCode
WHERE trim(gb."Company") = 'B' and UPPER(at.Rollup) = 'SALES' and gb."BudgetType" = 'A' and gb."BudgetNumber" = '8'
)tmp