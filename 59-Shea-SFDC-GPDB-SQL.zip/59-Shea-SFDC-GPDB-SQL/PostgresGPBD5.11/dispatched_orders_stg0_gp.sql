--------------------dispatched_orders_stg0_gp------------------------
SELECT ROW_NUMBER() OVER (ORDER BY now()) AS ID, now() as time,vw."CorpAcctName",
LTRIM(dd."SalesOrder",'0') as SalesOrder,
"SalesOrderLine",
"TotalValue",
"MStockCode",
"MStockDes",
"MWarehouse",
"MOrderQty",
"MQtyToDispatch",
"MBackOrderQty",
"MUnitCost",
"MPrice",
"MLineShipDate",
"MCustRequestDat",
"MQtyDispatched",
LTRIM(dm."Customer",'0')  as Customer
,dm."CustomerName",
"DispatchName",
"PlannedDeliverDate",
"ActualDeliveryDate",
"CustomerPoNumber"
FROM            sysprocompanyb.mdndetailmain_stg0_gp  dd INNER JOIN
                         sysprocompanyb.mdnmastermain_stg0_gp  dm ON dd."DispatchNote" = dm."DispatchNote"
    					 left join sysprocompanyb.arcustomermain_stg0_gp vw on vw."Customer"=dm."Customer"
WHERE        (dd."LineType" = '1') 
AND (dm."DispatchNoteStatus" is distinct from '*') 
AND (dm."DispatchNoteStatus" is distinct from '9') 
AND (dd."DispatchStatus" is distinct from '*') 
and (dm."Branch" is distinct from 'TR' and dm."Branch" is distinct from 'CO' and dm."Branch" is distinct from 'SM')