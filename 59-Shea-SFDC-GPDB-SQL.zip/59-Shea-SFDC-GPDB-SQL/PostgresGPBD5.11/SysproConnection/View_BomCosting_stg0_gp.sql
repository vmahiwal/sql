
---------View_BomCosting

 SELECT ROW_NUMBER() OVER (ORDER BY getdate()) AS ID, GETDATE() as time
      ,[Section]
      ,[Source]
      ,[ParentPart]
      ,[Ebq]
      ,[Route]
      ,[OperationOffset]
      ,[Comp/Wc]
      ,[Description]
      ,[QtyPer]
      ,[SetUpTime]
      ,[EffSetupTime]
      ,[SetupRate]
      ,[SetupCost]
      ,[RunTime]
      ,[RunTimeRate]
      ,[RunTimeCost]
      ,[Time4FixOH]
      ,[FixOHRate]
      ,[FixOHCost]
      ,[CurWhCost]
      ,[MaterialCost]
      ,[LabourCost]
      ,[FixOverhead]
      ,[TotCIUnitCost]
      ,[LineCost]
      ,[Bulk]
,NULL as ProductClass
,NULL as ProductGroup
,NULL as Description
  FROM [SysproCompanyB].[dbo].[View_BomCosting]
