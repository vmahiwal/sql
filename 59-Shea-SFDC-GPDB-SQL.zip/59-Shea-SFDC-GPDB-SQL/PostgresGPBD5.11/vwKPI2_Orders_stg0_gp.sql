-----------vwKPI2_Orders_stg0_gp--------------------------------------
SELECT 
 now() as time,'00' as Sequence, 'Gross Order Intake' as Description,
 SUM(CASE WHEN DATE_PART('doy',om."EntrySystemDate") = DATE_PART('doy',now()) 
    THEN ROUND((od."MOrderQty" * od."MPrice") ,2)
    ELSE 0 END) as Today
   , SUM(CASE WHEN TO_CHAR(om."EntrySystemDate",'WW') = TO_CHAR(now(),'WW') 
    THEN ROUND((od."MOrderQty" * od."MPrice") ,2)
    ELSE 0 END) as WTD
  
  , SUM(CASE WHEN DATE_PART('month',om."EntrySystemDate") = DATE_PART('month',now()) 
    THEN ROUND((od."MOrderQty" * od."MPrice") ,2)
    ELSE 0 END) as MTD
  
  , SUM(CASE WHEN DATE_PART('quarter',om."EntrySystemDate") = DATE_PART('quarter',now()) 
    THEN ROUND((od."MOrderQty" * od."MPrice") ,2)
    ELSE 0 END) as QTD
  
  , SUM(ROUND((od."MOrderQty" * od."MPrice") ,2)) as YTD
  
  
FROM sysprocompanyb.sormastermain_stg0_gp om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp   od ON om."SalesOrder" = od."SalesOrder"
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om."OrderStatus" in ('0','1','2','3','4','8','9','S'))
  AND (om."CancelledFlag" is distinct from 'Y')
  AND (om."InterWhSale" is distinct from 'Y') 
  AND (om."Branch" is distinct from 'TR' and om."Branch" is distinct from 'CO' and om."Branch" is distinct from  'SM') 
  AND (od."LineType" = '1')
  --Added following condition to eliminate credit notes 2016-06-07
  AND (om."DocumentType") is distinct from 'C'
  --2016-12-14 Next Line To Exclude Raw Material Customers
    AND (om."Customer" is distinct from '000000000048869' and om."Customer" is distinct from '000000000049870')
  AND DATE_PART('year',om."EntrySystemDate") = DATE_PART('year',now())  
union  
 SELECT  now() as time,'00' as Sequence, 'Net Order Intake' as Description,SUM(CASE WHEN DATE_PART('doy',om."EntrySystemDate") = DATE_PART('doy',now()) 
    THEN CASE WHEN od."MDiscValFlag" = 'V' THEN ROUND(((od."MOrderQty" * od."MPrice") - od."MDiscValue") * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100) ,2)
        WHEN od."MDiscValFlag" = 'U' THEN ROUND(((od."MOrderQty" * od."MPrice") - (od."MOrderQty" * od."MDiscValue")) * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100),2)
        ELSE ROUND((od."MOrderQty" * od."MPrice") * ((100 - od."MDiscPct1")/100) * ((100 - od."MDiscPct2")/100) * ((100 - od."MDiscPct3")/100) * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100) ,2)
      END
    ELSE 0 END) as TodayNet
  , SUM(CASE WHEN TO_CHAR(om."EntrySystemDate",'WW') = TO_CHAR(now(),'WW') 
    THEN CASE WHEN od."MDiscValFlag" = 'V' THEN ROUND(((od."MOrderQty" * od."MPrice") - od."MDiscValue") * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100) ,2)
        WHEN od."MDiscValFlag" = 'U' THEN ROUND(((od."MOrderQty" * od."MPrice") - (od."MOrderQty" * od."MDiscValue")) * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100),2)
        ELSE ROUND((od."MOrderQty" * od."MPrice") * ((100 - od."MDiscPct1")/100) * ((100 - od."MDiscPct2")/100) * ((100 - od."MDiscPct3")/100) * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100) ,2)
      END
    ELSE 0 END) as WTDNet
  , SUM(CASE WHEN DATE_PART('month',om."EntrySystemDate") = DATE_PART('month',now()) 
    THEN CASE WHEN od."MDiscValFlag" = 'V' THEN ROUND(((od."MOrderQty" * od."MPrice") - od."MDiscValue") * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100) ,2)
        WHEN od."MDiscValFlag" = 'U' THEN ROUND(((od."MOrderQty" * od."MPrice") - (od."MOrderQty" * od."MDiscValue")) * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100),2)
        ELSE ROUND((od."MOrderQty" * od."MPrice") * ((100 - od."MDiscPct1")/100) * ((100 - od."MDiscPct2")/100) * ((100 - od."MDiscPct3")/100) * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100) ,2)
      END
    ELSE 0 END) as MTDNet
  ,  SUM(CASE WHEN DATE_PART('quarter',om."EntrySystemDate") = DATE_PART('quarter',now()) 
    THEN CASE WHEN od."MDiscValFlag" = 'V' THEN ROUND(((od."MOrderQty" * od."MPrice") - od."MDiscValue") * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100) ,2)
        WHEN od."MDiscValFlag" = 'U' THEN ROUND(((od."MOrderQty" * od."MPrice") - (od."MOrderQty" * od."MDiscValue")) * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100),2)
        ELSE ROUND((od."MOrderQty" * od."MPrice") * ((100 - od."MDiscPct1")/100) * ((100 - od."MDiscPct2")/100) * ((100 - od."MDiscPct3")/100) * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100) ,2)
      END
    ELSE 0 END) as QTDNet
  , SUM(CASE WHEN od."MDiscValFlag" = 'V' THEN ROUND(((od."MOrderQty" * od."MPrice") - od."MDiscValue") * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100) ,2)
        WHEN od."MDiscValFlag" = 'U' THEN ROUND(((od."MOrderQty" * od."MPrice") - (od."MOrderQty" * od."MDiscValue")) * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100),2)
        ELSE ROUND((od."MOrderQty" * od."MPrice") * ((100 - od."MDiscPct1")/100) * ((100 - od."MDiscPct2")/100) * ((100 - od."MDiscPct3")/100) * ((100 - om."DiscPct1")/100) * ((100 - om."DiscPct2")/100) * ((100 - om."DiscPct3")/100) ,2)
    END) as YTDNet
  
FROM sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp   od ON om."SalesOrder" = od."SalesOrder"
--WHERE (NOT(OrderStatus in ('*','\')) or om.CancelledFlag <> 'Y') 
WHERE (om."OrderStatus" in ('0','1','2','3','4','8','9','S'))
  AND (om."CancelledFlag" is distinct from 'Y')
  AND (om."InterWhSale" is distinct from 'Y') 
  AND (om."Branch" is distinct from 'TR' and om."Branch" is distinct from 'CO' and om."Branch" is distinct from 'SM') 
  AND (od."LineType" = '1')
  --Added following condition to eliminate credit notes 2016-06-07
  AND (om."DocumentType") is distinct from 'C'
  --2016-12-14 Next Line To Exclude Raw Material Customers
    AND  (om."Customer" is distinct from  '000000000048869' and om."Customer" is distinct from '000000000049870')
  AND DATE_PART('year',om."EntrySystemDate") = DATE_PART('year',now())
 union 
 SELECT now() as time,'02' as Sequence
  , 'Picked Not Dispatched' as Description
  , SUM(ROUND(bo."ShipQty" * od."MPrice", 2)) as Today
  , SUM(ROUND(bo."ShipQty" * od."MPrice", 2)) as WTD
  , SUM(ROUND(bo."ShipQty"* od."MPrice", 2)) as MTD
  , SUM(ROUND(bo."ShipQty" * od."MPrice", 2)) as QTD
  , SUM(ROUND(bo."ShipQty" * od."MPrice", 2)) as YTD
FROM              sysprocompanyb.barcodeordersmain_stg0_gp  bo INNER JOIN sysprocompanyb.sordetailmain_stg0_gp   od 
           ON  ltrim(od."SalesOrder",'0' )= ltrim(bo."OrderNo",'0')-- COLLATE Latin1_General_BIN 
           AND od."MStockCode" = bo."ItemNo"-- COLLATE Latin1_General_BIN 
           AND od."SalesOrderLine" = bo."LineNumber"
          INNER JOIN sysprocompanyb.sormastermain_stg0_gp  om
           ON od."SalesOrder" = om."SalesOrder"
WHERE  (om."Branch" is distinct from 'TR' and om."Branch" is distinct from 'CO' and om."Branch" is distinct from 'SM')

    AND  (om."Customer" is distinct from  '000000000048869' and om."Customer" is distinct from '000000000049870')

UNION ALL

SELECT now() as time,'01' as Sequence
  , 'Open Orders By Ship Date' as Description
  , SUM(CASE WHEN od."MLineShipDate" <= now() 
   THEN ROUND(((od."MShipQty" + "MBackOrderQty") * od."MPrice") ,2)
   ELSE 0 END) as TodayGross
  , SUM(CASE WHEN ((od."MLineShipDate" <= now()) OR (TO_CHAR(od."MLineShipDate",'WW') = TO_CHAR(now(),'WW')))
   THEN ROUND(((od."MShipQty" + "MBackOrderQty") * od."MPrice") ,2)
   ELSE 0 END) as WTDGross
  , SUM(CASE WHEN ((od."MLineShipDate" <= now()) OR (DATE_PART('month',od."MLineShipDate") = DATE_PART('month',now())))
   THEN ROUND(((od."MShipQty" + "MBackOrderQty") * od."MPrice") ,2)
   ELSE 0 END) as MTDGross
  , SUM(CASE WHEN ((od."MLineShipDate" <= now()) OR (DATE_PART('quarter',od."MLineShipDate") = DATE_PART('quarter',now())))
   THEN ROUND(((od."MShipQty" + "MBackOrderQty") * od."MPrice") ,2)
   ELSE 0 END) as QTDGross
  , SUM(CASE WHEN ((od."MLineShipDate" <= now()) OR (DATE_PART('year',od."MLineShipDate") = DATE_PART('year',now())))
   THEN ROUND(((od."MShipQty" + "MBackOrderQty") * od."MPrice") ,2)
   ELSE 0 END) as YTDGross
FROM sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp  od ON om."SalesOrder" = od."SalesOrder" 

WHERE (om."OrderStatus" in ('0','1','2','3','4','S')) 
  AND (om."CancelledFlag" is distinct from 'Y')
  AND (om."InterWhSale" is distinct from 'Y') 
  AND (om."Branch" is distinct from 'TR' and om."Branch" is distinct from 'CO' and om."Branch" is distinct from 'SM')
  AND (od."LineType" = '1')
  
  AND (om."DocumentType") is distinct from 'C'
 
     AND  ("Customer" is distinct from  '000000000048869' and "Customer" is distinct from '000000000049870')
  AND ((od."MShipQty" + "MBackOrderQty") is distinct from 0) 

   union
    select now() as time,'03' as Sequence, 'Total To Be Picked' as Description, 
  (t02.TodayGross - t01.Today) AS Today,
  (t02.WTDGross - t01.WTD) AS WTD,
  (t02.MTDGross - t01.MTD) AS MTD,
   (t02.QTDGross - t01.QTD) AS QTD,
   (t02.YTDGross - t01.YTD) AS YTD  FROM (select now() as time
   , 'Picked Not Dispatched' as Description
  , SUM(ROUND(bo."ShipQty" * od."MPrice", 2)) as Today
  , SUM(ROUND(bo."ShipQty" * od."MPrice", 2)) as WTD
  , SUM(ROUND(bo."ShipQty" * od."MPrice", 2)) as MTD
  , SUM(ROUND(bo."ShipQty" * od."MPrice", 2)) as QTD
  , SUM(ROUND(bo."ShipQty" * od."MPrice", 2)) as YTD
FROM               sysprocompanyb.barcodeordersmain_stg0_gp bo INNER JOIN sysprocompanyb.sordetailmain_stg0_gp   od 
           ON LTRIM(od."SalesOrder",'0')  = LTRIM(bo."OrderNo",'0' )
           AND od."MStockCode" = bo."ItemNo"
           AND od."SalesOrderLine" = bo."LineNumber"
          INNER JOIN sysprocompanyb.sormastermain_stg0_gp  om
           ON od."SalesOrder" = om."SalesOrder"
WHERE ("Branch" is distinct from 'TR' and "Branch" is distinct from 'CO' and "Branch" is distinct from 'SM')

   AND  ("Customer" is distinct from  '000000000048869' and "Customer" is distinct from '000000000049870')) t01 
 CROSS JOIN (SELECT '01' as Sequence
  , 'Open Orders By Ship Date' as Description
  , SUM(CASE WHEN od."MLineShipDate" <= now() 
   THEN ROUND(((od."MShipQty" + "MBackOrderQty") * od."MPrice") ,2)
   ELSE 0 END) as TodayGross
  , SUM(CASE WHEN ((od."MLineShipDate" <= now()) OR (TO_CHAR(od."MLineShipDate",'WW') = TO_CHAR(now(),'WW')))
   THEN ROUND(((od."MShipQty" + "MBackOrderQty") * od."MPrice") ,2)
   ELSE 0 END) as WTDGross
  , SUM(CASE WHEN ((od."MLineShipDate" <= now()) OR (DATE_PART('month',od."MLineShipDate") = DATE_PART('month',now())))
   THEN ROUND(((od."MShipQty" + "MBackOrderQty") * od."MPrice") ,2)
   ELSE 0 END) as MTDGross
  , SUM(CASE WHEN ((od."MLineShipDate" <= now()) OR (DATE_PART('quarter',od."MLineShipDate") = DATE_PART('quarter',now())))
   THEN ROUND(((od."MShipQty" + "MBackOrderQty") * od."MPrice") ,2)
   ELSE 0 END) as QTDGross
  , SUM(CASE WHEN ((od."MLineShipDate" <= now()) OR (DATE_PART('year',od."MLineShipDate") = DATE_PART('year',now())))
   THEN ROUND(((od."MShipQty" + "MBackOrderQty") * od."MPrice") ,2)
   ELSE 0 END) as YTDGross
FROM sysprocompanyb.sormastermain_stg0_gp  om INNER JOIN sysprocompanyb.sordetailmain_stg0_gp od ON om."SalesOrder" = od."SalesOrder" 

WHERE (om."OrderStatus" in ('0','1','2','3','4','S')) 
  AND (om."CancelledFlag" is distinct from  'Y')
  AND (om."InterWhSale" is distinct from 'Y') 
  AND ("Branch" is distinct from 'TR' and "Branch" is distinct from 'CO' and "Branch" is distinct from 'SM')
  AND (od."LineType" = '1')

  AND (om."DocumentType") is distinct from 'C'
       AND  ("Customer" is distinct from  '000000000048869' and "Customer" is distinct from '000000000049870')
  AND ((od."MShipQty" + "MBackOrderQty") is distinct from 0)) t02 
  
 union 
    SELECT  now() as time,'04' as Sequence
  , 'Dispatched:  Awaiting Invoicing' as Description
  , SUM(ROUND(dd."MQtyToDispatch" * dd."MPrice",2)) as Today
  , SUM(ROUND(dd."MQtyToDispatch" * dd."MPrice",2)) as WTD
  , SUM(ROUND(dd."MQtyToDispatch" * dd."MPrice",2)) as MTD
  , SUM(ROUND(dd."MQtyToDispatch" * dd."MPrice",2)) as QTD
  , SUM(ROUND(dd."MQtyToDispatch" * dd."MPrice",2)) as YTD
FROM            sysprocompanyb.mdndetailmain_stg0_gp  dd INNER JOIN
                        sysprocompanyb.mdnmastermain_stg0_gp  dm ON dd."DispatchNote" = dm."DispatchNote"
WHERE        (dd."LineType" = '1') AND (dm."DispatchNoteStatus" is distinct from  '*') AND (dm."DispatchNoteStatus" is distinct from '9') 
AND (dd."DispatchStatus" is distinct from '*') 
and (dm."Branch" is distinct from 'TR' and dm."Branch" is distinct from 'CO' and dm."Branch" is distinct from 'SM')
   
    AND  ("Customer" is distinct from  '000000000048869' and "Customer" is distinct from '000000000049870')

UNION ALL

SELECT  now() as time,'05' as Sequence
  , 'Invoiced Before Chargebacks' as Description
  , SUM(CASE WHEN DATE_PART('doy',"InvoiceDate") = DATE_PART('doy',now()) THEN ("NetSalesValue" + "DiscValue") ELSE 0 END) as TodayGross
  
  , SUM(CASE WHEN TO_CHAR("InvoiceDate",'WW') = TO_CHAR(now(),'WW') THEN ("NetSalesValue" + "DiscValue") ELSE 0 END) as WTDGross
  , SUM(CASE WHEN "TrnMonth" = DATE_PART('month',now()) THEN ("NetSalesValue" + "DiscValue") ELSE 0 END) as MTDGross
   , SUM(CASE WHEN (CASE WHEN "TrnMonth" BETWEEN 1 AND 3 THEN 1
     WHEN "TrnMonth" BETWEEN 4 AND 6 THEN 2
     WHEN "TrnMonth" BETWEEN 7 AND 9 THEN 3
     WHEN "TrnMonth" BETWEEN 10 and 12 THEN 4 ELSE 0 END) = DATE_PART('quarter',now()) THEN ("NetSalesValue" + "DiscValue") ELSE 0 END) as QTDGross
   , SUM(("NetSalesValue" + "DiscValue")) as YTDGross
 
FROM sysprocompanyb.artrndetailmain_stg0_gp  
WHERE ("LineType" = '1') AND ("TrnYear" = DATE_PART('year',now())) AND ("Branch" is distinct from 'TR' and "Branch" is distinct from 'CO' and "Branch" is distinct from 'SM') 
   AND ("DocumentType") is distinct from 'C'
     AND  ("Customer" is distinct from  '000000000048869' and "Customer" is distinct from '000000000049870')