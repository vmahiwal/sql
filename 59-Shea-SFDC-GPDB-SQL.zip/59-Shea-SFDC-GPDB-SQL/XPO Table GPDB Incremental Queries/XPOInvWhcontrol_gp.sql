
BEGIN;
truncate sysprocompanyb.xpoinvwhcontrol_stg0_gp;
insert into sysprocompanyb.xpoinvwhcontrol_stg0_gp
 select * from sysprocompanyb.xpoinvwhcontrol_stg0;
END;