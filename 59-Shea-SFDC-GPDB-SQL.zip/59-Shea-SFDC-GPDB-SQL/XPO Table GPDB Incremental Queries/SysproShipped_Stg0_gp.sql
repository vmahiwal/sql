SELECT MD."SalesOrder" as MD_SalesOrder , MD."SalesOrderLine" as MD_SalesOrderLine, MM."Customer" AS MM_CUSTOMER , MM."CustomerName" AS MM_CUSTOMENAME,
MM."PlannedDeliverDate" AS MM_PLANNEDDELIVARYDATE, MM."ActualDeliveryDate" AS MM_ACTUALLYDELIVARYDATE,
MD."MStockCode" AS MDMSTOCKCODE, MD."MStockDes" AS MD_MSTOCKDESC, MD."MWarehouse" AS MD_MWAREHOUSE, MD."MOrderQty" AS MD_MORDERQTY, MD."MQtyToDispatch" AS MQTYTODISPATCHED,
MD."MBackOrderQty" AS MD_MBACKORDERQTY, MD."MUnitCost" AS MD_MUNITCOST, MD."MStockQtyToShp" AS MD_MSTOCKQTYTOSHP, MD."MPrice" AS MD_MPRICE , MD."TotalValue" AS MD_TOTALVALUE, MDL."Lot" AS MDL_LOT
FROM sysprocompanyb.mdnmastermain_stg0_gp MM INNER JOIN sysprocompanyb.mdndetailmain_stg0_gp MD on MM."DispatchNote" = MD."DispatchNote"
inner join sysprocompanyb.mdndetaillotmain_stg0_gp MDL on MDL."DispatchNoteLine"=MD."DispatchNoteLine" and MDL."DispatchNote"=MD."DispatchNote"
--left join sysprocompanyb.sormastermain_stg0_gp om on om."SalesOrder"= MM."SalesOrder"
WHERE (MD."LineType"= '1')
AND (MD."DispatchStatus" is distinct from '*') and (MM."Branch" is distinct from 'TR' and MM."Branch" is distinct from 'CO' and MM."Branch" is distinct from 'SM')
AND MM."SalesOrder">=(select min(XMM."SALESORDER")FROM sysprocompanyb.xpomdnmaster_stg0_gp XMM) 
