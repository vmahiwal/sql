
BEGIN;
insert into sysprocompanyb.xpoinvwarehouse_stg0_gp 
select s.* from sysprocompanyb.xpoinvwarehouse_stg0 s
 LEFT JOIN sysprocompanyb.xpoinvwarehouse_stg0_gp d
ON (s."STOCKCODE" = d."STOCKCODE" and s."WAREHOUSE"=d."WAREHOUSE") 
where (d."STOCKCODE" is null and d."WAREHOUSE" is null);

--Delete Not IN USE
delete from sysprocompanyb.xpoinvwarehouse_stg0_gp 
where (sysprocompanyb.xpoinvwarehouse_stg0_gp."STOCKCODE",
sysprocompanyb.xpoinvwarehouse_stg0_gp."WAREHOUSE")
in
(
select d."STOCKCODE",d."WAREHOUSE"
from sysprocompanyb.xpoinvwarehouse_stg0_gp d
left join sysprocompanyb.xpoinvwarehouse_stg0 s
on s."STOCKCODE"=d."STOCKCODE" and s."WAREHOUSE"=d."WAREHOUSE"
where s."STOCKCODE" is null and s."WAREHOUSE" is null 
);

UPDATE sysprocompanyb.xpoinvwarehouse_stg0_gp d
SET
"time"=s."time",
"QTYONHAND" = s."QTYONHAND",
"QTYONORDER" = s."QTYONORDER",
"QTYBACKORDER" = s."QTYBACKORDER",
"QTYALLOCATED" = s."QTYALLOCATED",
"QTYINTRANSIT" = s."QTYINTRANSIT",
"COST" = s."COST"
FROM sysprocompanyb.xpoinvwarehouse_stg0 s
Where s."STOCKCODE"= d."STOCKCODE" and s."WAREHOUSE"=d."WAREHOUSE" 
and
(
((s."QTYONHAND" != d."QTYONHAND") OR (s."QTYONHAND"  is not NULL and d."QTYONHAND"  is NULL) OR (d."QTYONHAND" is not NULL and s."QTYONHAND"  is NULL))OR
((s."QTYONORDER" != d."QTYONORDER") OR (s."QTYONORDER"  is not NULL and d."QTYONORDER"  is NULL) OR (d."QTYONORDER" is not NULL and s."QTYONORDER"  is NULL)) OR
((s."QTYBACKORDER" != d."QTYBACKORDER") OR (s."QTYBACKORDER"  is not NULL and d."QTYBACKORDER"  is NULL) OR (d."QTYBACKORDER" is not NULL and s."QTYBACKORDER"  is NULL)) OR
((s."QTYALLOCATED" != d."QTYALLOCATED") OR  (s."QTYALLOCATED"  is not NULL and d."QTYALLOCATED"  is NULL) OR (d."QTYALLOCATED" is not NULL and s."QTYALLOCATED"  is NULL)) OR
((s."QTYINTRANSIT" != d."QTYINTRANSIT") OR (s."QTYINTRANSIT"  is not NULL and d."QTYINTRANSIT"  is NULL) OR (d."QTYINTRANSIT" is not NULL and s."QTYINTRANSIT"  is NULL)) OR
((s."COST" != d."COST") OR (s."COST"  is not NULL and d."COST"  is NULL) OR (d."COST" is not NULL and s."COST"  is NULL))
);
END;
