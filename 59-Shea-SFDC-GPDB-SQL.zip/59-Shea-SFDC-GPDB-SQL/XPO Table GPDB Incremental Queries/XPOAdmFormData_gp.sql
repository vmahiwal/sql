
BEGIN;
truncate sysprocompanyb.xpoadmformdata_stg0_gp;
insert into sysprocompanyb.xpoadmformdata_stg0_gp
 select * from sysprocompanyb.xpoadmformdata_stg0;
END;