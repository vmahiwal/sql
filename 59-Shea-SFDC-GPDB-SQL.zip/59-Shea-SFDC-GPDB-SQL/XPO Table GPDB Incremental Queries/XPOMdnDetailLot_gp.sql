BEGIN;
truncate sysprocompanyb.xpomdndetaillot_stg0_gp;
insert into sysprocompanyb.xpomdndetaillot_stg0_gp
 select * from sysprocompanyb.xpomdndetaillot_stg0;
END;