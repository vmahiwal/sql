BEGIN;

insert into sysprocompanyb.xpomdnmaster_stg0_gp
select s.*
from sysprocompanyb.xpomdnmaster_stg0 s LEFT JOIN sysprocompanyb.xpomdnmaster_stg0_gp d
ON s."SALESORDER"=d."SALESORDER"
AND s."OBORDER"=d."OBORDER" AND s."XPOWHORDER"=d."XPOWHORDER" where d."SALESORDER" is null AND d."OBORDER" is null AND d."XPOWHORDER" is null;



UPDATE sysprocompanyb.xpomdnmaster_stg0_gp d
SET
"time"=s."time",
"TYPE"=s."TYPE",
"CUSTOMERNAME" = s."CUSTOMERNAME",
"PLANNEDDELIVERYDATE" = s."PLANNEDDELIVERYDATE",
"ACTUALDELIVERYDATE" = s."ACTUALDELIVERYDATE"
FROM sysprocompanyb.xpomdnmaster_stg0 s
Where (s."SALESORDER"=d."SALESORDER" AND s."OBORDER"=d."OBORDER" AND s."XPOWHORDER" = d."XPOWHORDER") and
(
((s."TYPE" != d."TYPE") OR (s."TYPE"  is not NULL and d."TYPE"  is NULL) OR (d."TYPE" is not NULL and s."TYPE"  is NULL)) OR
((s."CUSTOMERNAME" != d."CUSTOMERNAME")  OR (s."CUSTOMERNAME"  is not NULL and d."CUSTOMERNAME"  is NULL) OR (d."CUSTOMERNAME" is not NULL and s."CUSTOMERNAME"  is NULL)) OR
((s."PLANNEDDELIVERYDATE" != d."PLANNEDDELIVERYDATE") OR (s."PLANNEDDELIVERYDATE"  is not NULL and d."PLANNEDDELIVERYDATE"  is NULL) OR (d."PLANNEDDELIVERYDATE" is not NULL and s."PLANNEDDELIVERYDATE"  is NULL)) OR 
((s."ACTUALDELIVERYDATE" != d."ACTUALDELIVERYDATE") OR (s."ACTUALDELIVERYDATE"  is not NULL and d."ACTUALDELIVERYDATE"  is NULL) OR (d."ACTUALDELIVERYDATE" is not NULL and s."ACTUALDELIVERYDATE"  is NULL)) 
);

END;
