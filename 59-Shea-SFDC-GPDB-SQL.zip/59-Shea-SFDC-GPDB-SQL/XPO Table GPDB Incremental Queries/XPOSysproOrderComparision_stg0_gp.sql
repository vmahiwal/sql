----XPOSysproOrderComparision_stg0_gp.sql-----------------------

select * , case when ((s.SalesOrder = x.XSalesOrder and s."SalesOrderLine" = x."SALESORDERLINE") and (s.MOrderQty = x.XMOrderQty) and (s.MBackOrderQty = x.XMBackOrderQty)) then 'SalesOrder and Qty Same' 
 when ((s.SalesOrder is Null and x.XSalesOrder Is Not Null)or  (s.SalesOrder Is Not Null and x.XSalesOrder Is Null)) 
then 'Salesorder Null'
ELSE 'Not Same' 
END
,case when s.SalesOrder is Null then x.XSalesOrder Else s.SalesOrder End as UnionSalesOrder
,case when s."MStockCode" is Null then x."MSTOCKCODE" Else s."MStockCode" End as UnionStockCode
from
((select 
'Syspro Data' as SourceName , "CorpAcctName",
LTRIM(sysprocompanyb.sordetailmain_stg0_gp."SalesOrder",'0') SalesOrder, 
sysprocompanyb.sordetailmain_stg0_gp."SalesOrderLine",
sysprocompanyb.sormastermain_stg0_gp."EntrySystemDate",
sysprocompanyb.sormastermain_stg0_gp."ReqShipDate", 
sysprocompanyb.sormastermain_stg0_gp."OrderStatus", 
sysprocompanyb.sordetailmain_stg0_gp."MStockCode", 
sysprocompanyb.sordetailmain_stg0_gp."MStockDes", 
sysprocompanyb.sordetailmain_stg0_gp."MWarehouse",
sysprocompanyb.sordetailmain_stg0_gp."MUnitCost",
sysprocompanyb.sordetailmain_stg0_gp."MPrice",
sysprocompanyb.sordetailmain_stg0_gp."MProductClass",
sysprocompanyb.sormastermain_stg0_gp."CancelledFlag",
sysprocompanyb.sormastermain_stg0_gp."Branch",
"DocumentType",
"InterWhSale",
Round(Sum(sysprocompanyb.sordetailmain_stg0_gp."MOrderQty")) MOrderQty, 
Round(SUM(sysprocompanyb.sordetailmain_stg0_gp."MShipQty")) MShipQty,
Round(Sum(sysprocompanyb.sordetailmain_stg0_gp."MBackOrderQty")) MBackOrderQty
from sysprocompanyb.sordetailmain_stg0_gp inner join sysprocompanyb.sormastermain_stg0_gp 
    	on sysprocompanyb.sordetailmain_stg0_gp."SalesOrder" = sysprocompanyb.sormastermain_stg0_gp."SalesOrder"
		left join sysprocompanyb.arcustomermain_stg0_gp on sysprocompanyb.arcustomermain_stg0_gp."Customer" = sysprocompanyb.sormastermain_stg0_gp."Customer"
where sysprocompanyb.sordetailmain_stg0_gp."LineType" = '1'
--and  sysprocompanyb.sordetailmain_stg0_gp."SalesOrder" like '%348397%'
and sysprocompanyb.sormastermain_stg0_gp."EntrySystemDate" >= '05/01/2017'
group by 
sysprocompanyb.sordetailmain_stg0_gp."SalesOrder", 
sysprocompanyb.sordetailmain_stg0_gp."SalesOrderLine",
sysprocompanyb.sormastermain_stg0_gp."EntrySystemDate",
sysprocompanyb.sormastermain_stg0_gp."ReqShipDate", 
sysprocompanyb.sormastermain_stg0_gp."OrderStatus", 
sysprocompanyb.sordetailmain_stg0_gp."MStockCode", 
sysprocompanyb.sordetailmain_stg0_gp."MStockDes", 
sysprocompanyb.sordetailmain_stg0_gp."MWarehouse",
sysprocompanyb.sordetailmain_stg0_gp."MUnitCost",
sysprocompanyb.sordetailmain_stg0_gp."MPrice",
sysprocompanyb.sordetailmain_stg0_gp."MProductClass",
sysprocompanyb.sormastermain_stg0_gp."CancelledFlag",
sysprocompanyb.arcustomermain_stg0_gp."CorpAcctName",
sysprocompanyb.sormastermain_stg0_gp."Branch",
"DocumentType",
"InterWhSale")s 


full join (
SELECT t.SourceName XSourceName, t.SalesOrder XSalesOrder, t."SALESORDERLINE", t."OBORDER", t."CLIENTORDERDATE",t."REQSHIPDATE", t."XPOENTRYSYSTEMDATE",t."ORDERSTATUS", t."MSTOCKCODE",
t."MSTOCKDES",t."MWAREHOUSE","CUSTOMER" ,
t."MPRODUCTCLASS",t."CANCELLEDFLAG" 
,t.MOrderQty as XMOrderQty, t.MShipQty XMShipQty, t.MBackOrderQty XMBackOrderQty
from ( SELECT
		'XPO Data' as SourceName , "CUSTOMER" ,
		LTRIM(sysprocompanyb.xposordetail_stg0_gp."SALESORDER",'0') SalesOrder
       , "SALESORDERLINE"
	 
	  --,ROW_NUMBER() OVER (PARTITION BY sysprocompanyb.xposordetail_stg0_gp."SALESORDER","SALESORDERLINE"  
	 -- Order by sysprocompanyb.xposordetail_stg0_gp."OBORDER"

	 -- ) as rn

	 
       , sysprocompanyb.xposormaster_stg0_gp."OBORDER"
	   ,sysprocompanyb.xposormaster_stg0_gp."CLIENTORDERDATE"
	   ,sysprocompanyb.xposormaster_stg0_gp."REQSHIPDATE"
       , sysprocompanyb.xposordetail_stg0_gp."XPOENTRYSYSTEMDATE"
       , sysprocompanyb.xposordetail_stg0_gp."ORDERSTATUS"
       , "MSTOCKCODE"
       , "MSTOCKDES"
       , "MWAREHOUSE"
	   , "MUNITCOST"
       , "MPRICE"
       , "MPRODUCTCLASS"
	   ,sysprocompanyb.xposormaster_stg0_gp."CANCELLEDFLAG"
	   ,'N/A' as Branch
	   ,'N/A' as DocumentType
	   ,'N/A' as InterWhSale
       , ROUND(Sum("MORDERQTY")) as MOrderQty
       , ROUND(Sum("MSHIPQTY")) as MShipQty
       , ROUND(Sum("MBACKORDERQTY")) as MBackOrderQty

 FROM sysprocompanyb.xposordetail_stg0_gp
 INNER JOIN sysprocompanyb.xposormaster_stg0_gp ON sysprocompanyb.xposormaster_stg0_gp."SALESORDER" = sysprocompanyb.xposordetail_stg0_gp."SALESORDER"
                AND sysprocompanyb.xposormaster_stg0_gp."OBORDER" = sysprocompanyb.xposordetail_stg0_gp."OBORDER" 

 group by
 	sysprocompanyb.xposordetail_stg0_gp."SALESORDER"
       , "SALESORDERLINE"
       , sysprocompanyb.xposormaster_stg0_gp."OBORDER"
	   ,sysprocompanyb.xposormaster_stg0_gp."CLIENTORDERDATE"
	   ,sysprocompanyb.xposormaster_stg0_gp."REQSHIPDATE"
       , sysprocompanyb.xposordetail_stg0_gp."XPOENTRYSYSTEMDATE"
       , sysprocompanyb.xposordetail_stg0_gp."ORDERSTATUS"
       , "MSTOCKCODE"
       , "MSTOCKDES"
       , "MWAREHOUSE"
	   , "MUNITCOST"
       , "MPRICE"
       , "MPRODUCTCLASS"
	   , "CUSTOMER"
	   ,sysprocompanyb.xposormaster_stg0_gp."CANCELLEDFLAG"
	   )t
	   where 
	   t."ORDERSTATUS" <> 'CANCELED'
	   ) x 
	   on s.SalesOrder = x.XSalesOrder and s."SalesOrderLine" = x."SALESORDERLINE"
	   )
