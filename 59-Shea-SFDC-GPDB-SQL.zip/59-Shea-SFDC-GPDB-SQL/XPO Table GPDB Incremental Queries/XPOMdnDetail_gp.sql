BEGIN;

insert into sysprocompanyb.xpomdndetail_stg0_gp
select s.*
from sysprocompanyb.xpomdndetail_stg0 s LEFT JOIN sysprocompanyb.xpomdndetail_stg0_gp d
ON s."SALESORDER"=d."SALESORDER" AND s."SALESORDERLINE"= d."SALESORDERLINE"
AND s."OBORDER"=d."OBORDER" AND s."XPOWHORDER" = d."XPOWHORDER" 
where d."SALESORDER" is null AND d."SALESORDERLINE" is null AND d."OBORDER" is null AND d."XPOWHORDER" IS NULL;



UPDATE sysprocompanyb.xpomdndetail_stg0_gp d
SET
"time"=s."time",
"ORDERSTATUS" = s."ORDERSTATUS",
"MSTOCKCODE" = s."MSTOCKCODE",
"MSTOCKDES" = s."MSTOCKDES",
"MWAREHOUSE" = s."MWAREHOUSE",
"MQTYTODISPATCH" = s."MQTYTODISPATCH",
"MPRICECODE" = s."MPRICECODE"
FROM sysprocompanyb.xpomdndetail_stg0 s
Where (s."SALESORDER"=d."SALESORDER" AND s."SALESORDERLINE" = d."SALESORDERLINE" 
AND s."OBORDER"=d."OBORDER" AND  s."XPOWHORDER" = d."XPOWHORDER") AND
(
((s."ORDERSTATUS" != d."ORDERSTATUS") OR (s."ORDERSTATUS"  is not NULL and d."ORDERSTATUS"  is NULL) OR (d."ORDERSTATUS" is not NULL and s."ORDERSTATUS"  is NULL))OR
((s."MSTOCKCODE" != d."MSTOCKCODE") OR (s."MSTOCKCODE"  is not NULL and d."MSTOCKCODE"  is NULL) OR (d."MSTOCKCODE" is not NULL and s."MSTOCKCODE"  is NULL)) OR
((s."MSTOCKDES" != d."MSTOCKDES") OR (s."MSTOCKDES"  is not NULL and d."MSTOCKDES"  is NULL) OR (d."MSTOCKDES" is not NULL and s."MSTOCKDES"  is NULL)) OR
((s."MWAREHOUSE" != d."MWAREHOUSE") OR (s."MWAREHOUSE"  is not NULL and d."MWAREHOUSE"  is NULL) OR (d."MWAREHOUSE" is not NULL and s."MWAREHOUSE"  is NULL)) OR
((s."MQTYTODISPATCH" != d."MQTYTODISPATCH") OR (s."MQTYTODISPATCH"  is not NULL and d."MQTYTODISPATCH"  is NULL) OR (d."MQTYTODISPATCH" is not NULL and s."MQTYTODISPATCH"  is NULL)) OR
((s."MPRICECODE" != d."MPRICECODE")OR(s."MPRICECODE"  is not NULL and d."MPRICECODE"  is NULL) OR (d."MPRICECODE" is not NULL and s."MPRICECODE"  is NULL)) 
);

END;

