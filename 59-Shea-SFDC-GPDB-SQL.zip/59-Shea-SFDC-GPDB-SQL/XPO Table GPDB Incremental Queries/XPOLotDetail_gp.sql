BEGIN;
truncate sysprocompanyb.xpolotdetail_stg0_gp;
insert into sysprocompanyb.xpolotdetail_stg0_gp
 select * from sysprocompanyb.xpolotdetail_stg0;
END;