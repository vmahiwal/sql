--BomOperations_sg0_gp


Begin;
INSERT INTO sysprocompanyb.BomOperationsmain_stg0_gp
SELECT s.* FROM sysprocompanyb.BomOperationsmain_stg0 s LEFT JOIN sysprocompanyb.BomOperationsmain_stg0_gp d 
ON 
(
s."StockCode" = d."StockCode" 
and s."Version" = d."Version"
and s."Release" = d."Release" 
and s."Route" = d."Route"
and s."Operation" = d."Operation" 
)
WHERE ( d."StockCode" is NULL 
and d."Version" is NULL
and d."Release" is NULL
and d."Route" is NULL
and d."Operation" is NULL
);

---
delete from sysprocompanyb.BomOperationsmain_stg0_gp
where (
sysprocompanyb.BomOperationsmain_stg0_gp."StockCode",
sysprocompanyb.BomOperationsmain_stg0_gp."Version",
sysprocompanyb.BomOperationsmain_stg0_gp."Release",
sysprocompanyb.BomOperationsmain_stg0_gp."Route",
sysprocompanyb.BomOperationsmain_stg0_gp."Operation" )
in
(
select d."StockCode",  
d."Version", d."Release", 
d."Route", d."Operation" 
from sysprocompanyb.BomOperationsmain_stg0_gp d
left join sysprocompanyb.BomOperationsmain_stg0 s
on
s."StockCode" = d."StockCode" and s."Version" = d."Version"
and s."Release" = d."Release" and s."Route" = d."Route"
and s."Operation" = d."Operation" 
WHERE 
s."StockCode" is NULL  and s."Version" is NULL
and s."Release" is NULL and s."Route" is NULL
and s."Operation" is NULL
);

UPDATE sysprocompanyb.BomOperationsmain_stg0_gp d
SET
"time" = s."time",
"WorkCentre" = s."WorkCentre",
"WcRateInd" = s."WcRateInd",
"WhatIfWcInd" = s."WhatIfWcInd",
"SubcontractFlag" = s."SubcontractFlag",
"ISetUpTime" = s."ISetUpTime",
"IRunTime" = s."IRunTime",
"IStartupTime" = s."IStartupTime",
"ITeardownTime" = s."ITeardownTime",
"IWaitTime" = s."IWaitTime",
"IStartupQty" = s."IStartupQty",
"IMachine" = s."IMachine",
"IUnitCapacity" = s."IUnitCapacity",
"IMaxWorkOpertrs" = s."IMaxWorkOpertrs",
"IMaxProdUnits" = s."IMaxProdUnits",
"ITimeTaken" = s."ITimeTaken",
"IQuantity" = s."IQuantity",
"IRunTimeEnt" = s."IRunTimeEnt",
"ITimeTakenEnt" = s."ITimeTakenEnt",
"IStartupQtyEnt" = s."IStartupQtyEnt",
"IQuantityEnt" = s."IQuantityEnt",
"SubSupplier" = s."SubSupplier",
"SubPoStockCode" = s."SubPoStockCode",
"SubQtyPer" = s."SubQtyPer",
"SubOrderUom" = s."SubOrderUom",
"SubOpUnitValue" = s."SubOpUnitValue",
"SubWhatIfValue" = s."SubWhatIfValue",
"SubPlanner" = s."SubPlanner",
"SubBuyer" = s."SubBuyer",
"SubLeadTime" = s."SubLeadTime",
"SubDockToStock" = s."SubDockToStock",
"SubOffsiteDays" = s."SubOffsiteDays",
"Milestone" = s."Milestone",
"ElapsedTime" = s."ElapsedTime",
"MovementTime" = s."MovementTime",
"NarrationCode" = s."NarrationCode",
"AutoNarrCode" = s."AutoNarrCode",
"NumOfPieces" = s."NumOfPieces",
"InspectionFlag" = s."InspectionFlag",
"OperYieldPct" = s."OperYieldPct",
"OperYieldQty" = s."OperYieldQty",
"MinorSetup" = s."MinorSetup",
"MinorSetupCode" = s."MinorSetupCode",
"ToolSet" = s."ToolSet",
"ToolSetQty" = s."ToolSetQty",
"ToolConsumption" = s."ToolConsumption",
"TimeCalcFlag" = s."TimeCalcFlag",
"TransferQtyOrPct" = s."TransferQtyOrPct",
"TransferQtyPct" = s."TransferQtyPct",
"CoProductCostVal" = s."CoProductCostVal",
"ResourceMask" = s."ResourceMask",
"MaxOpDelay" = s."MaxOpDelay",
"OperYieldQtyEnt" = s."OperYieldQtyEnt",
"TransferQtyPctEnt" = s."TransferQtyPctEnt",
"MaxOpSpan" = s."MaxOpSpan",
"OpSlack" = s."OpSlack",
"AllowOpSplit" = s."AllowOpSplit",
"ProductCode" = s."ProductCode",
"LibraryCode" = s."LibraryCode",
"FirstSeq" = s."FirstSeq",
"SecondSeq" = s."SecondSeq",
"TimeStamp" = s."TimeStamp"

FROM sysprocompanyb.BomOperationsmain_stg0 s 
WHERE ((s."StockCode" = d."StockCode") AND
(s."Version" = d."Version") AND
(s."Release" = d."Release") AND
(s."Route" = d."Route") AND
(s."Operation" = d."Operation"))
and 
(
((s."WorkCentre" != d."WorkCentre")  OR (s."WorkCentre"  is not NULL and d."WorkCentre"  is NULL) OR (d."WorkCentre"  is not NULL and s."WorkCentre"  is NULL)) OR
((s."WcRateInd" != d."WcRateInd")  OR (s."WcRateInd"  is not NULL and d."WcRateInd"  is NULL) OR (d."WcRateInd"  is not NULL and s."WcRateInd"  is NULL)) OR
((s."WhatIfWcInd" != d."WhatIfWcInd")  OR (s."WhatIfWcInd"  is not NULL and d."WhatIfWcInd"  is NULL) OR (d."WhatIfWcInd"  is not NULL and s."WhatIfWcInd"  is NULL)) OR
((s."SubcontractFlag" != d."SubcontractFlag")  OR (s."SubcontractFlag"  is not NULL and d."SubcontractFlag"  is NULL) OR (d."SubcontractFlag"  is not NULL and s."SubcontractFlag"  is NULL)) OR
((s."ISetUpTime" != d."ISetUpTime")  OR (s."ISetUpTime"  is not NULL and d."ISetUpTime"  is NULL) OR (d."ISetUpTime"  is not NULL and s."ISetUpTime"  is NULL)) OR
((s."IRunTime" != d."IRunTime")  OR (s."IRunTime"  is not NULL and d."IRunTime"  is NULL) OR (d."IRunTime"  is not NULL and s."IRunTime"  is NULL)) OR
((s."IStartupTime" != d."IStartupTime")  OR (s."IStartupTime"  is not NULL and d."IStartupTime"  is NULL) OR (d."IStartupTime"  is not NULL and s."IStartupTime"  is NULL)) OR
((s."ITeardownTime" != d."ITeardownTime")  OR (s."ITeardownTime"  is not NULL and d."ITeardownTime"  is NULL) OR (d."ITeardownTime"  is not NULL and s."ITeardownTime"  is NULL)) OR
((s."IWaitTime" != d."IWaitTime")  OR (s."IWaitTime"  is not NULL and d."IWaitTime"  is NULL) OR (d."IWaitTime"  is not NULL and s."IWaitTime"  is NULL)) OR
((s."IStartupQty" != d."IStartupQty")  OR (s."IStartupQty"  is not NULL and d."IStartupQty"  is NULL) OR (d."IStartupQty"  is not NULL and s."IStartupQty"  is NULL)) OR
((s."IMachine" != d."IMachine")  OR (s."IMachine"  is not NULL and d."IMachine"  is NULL) OR (d."IMachine"  is not NULL and s."IMachine"  is NULL)) OR
((s."IUnitCapacity" != d."IUnitCapacity")  OR (s."IUnitCapacity"  is not NULL and d."IUnitCapacity"  is NULL) OR (d."IUnitCapacity"  is not NULL and s."IUnitCapacity"  is NULL)) OR
((s."IMaxWorkOpertrs" != d."IMaxWorkOpertrs")  OR (s."IMaxWorkOpertrs"  is not NULL and d."IMaxWorkOpertrs"  is NULL) OR (d."IMaxWorkOpertrs"  is not NULL and s."IMaxWorkOpertrs"  is NULL)) OR
((s."IMaxProdUnits" != d."IMaxProdUnits")  OR (s."IMaxProdUnits"  is not NULL and d."IMaxProdUnits"  is NULL) OR (d."IMaxProdUnits"  is not NULL and s."IMaxProdUnits"  is NULL)) OR
((s."ITimeTaken" != d."ITimeTaken")  OR (s."ITimeTaken"  is not NULL and d."ITimeTaken"  is NULL) OR (d."ITimeTaken"  is not NULL and s."ITimeTaken"  is NULL)) OR
((s."IQuantity" != d."IQuantity")  OR (s."IQuantity"  is not NULL and d."IQuantity"  is NULL) OR (d."IQuantity"  is not NULL and s."IQuantity"  is NULL)) OR
((s."IRunTimeEnt" != d."IRunTimeEnt")  OR (s."IRunTimeEnt"  is not NULL and d."IRunTimeEnt"  is NULL) OR (d."IRunTimeEnt"  is not NULL and s."IRunTimeEnt"  is NULL)) OR
((s."ITimeTakenEnt" != d."ITimeTakenEnt")  OR (s."ITimeTakenEnt"  is not NULL and d."ITimeTakenEnt"  is NULL) OR (d."ITimeTakenEnt"  is not NULL and s."ITimeTakenEnt"  is NULL)) OR
((s."IStartupQtyEnt" != d."IStartupQtyEnt")  OR (s."IStartupQtyEnt"  is not NULL and d."IStartupQtyEnt"  is NULL) OR (d."IStartupQtyEnt"  is not NULL and s."IStartupQtyEnt"  is NULL)) OR
((s."IQuantityEnt" != d."IQuantityEnt")  OR (s."IQuantityEnt"  is not NULL and d."IQuantityEnt"  is NULL) OR (d."IQuantityEnt"  is not NULL and s."IQuantityEnt"  is NULL)) OR
((s."SubSupplier" != d."SubSupplier")  OR (s."SubSupplier"  is not NULL and d."SubSupplier"  is NULL) OR (d."SubSupplier"  is not NULL and s."SubSupplier"  is NULL)) OR
((s."SubPoStockCode" != d."SubPoStockCode")  OR (s."SubPoStockCode"  is not NULL and d."SubPoStockCode"  is NULL) OR (d."SubPoStockCode"  is not NULL and s."SubPoStockCode"  is NULL)) OR
((s."SubQtyPer" != d."SubQtyPer")  OR (s."SubQtyPer"  is not NULL and d."SubQtyPer"  is NULL) OR (d."SubQtyPer"  is not NULL and s."SubQtyPer"  is NULL)) OR
((s."SubOrderUom" != d."SubOrderUom")  OR (s."SubOrderUom"  is not NULL and d."SubOrderUom"  is NULL) OR (d."SubOrderUom"  is not NULL and s."SubOrderUom"  is NULL)) OR
((s."SubOpUnitValue" != d."SubOpUnitValue")  OR (s."SubOpUnitValue"  is not NULL and d."SubOpUnitValue"  is NULL) OR (d."SubOpUnitValue"  is not NULL and s."SubOpUnitValue"  is NULL)) OR
((s."SubWhatIfValue" != d."SubWhatIfValue")  OR (s."SubWhatIfValue"  is not NULL and d."SubWhatIfValue"  is NULL) OR (d."SubWhatIfValue"  is not NULL and s."SubWhatIfValue"  is NULL)) OR
((s."SubPlanner" != d."SubPlanner")  OR (s."SubPlanner"  is not NULL and d."SubPlanner"  is NULL) OR (d."SubPlanner"  is not NULL and s."SubPlanner"  is NULL)) OR
((s."SubBuyer" != d."SubBuyer")  OR (s."SubBuyer"  is not NULL and d."SubBuyer"  is NULL) OR (d."SubBuyer"  is not NULL and s."SubBuyer"  is NULL)) OR
((s."SubLeadTime" != d."SubLeadTime")  OR (s."SubLeadTime"  is not NULL and d."SubLeadTime"  is NULL) OR (d."SubLeadTime"  is not NULL and s."SubLeadTime"  is NULL)) OR
((s."SubDockToStock" != d."SubDockToStock")  OR (s."SubDockToStock"  is not NULL and d."SubDockToStock"  is NULL) OR (d."SubDockToStock"  is not NULL and s."SubDockToStock"  is NULL)) OR
((s."SubOffsiteDays" != d."SubOffsiteDays")  OR (s."SubOffsiteDays"  is not NULL and d."SubOffsiteDays"  is NULL) OR (d."SubOffsiteDays"  is not NULL and s."SubOffsiteDays"  is NULL)) OR
((s."Milestone" != d."Milestone")  OR (s."Milestone"  is not NULL and d."Milestone"  is NULL) OR (d."Milestone"  is not NULL and s."Milestone"  is NULL)) OR
((s."ElapsedTime" != d."ElapsedTime")  OR (s."ElapsedTime"  is not NULL and d."ElapsedTime"  is NULL) OR (d."ElapsedTime"  is not NULL and s."ElapsedTime"  is NULL)) OR
((s."MovementTime" != d."MovementTime")  OR (s."MovementTime"  is not NULL and d."MovementTime"  is NULL) OR (d."MovementTime"  is not NULL and s."MovementTime"  is NULL)) OR
((s."NarrationCode" != d."NarrationCode")  OR (s."NarrationCode"  is not NULL and d."NarrationCode"  is NULL) OR (d."NarrationCode"  is not NULL and s."NarrationCode"  is NULL)) OR
((s."AutoNarrCode" != d."AutoNarrCode")  OR (s."AutoNarrCode"  is not NULL and d."AutoNarrCode"  is NULL) OR (d."AutoNarrCode"  is not NULL and s."AutoNarrCode"  is NULL)) OR
((s."NumOfPieces" != d."NumOfPieces")  OR (s."NumOfPieces"  is not NULL and d."NumOfPieces"  is NULL) OR (d."NumOfPieces"  is not NULL and s."NumOfPieces"  is NULL)) OR
((s."InspectionFlag" != d."InspectionFlag")  OR (s."InspectionFlag"  is not NULL and d."InspectionFlag"  is NULL) OR (d."InspectionFlag"  is not NULL and s."InspectionFlag"  is NULL)) OR
((s."OperYieldPct" != d."OperYieldPct")  OR (s."OperYieldPct"  is not NULL and d."OperYieldPct"  is NULL) OR (d."OperYieldPct"  is not NULL and s."OperYieldPct"  is NULL)) OR
((s."OperYieldQty" != d."OperYieldQty")  OR (s."OperYieldQty"  is not NULL and d."OperYieldQty"  is NULL) OR (d."OperYieldQty"  is not NULL and s."OperYieldQty"  is NULL)) OR
((s."MinorSetup" != d."MinorSetup")  OR (s."MinorSetup"  is not NULL and d."MinorSetup"  is NULL) OR (d."MinorSetup"  is not NULL and s."MinorSetup"  is NULL)) OR
((s."MinorSetupCode" != d."MinorSetupCode")  OR (s."MinorSetupCode"  is not NULL and d."MinorSetupCode"  is NULL) OR (d."MinorSetupCode"  is not NULL and s."MinorSetupCode"  is NULL)) OR
((s."ToolSet" != d."ToolSet")  OR (s."ToolSet"  is not NULL and d."ToolSet"  is NULL) OR (d."ToolSet"  is not NULL and s."ToolSet"  is NULL)) OR
((s."ToolSetQty" != d."ToolSetQty")  OR (s."ToolSetQty"  is not NULL and d."ToolSetQty"  is NULL) OR (d."ToolSetQty"  is not NULL and s."ToolSetQty"  is NULL)) OR
((s."ToolConsumption" != d."ToolConsumption")  OR (s."ToolConsumption"  is not NULL and d."ToolConsumption"  is NULL) OR (d."ToolConsumption"  is not NULL and s."ToolConsumption"  is NULL)) OR
((s."TimeCalcFlag" != d."TimeCalcFlag")  OR (s."TimeCalcFlag"  is not NULL and d."TimeCalcFlag"  is NULL) OR (d."TimeCalcFlag"  is not NULL and s."TimeCalcFlag"  is NULL)) OR
((s."TransferQtyOrPct" != d."TransferQtyOrPct")  OR (s."TransferQtyOrPct"  is not NULL and d."TransferQtyOrPct"  is NULL) OR (d."TransferQtyOrPct"  is not NULL and s."TransferQtyOrPct"  is NULL)) OR
((s."TransferQtyPct" != d."TransferQtyPct")  OR (s."TransferQtyPct"  is not NULL and d."TransferQtyPct"  is NULL) OR (d."TransferQtyPct"  is not NULL and s."TransferQtyPct"  is NULL)) OR
((s."CoProductCostVal" != d."CoProductCostVal")  OR (s."CoProductCostVal"  is not NULL and d."CoProductCostVal"  is NULL) OR (d."CoProductCostVal"  is not NULL and s."CoProductCostVal"  is NULL)) OR
((s."ResourceMask" != d."ResourceMask")  OR (s."ResourceMask"  is not NULL and d."ResourceMask"  is NULL) OR (d."ResourceMask"  is not NULL and s."ResourceMask"  is NULL)) OR
((s."MaxOpDelay" != d."MaxOpDelay")  OR (s."MaxOpDelay"  is not NULL and d."MaxOpDelay"  is NULL) OR (d."MaxOpDelay"  is not NULL and s."MaxOpDelay"  is NULL)) OR
((s."OperYieldQtyEnt" != d."OperYieldQtyEnt")  OR (s."OperYieldQtyEnt"  is not NULL and d."OperYieldQtyEnt"  is NULL) OR (d."OperYieldQtyEnt"  is not NULL and s."OperYieldQtyEnt"  is NULL)) OR
((s."TransferQtyPctEnt" != d."TransferQtyPctEnt")  OR (s."TransferQtyPctEnt"  is not NULL and d."TransferQtyPctEnt"  is NULL) OR (d."TransferQtyPctEnt"  is not NULL and s."TransferQtyPctEnt"  is NULL)) OR
((s."MaxOpSpan" != d."MaxOpSpan")  OR (s."MaxOpSpan"  is not NULL and d."MaxOpSpan"  is NULL) OR (d."MaxOpSpan"  is not NULL and s."MaxOpSpan"  is NULL)) OR
((s."OpSlack" != d."OpSlack")  OR (s."OpSlack"  is not NULL and d."OpSlack"  is NULL) OR (d."OpSlack"  is not NULL and s."OpSlack"  is NULL)) OR
((s."AllowOpSplit" != d."AllowOpSplit")  OR (s."AllowOpSplit"  is not NULL and d."AllowOpSplit"  is NULL) OR (d."AllowOpSplit"  is not NULL and s."AllowOpSplit"  is NULL)) OR
((s."ProductCode" != d."ProductCode")  OR (s."ProductCode"  is not NULL and d."ProductCode"  is NULL) OR (d."ProductCode"  is not NULL and s."ProductCode"  is NULL)) OR
((s."LibraryCode" != d."LibraryCode")  OR (s."LibraryCode"  is not NULL and d."LibraryCode"  is NULL) OR (d."LibraryCode"  is not NULL and s."LibraryCode"  is NULL)) OR
((s."FirstSeq" != d."FirstSeq")  OR (s."FirstSeq"  is not NULL and d."FirstSeq"  is NULL) OR (d."FirstSeq"  is not NULL and s."FirstSeq"  is NULL)) OR
((s."SecondSeq" != d."SecondSeq") OR (s."SecondSeq"  is not NULL and d."SecondSeq"  is NULL) OR (d."SecondSeq"  is not NULL and s."SecondSeq"  is NULL)) 
);


END;
