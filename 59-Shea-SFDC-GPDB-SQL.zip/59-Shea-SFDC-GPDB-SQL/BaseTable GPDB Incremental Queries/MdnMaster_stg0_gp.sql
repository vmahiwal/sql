--MdnMasterMain_stg0_gp


BEGIN;
INSERT INTO sysprocompanyb.mdnmastermain_stg0_gp  
SELECT s.* FROM 
sysprocompanyb.mdnmastermain_stg0 s LEFT JOIN 
sysprocompanyb.mdnmastermain_stg0_gp d ON 
s."DispatchNote"=d."DispatchNote" WHERE d."DispatchNote" IS NULL;

--delete
DELETE FROM sysprocompanyb.mdnmastermain_stg0_gp WHERE
(sysprocompanyb.mdnmastermain_stg0_gp."DispatchNote")
IN
(
SELECT d."DispatchNote"
FROM sysprocompanyb.mdnmastermain_stg0_gp d
LEFT JOIN sysprocompanyb.mdnmastermain_stg0 s
ON s."DispatchNote"=d."DispatchNote"
WHERE s."DispatchNote" IS NULL 
);

-----

UPDATE sysprocompanyb.mdnmastermain_stg0_gp d
SET
"time" = s."time",
"NextDetailLine" = s."NextDetailLine",
"SalesOrder" = s."SalesOrder",
"Customer" = s."Customer",
"CustomerName" = s."CustomerName",
"ShippingInstrs" = s."ShippingInstrs",
"ShippingInstrsCod" = s."ShippingInstrsCod",
"SpecialInstrs" = s."SpecialInstrs",
"DispatchComments1" = s."DispatchComments1",
"DispatchComments2" = s."DispatchComments2",
"DispatchComments3" = s."DispatchComments3",
"DispatchComments4" = s."DispatchComments4",
"UserField1" = s."UserField1",
"UserField2" = s."UserField2",
"Salesperson" = s."Salesperson",
"Branch" = s."Branch",
"Area" = s."Area",
"FixExchangeRate" = s."FixExchangeRate",
"ExchangeRate" = s."ExchangeRate",
"MulDiv" = s."MulDiv",
"Currency" = s."Currency",
"DiscPct1" = s."DiscPct1",
"DiscPct2" = s."DiscPct2",
"DiscPct3" = s."DiscPct3",
"OrderType" = s."OrderType",
"InvTermsOverride" = s."InvTermsOverride",
"ReprintFormat" = s."ReprintFormat",
"TaxExemptFlag" = s."TaxExemptFlag",
"TaxExemptOverride" = s."TaxExemptOverride",
"IbtFlag" = s."IbtFlag",
"DispatchName" = s."DispatchName",
"PlannedDeliverDate" = s."PlannedDeliverDate",
"ActualDeliveryDate" = s."ActualDeliveryDate",
"ShipAddressFlag" = s."ShipAddressFlag",
"CustomerPoNumber" = s."CustomerPoNumber",
"CompanyTaxNo" = s."CompanyTaxNo",
"Invoice" = s."Invoice",
"InvoiceCreatedDate" = s."InvoiceCreatedDate",
"ConsolidateInvFlag" = s."ConsolidateInvFlag",
"TaxExemptNumber" = s."TaxExemptNumber",
"DispatchNoteStatus" = s."DispatchNoteStatus",
"PrevStatus" = s."PrevStatus",
"ActiveFlag" = s."ActiveFlag",
"Reason" = s."Reason",
"StatusWhenHeld" = s."StatusWhenHeld",
"DateLastInvPrt" = s."DateLastInvPrt",
"Nationality" = s."Nationality",
"DeliveryTerms" = s."DeliveryTerms",
"TransactionNature" = s."TransactionNature",
"TransportMode" = s."TransportMode",
"ProcessFlag" = s."ProcessFlag",
"DispatchCustName" = s."DispatchCustName",
"DispatchAddress1" = s."DispatchAddress1",
"DispatchAddress2" = s."DispatchAddress2",
"DispatchAddress3" = s."DispatchAddress3",
"DispatchAddrLoc" = s."DispatchAddrLoc",
"DispatchAddress4" = s."DispatchAddress4",
"DispatchAddress5" = s."DispatchAddress5",
"DispatchPostalCode" = s."DispatchPostalCode",
"DispatchGpsLat" = s."DispatchGpsLat",
"DispatchGpsLong" = s."DispatchGpsLong",
"State" = s."State",
"CountyZip" = s."CountyZip",
"ExtendedTaxCode" = s."ExtendedTaxCode",
"MultiShipCode" = s."MultiShipCode",
"WebCreated" = s."WebCreated",
"Quote" = s."Quote",
"QuoteVersion" = s."QuoteVersion",
"GtrReference" = s."GtrReference",
"LastOperator" = s."LastOperator",
"Email" = s."Email",
"CreditAuthority" = s."CreditAuthority",
"TpmPickupFlag" = s."TpmPickupFlag",
"TpmEvaluatedFlag" = s."TpmEvaluatedFlag",
"StandardComment" = s."StandardComment",
"DetailStatus" = s."DetailStatus",
"SalesOrderSource" = s."SalesOrderSource",
"SalesOrderSrcDesc" = s."SalesOrderSrcDesc",
"LanguageCode" = s."LanguageCode",
"ShippingLocation" = s."ShippingLocation"
FROM sysprocompanyb.mdnmastermain_stg0 s
WHERE ( s."DispatchNote"=d."DispatchNote") and
(
((s."NextDetailLine" != d."NextDetailLine")  OR (s."NextDetailLine"  is not NULL and d."NextDetailLine"  is NULL) OR (d."NextDetailLine"  is not NULL and s."NextDetailLine"  is NULL)) OR
((s."SalesOrder" != d."SalesOrder")  OR (s."SalesOrder"  is not NULL and d."SalesOrder"  is NULL) OR (d."SalesOrder"  is not NULL and s."SalesOrder"  is NULL)) OR
((s."Customer" != d."Customer")  OR (s."Customer"  is not NULL and d."Customer"  is NULL) OR (d."Customer"  is not NULL and s."Customer"  is NULL)) OR
((s."CustomerName" != d."CustomerName")  OR (s."CustomerName"  is not NULL and d."CustomerName"  is NULL) OR (d."CustomerName"  is not NULL and s."CustomerName"  is NULL)) OR
((s."ShippingInstrs" != d."ShippingInstrs")  OR (s."ShippingInstrs"  is not NULL and d."ShippingInstrs"  is NULL) OR (d."ShippingInstrs"  is not NULL and s."ShippingInstrs"  is NULL)) OR
((s."ShippingInstrsCod" != d."ShippingInstrsCod")  OR (s."ShippingInstrsCod"  is not NULL and d."ShippingInstrsCod"  is NULL) OR (d."ShippingInstrsCod"  is not NULL and s."ShippingInstrsCod"  is NULL)) OR
((s."SpecialInstrs" != d."SpecialInstrs")  OR (s."SpecialInstrs"  is not NULL and d."SpecialInstrs"  is NULL) OR (d."SpecialInstrs"  is not NULL and s."SpecialInstrs"  is NULL)) OR
((s."DispatchComments1" != d."DispatchComments1")  OR (s."DispatchComments1"  is not NULL and d."DispatchComments1"  is NULL) OR (d."DispatchComments1"  is not NULL and s."DispatchComments1"  is NULL)) OR
((s."DispatchComments2" != d."DispatchComments2")  OR (s."DispatchComments2"  is not NULL and d."DispatchComments2"  is NULL) OR (d."DispatchComments2"  is not NULL and s."DispatchComments2"  is NULL)) OR
((s."DispatchComments3" != d."DispatchComments3")  OR (s."DispatchComments3"  is not NULL and d."DispatchComments3"  is NULL) OR (d."DispatchComments3"  is not NULL and s."DispatchComments3"  is NULL)) OR
((s."DispatchComments4" != d."DispatchComments4")  OR (s."DispatchComments4"  is not NULL and d."DispatchComments4"  is NULL) OR (d."DispatchComments4"  is not NULL and s."DispatchComments4"  is NULL)) OR
((s."UserField1" != d."UserField1")  OR (s."UserField1"  is not NULL and d."UserField1"  is NULL) OR (d."UserField1"  is not NULL and s."UserField1"  is NULL)) OR
((s."UserField2" != d."UserField2")  OR (s."UserField2"  is not NULL and d."UserField2"  is NULL) OR (d."UserField2"  is not NULL and s."UserField2"  is NULL)) OR
((s."Salesperson" != d."Salesperson")  OR (s."Salesperson"  is not NULL and d."Salesperson"  is NULL) OR (d."Salesperson"  is not NULL and s."Salesperson"  is NULL)) OR
((s."Branch" != d."Branch")  OR (s."Branch"  is not NULL and d."Branch"  is NULL) OR (d."Branch"  is not NULL and s."Branch"  is NULL)) OR
((s."Area" != d."Area")  OR (s."Area"  is not NULL and d."Area"  is NULL) OR (d."Area"  is not NULL and s."Area"  is NULL)) OR
((s."FixExchangeRate" != d."FixExchangeRate")  OR (s."FixExchangeRate"  is not NULL and d."FixExchangeRate"  is NULL) OR (d."FixExchangeRate"  is not NULL and s."FixExchangeRate"  is NULL)) OR
((s."ExchangeRate" != d."ExchangeRate")  OR (s."ExchangeRate"  is not NULL and d."ExchangeRate"  is NULL) OR (d."ExchangeRate"  is not NULL and s."ExchangeRate"  is NULL)) OR
((s."MulDiv" != d."MulDiv")  OR (s."MulDiv"  is not NULL and d."MulDiv"  is NULL) OR (d."MulDiv"  is not NULL and s."MulDiv"  is NULL)) OR
((s."Currency" != d."Currency")  OR (s."Currency"  is not NULL and d."Currency"  is NULL) OR (d."Currency"  is not NULL and s."Currency"  is NULL)) OR
((s."DiscPct1" != d."DiscPct1")  OR (s."DiscPct1"  is not NULL and d."DiscPct1"  is NULL) OR (d."DiscPct1"  is not NULL and s."DiscPct1"  is NULL)) OR
((s."DiscPct2" != d."DiscPct2")  OR (s."DiscPct2"  is not NULL and d."DiscPct2"  is NULL) OR (d."DiscPct2"  is not NULL and s."DiscPct2"  is NULL)) OR
((s."DiscPct3" != d."DiscPct3")  OR (s."DiscPct3"  is not NULL and d."DiscPct3"  is NULL) OR (d."DiscPct3"  is not NULL and s."DiscPct3"  is NULL)) OR
((s."OrderType" != d."OrderType")  OR (s."OrderType"  is not NULL and d."OrderType"  is NULL) OR (d."OrderType"  is not NULL and s."OrderType"  is NULL)) OR
((s."InvTermsOverride" != d."InvTermsOverride")  OR (s."InvTermsOverride"  is not NULL and d."InvTermsOverride"  is NULL) OR (d."InvTermsOverride"  is not NULL and s."InvTermsOverride"  is NULL)) OR
((s."ReprintFormat" != d."ReprintFormat")  OR (s."ReprintFormat"  is not NULL and d."ReprintFormat"  is NULL) OR (d."ReprintFormat"  is not NULL and s."ReprintFormat"  is NULL)) OR
((s."TaxExemptFlag" != d."TaxExemptFlag") OR (s."TaxExemptFlag"  is not NULL and d."TaxExemptFlag"  is NULL) OR (d."TaxExemptFlag"  is not NULL and s."TaxExemptFlag"  is NULL)) OR
((s."TaxExemptOverride" != d."TaxExemptOverride")  OR (s."TaxExemptOverride"  is not NULL and d."TaxExemptOverride"  is NULL) OR (d."TaxExemptOverride"  is not NULL and s."TaxExemptOverride"  is NULL)) OR
((s."IbtFlag" != d."IbtFlag")  OR (s."IbtFlag"  is not NULL and d."IbtFlag"  is NULL) OR (d."IbtFlag"  is not NULL and s."IbtFlag"  is NULL)) OR
((s."DispatchName" != d."DispatchName")  OR (s."DispatchName"  is not NULL and d."DispatchName"  is NULL) OR (d."DispatchName"  is not NULL and s."DispatchName"  is NULL)) OR
((s."PlannedDeliverDate" != d."PlannedDeliverDate")  OR (s."PlannedDeliverDate"  is not NULL and d."PlannedDeliverDate"  is NULL) OR (d."PlannedDeliverDate"  is not NULL and s."PlannedDeliverDate"  is NULL)) OR
((s."ActualDeliveryDate" != d."ActualDeliveryDate")  OR (s."ActualDeliveryDate"  is not NULL and d."ActualDeliveryDate"  is NULL) OR (d."ActualDeliveryDate"  is not NULL and s."ActualDeliveryDate"  is NULL)) OR
((s."ShipAddressFlag" != d."ShipAddressFlag")  OR (s."ShipAddressFlag"  is not NULL and d."ShipAddressFlag"  is NULL) OR (d."ShipAddressFlag"  is not NULL and s."ShipAddressFlag"  is NULL)) OR
((s."CustomerPoNumber" != d."CustomerPoNumber")  OR (s."CustomerPoNumber"  is not NULL and d."CustomerPoNumber"  is NULL) OR (d."CustomerPoNumber"  is not NULL and s."CustomerPoNumber"  is NULL)) OR
((s."CompanyTaxNo" != d."CompanyTaxNo")  OR (s."CompanyTaxNo"  is not NULL and d."CompanyTaxNo"  is NULL) OR (d."CompanyTaxNo"  is not NULL and s."CompanyTaxNo"  is NULL)) OR
((s."Invoice" != d."Invoice")  OR (s."Invoice"  is not NULL and d."Invoice"  is NULL) OR (d."Invoice"  is not NULL and s."Invoice"  is NULL)) OR
((s."InvoiceCreatedDate" != d."InvoiceCreatedDate")  OR (s."InvoiceCreatedDate"  is not NULL and d."InvoiceCreatedDate"  is NULL) OR (d."InvoiceCreatedDate"  is not NULL and s."InvoiceCreatedDate"  is NULL)) OR
((s."ConsolidateInvFlag" != d."ConsolidateInvFlag")  OR (s."ConsolidateInvFlag"  is not NULL and d."ConsolidateInvFlag"  is NULL) OR (d."ConsolidateInvFlag"  is not NULL and s."ConsolidateInvFlag"  is NULL)) OR
((s."TaxExemptNumber" != d."TaxExemptNumber")  OR (s."TaxExemptNumber"  is not NULL and d."TaxExemptNumber"  is NULL) OR (d."TaxExemptNumber"  is not NULL and s."TaxExemptNumber"  is NULL)) OR
((s."DispatchNoteStatus" != d."DispatchNoteStatus")  OR (s."DispatchNoteStatus"  is not NULL and d."DispatchNoteStatus"  is NULL) OR (d."DispatchNoteStatus"  is not NULL and s."DispatchNoteStatus"  is NULL)) OR
((s."PrevStatus" != d."PrevStatus")  OR (s."PrevStatus"  is not NULL and d."PrevStatus"  is NULL) OR (d."PrevStatus"  is not NULL and s."PrevStatus"  is NULL)) OR
((s."ActiveFlag" != d."ActiveFlag")  OR (s."ActiveFlag"  is not NULL and d."ActiveFlag"  is NULL) OR (d."ActiveFlag"  is not NULL and s."ActiveFlag"  is NULL)) OR
((s."Reason" != d."Reason")  OR (s."Reason"  is not NULL and d."Reason"  is NULL) OR (d."Reason"  is not NULL and s."Reason"  is NULL)) OR
((s."StatusWhenHeld" != d."StatusWhenHeld")  OR (s."StatusWhenHeld"  is not NULL and d."StatusWhenHeld"  is NULL) OR (d."StatusWhenHeld"  is not NULL and s."StatusWhenHeld"  is NULL)) OR
((s."DateLastInvPrt" != d."DateLastInvPrt")  OR (s."DateLastInvPrt"  is not NULL and d."DateLastInvPrt"  is NULL) OR (d."DateLastInvPrt"  is not NULL and s."DateLastInvPrt"  is NULL)) OR
((s."Nationality" != d."Nationality")  OR (s."Nationality"  is not NULL and d."Nationality"  is NULL) OR (d."Nationality"  is not NULL and s."Nationality"  is NULL)) OR
((s."DeliveryTerms" != d."DeliveryTerms")  OR (s."DeliveryTerms"  is not NULL and d."DeliveryTerms"  is NULL) OR (d."DeliveryTerms"  is not NULL and s."DeliveryTerms"  is NULL)) OR
((s."TransactionNature" != d."TransactionNature")  OR (s."TransactionNature"  is not NULL and d."TransactionNature"  is NULL) OR (d."TransactionNature"  is not NULL and s."TransactionNature"  is NULL)) OR
((s."TransportMode" != d."TransportMode")  OR (s."TransportMode"  is not NULL and d."TransportMode"  is NULL) OR (d."TransportMode"  is not NULL and s."TransportMode"  is NULL)) OR
((s."ProcessFlag" != d."ProcessFlag")  OR (s."ProcessFlag"  is not NULL and d."ProcessFlag"  is NULL) OR (d."ProcessFlag"  is not NULL and s."ProcessFlag"  is NULL)) OR
((s."DispatchCustName" != d."DispatchCustName")  OR (s."DispatchCustName"  is not NULL and d."DispatchCustName"  is NULL) OR (d."DispatchCustName"  is not NULL and s."DispatchCustName"  is NULL)) OR
((s."DispatchAddress1" != d."DispatchAddress1")  OR (s."DispatchAddress1"  is not NULL and d."DispatchAddress1"  is NULL) OR (d."DispatchAddress1"  is not NULL and s."DispatchAddress1"  is NULL)) OR
((s."DispatchAddress2" != d."DispatchAddress2")  OR (s."DispatchAddress2"  is not NULL and d."DispatchAddress2"  is NULL) OR (d."DispatchAddress2"  is not NULL and s."DispatchAddress2"  is NULL)) OR
((s."DispatchAddress3" != d."DispatchAddress3")  OR (s."DispatchAddress3"  is not NULL and d."DispatchAddress3"  is NULL) OR (d."DispatchAddress3"  is not NULL and s."DispatchAddress3"  is NULL)) OR
((s."DispatchAddrLoc" != d."DispatchAddrLoc")  OR (s."DispatchAddrLoc"  is not NULL and d."DispatchAddrLoc"  is NULL) OR (d."DispatchAddrLoc"  is not NULL and s."DispatchAddrLoc"  is NULL)) OR
((s."DispatchAddress4" != d."DispatchAddress4")  OR (s."DispatchAddress4"  is not NULL and d."DispatchAddress4"  is NULL) OR (d."DispatchAddress4"  is not NULL and s."DispatchAddress4"  is NULL)) OR
((s."DispatchAddress5" != d."DispatchAddress5")  OR (s."DispatchAddress5"  is not NULL and d."DispatchAddress5"  is NULL) OR (d."DispatchAddress5"  is not NULL and s."DispatchAddress5"  is NULL)) OR
((s."DispatchPostalCode" != d."DispatchPostalCode")  OR (s."DispatchPostalCode"  is not NULL and d."DispatchPostalCode"  is NULL) OR (d."DispatchPostalCode"  is not NULL and s."DispatchPostalCode"  is NULL)) OR
((s."DispatchGpsLat" != d."DispatchGpsLat") OR (s."DispatchGpsLat"  is not NULL and d."DispatchGpsLat"  is NULL) OR (d."DispatchGpsLat"  is not NULL and s."DispatchGpsLat"  is NULL)) OR
((s."DispatchGpsLong" != d."DispatchGpsLong")  OR (s."DispatchGpsLong"  is not NULL and d."DispatchGpsLong"  is NULL) OR (d."DispatchGpsLong"  is not NULL and s."DispatchGpsLong"  is NULL)) OR
((s."State" != d."State")  OR (s."State"  is not NULL and d."State"  is NULL) OR (d."State"  is not NULL and s."State"  is NULL)) OR
((s."CountyZip" != d."CountyZip")  OR (s."CountyZip"  is not NULL and d."CountyZip"  is NULL) OR (d."CountyZip"  is not NULL and s."CountyZip"  is NULL)) OR
((s."ExtendedTaxCode" != d."ExtendedTaxCode")  OR (s."ExtendedTaxCode"  is not NULL and d."ExtendedTaxCode"  is NULL) OR (d."ExtendedTaxCode"  is not NULL and s."ExtendedTaxCode"  is NULL)) OR
((s."MultiShipCode" != d."MultiShipCode")  OR (s."MultiShipCode"  is not NULL and d."MultiShipCode"  is NULL) OR (d."MultiShipCode"  is not NULL and s."MultiShipCode"  is NULL)) OR
((s."WebCreated" != d."WebCreated")  OR (s."WebCreated"  is not NULL and d."WebCreated"  is NULL) OR (d."WebCreated"  is not NULL and s."WebCreated"  is NULL)) OR
((s."Quote" != d."Quote")  OR (s."Quote"  is not NULL and d."Quote"  is NULL) OR (d."Quote"  is not NULL and s."Quote"  is NULL)) OR
((s."QuoteVersion" != d."QuoteVersion")  OR (s."QuoteVersion"  is not NULL and d."QuoteVersion"  is NULL) OR (d."QuoteVersion"  is not NULL and s."QuoteVersion"  is NULL)) OR
((s."GtrReference" != d."GtrReference")  OR (s."GtrReference"  is not NULL and d."GtrReference"  is NULL) OR (d."GtrReference"  is not NULL and s."GtrReference"  is NULL)) OR
((s."LastOperator" != d."LastOperator")  OR (s."LastOperator"  is not NULL and d."LastOperator"  is NULL) OR (d."LastOperator"  is not NULL and s."LastOperator"  is NULL)) OR
((s."Email" != d."Email")  OR (s."Email"  is not NULL and d."Email"  is NULL) OR (d."Email"  is not NULL and s."Email"  is NULL)) OR
((s."CreditAuthority" != d."CreditAuthority")  OR (s."CreditAuthority"  is not NULL and d."CreditAuthority"  is NULL) OR (d."CreditAuthority"  is not NULL and s."CreditAuthority"  is NULL)) OR
((s."TpmPickupFlag" != d."TpmPickupFlag")  OR (s."TpmPickupFlag"  is not NULL and d."TpmPickupFlag"  is NULL) OR (d."TpmPickupFlag"  is not NULL and s."TpmPickupFlag"  is NULL)) OR
((s."TpmEvaluatedFlag" != d."TpmEvaluatedFlag")  OR (s."TpmEvaluatedFlag"  is not NULL and d."TpmEvaluatedFlag"  is NULL) OR (d."TpmEvaluatedFlag"  is not NULL and s."TpmEvaluatedFlag"  is NULL)) OR
((s."StandardComment" != d."StandardComment")  OR (s."StandardComment"  is not NULL and d."StandardComment"  is NULL) OR (d."StandardComment"  is not NULL and s."StandardComment"  is NULL)) OR
((s."DetailStatus" != d."DetailStatus")  OR (s."DetailStatus"  is not NULL and d."DetailStatus"  is NULL) OR (d."DetailStatus"  is not NULL and s."DetailStatus"  is NULL)) OR
((s."SalesOrderSource" != d."SalesOrderSource")  OR (s."SalesOrderSource"  is not NULL and d."SalesOrderSource"  is NULL) OR (d."SalesOrderSource"  is not NULL and s."SalesOrderSource"  is NULL)) OR
((s."SalesOrderSrcDesc" != d."SalesOrderSrcDesc")  OR (s."SalesOrderSrcDesc"  is not NULL and d."SalesOrderSrcDesc"  is NULL) OR (d."SalesOrderSrcDesc"  is not NULL and s."SalesOrderSrcDesc"  is NULL)) OR
((s."LanguageCode" != d."LanguageCode")  OR (s."LanguageCode"  is not NULL and d."LanguageCode"  is NULL) OR (d."LanguageCode"  is not NULL and s."LanguageCode"  is NULL)) OR
((s."ShippingLocation" != d."ShippingLocation") OR (s."ShippingLocation"  is not NULL and d."ShippingLocation"  is NULL) OR (d."ShippingLocation"  is not NULL and s."ShippingLocation"  is NULL))
);
END;
