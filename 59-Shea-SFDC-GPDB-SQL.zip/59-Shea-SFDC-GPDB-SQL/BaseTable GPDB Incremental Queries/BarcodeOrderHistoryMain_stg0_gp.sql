---BarCodeOrderHistory_stg0_gp


BEGIN;
insert into sysprocompanyb.barcodeorderhistorymain_stg0_gp 
select s.* from sysprocompanyb.barcodeorderhistorymain_stg0 s LEFT JOIN 
sysprocompanyb.barcodeorderhistorymain_stg0_gp d 
ON s."Ky"=d."Ky" 
where d."Ky" is null;

UPDATE sysprocompanyb.barcodeorderhistorymain_stg0_gp d
SET
"time" = s."time",
"Ky" = s."Ky",
"OrderNo" = s."OrderNo",
"ItemNo" = s."ItemNo",
"LineNumber" = s."LineNumber",
"WH" = s."WH",
"Bin" = s."Bin",
"Lot" = s."Lot",
"SerialNo" = s."SerialNo",
"ShipQty" = s."ShipQty",
"EmpNo" = s."EmpNo",
"EntryDate" = s."EntryDate",
"Complete" = s."Complete",
"ProcessedFlag" = s."ProcessedFlag",
"TermID" = s."TermID",
"TraceLot" = s."TraceLot",
"TraceSerial" = s."TraceSerial",
"MStockQtyToShp" = s."MStockQtyToShp",
"TraceKy" = s."TraceKy",
"JournalNo" = s."JournalNo",
"VersionRelease" = s."VersionRelease",
"LabelID" = s."LabelID",
"DispatchNoteNo" = s."DispatchNoteNo",
"ReasonCode" = s."ReasonCode",
"SCTFlag" = s."SCTFlag",
"PalletNo" = s."PalletNo",
"BOMessage" = s."BOMessage",
"BOCounter" = s."BOCounter",
"BomFlag" = s."BomFlag",
"InvoiceNo" = s."InvoiceNo",
"ShipmentNo" = s."ShipmentNo",
"DateMarkedComplete" = s."DateMarkedComplete",
"NetWeight" = s."NetWeight"
FROM sysprocompanyb.barcodeorderhistorymain_stg0 s 
WHERE s."Ky"=d."Ky" and 
( 
((s."OrderNo" != d."OrderNo")  OR (s."OrderNo"  is not NULL and d."OrderNo"  is NULL) OR (d."OrderNo"  is not NULL and s."OrderNo"  is NULL)) OR
((s."ItemNo" != d."ItemNo")  OR (s."ItemNo"  is not NULL and d."ItemNo"  is NULL) OR (d."ItemNo"  is not NULL and s."ItemNo"  is NULL)) OR
((s."LineNumber" != d."LineNumber")  OR (s."LineNumber"  is not NULL and d."LineNumber"  is NULL) OR (d."LineNumber"  is not NULL and s."LineNumber"  is NULL)) OR
((s."WH" != d."WH")  OR (s."WH"  is not NULL and d."WH"  is NULL) OR (d."WH"  is not NULL and s."WH"  is NULL)) OR
((s."Bin" != d."Bin")  OR (s."Bin"  is not NULL and d."Bin"  is NULL) OR (d."Bin"  is not NULL and s."Bin"  is NULL)) OR
((s."Lot" != d."Lot")  OR (s."Lot"  is not NULL and d."Lot"  is NULL) OR (d."Lot"  is not NULL and s."Lot"  is NULL)) OR
((s."SerialNo" != d."SerialNo")  OR (s."SerialNo"  is not NULL and d."SerialNo"  is NULL) OR (d."SerialNo"  is not NULL and s."SerialNo"  is NULL)) OR
((s."ShipQty" != d."ShipQty")  OR (s."ShipQty"  is not NULL and d."ShipQty"  is NULL) OR (d."ShipQty"  is not NULL and s."ShipQty"  is NULL)) OR
((s."EmpNo" != d."EmpNo")  OR (s."EmpNo"  is not NULL and d."EmpNo"  is NULL) OR (d."EmpNo"  is not NULL and s."EmpNo"  is NULL)) OR
((s."EntryDate" != d."EntryDate")  OR (s."EntryDate"  is not NULL and d."EntryDate"  is NULL) OR (d."EntryDate"  is not NULL and s."EntryDate"  is NULL)) OR
((s."Complete" != d."Complete")  OR (s."Complete"  is not NULL and d."Complete"  is NULL) OR (d."Complete"  is not NULL and s."Complete"  is NULL)) OR
((s."ProcessedFlag" != d."ProcessedFlag")  OR (s."ProcessedFlag"  is not NULL and d."ProcessedFlag"  is NULL) OR (d."ProcessedFlag"  is not NULL and s."ProcessedFlag"  is NULL)) OR
((s."TermID" != d."TermID")  OR (s."TermID"  is not NULL and d."TermID"  is NULL) OR (d."TermID"  is not NULL and s."TermID"  is NULL)) OR
((s."TraceLot" != d."TraceLot")  OR (s."TraceLot"  is not NULL and d."TraceLot"  is NULL) OR (d."TraceLot"  is not NULL and s."TraceLot"  is NULL)) OR
((s."TraceSerial" != d."TraceSerial")  OR (s."TraceSerial"  is not NULL and d."TraceSerial"  is NULL) OR (d."TraceSerial"  is not NULL and s."TraceSerial"  is NULL)) OR
((s."MStockQtyToShp" != d."MStockQtyToShp")  OR (s."MStockQtyToShp"  is not NULL and d."MStockQtyToShp"  is NULL) OR (d."MStockQtyToShp"  is not NULL and s."MStockQtyToShp"  is NULL)) OR
((s."TraceKy" != d."TraceKy")  OR (s."TraceKy"  is not NULL and d."TraceKy"  is NULL) OR (d."TraceKy"  is not NULL and s."TraceKy"  is NULL)) OR
((s."JournalNo" != d."JournalNo")  OR (s."JournalNo"  is not NULL and d."JournalNo"  is NULL) OR (d."JournalNo"  is not NULL and s."JournalNo"  is NULL)) OR
((s."VersionRelease" != d."VersionRelease")  OR (s."VersionRelease"  is not NULL and d."VersionRelease"  is NULL) OR (d."VersionRelease"  is not NULL and s."VersionRelease"  is NULL)) OR
((s."LabelID" != d."LabelID")  OR (s."LabelID"  is not NULL and d."LabelID"  is NULL) OR (d."LabelID"  is not NULL and s."LabelID"  is NULL)) OR
((s."DispatchNoteNo" != d."DispatchNoteNo")  OR (s."DispatchNoteNo"  is not NULL and d."DispatchNoteNo"  is NULL) OR (d."DispatchNoteNo"  is not NULL and s."DispatchNoteNo"  is NULL)) OR
((s."ReasonCode" != d."ReasonCode")  OR (s."ReasonCode"  is not NULL and d."ReasonCode"  is NULL) OR (d."ReasonCode"  is not NULL and s."ReasonCode"  is NULL)) OR
((s."SCTFlag" != d."SCTFlag")  OR (s."SCTFlag"  is not NULL and d."SCTFlag"  is NULL) OR (d."SCTFlag"  is not NULL and s."SCTFlag"  is NULL)) OR
((s."PalletNo" != d."PalletNo")  OR (s."PalletNo"  is not NULL and d."PalletNo"  is NULL) OR (d."PalletNo"  is not NULL and s."PalletNo"  is NULL)) OR
((s."BOMessage" != d."BOMessage")  OR (s."BOMessage"  is not NULL and d."BOMessage"  is NULL) OR (d."BOMessage"  is not NULL and s."BOMessage"  is NULL)) OR
((s."BOCounter" != d."BOCounter")  OR (s."BOCounter"  is not NULL and d."BOCounter"  is NULL) OR (d."BOCounter"  is not NULL and s."BOCounter"  is NULL)) OR
((s."BomFlag" != d."BomFlag")  OR (s."BomFlag"  is not NULL and d."BomFlag"  is NULL) OR (d."BomFlag"  is not NULL and s."BomFlag"  is NULL)) OR
((s."InvoiceNo" != d."InvoiceNo")  OR (s."InvoiceNo"  is not NULL and d."InvoiceNo"  is NULL) OR (d."InvoiceNo"  is not NULL and s."InvoiceNo"  is NULL)) OR
((s."ShipmentNo" != d."ShipmentNo")  OR (s."ShipmentNo"  is not NULL and d."ShipmentNo"  is NULL) OR (d."ShipmentNo"  is not NULL and s."ShipmentNo"  is NULL)) OR
((s."DateMarkedComplete" != d."DateMarkedComplete")  OR (s."DateMarkedComplete"  is not NULL and d."DateMarkedComplete"  is NULL) OR (d."DateMarkedComplete"  is not NULL and s."DateMarkedComplete"  is NULL)) OR
((s."NetWeight" != d."NetWeight") OR (s."NetWeight"  is not NULL and d."NetWeight"  is NULL) OR (d."NetWeight"  is not NULL and s."NetWeight"  is NULL)));

--Delete
delete from sysprocompanyb.barcodeorderhistorymain_stg0_gp  
where sysprocompanyb.barcodeorderhistorymain_stg0_gp."Ky"
in
(
  select d."Ky"
  from   sysprocompanyb.barcodeorderhistorymain_stg0_gp d
  left join   sysprocompanyb.barcodeorderhistorymain_stg0 s
  on   s."Ky"=d."Ky"  
  where 
  s."Ky" is null
);

END;
