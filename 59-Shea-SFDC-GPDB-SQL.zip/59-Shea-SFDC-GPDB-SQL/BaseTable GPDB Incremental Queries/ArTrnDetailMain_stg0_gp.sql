--ArtrnDetail_stg0_gp


Begin;

INSERT INTO sysprocompanyb.artrndetailmain_stg0_gp
select s.* from 
sysprocompanyb.artrndetailmain_stg0 s LEFT JOIN sysprocompanyb.artrndetailmain_stg0_gp d
ON
(s."TrnYear" = d."TrnYear" and
s."TrnMonth" = d."TrnMonth" and
s."Register" = d."Register" and
s."Invoice" = d."Invoice" and
s."SummaryLine" = d."SummaryLine" and
s."DetailLine" = d."DetailLine")
where(
d."TrnYear" is null and
d."TrnMonth" is null and
d."Register" is null and
d."Invoice" is null and
d."SummaryLine" is null and
d."DetailLine" is  null
);
savepoint sd;

delete from sysprocompanyb.artrndetailmain_stg0_gp
where
(
sysprocompanyb.artrndetailmain_stg0_gp."TrnYear",
sysprocompanyb.artrndetailmain_stg0_gp."TrnMonth",
sysprocompanyb.artrndetailmain_stg0_gp."Register",
sysprocompanyb.artrndetailmain_stg0_gp."Invoice",
sysprocompanyb.artrndetailmain_stg0_gp."SummaryLine",
sysprocompanyb.artrndetailmain_stg0_gp."DetailLine"
)
in
( 
select d."TrnYear", d."TrnMonth", d."Register", d."Invoice", d."SummaryLine", d."DetailLine"
from sysprocompanyb.artrndetailmain_stg0_gp d
left join sysprocompanyb.artrndetailmain_stg0 s
ON 
s."TrnYear" = d."TrnYear" and  s."TrnMonth" = d."TrnMonth"
and s."Register" = d."Register" and s."Invoice" = d."Invoice" 
and s."SummaryLine" = d."SummaryLine"
and s."DetailLine" = d."DetailLine"
where s."TrnYear" is null and s."TrnMonth" is null and s."Register" is null
and s."Invoice" is null and s."SummaryLine" is null 
and s."DetailLine" is null
);


UPDATE sysprocompanyb.artrndetailmain_stg0_gp d
SET
"time" = s."time",
"InvoiceDate" = s."InvoiceDate",
"Branch" = s."Branch",
"Salesperson" = s."Salesperson",
"Customer" = s."Customer",
"StockCode" = s."StockCode",
"Warehouse" = s."Warehouse",
"ProductClass" = s."ProductClass",
"CustomerClass" = s."CustomerClass",
"QtyInvoiced" = s."QtyInvoiced",
"Mass" = s."Mass",
"NetSalesValue" = s."NetSalesValue",
"TaxValue" = s."TaxValue",
"CostValue" = s."CostValue",
"DiscValue" = s."DiscValue",
"LineType" = s."LineType",
"PriceCode" = s."PriceCode",
"DocumentType" = s."DocumentType",
"SalesOrder" = s."SalesOrder",
"CustomerPoNumber" = s."CustomerPoNumber",
"SalesOrderLine" = s."SalesOrderLine"
FROM sysprocompanyb.artrndetailmain_stg0 s 
WHERE (s."TrnYear" = d."TrnYear" and
s."TrnMonth" = d."TrnMonth" and
s."Register" = d."Register" and
s."Invoice" = d."Invoice" and
s."SummaryLine" = d."SummaryLine" and
s."DetailLine" = d."DetailLine")
and 
(
((s."InvoiceDate" != d."InvoiceDate")  OR (s."InvoiceDate"  is not NULL and d."InvoiceDate"  is NULL) OR (d."InvoiceDate"  is not NULL and s."InvoiceDate"  is NULL)) OR
((s."Branch" != d."Branch")  OR (s."Branch"  is not NULL and d."Branch"  is NULL) OR (d."Branch"  is not NULL and s."Branch"  is NULL)) OR
((s."Salesperson" != d."Salesperson")  OR (s."Salesperson"  is not NULL and d."Salesperson"  is NULL) OR (d."Salesperson"  is not NULL and s."Salesperson"  is NULL)) OR
((s."Customer" != d."Customer")  OR (s."Customer"  is not NULL and d."Customer"  is NULL) OR (d."Customer"  is not NULL and s."Customer"  is NULL)) OR
((s."StockCode" != d."StockCode")  OR (s."StockCode"  is not NULL and d."StockCode"  is NULL) OR (d."StockCode"  is not NULL and s."StockCode"  is NULL)) OR
((s."Warehouse" != d."Warehouse")  OR (s."Warehouse"  is not NULL and d."Warehouse"  is NULL) OR (d."Warehouse"  is not NULL and s."Warehouse"  is NULL)) OR
((s."ProductClass" != d."ProductClass")  OR (s."ProductClass"  is not NULL and d."ProductClass"  is NULL) OR (d."ProductClass"  is not NULL and s."ProductClass"  is NULL)) OR
((s."CustomerClass" != d."CustomerClass")  OR (s."CustomerClass"  is not NULL and d."CustomerClass"  is NULL) OR (d."CustomerClass"  is not NULL and s."CustomerClass"  is NULL)) OR
((s."QtyInvoiced" != d."QtyInvoiced")  OR (s."QtyInvoiced"  is not NULL and d."QtyInvoiced"  is NULL) OR (d."QtyInvoiced"  is not NULL and s."QtyInvoiced"  is NULL)) OR
((s."Mass" != d."Mass")  OR (s."Mass"  is not NULL and d."Mass"  is NULL) OR (d."Mass"  is not NULL and s."Mass"  is NULL)) OR
((s."NetSalesValue" != d."NetSalesValue")  OR (s."NetSalesValue"  is not NULL and d."NetSalesValue"  is NULL) OR (d."NetSalesValue"  is not NULL and s."NetSalesValue"  is NULL)) OR
((s."TaxValue" != d."TaxValue")  OR (s."TaxValue"  is not NULL and d."TaxValue"  is NULL) OR (d."TaxValue"  is not NULL and s."TaxValue"  is NULL)) OR
((s."CostValue" != d."CostValue")  OR (s."CostValue"  is not NULL and d."CostValue"  is NULL) OR (d."CostValue"  is not NULL and s."CostValue"  is NULL)) OR
((s."DiscValue" != d."DiscValue")  OR (s."DiscValue"  is not NULL and d."DiscValue"  is NULL) OR (d."DiscValue"  is not NULL and s."DiscValue"  is NULL)) OR
((s."LineType" != d."LineType")  OR (s."LineType"  is not NULL and d."LineType"  is NULL) OR (d."LineType"  is not NULL and s."LineType"  is NULL)) OR
((s."PriceCode" != d."PriceCode")  OR (s."PriceCode"  is not NULL and d."PriceCode"  is NULL) OR (d."PriceCode"  is not NULL and s."PriceCode"  is NULL)) OR
((s."DocumentType" != d."DocumentType")  OR (s."DocumentType"  is not NULL and d."DocumentType"  is NULL) OR (d."DocumentType"  is not NULL and s."DocumentType"  is NULL)) OR
((s."SalesOrder" != d."SalesOrder")  OR (s."SalesOrder"  is not NULL and d."SalesOrder"  is NULL) OR (d."SalesOrder"  is not NULL and s."SalesOrder"  is NULL)) OR
((s."CustomerPoNumber" != d."CustomerPoNumber")  OR (s."CustomerPoNumber"  is not NULL and d."CustomerPoNumber"  is NULL) OR (d."CustomerPoNumber"  is not NULL and s."CustomerPoNumber"  is NULL)) OR
((s."SalesOrderLine" != d."SalesOrderLine") OR (s."SalesOrderLine"  is not NULL and d."SalesOrderLine"  is NULL) OR (d."SalesOrderLine"  is not NULL and s."SalesOrderLine"  is NULL))
);

End;
