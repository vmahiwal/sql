--TblCustomerClassMain_stg0_gp

BEGIN;
insert into sysprocompanyb.tblcustomerclassmain_stg0_gp select s.*
from sysprocompanyb.tblcustomerclassmain_stg0 s 
LEFT JOIN sysprocompanyb.tblcustomerclassmain_stg0_gp d
ON s."Class"=d."Class" where d."Class" is null ;
Savepoint sp2;
--Delete
delete from sysprocompanyb.tblcustomerclassmain_stg0_gp
where sysprocompanyb.tblcustomerclassmain_stg0_gp."Class"
in
(
select d."Class"
from
sysprocompanyb.tblcustomerclassmain_stg0_gp d
left join
sysprocompanyb.tblcustomerclassmain_stg0 s
on
s."Class"=d."Class"
where s."Class" is null
);
UPDATE sysprocompanyb.tblcustomerclassmain_stg0_gp d
SET
"time"= s."time",
"Description" = s."Description",
"TimeStamp" = s."TimeStamp"
FROM sysprocompanyb.tblcustomerclassmain_stg0 s
Where (s."Class"=d."Class") and

(((s."Description" != d."Description") OR (s."Description"  is not NULL and d."Description"  is NULL) OR (d."Description"  is not NULL and s."Description"  is NULL))
);
END;
