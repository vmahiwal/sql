--Admformdatamain_stg0_gp

BEGIN;
insert into sysprocompanyb.admformdatamain_stg0_gp 
select s.* from sysprocompanyb.admformdatamain_stg0 s LEFT JOIN 

sysprocompanyb.admformdatamain_stg0_gp d 
ON s."FormType"=d."FormType" and
s."KeyField"=d."KeyField" and
s."FieldName"=d."FieldName"
where d."FormType" is null and d."KeyField" is null and 

d."FieldName" is null;

UPDATE sysprocompanyb.admformdatamain_stg0_gp d
SET
"time"=s."time",
"AlphaValue"=s."AlphaValue",
"NumericValue"=s."NumericValue",
"DateValue"=s."DateValue"
FROM sysprocompanyb.admformdatamain_stg0 s
WHERE (s."FormType"=d."FormType") and
(s."KeyField"=d."KeyField") AND
(s."FieldName"=d."FieldName") AND
(
(( s."AlphaValue" != d."AlphaValue")  OR (s."AlphaValue"  is not NULL and d."AlphaValue"  is NULL) OR (d."AlphaValue"  is not NULL and s."AlphaValue"  is NULL)) OR
(( s."NumericValue" != d."NumericValue")  OR (s."NumericValue"  is not NULL and d."NumericValue"  is NULL) OR (d."NumericValue"  is not NULL and s."NumericValue"  is NULL)) OR
(( s."DateValue" != d."DateValue") OR (s."DateValue"  is not NULL and d."DateValue"  is NULL) OR (d."DateValue"  is not NULL and s."DateValue"  is NULL))
);

delete from sysprocompanyb.admformdatamain_stg0_gp
where(sysprocompanyb.admformdatamain_stg0_gp."FormType", 

sysprocompanyb.admformdatamain_stg0_gp."KeyField",sysprocompanyb.

admformdatamain_stg0_gp."FieldName")
in
(
select d."FormType", d."KeyField",d."FieldName"
from
sysprocompanyb.admformdatamain_stg0_gp d 
left join
sysprocompanyb.admformdatamain_stg0 s
on
s."FormType"=d."FormType" and  s."KeyField" = d."KeyField" and 
s."FieldName" = d."FieldName"
where s."FormType" is null and  s."KeyField" is null and 
s."FieldName" is null
);
END;
