--MdnDetailMain_stg0_gp


--MdnDetails
BEGIN;
--insert Query
insert into sysprocompanyb.mdndetailmain_stg0_gp select s.* from sysprocompanyb.mdndetailmain_stg0 s
LEFT JOIN sysprocompanyb.mdndetailmain_stg0_gp d 
ON s."DispatchNote"=d."DispatchNote" and s."DispatchNoteLine"=d."DispatchNoteLine" 
where d."DispatchNote" is null and d."DispatchNoteLine" is null;

--update Query
UPDATE sysprocompanyb.mdndetailmain_stg0_gp d
SET
"time" = s."time",
"SalesOrder" = s."SalesOrder",
"SalesOrderLine" = s."SalesOrderLine",
"LineType" = s."LineType",
"DispatchStatus" = s."DispatchStatus",
"TotalValue" = s."TotalValue",
"OverUnderFlag" = s."OverUnderFlag",
"StockDepleted" = s."StockDepleted",
"ConfirmationDate" = s."ConfirmationDate",
"ConfirmationLine" = s."ConfirmationLine",
"OrigShipSoUom" = s."OrigShipSoUom",
"OrigShipStkUom" = s."OrigShipStkUom",
"OrigBoSoUom" = s."OrigBoSoUom",
"MStockCode" = s."MStockCode",
"MStockDes" = s."MStockDes",
"MWarehouse" = s."MWarehouse",
"MBin" = s."MBin",
"MOrderQty" = s."MOrderQty",
"MQtyToDispatch" = s."MQtyToDispatch",
"MBackOrderQty" = s."MBackOrderQty",
"MUnitCost" = s."MUnitCost",
"MBomFlag" = s."MBomFlag",
"MParentKitType" = s."MParentKitType",
"MQtyPer" = s."MQtyPer",
"MScrapPercentage" = s."MScrapPercentage",
"MPrintComponent" = s."MPrintComponent",
"MComponentSeq" = s."MComponentSeq",
"MQtyChangesFlag" = s."MQtyChangesFlag",
"MOptionalFlag" = s."MOptionalFlag",
"MDecimals" = s."MDecimals",
"MOrderUom" = s."MOrderUom",
"MStockQtyToShp" = s."MStockQtyToShp",
"MStockingUom" = s."MStockingUom",
"MConvFactOrdUm" = s."MConvFactOrdUm",
"MMulDivPrcFct" = s."MMulDivPrcFct",
"MPrice" = s."MPrice",
"MPriceUom" = s."MPriceUom",
"MCommissionCode" = s."MCommissionCode",
"MDiscPct1" = s."MDiscPct1",
"MDiscPct2" = s."MDiscPct2",
"MDiscPct3" = s."MDiscPct3",
"MDiscValFlag" = s."MDiscValFlag",
"MDiscValue" = s."MDiscValue",
"MProductClass" = s."MProductClass",
"MTaxCode" = s."MTaxCode",
"MLineShipDate" = s."MLineShipDate",
"MAllocStatSched" = s."MAllocStatSched",
"MFstTaxCode" = s."MFstTaxCode",
"MStockUnitMass" = s."MStockUnitMass",
"MStockUnitVol" = s."MStockUnitVol",
"MPriceCode" = s."MPriceCode",
"MConvFactAlloc" = s."MConvFactAlloc",
"MMulDivQtyFct" = s."MMulDivQtyFct",
"MTraceableType" = s."MTraceableType",
"MMpsFlag" = s."MMpsFlag",
"MPickingSlip" = s."MPickingSlip",
"MMovementReqd" = s."MMovementReqd",
"MSerialMethod" = s."MSerialMethod",
"MZeroQtyCrNote" = s."MZeroQtyCrNote",
"MAbcApplied" = s."MAbcApplied",
"MMpsGrossReqd" = s."MMpsGrossReqd",
"MContract" = s."MContract",
"MBuyingGroup" = s."MBuyingGroup",
"MCusSupStkCode" = s."MCusSupStkCode",
"MCusRetailPrice" = s."MCusRetailPrice",
"MTariffCode" = s."MTariffCode",
"MLineReceiptDat" = s."MLineReceiptDat",
"MLeadTime" = s."MLeadTime",
"MTrfCostMult" = s."MTrfCostMult",
"MSupplementaryUn" = s."MSupplementaryUn",
"MReviewFlag" = s."MReviewFlag",
"MReviewStatus" = s."MReviewStatus",
"MInvoicePrinted" = s."MInvoicePrinted",
"MDelNotePrinted" = s."MDelNotePrinted",
"MOrdAckPrinted" = s."MOrdAckPrinted",
"MHierarchyJob" = s."MHierarchyJob",
"MCustRequestDat" = s."MCustRequestDat",
"MLastDelNote" = s."MLastDelNote",
"MUserDef" = s."MUserDef",
"MQtyDispatched" = s."MQtyDispatched",
"MDiscChanged" = s."MDiscChanged",
"MCreditOrderNo" = s."MCreditOrderNo",
"MCreditOrderLine" = s."MCreditOrderLine",
"MUnitQuantity" = s."MUnitQuantity",
"MConvFactUnitQ" = s."MConvFactUnitQ",
"MAltUomUnitQ" = s."MAltUomUnitQ",
"MDecimalsUnitQ" = s."MDecimalsUnitQ",
"MEccFlag" = s."MEccFlag",
"MVersion" = s."MVersion",
"MRelease" = s."MRelease",
"MCommitDate" = s."MCommitDate",
"NComment" = s."NComment",
"NCommentFromLin" = s."NCommentFromLin",
"NMscChargeValue" = s."NMscChargeValue",
"NMscProductCls" = s."NMscProductCls",
"NMscChargeCost" = s."NMscChargeCost",
"NMscInvCharge" = s."NMscInvCharge",
"NCommentType" = s."NCommentType",
"NMscTaxCode" = s."NMscTaxCode",
"NMscFstCode" = s."NMscFstCode",
"NCommentTextTyp" = s."NCommentTextTyp",
"NMscChargeQty" = s."NMscChargeQty",
"NSrvIncTotal" = s."NSrvIncTotal",
"NSrvSummary" = s."NSrvSummary",
"NSrvChargeType" = s."NSrvChargeType",
"NSrvParentLine" = s."NSrvParentLine",
"NSrvUnitPrice" = s."NSrvUnitPrice",
"NSrvUnitCost" = s."NSrvUnitCost",
"NSrvQtyFactor" = s."NSrvQtyFactor",
"NSrvApplyFactor" = s."NSrvApplyFactor",
"NSrvDecimalRnd" = s."NSrvDecimalRnd",
"NSrvDecRndFlag" = s."NSrvDecRndFlag",
"NSrvMinValue" = s."NSrvMinValue",
"NSrvMaxValue" = s."NSrvMaxValue",
"NSrvMulDiv" = s."NSrvMulDiv",
"NPrtOnInv" = s."NPrtOnInv",
"NPrtOnDel" = s."NPrtOnDel",
"NPrtOnAck" = s."NPrtOnAck",
"NTaxAmtFlag" = s."NTaxAmtFlag",
"NDepRetFlagProj" = s."NDepRetFlagProj",
"NRetentionJob" = s."NRetentionJob",
"NSrvMinQuantity" = s."NSrvMinQuantity",
"NChargeCode" = s."NChargeCode",
"TpmUsageFlag" = s."TpmUsageFlag",
"PromotionCode" = s."PromotionCode",
"TpmSequence" = s."TpmSequence",
"SalesOrderInitLine" = s."SalesOrderInitLine",
"PreactorPriority" = s."PreactorPriority",
"SalesOrderDetStat" = s."SalesOrderDetStat",
"JnlYear" = s."JnlYear",
"JnlMonth" = s."JnlMonth",
"Journal" = s."Journal",
"JournalLine" = s."JournalLine",
"MaterialAllocLine" = s."MaterialAllocLine",
"ScrapQuantity" = s."ScrapQuantity",
"FixedQtyPerFlag" = s."FixedQtyPerFlag",
"FixedQtyPer" = s."FixedQtyPer"


FROM sysprocompanyb.mdndetailmain_stg0 s
WHERE s."DispatchNote"=d."DispatchNote" 
and s."DispatchNoteLine"=d."DispatchNoteLine"
and(
((s."SalesOrder" != d."SalesOrder")  OR (s."SalesOrder"  is not NULL and d."SalesOrder"  is NULL) OR (d."SalesOrder"  is not NULL and s."SalesOrder"  is NULL)) OR
((s."SalesOrderLine" != d."SalesOrderLine")  OR (s."SalesOrderLine"  is not NULL and d."SalesOrderLine"  is NULL) OR (d."SalesOrderLine"  is not NULL and s."SalesOrderLine"  is NULL)) OR
((s."LineType" != d."LineType")  OR (s."LineType"  is not NULL and d."LineType"  is NULL) OR (d."LineType"  is not NULL and s."LineType"  is NULL)) OR
((s."DispatchStatus" != d."DispatchStatus")  OR (s."DispatchStatus"  is not NULL and d."DispatchStatus"  is NULL) OR (d."DispatchStatus"  is not NULL and s."DispatchStatus"  is NULL)) OR
((s."TotalValue" != d."TotalValue")  OR (s."TotalValue"  is not NULL and d."TotalValue"  is NULL) OR (d."TotalValue"  is not NULL and s."TotalValue"  is NULL)) OR
((s."OverUnderFlag" != d."OverUnderFlag")  OR (s."OverUnderFlag"  is not NULL and d."OverUnderFlag"  is NULL) OR (d."OverUnderFlag"  is not NULL and s."OverUnderFlag"  is NULL)) OR
((s."StockDepleted" != d."StockDepleted")  OR (s."StockDepleted"  is not NULL and d."StockDepleted"  is NULL) OR (d."StockDepleted"  is not NULL and s."StockDepleted"  is NULL)) OR
((s."ConfirmationDate" != d."ConfirmationDate")  OR (s."ConfirmationDate"  is not NULL and d."ConfirmationDate"  is NULL) OR (d."ConfirmationDate"  is not NULL and s."ConfirmationDate"  is NULL)) OR
((s."ConfirmationLine" != d."ConfirmationLine")  OR (s."ConfirmationLine"  is not NULL and d."ConfirmationLine"  is NULL) OR (d."ConfirmationLine"  is not NULL and s."ConfirmationLine"  is NULL)) OR
((s."OrigShipSoUom" != d."OrigShipSoUom")  OR (s."OrigShipSoUom"  is not NULL and d."OrigShipSoUom"  is NULL) OR (d."OrigShipSoUom"  is not NULL and s."OrigShipSoUom"  is NULL)) OR
((s."OrigShipStkUom" != d."OrigShipStkUom")  OR (s."OrigShipStkUom"  is not NULL and d."OrigShipStkUom"  is NULL) OR (d."OrigShipStkUom"  is not NULL and s."OrigShipStkUom"  is NULL)) OR
((s."OrigBoSoUom" != d."OrigBoSoUom")  OR (s."OrigBoSoUom"  is not NULL and d."OrigBoSoUom"  is NULL) OR (d."OrigBoSoUom"  is not NULL and s."OrigBoSoUom"  is NULL)) OR
((s."MStockCode" != d."MStockCode")  OR (s."MStockCode"  is not NULL and d."MStockCode"  is NULL) OR (d."MStockCode"  is not NULL and s."MStockCode"  is NULL)) OR
((s."MStockDes" != d."MStockDes")  OR (s."MStockDes"  is not NULL and d."MStockDes"  is NULL) OR (d."MStockDes"  is not NULL and s."MStockDes"  is NULL)) OR
((s."MWarehouse" != d."MWarehouse")  OR (s."MWarehouse"  is not NULL and d."MWarehouse"  is NULL) OR (d."MWarehouse"  is not NULL and s."MWarehouse"  is NULL)) OR
((s."MBin" != d."MBin")  OR (s."MBin"  is not NULL and d."MBin"  is NULL) OR (d."MBin"  is not NULL and s."MBin"  is NULL)) OR
((s."MOrderQty" != d."MOrderQty")  OR (s."MOrderQty"  is not NULL and d."MOrderQty"  is NULL) OR (d."MOrderQty"  is not NULL and s."MOrderQty"  is NULL)) OR
((s."MQtyToDispatch" != d."MQtyToDispatch")  OR (s."MQtyToDispatch"  is not NULL and d."MQtyToDispatch"  is NULL) OR (d."MQtyToDispatch"  is not NULL and s."MQtyToDispatch"  is NULL)) OR
((s."MBackOrderQty" != d."MBackOrderQty")  OR (s."MBackOrderQty"  is not NULL and d."MBackOrderQty"  is NULL) OR (d."MBackOrderQty"  is not NULL and s."MBackOrderQty"  is NULL)) OR
((s."MUnitCost" != d."MUnitCost")  OR (s."MUnitCost"  is not NULL and d."MUnitCost"  is NULL) OR (d."MUnitCost"  is not NULL and s."MUnitCost"  is NULL)) OR
((s."MBomFlag" != d."MBomFlag")  OR (s."MBomFlag"  is not NULL and d."MBomFlag"  is NULL) OR (d."MBomFlag"  is not NULL and s."MBomFlag"  is NULL)) OR
((s."MParentKitType" != d."MParentKitType")  OR (s."MParentKitType"  is not NULL and d."MParentKitType"  is NULL) OR (d."MParentKitType"  is not NULL and s."MParentKitType"  is NULL)) OR
((s."MQtyPer" != d."MQtyPer")  OR (s."MQtyPer"  is not NULL and d."MQtyPer"  is NULL) OR (d."MQtyPer"  is not NULL and s."MQtyPer"  is NULL)) OR
((s."MScrapPercentage" != d."MScrapPercentage")  OR (s."MScrapPercentage"  is not NULL and d."MScrapPercentage"  is NULL) OR (d."MScrapPercentage"  is not NULL and s."MScrapPercentage"  is NULL)) OR
((s."MPrintComponent" != d."MPrintComponent")  OR (s."MPrintComponent"  is not NULL and d."MPrintComponent"  is NULL) OR (d."MPrintComponent"  is not NULL and s."MPrintComponent"  is NULL)) OR
((s."MComponentSeq" != d."MComponentSeq")  OR (s."MComponentSeq"  is not NULL and d."MComponentSeq"  is NULL) OR (d."MComponentSeq"  is not NULL and s."MComponentSeq"  is NULL)) OR
((s."MQtyChangesFlag" != d."MQtyChangesFlag") OR (s."MQtyChangesFlag"  is not NULL and d."MQtyChangesFlag"  is NULL) OR (d."MQtyChangesFlag"  is not NULL and s."MQtyChangesFlag"  is NULL)) OR
((s."MOptionalFlag" != d."MOptionalFlag")  OR (s."MOptionalFlag"  is not NULL and d."MOptionalFlag"  is NULL) OR (d."MOptionalFlag"  is not NULL and s."MOptionalFlag"  is NULL)) OR
((s."MDecimals" != d."MDecimals")  OR (s."MDecimals"  is not NULL and d."MDecimals"  is NULL) OR (d."MDecimals"  is not NULL and s."MDecimals"  is NULL)) OR
((s."MOrderUom" != d."MOrderUom")  OR (s."MOrderUom"  is not NULL and d."MOrderUom"  is NULL) OR (d."MOrderUom"  is not NULL and s."MOrderUom"  is NULL)) OR
((s."MStockQtyToShp" != d."MStockQtyToShp")  OR (s."MStockQtyToShp"  is not NULL and d."MStockQtyToShp"  is NULL) OR (d."MStockQtyToShp"  is not NULL and s."MStockQtyToShp"  is NULL)) OR
((s."MStockingUom" != d."MStockingUom")  OR (s."MStockingUom"  is not NULL and d."MStockingUom"  is NULL) OR (d."MStockingUom"  is not NULL and s."MStockingUom"  is NULL)) OR
((s."MConvFactOrdUm" != d."MConvFactOrdUm")  OR (s."MConvFactOrdUm"  is not NULL and d."MConvFactOrdUm"  is NULL) OR (d."MConvFactOrdUm"  is not NULL and s."MConvFactOrdUm"  is NULL)) OR
((s."MMulDivPrcFct" != d."MMulDivPrcFct")  OR (s."MMulDivPrcFct"  is not NULL and d."MMulDivPrcFct"  is NULL) OR (d."MMulDivPrcFct"  is not NULL and s."MMulDivPrcFct"  is NULL)) OR
((s."MPrice" != d."MPrice")  OR (s."MPrice"  is not NULL and d."MPrice"  is NULL) OR (d."MPrice"  is not NULL and s."MPrice"  is NULL)) OR
((s."MPriceUom" != d."MPriceUom")  OR (s."MPriceUom"  is not NULL and d."MPriceUom"  is NULL) OR (d."MPriceUom"  is not NULL and s."MPriceUom"  is NULL)) OR
((s."MCommissionCode" != d."MCommissionCode")  OR (s."MCommissionCode"  is not NULL and d."MCommissionCode"  is NULL) OR (d."MCommissionCode"  is not NULL and s."MCommissionCode"  is NULL)) OR
((s."MDiscPct1" != d."MDiscPct1")  OR (s."MDiscPct1"  is not NULL and d."MDiscPct1"  is NULL) OR (d."MDiscPct1"  is not NULL and s."MDiscPct1"  is NULL)) OR
((s."MDiscPct2" != d."MDiscPct2")  OR (s."MDiscPct2"  is not NULL and d."MDiscPct2"  is NULL) OR (d."MDiscPct2"  is not NULL and s."MDiscPct2"  is NULL)) OR
((s."MDiscPct3" != d."MDiscPct3")  OR (s."MDiscPct3"  is not NULL and d."MDiscPct3"  is NULL) OR (d."MDiscPct3"  is not NULL and s."MDiscPct3"  is NULL)) OR
((s."MDiscValFlag" != d."MDiscValFlag")  OR (s."MDiscValFlag"  is not NULL and d."MDiscValFlag"  is NULL) OR (d."MDiscValFlag"  is not NULL and s."MDiscValFlag"  is NULL)) OR
((s."MDiscValue" != d."MDiscValue")  OR (s."MDiscValue"  is not NULL and d."MDiscValue"  is NULL) OR (d."MDiscValue"  is not NULL and s."MDiscValue"  is NULL)) OR
((s."MProductClass" != d."MProductClass")  OR (s."MProductClass"  is not NULL and d."MProductClass"  is NULL) OR (d."MProductClass"  is not NULL and s."MProductClass"  is NULL)) OR
((s."MTaxCode" != d."MTaxCode")  OR (s."MTaxCode"  is not NULL and d."MTaxCode"  is NULL) OR (d."MTaxCode"  is not NULL and s."MTaxCode"  is NULL)) OR
((s."MLineShipDate" != d."MLineShipDate")  OR (s."MLineShipDate"  is not NULL and d."MLineShipDate"  is NULL) OR (d."MLineShipDate"  is not NULL and s."MLineShipDate"  is NULL)) OR
((s."MAllocStatSched" != d."MAllocStatSched")  OR (s."MAllocStatSched"  is not NULL and d."MAllocStatSched"  is NULL) OR (d."MAllocStatSched"  is not NULL and s."MAllocStatSched"  is NULL)) OR
((s."MFstTaxCode" != d."MFstTaxCode")  OR (s."MFstTaxCode"  is not NULL and d."MFstTaxCode"  is NULL) OR (d."MFstTaxCode"  is not NULL and s."MFstTaxCode"  is NULL)) OR
((s."MStockUnitMass" != d."MStockUnitMass")  OR (s."MStockUnitMass"  is not NULL and d."MStockUnitMass"  is NULL) OR (d."MStockUnitMass"  is not NULL and s."MStockUnitMass"  is NULL)) OR
((s."MStockUnitVol" != d."MStockUnitVol")  OR (s."MStockUnitVol"  is not NULL and d."MStockUnitVol"  is NULL) OR (d."MStockUnitVol"  is not NULL and s."MStockUnitVol"  is NULL)) OR
((s."MPriceCode" != d."MPriceCode")  OR (s."MPriceCode"  is not NULL and d."MPriceCode"  is NULL) OR (d."MPriceCode"  is not NULL and s."MPriceCode"  is NULL)) OR
((s."MConvFactAlloc" != d."MConvFactAlloc")  OR (s."MConvFactAlloc"  is not NULL and d."MConvFactAlloc"  is NULL) OR (d."MConvFactAlloc"  is not NULL and s."MConvFactAlloc"  is NULL)) OR
((s."MMulDivQtyFct" != d."MMulDivQtyFct")  OR (s."MMulDivQtyFct"  is not NULL and d."MMulDivQtyFct"  is NULL) OR (d."MMulDivQtyFct"  is not NULL and s."MMulDivQtyFct"  is NULL)) OR
((s."MTraceableType" != d."MTraceableType")  OR (s."MTraceableType"  is not NULL and d."MTraceableType"  is NULL) OR (d."MTraceableType"  is not NULL and s."MTraceableType"  is NULL)) OR
((s."MMpsFlag" != d."MMpsFlag")  OR (s."MMpsFlag"  is not NULL and d."MMpsFlag"  is NULL) OR (d."MMpsFlag"  is not NULL and s."MMpsFlag"  is NULL)) OR
((s."MPickingSlip" != d."MPickingSlip")  OR (s."MPickingSlip"  is not NULL and d."MPickingSlip"  is NULL) OR (d."MPickingSlip"  is not NULL and s."MPickingSlip"  is NULL)) OR
((s."MMovementReqd" != d."MMovementReqd")  OR (s."MMovementReqd"  is not NULL and d."MMovementReqd"  is NULL) OR (d."MMovementReqd"  is not NULL and s."MMovementReqd"  is NULL)) OR
((s."MSerialMethod" != d."MSerialMethod")  OR (s."MSerialMethod"  is not NULL and d."MSerialMethod"  is NULL) OR (d."MSerialMethod"  is not NULL and s."MSerialMethod"  is NULL)) OR
((s."MZeroQtyCrNote" != d."MZeroQtyCrNote")  OR (s."MZeroQtyCrNote"  is not NULL and d."MZeroQtyCrNote"  is NULL) OR (d."MZeroQtyCrNote"  is not NULL and s."MZeroQtyCrNote"  is NULL)) OR
((s."MAbcApplied" != d."MAbcApplied") OR (s."MAbcApplied"  is not NULL and d."MAbcApplied"  is NULL) OR (d."MAbcApplied"  is not NULL and s."MAbcApplied"  is NULL)) OR
((s."MMpsGrossReqd" != d."MMpsGrossReqd")  OR (s."MMpsGrossReqd"  is not NULL and d."MMpsGrossReqd"  is NULL) OR (d."MMpsGrossReqd"  is not NULL and s."MMpsGrossReqd"  is NULL)) OR
((s."MContract" != d."MContract")  OR (s."MContract"  is not NULL and d."MContract"  is NULL) OR (d."MContract"  is not NULL and s."MContract"  is NULL)) OR
((s."MBuyingGroup" != d."MBuyingGroup")  OR (s."MBuyingGroup"  is not NULL and d."MBuyingGroup"  is NULL) OR (d."MBuyingGroup"  is not NULL and s."MBuyingGroup"  is NULL)) OR
((s."MCusSupStkCode" != d."MCusSupStkCode")  OR (s."MCusSupStkCode"  is not NULL and d."MCusSupStkCode"  is NULL) OR (d."MCusSupStkCode"  is not NULL and s."MCusSupStkCode"  is NULL)) OR
((s."MCusRetailPrice" != d."MCusRetailPrice")  OR (s."MCusRetailPrice"  is not NULL and d."MCusRetailPrice"  is NULL) OR (d."MCusRetailPrice"  is not NULL and s."MCusRetailPrice"  is NULL)) OR
((s."MTariffCode" != d."MTariffCode")  OR (s."MTariffCode"  is not NULL and d."MTariffCode"  is NULL) OR (d."MTariffCode"  is not NULL and s."MTariffCode"  is NULL)) OR
((s."MLineReceiptDat" != d."MLineReceiptDat")  OR (s."MLineReceiptDat"  is not NULL and d."MLineReceiptDat"  is NULL) OR (d."MLineReceiptDat"  is not NULL and s."MLineReceiptDat"  is NULL)) OR
((s."MLeadTime" != d."MLeadTime")  OR (s."MLeadTime"  is not NULL and d."MLeadTime"  is NULL) OR (d."MLeadTime"  is not NULL and s."MLeadTime"  is NULL)) OR
((s."MTrfCostMult" != d."MTrfCostMult")  OR (s."MTrfCostMult"  is not NULL and d."MTrfCostMult"  is NULL) OR (d."MTrfCostMult"  is not NULL and s."MTrfCostMult"  is NULL)) OR
((s."MSupplementaryUn" != d."MSupplementaryUn")  OR (s."MSupplementaryUn"  is not NULL and d."MSupplementaryUn"  is NULL) OR (d."MSupplementaryUn"  is not NULL and s."MSupplementaryUn"  is NULL)) OR
((s."MReviewFlag" != d."MReviewFlag")  OR (s."MReviewFlag"  is not NULL and d."MReviewFlag"  is NULL) OR (d."MReviewFlag"  is not NULL and s."MReviewFlag"  is NULL)) OR
((s."MReviewStatus" != d."MReviewStatus")  OR (s."MReviewStatus"  is not NULL and d."MReviewStatus"  is NULL) OR (d."MReviewStatus"  is not NULL and s."MReviewStatus"  is NULL)) OR
((s."MInvoicePrinted" != d."MInvoicePrinted")  OR (s."MInvoicePrinted"  is not NULL and d."MInvoicePrinted"  is NULL) OR (d."MInvoicePrinted"  is not NULL and s."MInvoicePrinted"  is NULL)) OR
((s."MDelNotePrinted" != d."MDelNotePrinted")  OR (s."MDelNotePrinted"  is not NULL and d."MDelNotePrinted"  is NULL) OR (d."MDelNotePrinted"  is not NULL and s."MDelNotePrinted"  is NULL)) OR
((s."MOrdAckPrinted" != d."MOrdAckPrinted")  OR (s."MOrdAckPrinted"  is not NULL and d."MOrdAckPrinted"  is NULL) OR (d."MOrdAckPrinted"  is not NULL and s."MOrdAckPrinted"  is NULL)) OR
((s."MHierarchyJob" != d."MHierarchyJob")  OR (s."MHierarchyJob"  is not NULL and d."MHierarchyJob"  is NULL) OR (d."MHierarchyJob"  is not NULL and s."MHierarchyJob"  is NULL)) OR
((s."MCustRequestDat" != d."MCustRequestDat")  OR (s."MCustRequestDat"  is not NULL and d."MCustRequestDat"  is NULL) OR (d."MCustRequestDat"  is not NULL and s."MCustRequestDat"  is NULL)) OR
((s."MLastDelNote" != d."MLastDelNote")  OR (s."MLastDelNote"  is not NULL and d."MLastDelNote"  is NULL) OR (d."MLastDelNote"  is not NULL and s."MLastDelNote"  is NULL)) OR
((s."MUserDef" != d."MUserDef")  OR (s."MUserDef"  is not NULL and d."MUserDef"  is NULL) OR (d."MUserDef"  is not NULL and s."MUserDef"  is NULL)) OR
((s."MQtyDispatched" != d."MQtyDispatched")  OR (s."MQtyDispatched"  is not NULL and d."MQtyDispatched"  is NULL) OR (d."MQtyDispatched"  is not NULL and s."MQtyDispatched"  is NULL)) OR
((s."MDiscChanged" != d."MDiscChanged")  OR (s."MDiscChanged"  is not NULL and d."MDiscChanged"  is NULL) OR (d."MDiscChanged"  is not NULL and s."MDiscChanged"  is NULL)) OR
((s."MCreditOrderNo" != d."MCreditOrderNo")  OR (s."MCreditOrderNo"  is not NULL and d."MCreditOrderNo"  is NULL) OR (d."MCreditOrderNo"  is not NULL and s."MCreditOrderNo"  is NULL)) OR
((s."MCreditOrderLine" != d."MCreditOrderLine")  OR (s."MCreditOrderLine"  is not NULL and d."MCreditOrderLine"  is NULL) OR (d."MCreditOrderLine"  is not NULL and s."MCreditOrderLine"  is NULL)) OR
((s."MUnitQuantity" != d."MUnitQuantity")  OR (s."MUnitQuantity"  is not NULL and d."MUnitQuantity"  is NULL) OR (d."MUnitQuantity"  is not NULL and s."MUnitQuantity"  is NULL)) OR
((s."MConvFactUnitQ" != d."MConvFactUnitQ")  OR (s."MConvFactUnitQ"  is not NULL and d."MConvFactUnitQ"  is NULL) OR (d."MConvFactUnitQ"  is not NULL and s."MConvFactUnitQ"  is NULL)) OR
((s."MAltUomUnitQ" != d."MAltUomUnitQ")  OR (s."MAltUomUnitQ"  is not NULL and d."MAltUomUnitQ"  is NULL) OR (d."MAltUomUnitQ"  is not NULL and s."MAltUomUnitQ"  is NULL)) OR
((s."MDecimalsUnitQ" != d."MDecimalsUnitQ")  OR (s."MDecimalsUnitQ"  is not NULL and d."MDecimalsUnitQ"  is NULL) OR (d."MDecimalsUnitQ"  is not NULL and s."MDecimalsUnitQ"  is NULL)) OR
((s."MEccFlag" != d."MEccFlag")  OR (s."MEccFlag"  is not NULL and d."MEccFlag"  is NULL) OR (d."MEccFlag"  is not NULL and s."MEccFlag"  is NULL)) OR
((s."MVersion" != d."MVersion")  OR (s."MVersion"  is not NULL and d."MVersion"  is NULL) OR (d."MVersion"  is not NULL and s."MVersion"  is NULL)) OR
((s."MRelease" != d."MRelease")  OR (s."MRelease"  is not NULL and d."MRelease"  is NULL) OR (d."MRelease"  is not NULL and s."MRelease"  is NULL)) OR
((s."MCommitDate" != d."MCommitDate")  OR (s."MCommitDate"  is not NULL and d."MCommitDate"  is NULL) OR (d."MCommitDate"  is not NULL and s."MCommitDate"  is NULL)) OR
((s."NComment" != d."NComment")  OR (s."NComment"  is not NULL and d."NComment"  is NULL) OR (d."NComment"  is not NULL and s."NComment"  is NULL)) OR
((s."NCommentFromLin" != d."NCommentFromLin")  OR (s."NCommentFromLin"  is not NULL and d."NCommentFromLin"  is NULL) OR (d."NCommentFromLin"  is not NULL and s."NCommentFromLin"  is NULL)) OR
((s."NMscChargeValue" != d."NMscChargeValue")  OR (s."NMscChargeValue"  is not NULL and d."NMscChargeValue"  is NULL) OR (d."NMscChargeValue"  is not NULL and s."NMscChargeValue"  is NULL)) OR
((s."NMscProductCls" != d."NMscProductCls")  OR (s."NMscProductCls"  is not NULL and d."NMscProductCls"  is NULL) OR (d."NMscProductCls"  is not NULL and s."NMscProductCls"  is NULL)) OR
((s."NMscChargeCost" != d."NMscChargeCost")  OR (s."NMscChargeCost"  is not NULL and d."NMscChargeCost"  is NULL) OR (d."NMscChargeCost"  is not NULL and s."NMscChargeCost"  is NULL)) OR
((s."NMscInvCharge" != d."NMscInvCharge")  OR (s."NMscInvCharge"  is not NULL and d."NMscInvCharge"  is NULL) OR (d."NMscInvCharge"  is not NULL and s."NMscInvCharge"  is NULL)) OR
((s."NCommentType" != d."NCommentType")  OR (s."NCommentType"  is not NULL and d."NCommentType"  is NULL) OR (d."NCommentType"  is not NULL and s."NCommentType"  is NULL)) OR
((s."NMscTaxCode" != d."NMscTaxCode")  OR (s."NMscTaxCode"  is not NULL and d."NMscTaxCode"  is NULL) OR (d."NMscTaxCode"  is not NULL and s."NMscTaxCode"  is NULL)) OR
((s."NMscFstCode" != d."NMscFstCode")  OR (s."NMscFstCode"  is not NULL and d."NMscFstCode"  is NULL) OR (d."NMscFstCode"  is not NULL and s."NMscFstCode"  is NULL)) OR
((s."NCommentTextTyp" != d."NCommentTextTyp")  OR (s."NCommentTextTyp"  is not NULL and d."NCommentTextTyp"  is NULL) OR (d."NCommentTextTyp"  is not NULL and s."NCommentTextTyp"  is NULL)) OR
((s."NMscChargeQty" != d."NMscChargeQty")  OR (s."NMscChargeQty"  is not NULL and d."NMscChargeQty"  is NULL) OR (d."NMscChargeQty"  is not NULL and s."NMscChargeQty"  is NULL)) OR
((s."NSrvIncTotal" != d."NSrvIncTotal")  OR (s."NSrvIncTotal"  is not NULL and d."NSrvIncTotal"  is NULL) OR (d."NSrvIncTotal"  is not NULL and s."NSrvIncTotal"  is NULL)) OR
((s."NSrvSummary" != d."NSrvSummary")  OR (s."NSrvSummary"  is not NULL and d."NSrvSummary"  is NULL) OR (d."NSrvSummary"  is not NULL and s."NSrvSummary"  is NULL)) OR
((s."NSrvChargeType" != d."NSrvChargeType")  OR (s."NSrvChargeType"  is not NULL and d."NSrvChargeType"  is NULL) OR (d."NSrvChargeType"  is not NULL and s."NSrvChargeType"  is NULL)) OR
((s."NSrvParentLine" != d."NSrvParentLine")  OR (s."NSrvParentLine"  is not NULL and d."NSrvParentLine"  is NULL) OR (d."NSrvParentLine"  is not NULL and s."NSrvParentLine"  is NULL)) OR
((s."NSrvUnitPrice" != d."NSrvUnitPrice")  OR (s."NSrvUnitPrice"  is not NULL and d."NSrvUnitPrice"  is NULL) OR (d."NSrvUnitPrice"  is not NULL and s."NSrvUnitPrice"  is NULL)) OR
((s."NSrvUnitCost" != d."NSrvUnitCost")  OR (s."NSrvUnitCost"  is not NULL and d."NSrvUnitCost"  is NULL) OR (d."NSrvUnitCost"  is not NULL and s."NSrvUnitCost"  is NULL)) OR
((s."NSrvQtyFactor" != d."NSrvQtyFactor")  OR (s."NSrvQtyFactor"  is not NULL and d."NSrvQtyFactor"  is NULL) OR (d."NSrvQtyFactor"  is not NULL and s."NSrvQtyFactor"  is NULL)) OR
((s."NSrvApplyFactor" != d."NSrvApplyFactor")  OR (s."NSrvApplyFactor"  is not NULL and d."NSrvApplyFactor"  is NULL) OR (d."NSrvApplyFactor"  is not NULL and s."NSrvApplyFactor"  is NULL)) OR
((s."NSrvDecimalRnd" != d."NSrvDecimalRnd")  OR (s."NSrvDecimalRnd"  is not NULL and d."NSrvDecimalRnd"  is NULL) OR (d."NSrvDecimalRnd"  is not NULL and s."NSrvDecimalRnd"  is NULL)) OR
((s."NSrvDecRndFlag" != d."NSrvDecRndFlag")  OR (s."NSrvDecRndFlag"  is not NULL and d."NSrvDecRndFlag"  is NULL) OR (d."NSrvDecRndFlag"  is not NULL and s."NSrvDecRndFlag"  is NULL)) OR
((s."NSrvMinValue" != d."NSrvMinValue")  OR (s."NSrvMinValue"  is not NULL and d."NSrvMinValue"  is NULL) OR (d."NSrvMinValue"  is not NULL and s."NSrvMinValue"  is NULL)) OR
((s."NSrvMaxValue" != d."NSrvMaxValue")  OR (s."NSrvMaxValue"  is not NULL and d."NSrvMaxValue"  is NULL) OR (d."NSrvMaxValue"  is not NULL and s."NSrvMaxValue"  is NULL)) OR
((s."NSrvMulDiv" != d."NSrvMulDiv")  OR (s."NSrvMulDiv"  is not NULL and d."NSrvMulDiv"  is NULL) OR (d."NSrvMulDiv"  is not NULL and s."NSrvMulDiv"  is NULL)) OR
((s."NPrtOnInv" != d."NPrtOnInv")  OR (s."NPrtOnInv"  is not NULL and d."NPrtOnInv"  is NULL) OR (d."NPrtOnInv"  is not NULL and s."NPrtOnInv"  is NULL)) OR
((s."NPrtOnDel" != d."NPrtOnDel")  OR (s."NPrtOnDel"  is not NULL and d."NPrtOnDel"  is NULL) OR (d."NPrtOnDel"  is not NULL and s."NPrtOnDel"  is NULL)) OR
((s."NPrtOnAck" != d."NPrtOnAck")  OR (s."NPrtOnAck"  is not NULL and d."NPrtOnAck"  is NULL) OR (d."NPrtOnAck"  is not NULL and s."NPrtOnAck"  is NULL)) OR
((s."NTaxAmtFlag" != d."NTaxAmtFlag")  OR (s."NTaxAmtFlag"  is not NULL and d."NTaxAmtFlag"  is NULL) OR (d."NTaxAmtFlag"  is not NULL and s."NTaxAmtFlag"  is NULL)) OR
((s."NDepRetFlagProj" != d."NDepRetFlagProj")  OR (s."NDepRetFlagProj"  is not NULL and d."NDepRetFlagProj"  is NULL) OR (d."NDepRetFlagProj"  is not NULL and s."NDepRetFlagProj"  is NULL)) OR
((s."NRetentionJob" != d."NRetentionJob")  OR (s."NRetentionJob"  is not NULL and d."NRetentionJob"  is NULL) OR (d."NRetentionJob"  is not NULL and s."NRetentionJob"  is NULL)) OR
((s."NSrvMinQuantity" != d."NSrvMinQuantity")  OR (s."NSrvMinQuantity"  is not NULL and d."NSrvMinQuantity"  is NULL) OR (d."NSrvMinQuantity"  is not NULL and s."NSrvMinQuantity"  is NULL)) OR
((s."NChargeCode" != d."NChargeCode")  OR (s."NChargeCode"  is not NULL and d."NChargeCode"  is NULL) OR (d."NChargeCode"  is not NULL and s."NChargeCode"  is NULL)) OR
((s."TpmUsageFlag" != d."TpmUsageFlag")  OR (s."TpmUsageFlag"  is not NULL and d."TpmUsageFlag"  is NULL) OR (d."TpmUsageFlag"  is not NULL and s."TpmUsageFlag"  is NULL)) OR
((s."PromotionCode" != d."PromotionCode")  OR (s."PromotionCode"  is not NULL and d."PromotionCode"  is NULL) OR (d."PromotionCode"  is not NULL and s."PromotionCode"  is NULL)) OR
((s."TpmSequence" != d."TpmSequence")  OR (s."TpmSequence"  is not NULL and d."TpmSequence"  is NULL) OR (d."TpmSequence"  is not NULL and s."TpmSequence"  is NULL)) OR
((s."SalesOrderInitLine" != d."SalesOrderInitLine")  OR (s."SalesOrderInitLine"  is not NULL and d."SalesOrderInitLine"  is NULL) OR (d."SalesOrderInitLine"  is not NULL and s."SalesOrderInitLine"  is NULL)) OR
((s."PreactorPriority" != d."PreactorPriority")  OR (s."PreactorPriority"  is not NULL and d."PreactorPriority"  is NULL) OR (d."PreactorPriority"  is not NULL and s."PreactorPriority"  is NULL)) OR
((s."SalesOrderDetStat" != d."SalesOrderDetStat")  OR (s."SalesOrderDetStat"  is not NULL and d."SalesOrderDetStat"  is NULL) OR (d."SalesOrderDetStat"  is not NULL and s."SalesOrderDetStat"  is NULL)) OR
((s."JnlYear" != d."JnlYear")  OR (s."JnlYear"  is not NULL and d."JnlYear"  is NULL) OR (d."JnlYear"  is not NULL and s."JnlYear"  is NULL)) OR
((s."JnlMonth" != d."JnlMonth")  OR (s."JnlMonth"  is not NULL and d."JnlMonth"  is NULL) OR (d."JnlMonth"  is not NULL and s."JnlMonth"  is NULL)) OR
((s."Journal" != d."Journal")  OR (s."Journal"  is not NULL and d."Journal"  is NULL) OR (d."Journal"  is not NULL and s."Journal"  is NULL)) OR
((s."JournalLine" != d."JournalLine")  OR (s."JournalLine"  is not NULL and d."JournalLine"  is NULL) OR (d."JournalLine"  is not NULL and s."JournalLine"  is NULL)) OR
((s."MaterialAllocLine" != d."MaterialAllocLine")  OR (s."MaterialAllocLine"  is not NULL and d."MaterialAllocLine"  is NULL) OR (d."MaterialAllocLine"  is not NULL and s."MaterialAllocLine"  is NULL)) OR
((s."ScrapQuantity" != d."ScrapQuantity")  OR (s."ScrapQuantity"  is not NULL and d."ScrapQuantity"  is NULL) OR (d."ScrapQuantity"  is not NULL and s."ScrapQuantity"  is NULL)) OR
((s."FixedQtyPerFlag" != d."FixedQtyPerFlag")  OR (s."FixedQtyPerFlag"  is not NULL and d."FixedQtyPerFlag"  is NULL) OR (d."FixedQtyPerFlag"  is not NULL and s."FixedQtyPerFlag"  is NULL)) OR
((s."FixedQtyPer" != d."FixedQtyPer") OR (s."FixedQtyPer"  is not NULL and d."FixedQtyPer"  is NULL) OR (d."FixedQtyPer"  is not NULL and s."FixedQtyPer"  is NULL)) 
);



--Delete Query

delete from sysprocompanyb.mdndetailmain_stg0_gp d 
where(d."DispatchNote",d."DispatchNoteLine")
in
(
select d."DispatchNote",d."DispatchNoteLine"
from
sysprocompanyb.mdndetailmain_stg0_gp d
left join
sysprocompanyb.mdndetailmain_stg0 s
on
s."DispatchNote"=d."DispatchNote" 
and s."DispatchNoteLine"=d."DispatchNoteLine" 
 where 
 s."DispatchNote" is null and s."DispatchNoteLine" is null
);	

END;
