--MrpForecastMain_stg0_gp



BEGIN;
INSERT INTO sysprocompanyb.mrpforecastmain_stg0_gp 
SELECT s.* FROM sysprocompanyb.mrpforecastmain_stg0 s 
LEFT JOIN 
sysprocompanyb.mrpforecastmain_stg0_gp d 
ON s."StockCode"=d."StockCode"
AND s."ForecastWh"=d."ForecastWh" 
AND s."ForecastDate"=d."ForecastDate" 
AND s."Line"=d."Line" 
WHERE d."StockCode" IS NULL 
AND d."ForecastWh" IS NULL 
AND d."ForecastDate" IS NULL 
AND d."Line" IS NULL;

UPDATE sysprocompanyb.mrpforecastmain_stg0_gp d
SET
"time" = s."time",
"ForecastQtyOutst" = s."ForecastQtyOutst",
"Description" = s."Description",
"Reference" = s."Reference",
"Customer" = s."Customer",
"ResourceParent" = s."ResourceParent",
"InactiveFlag" = s."InactiveFlag",
"ForecastType" = s."ForecastType",
"QtyInvoiced" = s."QtyInvoiced",
"OrigForecastDate" = s."OrigForecastDate",
"OriginalLine" = s."OriginalLine",
"OrigQtyOutst" = s."OrigQtyOutst",
"Version" = s."Version",
"Release" = s."Release"
FROM sysprocompanyb.mrpforecastmain_stg0 s

WHERE  s."StockCode"=d."StockCode"
AND s."ForecastWh"=d."ForecastWh"
AND s."ForecastDate"=d."ForecastDate" 
AND s."Line"=d."Line" 
AND 
(
((s."ForecastQtyOutst" != d."ForecastQtyOutst")  OR (s."ForecastQtyOutst"  is not NULL and d."ForecastQtyOutst"  is NULL) OR (d."ForecastQtyOutst"  is not NULL and s."ForecastQtyOutst"  is NULL)) OR
((s."Description" != d."Description")  OR (s."Description"  is not NULL and d."Description"  is NULL) OR (d."Description"  is not NULL and s."Description"  is NULL)) OR
((s."Reference" != d."Reference")  OR (s."Reference"  is not NULL and d."Reference"  is NULL) OR (d."Reference"  is not NULL and s."Reference"  is NULL)) OR
((s."Customer" != d."Customer")  OR (s."Customer"  is not NULL and d."Customer"  is NULL) OR (d."Customer"  is not NULL and s."Customer"  is NULL)) OR
((s."ResourceParent" != d."ResourceParent")  OR (s."ResourceParent"  is not NULL and d."ResourceParent"  is NULL) OR (d."ResourceParent"  is not NULL and s."ResourceParent"  is NULL)) OR
((s."InactiveFlag" != d."InactiveFlag")  OR (s."InactiveFlag"  is not NULL and d."InactiveFlag"  is NULL) OR (d."InactiveFlag"  is not NULL and s."InactiveFlag"  is NULL)) OR
((s."ForecastType" != d."ForecastType")  OR (s."ForecastType"  is not NULL and d."ForecastType"  is NULL) OR (d."ForecastType"  is not NULL and s."ForecastType"  is NULL)) OR
((s."QtyInvoiced" != d."QtyInvoiced")  OR (s."QtyInvoiced"  is not NULL and d."QtyInvoiced"  is NULL) OR (d."QtyInvoiced"  is not NULL and s."QtyInvoiced"  is NULL)) OR
((s."OrigForecastDate" != d."OrigForecastDate")  OR (s."OrigForecastDate"  is not NULL and d."OrigForecastDate"  is NULL) OR (d."OrigForecastDate"  is not NULL and s."OrigForecastDate"  is NULL)) OR
((s."OriginalLine" != d."OriginalLine")  OR (s."OriginalLine"  is not NULL and d."OriginalLine"  is NULL) OR (d."OriginalLine"  is not NULL and s."OriginalLine"  is NULL)) OR
((s."OrigQtyOutst" != d."OrigQtyOutst")  OR (s."OrigQtyOutst"  is not NULL and d."OrigQtyOutst"  is NULL) OR (d."OrigQtyOutst"  is not NULL and s."OrigQtyOutst"  is NULL)) OR
((s."Version" != d."Version")  OR (s."Version"  is not NULL and d."Version"  is NULL) OR (d."Version"  is not NULL and s."Version"  is NULL)) OR
((s."Release" != d."Release") OR (s."Release"  is not NULL and d."Release"  is NULL) OR (d."Release"  is not NULL and s."Release"  is NULL)) 
);

DELETE FROM sysprocompanyb.mrpforecastmain_stg0_gp WHERE
(sysprocompanyb.mrpforecastmain_stg0_gp."StockCode",
sysprocompanyb.mrpforecastmain_stg0_gp."ForecastWh",
sysprocompanyb.mrpforecastmain_stg0_gp."ForecastDate",
sysprocompanyb.mrpforecastmain_stg0_gp."Line")
IN
(
SELECT d."StockCode", d."ForecastWh",
d."ForecastDate",d."Line"
FROM
sysprocompanyb.mrpforecastmain_stg0_gp d
LEFT JOIN
sysprocompanyb.mrpforecastmain_stg0 s
ON
s."StockCode"=d."StockCode" AND 
s."ForecastWh"=d."ForecastWh" AND 
s."ForecastDate"=d."ForecastDate" AND 
s."Line"=d."Line"
WHERE
s."StockCode" IS NULL AND s."ForecastWh" IS NULL  
AND s."ForecastDate" IS NULL  AND s."Line" IS NULL 
);
END;
