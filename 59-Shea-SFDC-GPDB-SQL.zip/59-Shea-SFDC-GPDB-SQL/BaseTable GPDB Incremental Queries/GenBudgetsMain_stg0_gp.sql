--GenBudgets_stg0_gp


BEGIN;

insert into sysprocompanyb.genbudgetsmain_stg0_gp select s.*
from sysprocompanyb.genbudgetsmain_stg0 s 
LEFT JOIN sysprocompanyb.genbudgetsmain_stg0_gp d
ON (s."GlCode"=d."GlCode" 
and s."Company"=d."Company"
and s."BudgetType"=d."BudgetType" 
and s."BudgetNumber"=d."BudgetNumber")
where (d."GlCode" is null and d."Company" is null 
and d."BudgetNumber" is null and d."BudgetType" is null);


--Delete
delete from sysprocompanyb.genbudgetsmain_stg0_gp
where (sysprocompanyb.genbudgetsmain_stg0_gp."GlCode",
sysprocompanyb.genbudgetsmain_stg0_gp."Company",
sysprocompanyb.genbudgetsmain_stg0_gp."BudgetType",
sysprocompanyb.genbudgetsmain_stg0_gp."BudgetNumber")
in
(
select d."GlCode",d."Company", 
d."BudgetType",d."BudgetNumber"
from
sysprocompanyb.genbudgetsmain_stg0_gp d
left join sysprocompanyb.genbudgetsmain_stg0 s
on
s."GlCode"=d."GlCode" and s."Company"=d."Company"
and s."BudgetType"=d."BudgetType"
and s."BudgetNumber"=d."BudgetNumber"
where s."GlCode" is null 
and s."Company" is null 
and s."BudgetNumber" is null 
and s."BudgetType" is null
);

UPDATE sysprocompanyb.genbudgetsmain_stg0_gp d
SET
"time"=s."time",
"RevisionLevel" = s."RevisionLevel",
"DateLastModified" = s."DateLastModified",
"Budget1" = s."Budget1",
"Budget2" = s."Budget2",
"Budget3" = s."Budget3",
"Budget4" = s."Budget4",
"Budget5" = s."Budget5",
"Budget6" = s."Budget6",
"Budget7" = s."Budget7",
"Budget8" = s."Budget8",
"Budget9" = s."Budget9",
"Budget10" = s."Budget10",
"Budget11" = s."Budget11",
"Budget12" = s."Budget12", 
"Budget13" = s."Budget13",
"Budget14" = s."Budget14",
"Budget15" = s."Budget15",
"TimeStamp" = s."TimeStamp"
FROM sysprocompanyb.genbudgetsmain_stg0 s
Where (s."GlCode"=d."GlCode" 
and s."Company"=d."Company"
and s."BudgetType"=d."BudgetType"
and s."BudgetNumber"=d."BudgetNumber") 
and(
((s."RevisionLevel" != d."RevisionLevel")  OR (s."RevisionLevel"  is not NULL and d."RevisionLevel"  is NULL) OR (d."RevisionLevel"  is not NULL and s."RevisionLevel"  is NULL)) OR
((s."DateLastModified" != d."DateLastModified")  OR (s."DateLastModified"  is not NULL and d."DateLastModified"  is NULL) OR (d."DateLastModified"  is not NULL and s."DateLastModified"  is NULL)) OR
((s."Budget1" != d."Budget1")  OR (s."Budget1"  is not NULL and d."Budget1"  is NULL) OR (d."Budget1"  is not NULL and s."Budget1"  is NULL)) OR
((s."Budget2" != d."Budget2")  OR (s."Budget2"  is not NULL and d."Budget2"  is NULL) OR (d."Budget2"  is not NULL and s."Budget2"  is NULL)) OR
((s."Budget3" != d."Budget3")  OR (s."Budget3"  is not NULL and d."Budget3"  is NULL) OR (d."Budget3"  is not NULL and s."Budget3"  is NULL)) OR
((s."Budget4" != d."Budget4")  OR (s."Budget4"  is not NULL and d."Budget4"  is NULL) OR (d."Budget4"  is not NULL and s."Budget4"  is NULL)) OR
((s."Budget5" != d."Budget5")  OR (s."Budget5"  is not NULL and d."Budget5"  is NULL) OR (d."Budget5"  is not NULL and s."Budget5"  is NULL)) OR
((s."Budget6" != d."Budget6")  OR (s."Budget6"  is not NULL and d."Budget6"  is NULL) OR (d."Budget6"  is not NULL and s."Budget6"  is NULL)) OR
((s."Budget7" != d."Budget7")  OR (s."Budget7"  is not NULL and d."Budget7"  is NULL) OR (d."Budget7"  is not NULL and s."Budget7"  is NULL)) OR
((s."Budget8" != d."Budget8")  OR (s."Budget8"  is not NULL and d."Budget8"  is NULL) OR (d."Budget8"  is not NULL and s."Budget8"  is NULL)) OR
((s."Budget9" != d."Budget9")  OR (s."Budget9"  is not NULL and d."Budget9"  is NULL) OR (d."Budget9"  is not NULL and s."Budget9"  is NULL)) OR
((s."Budget10" != d."Budget10")  OR (s."Budget10"  is not NULL and d."Budget10"  is NULL) OR (d."Budget10"  is not NULL and s."Budget10"  is NULL)) OR
((s."Budget11" != d."Budget11")  OR (s."Budget11"  is not NULL and d."Budget11"  is NULL) OR (d."Budget11"  is not NULL and s."Budget11"  is NULL)) OR
((s."Budget12" != d."Budget12")  OR (s."Budget12"  is not NULL and d."Budget12"  is NULL) OR (d."Budget12"  is not NULL and s."Budget12"  is NULL)) OR
((s."Budget13" != d."Budget13")  OR (s."Budget13"  is not NULL and d."Budget13"  is NULL) OR (d."Budget13"  is not NULL and s."Budget13"  is NULL)) OR
((s."Budget14" != d."Budget14")  OR (s."Budget14"  is not NULL and d."Budget14"  is NULL) OR (d."Budget14"  is not NULL and s."Budget14"  is NULL)) OR
((s."Budget15" != d."Budget15") OR (s."Budget15"  is not NULL and d."Budget15"  is NULL) OR (d."Budget15"  is not NULL and s."Budget15"  is NULL)) 
);
END;
