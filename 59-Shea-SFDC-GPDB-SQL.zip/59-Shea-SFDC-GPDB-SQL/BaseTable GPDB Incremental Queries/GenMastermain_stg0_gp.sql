--GenMaster_stg0_gp


BEGIN;
insert into sysprocompanyb.genmastermain_stg0_gp 
select s.* from sysprocompanyb.genmastermain_stg0 s
 LEFT JOIN sysprocompanyb.genmastermain_stg0_gp d
ON (s."GlCode" = d."GlCode" and s."Company"=d."Company") 
where (d."GlCode" is null and d."Company" is null);

--Delete
delete from sysprocompanyb.genmastermain_stg0_gp 
where (sysprocompanyb.genmastermain_stg0_gp."GlCode",
sysprocompanyb.genmastermain_stg0_gp."Company")
in
(
select d."GlCode",d."Company"
from sysprocompanyb.genmastermain_stg0_gp d
left join sysprocompanyb.genmastermain_stg0 s
on s."GlCode"=d."GlCode" and s."Company"=d."Company"
where s."GlCode" is null and s."Company" is null 
);

UPDATE sysprocompanyb.genmastermain_stg0_gp d
SET
"time"=s."time",
"Description" = s."Description",
"NextGlLine" = s."NextGlLine",
"NextGlLinePyr" = s."NextGlLinePyr",
"NextLine" = s."NextLine",
"NextLinePyr" = s."NextLinePyr",
"ReportIndex1" = s."ReportIndex1",
"ReportIndex2" = s."ReportIndex2",
"AccountType" = s."AccountType",
"ExpenseType" = s."ExpenseType",
"PtdDrValue" = s."PtdDrValue",
"PtdCrValue" = s."PtdCrValue",
"CurrentBalance" = s."CurrentBalance",
"PrevPerEndBal" = s."PrevPerEndBal",
"GlGroup" = s."GlGroup",
"BudgetMethod" = s."BudgetMethod",
"ControlAccFlag" = s."ControlAccFlag",
"AccOnHldFlag" = s."AccOnHldFlag",
"TaxCode" = s."TaxCode",
"NumDetailCurYr" = s."NumDetailCurYr",
"NumDetailPrvYr" = s."NumDetailPrvYr",
"IntegrationMethod" = s."IntegrationMethod",
"AltDescription" = s."AltDescription",
"Historical" = s."Historical",
"Tax2Code" = s."Tax2Code",
"RevalCategory" = s."RevalCategory",
"AltCurIndicator" = s."AltCurIndicator",
"GlUnitOfMeasure" = s."GlUnitOfMeasure",
"BusinessProcess1" = s."BusinessProcess1",
"BusinessProcess2" = s."BusinessProcess2",
"BusinessProcess3" = s."BusinessProcess3",
"BusinessProcess4" = s."BusinessProcess4",
"BusinessProcess5" = s."BusinessProcess5",
"BusinessProcess6" = s."BusinessProcess6",
"BusinessProcess7" = s."BusinessProcess7",
"BusinessProcess8" = s."BusinessProcess8",
"BusinessProcess9" = s."BusinessProcess9",
"BusinessProcess10" = s."BusinessProcess10",
"AnalysisRequired" = s."AnalysisRequired",
"AnalysisCategory" = s."AnalysisCategory",
"CurrentInd" = s."CurrentInd",
"RetEarnsAccount" = s."RetEarnsAccount",
"TaxAccount" = s."TaxAccount",
"InterestAccount" = s."InterestAccount",
"TimeStamp" = s."TimeStamp"
FROM sysprocompanyb.genmastermain_stg0 s
Where s."GlCode"= d."GlCode" and s."Company"=d."Company" 
and
(
((s."Description" != d."Description")  OR (s."Description"  is not NULL and d."Description"  is NULL) OR (d."Description"  is not NULL and s."Description"  is NULL)) OR
((s."NextGlLine" != d."NextGlLine")  OR (s."NextGlLine"  is not NULL and d."NextGlLine"  is NULL) OR (d."NextGlLine"  is not NULL and s."NextGlLine"  is NULL)) OR
((s."NextGlLinePyr" != d."NextGlLinePyr")  OR (s."NextGlLinePyr"  is not NULL and d."NextGlLinePyr"  is NULL) OR (d."NextGlLinePyr"  is not NULL and s."NextGlLinePyr"  is NULL)) OR
((s."NextLine" != d."NextLine")  OR (s."NextLine"  is not NULL and d."NextLine"  is NULL) OR (d."NextLine"  is not NULL and s."NextLine"  is NULL)) OR
((s."NextLinePyr" != d."NextLinePyr")  OR (s."NextLinePyr"  is not NULL and d."NextLinePyr"  is NULL) OR (d."NextLinePyr"  is not NULL and s."NextLinePyr"  is NULL)) OR
((s."ReportIndex1" != d."ReportIndex1")  OR (s."ReportIndex1"  is not NULL and d."ReportIndex1"  is NULL) OR (d."ReportIndex1"  is not NULL and s."ReportIndex1"  is NULL)) OR
((s."ReportIndex2" != d."ReportIndex2")  OR (s."ReportIndex2"  is not NULL and d."ReportIndex2"  is NULL) OR (d."ReportIndex2"  is not NULL and s."ReportIndex2"  is NULL)) OR
((s."AccountType" != d."AccountType")  OR (s."AccountType"  is not NULL and d."AccountType"  is NULL) OR (d."AccountType"  is not NULL and s."AccountType"  is NULL)) OR
((s."ExpenseType" != d."ExpenseType")  OR (s."ExpenseType"  is not NULL and d."ExpenseType"  is NULL) OR (d."ExpenseType"  is not NULL and s."ExpenseType"  is NULL)) OR
((s."PtdDrValue" != d."PtdDrValue")  OR (s."PtdDrValue"  is not NULL and d."PtdDrValue"  is NULL) OR (d."PtdDrValue"  is not NULL and s."PtdDrValue"  is NULL)) OR
((s."PtdCrValue" != d."PtdCrValue")  OR (s."PtdCrValue"  is not NULL and d."PtdCrValue"  is NULL) OR (d."PtdCrValue"  is not NULL and s."PtdCrValue"  is NULL)) OR
((s."CurrentBalance" != d."CurrentBalance")  OR (s."CurrentBalance"  is not NULL and d."CurrentBalance"  is NULL) OR (d."CurrentBalance"  is not NULL and s."CurrentBalance"  is NULL)) OR
((s."PrevPerEndBal" != d."PrevPerEndBal")  OR (s."PrevPerEndBal"  is not NULL and d."PrevPerEndBal"  is NULL) OR (d."PrevPerEndBal"  is not NULL and s."PrevPerEndBal"  is NULL)) OR
((s."GlGroup" != d."GlGroup")  OR (s."GlGroup"  is not NULL and d."GlGroup"  is NULL) OR (d."GlGroup"  is not NULL and s."GlGroup"  is NULL)) OR
((s."BudgetMethod" != d."BudgetMethod")  OR (s."BudgetMethod"  is not NULL and d."BudgetMethod"  is NULL) OR (d."BudgetMethod"  is not NULL and s."BudgetMethod"  is NULL)) OR
((s."ControlAccFlag" != d."ControlAccFlag")  OR (s."ControlAccFlag"  is not NULL and d."ControlAccFlag"  is NULL) OR (d."ControlAccFlag"  is not NULL and s."ControlAccFlag"  is NULL)) OR
((s."AccOnHldFlag" != d."AccOnHldFlag")  OR (s."AccOnHldFlag"  is not NULL and d."AccOnHldFlag"  is NULL) OR (d."AccOnHldFlag"  is not NULL and s."AccOnHldFlag"  is NULL)) OR
((s."TaxCode" != d."TaxCode")  OR (s."TaxCode"  is not NULL and d."TaxCode"  is NULL) OR (d."TaxCode"  is not NULL and s."TaxCode"  is NULL)) OR
((s."NumDetailCurYr" != d."NumDetailCurYr")  OR (s."NumDetailCurYr"  is not NULL and d."NumDetailCurYr"  is NULL) OR (d."NumDetailCurYr"  is not NULL and s."NumDetailCurYr"  is NULL)) OR
((s."NumDetailPrvYr" != d."NumDetailPrvYr")  OR (s."NumDetailPrvYr"  is not NULL and d."NumDetailPrvYr"  is NULL) OR (d."NumDetailPrvYr"  is not NULL and s."NumDetailPrvYr"  is NULL)) OR
((s."IntegrationMethod" != d."IntegrationMethod")  OR (s."IntegrationMethod"  is not NULL and d."IntegrationMethod"  is NULL) OR (d."IntegrationMethod"  is not NULL and s."IntegrationMethod"  is NULL)) OR
((s."AltDescription" != d."AltDescription")  OR (s."AltDescription"  is not NULL and d."AltDescription"  is NULL) OR (d."AltDescription"  is not NULL and s."AltDescription"  is NULL)) OR
((s."Historical" != d."Historical")  OR (s."Historical"  is not NULL and d."Historical"  is NULL) OR (d."Historical"  is not NULL and s."Historical"  is NULL)) OR
((s."Tax2Code" != d."Tax2Code")  OR (s."Tax2Code"  is not NULL and d."Tax2Code"  is NULL) OR (d."Tax2Code"  is not NULL and s."Tax2Code"  is NULL)) OR
((s."RevalCategory" != d."RevalCategory")  OR (s."RevalCategory"  is not NULL and d."RevalCategory"  is NULL) OR (d."RevalCategory"  is not NULL and s."RevalCategory"  is NULL)) OR
((s."AltCurIndicator" != d."AltCurIndicator")  OR (s."AltCurIndicator"  is not NULL and d."AltCurIndicator"  is NULL) OR (d."AltCurIndicator"  is not NULL and s."AltCurIndicator"  is NULL)) OR
((s."GlUnitOfMeasure" != d."GlUnitOfMeasure")  OR (s."GlUnitOfMeasure"  is not NULL and d."GlUnitOfMeasure"  is NULL) OR (d."GlUnitOfMeasure"  is not NULL and s."GlUnitOfMeasure"  is NULL)) OR
((s."BusinessProcess1" != d."BusinessProcess1")  OR (s."BusinessProcess1"  is not NULL and d."BusinessProcess1"  is NULL) OR (d."BusinessProcess1"  is not NULL and s."BusinessProcess1"  is NULL)) OR
((s."BusinessProcess2" != d."BusinessProcess2")  OR (s."BusinessProcess2"  is not NULL and d."BusinessProcess2"  is NULL) OR (d."BusinessProcess2"  is not NULL and s."BusinessProcess2"  is NULL)) OR
((s."BusinessProcess3" != d."BusinessProcess3")  OR (s."BusinessProcess3"  is not NULL and d."BusinessProcess3"  is NULL) OR (d."BusinessProcess3"  is not NULL and s."BusinessProcess3"  is NULL)) OR
((s."BusinessProcess4" != d."BusinessProcess4")  OR (s."BusinessProcess4"  is not NULL and d."BusinessProcess4"  is NULL) OR (d."BusinessProcess4"  is not NULL and s."BusinessProcess4"  is NULL)) OR
((s."BusinessProcess5" != d."BusinessProcess5")  OR (s."BusinessProcess5"  is not NULL and d."BusinessProcess5"  is NULL) OR (d."BusinessProcess5"  is not NULL and s."BusinessProcess5"  is NULL)) OR
((s."BusinessProcess6" != d."BusinessProcess6")  OR (s."BusinessProcess6"  is not NULL and d."BusinessProcess6"  is NULL) OR (d."BusinessProcess6"  is not NULL and s."BusinessProcess6"  is NULL)) OR
((s."BusinessProcess7" != d."BusinessProcess7")  OR (s."BusinessProcess7"  is not NULL and d."BusinessProcess7"  is NULL) OR (d."BusinessProcess7"  is not NULL and s."BusinessProcess7"  is NULL)) OR
((s."BusinessProcess8" != d."BusinessProcess8")  OR (s."BusinessProcess8"  is not NULL and d."BusinessProcess8"  is NULL) OR (d."BusinessProcess8"  is not NULL and s."BusinessProcess8"  is NULL)) OR
((s."BusinessProcess9" != d."BusinessProcess9")  OR (s."BusinessProcess9"  is not NULL and d."BusinessProcess9"  is NULL) OR (d."BusinessProcess9"  is not NULL and s."BusinessProcess9"  is NULL)) OR
((s."BusinessProcess10" != d."BusinessProcess10")  OR (s."BusinessProcess10"  is not NULL and d."BusinessProcess10"  is NULL) OR (d."BusinessProcess10"  is not NULL and s."BusinessProcess10"  is NULL)) OR
((s."AnalysisRequired" != d."AnalysisRequired")  OR (s."AnalysisRequired"  is not NULL and d."AnalysisRequired"  is NULL) OR (d."AnalysisRequired"  is not NULL and s."AnalysisRequired"  is NULL)) OR
((s."AnalysisCategory" != d."AnalysisCategory")  OR (s."AnalysisCategory"  is not NULL and d."AnalysisCategory"  is NULL) OR (d."AnalysisCategory"  is not NULL and s."AnalysisCategory"  is NULL)) OR
((s."CurrentInd" != d."CurrentInd")  OR (s."CurrentInd"  is not NULL and d."CurrentInd"  is NULL) OR (d."CurrentInd"  is not NULL and s."CurrentInd"  is NULL)) OR
((s."RetEarnsAccount" != d."RetEarnsAccount")  OR (s."RetEarnsAccount"  is not NULL and d."RetEarnsAccount"  is NULL) OR (d."RetEarnsAccount"  is not NULL and s."RetEarnsAccount"  is NULL)) OR
((s."TaxAccount" != d."TaxAccount")  OR (s."TaxAccount"  is not NULL and d."TaxAccount"  is NULL) OR (d."TaxAccount"  is not NULL and s."TaxAccount"  is NULL)) OR
((s."InterestAccount" != d."InterestAccount") OR (s."InterestAccount"  is not NULL and d."InterestAccount"  is NULL) OR (d."InterestAccount"  is not NULL and s."InterestAccount"  is NULL)) 
);
END;
