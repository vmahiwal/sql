--InvPricemain_stg0_gp



BEGIN;
--insert Query
insert into sysprocompanyb.invpricemain_stg0_gp select s.* from sysprocompanyb.invpricemain_stg0 s 
LEFT JOIN sysprocompanyb.invpricemain_stg0_gp d ON s."StockCode"=d."StockCode" and s."PriceCode"=d."PriceCode" where 
d."StockCode" is null and d."PriceCode" is null;

--Delete Query
delete from sysprocompanyb.invpricemain_stg0_gp where
(sysprocompanyb.invpricemain_stg0_gp."StockCode",sysprocompanyb.invpricemain_stg0_gp."PriceCode")
in
(
  select d."StockCode",d."PriceCode"
  from
  sysprocompanyb.invpricemain_stg0_gp d
  left join   sysprocompanyb.invpricemain_stg0 s
  on
  s."StockCode"=d."StockCode" and 
  s."PriceCode"=d."PriceCode" 
  where   s."StockCode" is null and s."PriceCode" is null
);	

--update Query
UPDATE sysprocompanyb.invpricemain_stg0_gp d
SET
"time" = s."time",
"StockCode" = s."StockCode",
"PriceCode" = s."PriceCode",
"SellingPrice" = s."SellingPrice",
"PriceBasis" = s."PriceBasis",
"CommissionCode" = s."CommissionCode"
FROM sysprocompanyb.invpricemain_stg0 s
WHERE (s."StockCode"=d."StockCode" and s."PriceCode"=d."PriceCode") and
(
((s."StockCode" != d."StockCode")  OR (s."StockCode"  is not NULL and d."StockCode"  is NULL) OR (d."StockCode"  is not NULL and s."StockCode"  is NULL)) OR
((s."PriceCode" != d."PriceCode")  OR (s."PriceCode"  is not NULL and d."PriceCode"  is NULL) OR (d."PriceCode"  is not NULL and s."PriceCode"  is NULL)) OR
((s."SellingPrice" != d."SellingPrice")  OR (s."SellingPrice"  is not NULL and d."SellingPrice"  is NULL) OR (d."SellingPrice"  is not NULL and s."SellingPrice"  is NULL)) OR
((s."PriceBasis" != d."PriceBasis")  OR (s."PriceBasis"  is not NULL and d."PriceBasis"  is NULL) OR (d."PriceBasis"  is not NULL and s."PriceBasis"  is NULL)) OR
((s."CommissionCode" != d."CommissionCode") OR (s."CommissionCode"  is not NULL and d."CommissionCode"  is NULL) OR (d."CommissionCode"  is not NULL and s."CommissionCode"  is NULL)) 
);


END;
