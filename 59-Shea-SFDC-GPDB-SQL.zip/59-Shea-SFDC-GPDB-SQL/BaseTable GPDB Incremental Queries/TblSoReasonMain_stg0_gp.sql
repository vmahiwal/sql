--TblSoReasonMain_stg0_gp


BEGIN;
insert into sysprocompanyb.tblsoreasonmain_stg0_gp select s.*
from sysprocompanyb.tblsoreasonmain_stg0 s LEFT JOIN 
sysprocompanyb.tblsoreasonmain_stg0_gp d
ON s."ReasonCode"=d."ReasonCode" where d."ReasonCode" is null ;
Savepoint sp2;
--Delete
delete from sysprocompanyb.tblsoreasonmain_stg0_gp
where sysprocompanyb.tblsoreasonmain_stg0_gp."ReasonCode"
in
(
select d."ReasonCode"
from
sysprocompanyb.tblsoreasonmain_stg0_gp d
left join
sysprocompanyb.tblsoreasonmain_stg0 s
on
s."ReasonCode"=d."ReasonCode"
where s."ReasonCode" is null
);
UPDATE sysprocompanyb.tblsoreasonmain_stg0_gp d
SET
"time"=s."time",
"Description" = s."Description",
"IoLostSaleFlag" = s."IoLostSaleFlag",
"TimeStamp" = s."TimeStamp"
FROM sysprocompanyb.tblsoreasonmain_stg0 s
Where (s."ReasonCode"=d."ReasonCode") and
(
((s."Description" != d."Description")  OR (s."Description"  is not NULL and d."Description"  is NULL) OR (d."Description"  is not NULL and s."Description"  is NULL)) OR
((s."IoLostSaleFlag" != d."IoLostSaleFlag") OR (s."IoLostSaleFlag"  is not NULL and d."IoLostSaleFlag"  is NULL) OR (d."IoLostSaleFlag"  is not NULL and s."IoLostSaleFlag"  is NULL)) 
);
END;
