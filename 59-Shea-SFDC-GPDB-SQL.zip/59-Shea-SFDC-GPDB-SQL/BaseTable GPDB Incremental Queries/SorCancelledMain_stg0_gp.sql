--SorCancelledMain_stg0_gp


BEGIN;
insert into sysprocompanyb.sorcancelledmain_stg0_gp select s.*
from sysprocompanyb.sorcancelledmain_stg0 s 
LEFT JOIN sysprocompanyb.sorcancelledmain_stg0_gp d
ON (s."SalesOrder"=d."SalesOrder" 
and s."SalesOrderLine"=d."SalesOrderLine"
and s."TrnTime"=d."TrnTime"
and s."TrnDate"=d."TrnDate") 
where (d."SalesOrder" is null and d."SalesOrderLine" is null 
and d."TrnDate" is null and d."TrnTime" is null);
Savepoint sp2;

--Delete
delete from sysprocompanyb.sorcancelledmain_stg0_gp 
where (sysprocompanyb.sorcancelledmain_stg0_gp."SalesOrder",
sysprocompanyb.sorcancelledmain_stg0_gp."SalesOrderLine",
sysprocompanyb.sorcancelledmain_stg0_gp."TrnTime",
sysprocompanyb.sorcancelledmain_stg0_gp."TrnDate")
in
(
select d."SalesOrder",d."SalesOrderLine",
d."TrnTime", d."TrnDate"
from
sysprocompanyb.sorcancelledmain_stg0_gp d
left join sysprocompanyb.sorcancelledmain_stg0 s
on
s."SalesOrder"=d."SalesOrder" 
and s."SalesOrderLine"=d."SalesOrderLine"
and s."TrnTime"=d."TrnTime"
and s."TrnDate"=d."TrnDate"
where s."SalesOrder" is null and s."SalesOrderLine" is null 
and s."TrnDate" is null and s."TrnTime" is null
);
UPDATE sysprocompanyb.sorcancelledmain_stg0_gp d
SET
"time"=s."time",
"Area" = s."Area",
"Branch" = s."Branch",
"CancelledValue" = s."CancelledValue",
"Customer" = s."Customer",
"Description" = s."Description",
"DocumentType" = s."DocumentType",
"LineType" = s."LineType",
"Operator" = s."Operator",
"OrderQty" = s."OrderQty",
"OrderUom" = s."OrderUom",
"ProductClass" = s."ProductClass",
"Reason" = s."Reason",
"Salesperson" = s."Salesperson",
"StockCode" = s."StockCode",
"TaxCode" = s."TaxCode",
"TimeStamp" = s."TimeStamp",
"UserField1" = s."UserField1",
"Warehouse" = s."Warehouse"
FROM sysprocompanyb.sorcancelledmain_stg0 s
Where (s."SalesOrder"=d."SalesOrder" 
and s."SalesOrderLine"=d."SalesOrderLine"
and s."TrnTime"=d."TrnTime" and s."TrnDate"=d."TrnDate") 
and
(
((s."Area" != d."Area")  OR (s."Area"  is not NULL and d."Area"  is NULL) OR (d."Area"  is not NULL and s."Area"  is NULL)) OR
((s."Branch" != d."Branch")  OR (s."Branch"  is not NULL and d."Branch"  is NULL) OR (d."Branch"  is not NULL and s."Branch"  is NULL)) OR
((s."CancelledValue" != d."CancelledValue")  OR (s."CancelledValue"  is not NULL and d."CancelledValue"  is NULL) OR (d."CancelledValue"  is not NULL and s."CancelledValue"  is NULL)) OR
((s."Customer" != d."Customer")  OR (s."Customer"  is not NULL and d."Customer"  is NULL) OR (d."Customer"  is not NULL and s."Customer"  is NULL)) OR
((s."Description" != d."Description")  OR (s."Description"  is not NULL and d."Description"  is NULL) OR (d."Description"  is not NULL and s."Description"  is NULL)) OR
((s."DocumentType" != d."DocumentType")  OR (s."DocumentType"  is not NULL and d."DocumentType"  is NULL) OR (d."DocumentType"  is not NULL and s."DocumentType"  is NULL)) OR
((s."LineType" != d."LineType")  OR (s."LineType"  is not NULL and d."LineType"  is NULL) OR (d."LineType"  is not NULL and s."LineType"  is NULL)) OR
((s."Operator" != d."Operator")  OR (s."Operator"  is not NULL and d."Operator"  is NULL) OR (d."Operator"  is not NULL and s."Operator"  is NULL)) OR
((s."OrderQty" != d."OrderQty")  OR (s."OrderQty"  is not NULL and d."OrderQty"  is NULL) OR (d."OrderQty"  is not NULL and s."OrderQty"  is NULL)) OR
((s."OrderUom" != d."OrderUom")  OR (s."OrderUom"  is not NULL and d."OrderUom"  is NULL) OR (d."OrderUom"  is not NULL and s."OrderUom"  is NULL)) OR
((s."ProductClass" != d."ProductClass")  OR (s."ProductClass"  is not NULL and d."ProductClass"  is NULL) OR (d."ProductClass"  is not NULL and s."ProductClass"  is NULL)) OR
((s."Reason" != d."Reason")  OR (s."Reason"  is not NULL and d."Reason"  is NULL) OR (d."Reason"  is not NULL and s."Reason"  is NULL)) OR
((s."Salesperson" != d."Salesperson") OR (s."Salesperson"  is not NULL and d."Salesperson"  is NULL) OR (d."Salesperson"  is not NULL and s."Salesperson"  is NULL)) OR
((s."StockCode" != d."StockCode")  OR (s."StockCode"  is not NULL and d."StockCode"  is NULL) OR (d."StockCode"  is not NULL and s."StockCode"  is NULL)) OR
((s."TaxCode" != d."TaxCode")   OR (s."TaxCode"  is not NULL and d."TaxCode"  is NULL) OR (d."TaxCode"  is not NULL and s."TaxCode"  is NULL)) OR
((s."UserField1" != d."UserField1")  OR (s."UserField1"  is not NULL and d."UserField1"  is NULL) OR (d."UserField1"  is not NULL and s."UserField1"  is NULL)) OR
((s."Warehouse" != d."Warehouse") OR (s."Warehouse"  is not NULL and d."Warehouse"  is NULL) OR (d."Warehouse"  is not NULL and s."Warehouse"  is NULL))
);
END;
