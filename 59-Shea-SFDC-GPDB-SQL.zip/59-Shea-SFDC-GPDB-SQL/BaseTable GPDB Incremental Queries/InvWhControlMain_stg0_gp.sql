--InvWhControlmain_stg0_gp


BEGIN;
insert into sysprocompanyb.invwhcontrolmain_stg0_gp select s.*
from sysprocompanyb.invwhcontrolmain_stg0 s
 LEFT JOIN sysprocompanyb.invwhcontrolmain_stg0_gp d
ON s."Warehouse"=d."Warehouse" where d."Warehouse" is null ;

--Delete
delete from sysprocompanyb.invwhcontrolmain_stg0_gp
where sysprocompanyb.invwhcontrolmain_stg0_gp."Warehouse"
in
(
select d."Warehouse"
from sysprocompanyb.invwhcontrolmain_stg0_gp d
left join sysprocompanyb.invwhcontrolmain_stg0 s
on s."Warehouse"=d."Warehouse"
where s."Warehouse" is null
);

UPDATE sysprocompanyb.invwhcontrolmain_stg0_gp d
SET
"time"= s."time",
"Description" = s."Description",
"MtdTrnsVar" = s."MtdTrnsVar",
"NextTicketNo" = s."NextTicketNo",
"StockTakeFlag" = s."StockTakeFlag",
"WhLdgCtlAcc" = s."WhLdgCtlAcc",
"WhVarLdg" = s."WhVarLdg",
"TrnMonth" = s."TrnMonth",
"TrnYear" = s."TrnYear",
"GrnLdgAcc" = s."GrnLdgAcc",
"DeliveryAddr1" = s."DeliveryAddr1",
"DeliveryAddr2" = s."DeliveryAddr2",
"DeliveryAddr3" = s."DeliveryAddr3",
"DeliveryAddr3Loc" = s."DeliveryAddr3Loc",
"DeliveryAddr4" = s."DeliveryAddr4",
"DeliveryAddr5" = s."DeliveryAddr5",
"PostalCode" = s."PostalCode",
"DeliveryGpsLat" = s."DeliveryGpsLat",
"DeliveryGpsLong" = s."DeliveryGpsLong",
"NegStockAllow" = s."NegStockAllow",
"GtrCtlAccl" = s."GtrCtlAccl",
"GtrPrefix" = s."GtrPrefix",
"GtrNextNo" = s."GtrNextNo",
"Branch" = s."Branch",
"Area" = s."Area",
"FaxContact" = s."FaxContact",
"Fax" = s."Fax",
"FaxDocIwsFlag" = s."FaxDocIwsFlag",
"GitAdjAcc" = s."GitAdjAcc",
"WhForComp" = s."WhForComp",
"Route" = s."Route",
"InclPlanning" = s."InclPlanning",
"UseMultipleBins" = s."UseMultipleBins",
"CostingMethod" = s."CostingMethod",
"UseFifoBuckets" = s."UseFifoBuckets",
"PoPrefix" = s."PoPrefix",
"PoNextNumber" = s."PoNextNumber",
"GrnPrefix" = s."GrnPrefix",
"GrnNextNumber" = s."GrnNextNumber",
"WipInspectGlCode" = s."WipInspectGlCode",
"Nationality" = s."Nationality",
"SoDefaultDoc" = s."SoDefaultDoc",
"RouteCode" = s."RouteCode",
"RouteDistance" = s."RouteDistance",
"WipControlGlCode" = s."WipControlGlCode",
"WipVarCtlGlCode" = s."WipVarCtlGlCode",
"WipAutoVarGlCode" = s."WipAutoVarGlCode",
"SiteId" = s."SiteId",
"RollParentGl" = s."RollParentGl",
"WmsActive" = s."WmsActive",
"PickLeadHours" = s."PickLeadHours",
"StockTakeUpdate" = s."StockTakeUpdate",
"NonStockedGl" = s."NonStockedGl",
"State" = s."State",
"CountyZip" = s."CountyZip",
"City" = s."City",
"LanguageCode" = s."LanguageCode",
"ShippingLocation" = s."ShippingLocation",
"DeliveryTerms" = s."DeliveryTerms",
"UseFixedBins" = s."UseFixedBins",
"TimeStamp" = s."TimeStamp"
FROM sysprocompanyb.invwhcontrolmain_stg0 s
Where (s."Warehouse"=d."Warehouse") and
(
((s."Description" != d."Description")  OR (s."Description"  is not NULL and d."Description"  is NULL) OR (d."Description"  is not NULL and s."Description"  is NULL)) OR
((s."MtdTrnsVar" != d."MtdTrnsVar")  OR (s."MtdTrnsVar"  is not NULL and d."MtdTrnsVar"  is NULL) OR (d."MtdTrnsVar"  is not NULL and s."MtdTrnsVar"  is NULL)) OR
((s."NextTicketNo" != d."NextTicketNo")  OR (s."NextTicketNo"  is not NULL and d."NextTicketNo"  is NULL) OR (d."NextTicketNo"  is not NULL and s."NextTicketNo"  is NULL)) OR
((s."StockTakeFlag" != d."StockTakeFlag")  OR (s."StockTakeFlag"  is not NULL and d."StockTakeFlag"  is NULL) OR (d."StockTakeFlag"  is not NULL and s."StockTakeFlag"  is NULL)) OR
((s."WhLdgCtlAcc" != d."WhLdgCtlAcc")  OR (s."WhLdgCtlAcc"  is not NULL and d."WhLdgCtlAcc"  is NULL) OR (d."WhLdgCtlAcc"  is not NULL and s."WhLdgCtlAcc"  is NULL)) OR
((s."WhVarLdg" != d."WhVarLdg")  OR (s."WhVarLdg"  is not NULL and d."WhVarLdg"  is NULL) OR (d."WhVarLdg"  is not NULL and s."WhVarLdg"  is NULL)) OR
((s."TrnMonth" != d."TrnMonth")  OR (s."TrnMonth"  is not NULL and d."TrnMonth"  is NULL) OR (d."TrnMonth"  is not NULL and s."TrnMonth"  is NULL)) OR
((s."TrnYear" != d."TrnYear")  OR (s."TrnYear"  is not NULL and d."TrnYear"  is NULL) OR (d."TrnYear"  is not NULL and s."TrnYear"  is NULL)) OR
((s."GrnLdgAcc" != d."GrnLdgAcc")  OR (s."GrnLdgAcc"  is not NULL and d."GrnLdgAcc"  is NULL) OR (d."GrnLdgAcc"  is not NULL and s."GrnLdgAcc"  is NULL)) OR
((s."DeliveryAddr1" != d."DeliveryAddr1")  OR (s."DeliveryAddr1"  is not NULL and d."DeliveryAddr1"  is NULL) OR (d."DeliveryAddr1"  is not NULL and s."DeliveryAddr1"  is NULL)) OR
((s."DeliveryAddr2" != d."DeliveryAddr2")  OR (s."DeliveryAddr2"  is not NULL and d."DeliveryAddr2"  is NULL) OR (d."DeliveryAddr2"  is not NULL and s."DeliveryAddr2"  is NULL)) OR
((s."DeliveryAddr3" != d."DeliveryAddr3")  OR (s."DeliveryAddr3"  is not NULL and d."DeliveryAddr3"  is NULL) OR (d."DeliveryAddr3"  is not NULL and s."DeliveryAddr3"  is NULL)) OR
((s."DeliveryAddr3Loc" != d."DeliveryAddr3Loc")  OR (s."DeliveryAddr3Loc"  is not NULL and d."DeliveryAddr3Loc"  is NULL) OR (d."DeliveryAddr3Loc"  is not NULL and s."DeliveryAddr3Loc"  is NULL)) OR
((s."DeliveryAddr4" != d."DeliveryAddr4")  OR (s."DeliveryAddr4"  is not NULL and d."DeliveryAddr4"  is NULL) OR (d."DeliveryAddr4"  is not NULL and s."DeliveryAddr4"  is NULL)) OR
((s."DeliveryAddr5" != d."DeliveryAddr5")  OR (s."DeliveryAddr5"  is not NULL and d."DeliveryAddr5"  is NULL) OR (d."DeliveryAddr5"  is not NULL and s."DeliveryAddr5"  is NULL)) OR
((s."PostalCode" != d."PostalCode")  OR (s."PostalCode"  is not NULL and d."PostalCode"  is NULL) OR (d."PostalCode"  is not NULL and s."PostalCode"  is NULL)) OR
((s."DeliveryGpsLat" != d."DeliveryGpsLat")  OR (s."DeliveryGpsLat"  is not NULL and d."DeliveryGpsLat"  is NULL) OR (d."DeliveryGpsLat"  is not NULL and s."DeliveryGpsLat"  is NULL)) OR
((s."DeliveryGpsLong" != d."DeliveryGpsLong")  OR (s."DeliveryGpsLong"  is not NULL and d."DeliveryGpsLong"  is NULL) OR (d."DeliveryGpsLong"  is not NULL and s."DeliveryGpsLong"  is NULL)) OR
((s."NegStockAllow" != d."NegStockAllow")  OR (s."NegStockAllow"  is not NULL and d."NegStockAllow"  is NULL) OR (d."NegStockAllow"  is not NULL and s."NegStockAllow"  is NULL)) OR
((s."GtrCtlAccl" != d."GtrCtlAccl")  OR (s."GtrCtlAccl"  is not NULL and d."GtrCtlAccl"  is NULL) OR (d."GtrCtlAccl"  is not NULL and s."GtrCtlAccl"  is NULL)) OR
((s."GtrPrefix" != d."GtrPrefix")  OR (s."GtrPrefix"  is not NULL and d."GtrPrefix"  is NULL) OR (d."GtrPrefix"  is not NULL and s."GtrPrefix"  is NULL)) OR
((s."GtrNextNo" != d."GtrNextNo")  OR (s."GtrNextNo"  is not NULL and d."GtrNextNo"  is NULL) OR (d."GtrNextNo"  is not NULL and s."GtrNextNo"  is NULL)) OR
((s."Branch" != d."Branch")  OR (s."Branch"  is not NULL and d."Branch"  is NULL) OR (d."Branch"  is not NULL and s."Branch"  is NULL)) OR
((s."Area" != d."Area")  OR (s."Area"  is not NULL and d."Area"  is NULL) OR (d."Area"  is not NULL and s."Area"  is NULL)) OR
((s."FaxContact" != d."FaxContact")  OR (s."FaxContact"  is not NULL and d."FaxContact"  is NULL) OR (d."FaxContact"  is not NULL and s."FaxContact"  is NULL)) OR
((s."Fax" != d."Fax")  OR (s."Fax"  is not NULL and d."Fax"  is NULL) OR (d."Fax"  is not NULL and s."Fax"  is NULL)) OR
((s."FaxDocIwsFlag" != d."FaxDocIwsFlag")  OR (s."FaxDocIwsFlag"  is not NULL and d."FaxDocIwsFlag"  is NULL) OR (d."FaxDocIwsFlag"  is not NULL and s."FaxDocIwsFlag"  is NULL)) OR
((s."GitAdjAcc" != d."GitAdjAcc")  OR (s."GitAdjAcc"  is not NULL and d."GitAdjAcc"  is NULL) OR (d."GitAdjAcc"  is not NULL and s."GitAdjAcc"  is NULL)) OR
((s."WhForComp" != d."WhForComp")  OR (s."WhForComp"  is not NULL and d."WhForComp"  is NULL) OR (d."WhForComp"  is not NULL and s."WhForComp"  is NULL)) OR
((s."Route" != d."Route")  OR (s."Route"  is not NULL and d."Route"  is NULL) OR (d."Route"  is not NULL and s."Route"  is NULL)) OR
((s."InclPlanning" != d."InclPlanning")  OR (s."InclPlanning"  is not NULL and d."InclPlanning"  is NULL) OR (d."InclPlanning"  is not NULL and s."InclPlanning"  is NULL)) OR
((s."UseMultipleBins" != d."UseMultipleBins")  OR (s."UseMultipleBins"  is not NULL and d."UseMultipleBins"  is NULL) OR (d."UseMultipleBins"  is not NULL and s."UseMultipleBins"  is NULL)) OR
((s."CostingMethod" != d."CostingMethod")  OR (s."CostingMethod"  is not NULL and d."CostingMethod"  is NULL) OR (d."CostingMethod"  is not NULL and s."CostingMethod"  is NULL)) OR
((s."UseFifoBuckets" != d."UseFifoBuckets")  OR (s."UseFifoBuckets"  is not NULL and d."UseFifoBuckets"  is NULL) OR (d."UseFifoBuckets"  is not NULL and s."UseFifoBuckets"  is NULL)) OR
((s."PoPrefix" != d."PoPrefix")  OR (s."PoPrefix"  is not NULL and d."PoPrefix"  is NULL) OR (d."PoPrefix"  is not NULL and s."PoPrefix"  is NULL)) OR
((s."PoNextNumber" != d."PoNextNumber")  OR (s."PoNextNumber"  is not NULL and d."PoNextNumber"  is NULL) OR (d."PoNextNumber"  is not NULL and s."PoNextNumber"  is NULL)) OR
((s."GrnPrefix" != d."GrnPrefix")  OR (s."GrnPrefix"  is not NULL and d."GrnPrefix"  is NULL) OR (d."GrnPrefix"  is not NULL and s."GrnPrefix"  is NULL)) OR
((s."GrnNextNumber" != d."GrnNextNumber")  OR (s."GrnNextNumber"  is not NULL and d."GrnNextNumber"  is NULL) OR (d."GrnNextNumber"  is not NULL and s."GrnNextNumber"  is NULL)) OR
((s."WipInspectGlCode" != d."WipInspectGlCode")  OR (s."WipInspectGlCode"  is not NULL and d."WipInspectGlCode"  is NULL) OR (d."WipInspectGlCode"  is not NULL and s."WipInspectGlCode"  is NULL)) OR
((s."Nationality" != d."Nationality")  OR (s."Nationality"  is not NULL and d."Nationality"  is NULL) OR (d."Nationality"  is not NULL and s."Nationality"  is NULL)) OR
((s."SoDefaultDoc" != d."SoDefaultDoc")  OR (s."SoDefaultDoc"  is not NULL and d."SoDefaultDoc"  is NULL) OR (d."SoDefaultDoc"  is not NULL and s."SoDefaultDoc"  is NULL)) OR
((s."RouteCode" != d."RouteCode")  OR (s."RouteCode"  is not NULL and d."RouteCode"  is NULL) OR (d."RouteCode"  is not NULL and s."RouteCode"  is NULL)) OR
((s."RouteDistance" != d."RouteDistance")  OR (s."RouteDistance"  is not NULL and d."RouteDistance"  is NULL) OR (d."RouteDistance"  is not NULL and s."RouteDistance"  is NULL)) OR
((s."WipControlGlCode" != d."WipControlGlCode")  OR (s."WipControlGlCode"  is not NULL and d."WipControlGlCode"  is NULL) OR (d."WipControlGlCode"  is not NULL and s."WipControlGlCode"  is NULL)) OR
((s."WipVarCtlGlCode" != d."WipVarCtlGlCode")  OR (s."WipVarCtlGlCode"  is not NULL and d."WipVarCtlGlCode"  is NULL) OR (d."WipVarCtlGlCode"  is not NULL and s."WipVarCtlGlCode"  is NULL)) OR
((s."WipAutoVarGlCode" != d."WipAutoVarGlCode")  OR (s."WipAutoVarGlCode"  is not NULL and d."WipAutoVarGlCode"  is NULL) OR (d."WipAutoVarGlCode"  is not NULL and s."WipAutoVarGlCode"  is NULL)) OR
((s."SiteId" != d."SiteId")  OR (s."SiteId"  is not NULL and d."SiteId"  is NULL) OR (d."SiteId"  is not NULL and s."SiteId"  is NULL)) OR
((s."RollParentGl" != d."RollParentGl")  OR (s."RollParentGl"  is not NULL and d."RollParentGl"  is NULL) OR (d."RollParentGl"  is not NULL and s."RollParentGl"  is NULL)) OR
((s."WmsActive" != d."WmsActive")  OR (s."WmsActive"  is not NULL and d."WmsActive"  is NULL) OR (d."WmsActive"  is not NULL and s."WmsActive"  is NULL)) OR
((s."PickLeadHours" != d."PickLeadHours")  OR (s."PickLeadHours"  is not NULL and d."PickLeadHours"  is NULL) OR (d."PickLeadHours"  is not NULL and s."PickLeadHours"  is NULL)) OR
((s."StockTakeUpdate" != d."StockTakeUpdate")  OR (s."StockTakeUpdate"  is not NULL and d."StockTakeUpdate"  is NULL) OR (d."StockTakeUpdate"  is not NULL and s."StockTakeUpdate"  is NULL)) OR
((s."NonStockedGl" != d."NonStockedGl")  OR (s."NonStockedGl"  is not NULL and d."NonStockedGl"  is NULL) OR (d."NonStockedGl"  is not NULL and s."NonStockedGl"  is NULL)) OR
((s."State" != d."State")  OR (s."State"  is not NULL and d."State"  is NULL) OR (d."State"  is not NULL and s."State"  is NULL)) OR
((s."CountyZip" != d."CountyZip")  OR (s."CountyZip"  is not NULL and d."CountyZip"  is NULL) OR (d."CountyZip"  is not NULL and s."CountyZip"  is NULL)) OR
((s."City" != d."City")  OR (s."City"  is not NULL and d."City"  is NULL) OR (d."City"  is not NULL and s."City"  is NULL)) OR
((s."LanguageCode" != d."LanguageCode")  OR (s."LanguageCode"  is not NULL and d."LanguageCode"  is NULL) OR (d."LanguageCode"  is not NULL and s."LanguageCode"  is NULL)) OR
((s."ShippingLocation" != d."ShippingLocation")  OR (s."ShippingLocation"  is not NULL and d."ShippingLocation"  is NULL) OR (d."ShippingLocation"  is not NULL and s."ShippingLocation"  is NULL)) OR
((s."DeliveryTerms" != d."DeliveryTerms")  OR (s."DeliveryTerms"  is not NULL and d."DeliveryTerms"  is NULL) OR (d."DeliveryTerms"  is not NULL and s."DeliveryTerms"  is NULL)) OR
((s."UseFixedBins" != d."UseFixedBins") OR (s."UseFixedBins"  is not NULL and d."UseFixedBins"  is NULL) OR (d."UseFixedBins"  is not NULL and s."UseFixedBins"  is NULL)) 
);
END;
