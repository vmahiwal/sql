--SorDetailMain_stg0_gp


BEGIN;
insert into sysprocompanyb.sordetailmain_stg0_gp select s.*  from sysprocompanyb.sordetailmain_stg0 s LEFT JOIN sysprocompanyb.sordetailmain_stg0_gp d ON (s."SalesOrder"=d."SalesOrder" and s."SalesOrderLine"=d."SalesOrderLine") where (d."SalesOrder" is null and d."SalesOrderLine" is null) ;  
SAVEPOINT sd;

delete from sysprocompanyb.sordetailmain_stg0_gp  where
(sysprocompanyb.sordetailmain_stg0_gp."SalesOrder",sysprocompanyb.sordetailmain_stg0_gp."SalesOrderLine")
in
(
  select d."SalesOrder",d."SalesOrderLine"
  from
  sysprocompanyb.sordetailmain_stg0_gp d   left join   sysprocompanyb.sordetailmain_stg0 s
  on   s."SalesOrder"=d."SalesOrder" and s."SalesOrderLine"=d."SalesOrderLine" 
  where 
  s."SalesOrder" is null and s."SalesOrderLine" is null
);
---Update
UPDATE sysprocompanyb.sordetailmain_stg0_gp d
SET
"time" = s."time",
"LineType" = s."LineType",
"MStockCode" = s."MStockCode",
"MStockDes" = s."MStockDes",
"MWarehouse" = s."MWarehouse",
"MOrderQty" = s."MOrderQty",
"MShipQty" = s."MShipQty",
"MBackOrderQty" = s."MBackOrderQty",
"MUnitCost" = s."MUnitCost",
"MOrderUom" = s."MOrderUom",
"MConvFactOrdUm" = s."MConvFactOrdUm",
"MPrice" = s."MPrice",
"MPriceUom" = s."MPriceUom",
"MDiscPct1" = s."MDiscPct1",
"MDiscPct2" = s."MDiscPct2",
"MDiscPct3" = s."MDiscPct3",
"MDiscValFlag" = s."MDiscValFlag",
"MDiscValue" = s."MDiscValue",
"MProductClass" = s."MProductClass",
"MLineShipDate" = s."MLineShipDate",
"MCustRequestDat" = s."MCustRequestDat",
"NComment" = s."NComment"
FROM sysprocompanyb.sordetailmain_stg0 s 
WHERE
(s."SalesOrder" = d."SalesOrder" AND
s."SalesOrderLine" = d."SalesOrderLine")
AND 
(
((s."LineType" != d."LineType")  OR (s."LineType"  is not NULL and d."LineType"  is NULL) OR (d."LineType"  is not NULL and s."LineType"  is NULL)) OR
((s."MStockCode" != d."MStockCode")  OR (s."MStockCode"  is not NULL and d."MStockCode"  is NULL) OR (d."MStockCode"  is not NULL and s."MStockCode"  is NULL)) OR
((s."MStockDes" != d."MStockDes")  OR (s."MStockDes"  is not NULL and d."MStockDes"  is NULL) OR (d."MStockDes"  is not NULL and s."MStockDes"  is NULL)) OR
((s."MWarehouse" != d."MWarehouse")  OR (s."MWarehouse"  is not NULL and d."MWarehouse"  is NULL) OR (d."MWarehouse"  is not NULL and s."MWarehouse"  is NULL)) OR
((s."MOrderQty" != d."MOrderQty")  OR (s."MOrderQty"  is not NULL and d."MOrderQty"  is NULL) OR (d."MOrderQty"  is not NULL and s."MOrderQty"  is NULL)) OR
((s."MShipQty" != d."MShipQty")  OR (s."MShipQty"  is not NULL and d."MShipQty"  is NULL) OR (d."MShipQty"  is not NULL and s."MShipQty"  is NULL)) OR
((s."MBackOrderQty" != d."MBackOrderQty")  OR (s."MBackOrderQty"  is not NULL and d."MBackOrderQty"  is NULL) OR (d."MBackOrderQty"  is not NULL and s."MBackOrderQty"  is NULL)) OR
((s."MUnitCost" != d."MUnitCost")  OR (s."MUnitCost"  is not NULL and d."MUnitCost"  is NULL) OR (d."MUnitCost"  is not NULL and s."MUnitCost"  is NULL)) OR
((s."MOrderUom" != d."MOrderUom")  OR (s."MOrderUom"  is not NULL and d."MOrderUom"  is NULL) OR (d."MOrderUom"  is not NULL and s."MOrderUom"  is NULL)) OR
((s."MConvFactOrdUm" != d."MConvFactOrdUm")  OR (s."MConvFactOrdUm"  is not NULL and d."MConvFactOrdUm"  is NULL) OR (d."MConvFactOrdUm"  is not NULL and s."MConvFactOrdUm"  is NULL)) OR
((s."MPrice" != d."MPrice")  OR (s."MPrice"  is not NULL and d."MPrice"  is NULL) OR (d."MPrice"  is not NULL and s."MPrice"  is NULL)) OR
((s."MPriceUom" != d."MPriceUom")  OR (s."MPriceUom"  is not NULL and d."MPriceUom"  is NULL) OR (d."MPriceUom"  is not NULL and s."MPriceUom"  is NULL)) OR
((s."MDiscPct1" != d."MDiscPct1") OR (s."MDiscPct1"  is not NULL and d."MDiscPct1"  is NULL) OR (d."MDiscPct1"  is not NULL and s."MDiscPct1"  is NULL)) OR
((s."MDiscPct2" != d."MDiscPct2")  OR (s."MDiscPct2"  is not NULL and d."MDiscPct2"  is NULL) OR (d."MDiscPct2"  is not NULL and s."MDiscPct2"  is NULL)) OR
((s."MDiscPct3" != d."MDiscPct3")  OR (s."MDiscPct3"  is not NULL and d."MDiscPct3"  is NULL) OR (d."MDiscPct3"  is not NULL and s."MDiscPct3"  is NULL)) OR
((s."MDiscValFlag" != d."MDiscValFlag")  OR (s."MDiscValFlag"  is not NULL and d."MDiscValFlag"  is NULL) OR (d."MDiscValFlag"  is not NULL and s."MDiscValFlag"  is NULL)) OR
((s."MDiscValue" != d."MDiscValue") OR (s."MDiscValue"  is not NULL and d."MDiscValue"  is NULL) OR (d."MDiscValue"  is not NULL and s."MDiscValue"  is NULL)) OR
((s."MProductClass" != d."MProductClass")  OR (s."MProductClass"  is not NULL and d."MProductClass"  is NULL) OR (d."MProductClass"  is not NULL and s."MProductClass"  is NULL)) OR
((s."MLineShipDate" != d."MLineShipDate")  OR (s."MLineShipDate"  is not NULL and d."MLineShipDate"  is NULL) OR (d."MLineShipDate"  is not NULL and s."MLineShipDate"  is NULL)) OR
((s."MCustRequestDat" != d."MCustRequestDat")  OR (s."MCustRequestDat"  is not NULL and d."MCustRequestDat"  is NULL) OR (d."MCustRequestDat"  is not NULL and s."MCustRequestDat"  is NULL)) OR
((s."NComment" != d."NComment") OR (s."NComment"  is not NULL and d."NComment"  is NULL) OR (d."NComment"  is not NULL and s."NComment"  is NULL))
);

END;
