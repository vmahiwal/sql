--PorMasterDetailMain_stg0_gp



BEGIN;
insert into sysprocompanyb.pormasterdetailmain_stg0_gp 
select s.* from sysprocompanyb.pormasterdetailmain_stg0 s 
LEFT JOIN sysprocompanyb.pormasterdetailmain_stg0_gp d 
ON (s."PurchaseOrder"=d."PurchaseOrder" and s."Line"=d."Line") 
where (d."PurchaseOrder" is null and d."Line" is null) ;

SAVEPOINT sd;

delete from sysprocompanyb.pormasterdetailmain_stg0_gp where
(sysprocompanyb.pormasterdetailmain_stg0_gp."PurchaseOrder",
sysprocompanyb.pormasterdetailmain_stg0_gp."Line")
in
(
select d."PurchaseOrder",d."Line"
from sysprocompanyb.pormasterdetailmain_stg0_gp d 
left join sysprocompanyb.pormasterdetailmain_stg0 s
on s."PurchaseOrder"=d."PurchaseOrder" 
and s."Line"=d."Line"
where
s."PurchaseOrder" is null and s."Line" is null
);
---Update
UPDATE sysprocompanyb.pormasterdetailmain_stg0_gp d
SET
"time" = s."time",
"LineType" = s."LineType",
"MStockCode" = s."MStockCode",
"MStockDes" = s."MStockDes",
"MWarehouse" = s."MWarehouse",
"MOrderUom" = s."MOrderUom",
"MStockingUom" = s."MStockingUom",
"MOrderQty" = s."MOrderQty",
"MReceivedQty" = s."MReceivedQty",
"MLatestDueDate" = s."MLatestDueDate",
"MLastReceiptDat" = s."MLastReceiptDat",
"MSupCatalogue" = s."MSupCatalogue",
"MDiscPct1" = s."MDiscPct1",
"MDiscPct2" = s."MDiscPct2",
"MDiscPct3" = s."MDiscPct3",
"MDiscValFlag" = s."MDiscValFlag",
"MDiscValue" = s."MDiscValue",
"MPrice" = s."MPrice",
"MForeignPrice" = s."MForeignPrice",
"MDecimalsToPrt" = s."MDecimalsToPrt",
"MConvFactPrcUm" = s."MConvFactPrcUm",
"MMulDivPrc" = s."MMulDivPrc",
"MPriceUom" = s."MPriceUom",
"MTaxCode" = s."MTaxCode",
"MConvFactOrdUm" = s."MConvFactOrdUm",
"MMulDivAlloc" = s."MMulDivAlloc",
"MProductClass" = s."MProductClass",
"MCompleteFlag" = s."MCompleteFlag",
"MJob" = s."MJob",
"MJobLine" = s."MJobLine",
"MGlCode" = s."MGlCode",
"MUserAuthReqn" = s."MUserAuthReqn",
"MRequisition" = s."MRequisition",
"MRequisitionLine" = s."MRequisitionLine",
"MSalesOrder" = s."MSalesOrder",
"MSalesOrderLine" = s."MSalesOrderLine",
"MOrigDueDate" = s."MOrigDueDate",
"MReschedDueDate" = s."MReschedDueDate",
"MLctConfirmed" = s."MLctConfirmed",
"MOriginalLine" = s."MOriginalLine",
"MSubcontractOp" = s."MSubcontractOp",
"MEdiExtractFlag" = s."MEdiExtractFlag",
"MEdiActionFlag" = s."MEdiActionFlag",
"MInspectionReqd" = s."MInspectionReqd",
"MNonsUnitMass" = s."MNonsUnitMass",
"MNonsUnitVol" = s."MNonsUnitVol",
"MVersion" = s."MVersion",
"MRelease" = s."MRelease",
"NComment" = s."NComment",
"NCommentFromLin" = s."NCommentFromLin",
"NMscChargeValue" = s."NMscChargeValue",
"NMscChargePrint" = s."NMscChargePrint",
"NComPrintType" = s."NComPrintType",
"NMscChargeTax" = s."NMscChargeTax",
"NCommentFlag" = s."NCommentFlag",
"NMscChargeFor" = s."NMscChargeFor",
"NMscChargeFLoc" = s."NMscChargeFLoc",
"NEdiExtract" = s."NEdiExtract",
"MEccFlag" = s."MEccFlag",
"MBlanketDate" = s."MBlanketDate",
"MContractNumber" = s."MContractNumber",
"MBlanketContLine" = s."MBlanketContLine",
"AssetFlag" = s."AssetFlag",
"CapexCode" = s."CapexCode",
"CapexLine" = s."CapexLine",
"SelectionCode" = s."SelectionCode",
"SelectionType" = s."SelectionType",
"User1" = s."User1",
"OrderLineStatus" = s."OrderLineStatus",
"AutoVoucherReqd" = s."AutoVoucherReqd",
"IncludeInMrp" = s."IncludeInMrp",
"WithTaxExpenseType" = s."WithTaxExpenseType",
"TimeStamp" = s."TimeStamp"
FROM sysprocompanyb.pormasterdetailmain_stg0 s
WHERE
(s."PurchaseOrder" = d."PurchaseOrder" AND
s."Line" = d."Line")
AND
(
((s."LineType" != d."LineType")  OR (s."LineType"  is not NULL and d."LineType"  is NULL) OR (d."LineType"  is not NULL and s."LineType"  is NULL)) OR
((s."MStockCode" != d."MStockCode")  OR (s."MStockCode"  is not NULL and d."MStockCode"  is NULL) OR (d."MStockCode"  is not NULL and s."MStockCode"  is NULL)) OR
((s."MStockDes" != d."MStockDes")  OR (s."MStockDes"  is not NULL and d."MStockDes"  is NULL) OR (d."MStockDes"  is not NULL and s."MStockDes"  is NULL)) OR
((s."MWarehouse" != d."MWarehouse")  OR (s."MWarehouse"  is not NULL and d."MWarehouse"  is NULL) OR (d."MWarehouse"  is not NULL and s."MWarehouse"  is NULL)) OR
((s."MOrderUom" != d."MOrderUom")  OR (s."MOrderUom"  is not NULL and d."MOrderUom"  is NULL) OR (d."MOrderUom"  is not NULL and s."MOrderUom"  is NULL)) OR
((s."MStockingUom" != d."MStockingUom")  OR (s."MStockingUom"  is not NULL and d."MStockingUom"  is NULL) OR (d."MStockingUom"  is not NULL and s."MStockingUom"  is NULL)) OR
((s."MOrderQty" != d."MOrderQty")  OR (s."MOrderQty"  is not NULL and d."MOrderQty"  is NULL) OR (d."MOrderQty"  is not NULL and s."MOrderQty"  is NULL)) OR
((s."MReceivedQty" != d."MReceivedQty")  OR (s."MReceivedQty"  is not NULL and d."MReceivedQty"  is NULL) OR (d."MReceivedQty"  is not NULL and s."MReceivedQty"  is NULL)) OR
((s."MLatestDueDate" != d."MLatestDueDate")  OR (s."MLatestDueDate"  is not NULL and d."MLatestDueDate"  is NULL) OR (d."MLatestDueDate"  is not NULL and s."MLatestDueDate"  is NULL)) OR
((s."MLastReceiptDat" != d."MLastReceiptDat")  OR (s."MLastReceiptDat"  is not NULL and d."MLastReceiptDat"  is NULL) OR (d."MLastReceiptDat"  is not NULL and s."MLastReceiptDat"  is NULL)) OR
((s."MSupCatalogue" != d."MSupCatalogue")  OR (s."MSupCatalogue"  is not NULL and d."MSupCatalogue"  is NULL) OR (d."MSupCatalogue"  is not NULL and s."MSupCatalogue"  is NULL)) OR
((s."MDiscPct1" != d."MDiscPct1")  OR (s."MDiscPct1"  is not NULL and d."MDiscPct1"  is NULL) OR (d."MDiscPct1"  is not NULL and s."MDiscPct1"  is NULL)) OR
((s."MDiscPct2" != d."MDiscPct2") OR (s."MDiscPct2"  is not NULL and d."MDiscPct2"  is NULL) OR (d."MDiscPct2"  is not NULL and s."MDiscPct2"  is NULL)) OR
((s."MDiscPct3" != d."MDiscPct3")  OR (s."MDiscPct3"  is not NULL and d."MDiscPct3"  is NULL) OR (d."MDiscPct3"  is not NULL and s."MDiscPct3"  is NULL)) OR
((s."MDiscValFlag" != d."MDiscValFlag")  OR (s."MDiscValFlag"  is not NULL and d."MDiscValFlag"  is NULL) OR (d."MDiscValFlag"  is not NULL and s."MDiscValFlag"  is NULL)) OR
((s."MDiscValue" != d."MDiscValue")  OR (s."MDiscValue"  is not NULL and d."MDiscValue"  is NULL) OR (d."MDiscValue"  is not NULL and s."MDiscValue"  is NULL)) OR
((s."MPrice" != d."MPrice")  OR (s."MPrice"  is not NULL and d."MPrice"  is NULL) OR (d."MPrice"  is not NULL and s."MPrice"  is NULL)) OR
((s."MForeignPrice" != d."MForeignPrice")  OR (s."MForeignPrice"  is not NULL and d."MForeignPrice"  is NULL) OR (d."MForeignPrice"  is not NULL and s."MForeignPrice"  is NULL)) OR
((s."MDecimalsToPrt" != d."MDecimalsToPrt")  OR (s."MDecimalsToPrt"  is not NULL and d."MDecimalsToPrt"  is NULL) OR (d."MDecimalsToPrt"  is not NULL and s."MDecimalsToPrt"  is NULL)) OR
((s."MConvFactPrcUm" != d."MConvFactPrcUm")  OR (s."MConvFactPrcUm"  is not NULL and d."MConvFactPrcUm"  is NULL) OR (d."MConvFactPrcUm"  is not NULL and s."MConvFactPrcUm"  is NULL)) OR
((s."MMulDivPrc" != d."MMulDivPrc")  OR (s."MMulDivPrc"  is not NULL and d."MMulDivPrc"  is NULL) OR (d."MMulDivPrc"  is not NULL and s."MMulDivPrc"  is NULL)) OR
((s."MPriceUom" != d."MPriceUom")  OR (s."MPriceUom"  is not NULL and d."MPriceUom"  is NULL) OR (d."MPriceUom"  is not NULL and s."MPriceUom"  is NULL)) OR
((s."MTaxCode" != d."MTaxCode")  OR (s."MTaxCode"  is not NULL and d."MTaxCode"  is NULL) OR (d."MTaxCode"  is not NULL and s."MTaxCode"  is NULL)) OR
((s."MConvFactOrdUm" != d."MConvFactOrdUm")  OR (s."MConvFactOrdUm"  is not NULL and d."MConvFactOrdUm"  is NULL) OR (d."MConvFactOrdUm"  is not NULL and s."MConvFactOrdUm"  is NULL)) OR
((s."MMulDivAlloc" != d."MMulDivAlloc")  OR (s."MMulDivAlloc"  is not NULL and d."MMulDivAlloc"  is NULL) OR (d."MMulDivAlloc"  is not NULL and s."MMulDivAlloc"  is NULL)) OR
((s."MProductClass" != d."MProductClass")  OR (s."MProductClass"  is not NULL and d."MProductClass"  is NULL) OR (d."MProductClass"  is not NULL and s."MProductClass"  is NULL)) OR
((s."MCompleteFlag" != d."MCompleteFlag") OR (s."MCompleteFlag"  is not NULL and d."MCompleteFlag"  is NULL) OR (d."MCompleteFlag"  is not NULL and s."MCompleteFlag"  is NULL)) OR
((s."MJob" != d."MJob")  OR (s."MJob"  is not NULL and d."MJob"  is NULL) OR (d."MJob"  is not NULL and s."MJob"  is NULL)) OR
((s."MJobLine" != d."MJobLine")  OR (s."MJobLine"  is not NULL and d."MJobLine"  is NULL) OR (d."MJobLine"  is not NULL and s."MJobLine"  is NULL)) OR
((s."MGlCode" != d."MGlCode")  OR (s."MGlCode"  is not NULL and d."MGlCode"  is NULL) OR (d."MGlCode"  is not NULL and s."MGlCode"  is NULL)) OR
((s."MUserAuthReqn" != d."MUserAuthReqn")  OR (s."MUserAuthReqn"  is not NULL and d."MUserAuthReqn"  is NULL) OR (d."MUserAuthReqn"  is not NULL and s."MUserAuthReqn"  is NULL)) OR
((s."MRequisition" != d."MRequisition")  OR (s."MRequisition"  is not NULL and d."MRequisition"  is NULL) OR (d."MRequisition"  is not NULL and s."MRequisition"  is NULL)) OR
((s."MRequisitionLine" != d."MRequisitionLine")  OR (s."MRequisitionLine"  is not NULL and d."MRequisitionLine"  is NULL) OR (d."MRequisitionLine"  is not NULL and s."MRequisitionLine"  is NULL)) OR
((s."MSalesOrder" != d."MSalesOrder")  OR (s."MSalesOrder"  is not NULL and d."MSalesOrder"  is NULL) OR (d."MSalesOrder"  is not NULL and s."MSalesOrder"  is NULL)) OR
((s."MSalesOrderLine" != d."MSalesOrderLine")  OR (s."MSalesOrderLine"  is not NULL and d."MSalesOrderLine"  is NULL) OR (d."MSalesOrderLine"  is not NULL and s."MSalesOrderLine"  is NULL)) OR
((s."MOrigDueDate" != d."MOrigDueDate")  OR (s."MOrigDueDate"  is not NULL and d."MOrigDueDate"  is NULL) OR (d."MOrigDueDate"  is not NULL and s."MOrigDueDate"  is NULL)) OR
((s."MReschedDueDate" != d."MReschedDueDate")  OR (s."MReschedDueDate"  is not NULL and d."MReschedDueDate"  is NULL) OR (d."MReschedDueDate"  is not NULL and s."MReschedDueDate"  is NULL)) OR
((s."MLctConfirmed" != d."MLctConfirmed")  OR (s."MLctConfirmed"  is not NULL and d."MLctConfirmed"  is NULL) OR (d."MLctConfirmed"  is not NULL and s."MLctConfirmed"  is NULL)) OR
((s."MOriginalLine" != d."MOriginalLine")  OR (s."MOriginalLine"  is not NULL and d."MOriginalLine"  is NULL) OR (d."MOriginalLine"  is not NULL and s."MOriginalLine"  is NULL)) OR
((s."MSubcontractOp" != d."MSubcontractOp")  OR (s."MSubcontractOp"  is not NULL and d."MSubcontractOp"  is NULL) OR (d."MSubcontractOp"  is not NULL and s."MSubcontractOp"  is NULL)) OR
((s."MEdiExtractFlag" != d."MEdiExtractFlag")  OR (s."MEdiExtractFlag"  is not NULL and d."MEdiExtractFlag"  is NULL) OR (d."MEdiExtractFlag"  is not NULL and s."MEdiExtractFlag"  is NULL)) OR
((s."MEdiActionFlag" != d."MEdiActionFlag")  OR (s."MEdiActionFlag"  is not NULL and d."MEdiActionFlag"  is NULL) OR (d."MEdiActionFlag"  is not NULL and s."MEdiActionFlag"  is NULL)) OR
((s."MInspectionReqd" != d."MInspectionReqd")  OR (s."MInspectionReqd"  is not NULL and d."MInspectionReqd"  is NULL) OR (d."MInspectionReqd"  is not NULL and s."MInspectionReqd"  is NULL)) OR
((s."MNonsUnitMass" != d."MNonsUnitMass")  OR (s."MNonsUnitMass"  is not NULL and d."MNonsUnitMass"  is NULL) OR (d."MNonsUnitMass"  is not NULL and s."MNonsUnitMass"  is NULL)) OR
((s."MNonsUnitVol" != d."MNonsUnitVol")  OR (s."MNonsUnitVol"  is not NULL and d."MNonsUnitVol"  is NULL) OR (d."MNonsUnitVol"  is not NULL and s."MNonsUnitVol"  is NULL)) OR
((s."MVersion" != d."MVersion")  OR (s."MVersion"  is not NULL and d."MVersion"  is NULL) OR (d."MVersion"  is not NULL and s."MVersion"  is NULL)) OR
((s."MRelease" != d."MRelease")  OR (s."MRelease"  is not NULL and d."MRelease"  is NULL) OR (d."MRelease"  is not NULL and s."MRelease"  is NULL)) OR
((s."NComment" != d."NComment")  OR (s."NComment"  is not NULL and d."NComment"  is NULL) OR (d."NComment"  is not NULL and s."NComment"  is NULL)) OR
((s."NCommentFromLin" != d."NCommentFromLin")  OR (s."NCommentFromLin"  is not NULL and d."NCommentFromLin"  is NULL) OR (d."NCommentFromLin"  is not NULL and s."NCommentFromLin"  is NULL)) OR
((s."NMscChargeValue" != d."NMscChargeValue")  OR (s."NMscChargeValue"  is not NULL and d."NMscChargeValue"  is NULL) OR (d."NMscChargeValue"  is not NULL and s."NMscChargeValue"  is NULL)) OR
((s."NMscChargePrint" != d."NMscChargePrint")  OR (s."NMscChargePrint"  is not NULL and d."NMscChargePrint"  is NULL) OR (d."NMscChargePrint"  is not NULL and s."NMscChargePrint"  is NULL)) OR
((s."NComPrintType" != d."NComPrintType")  OR (s."NComPrintType"  is not NULL and d."NComPrintType"  is NULL) OR (d."NComPrintType"  is not NULL and s."NComPrintType"  is NULL)) OR
((s."NMscChargeTax" != d."NMscChargeTax")  OR (s."NMscChargeTax"  is not NULL and d."NMscChargeTax"  is NULL) OR (d."NMscChargeTax"  is not NULL and s."NMscChargeTax"  is NULL)) OR
((s."NCommentFlag" != d."NCommentFlag")  OR (s."NCommentFlag"  is not NULL and d."NCommentFlag"  is NULL) OR (d."NCommentFlag"  is not NULL and s."NCommentFlag"  is NULL)) OR
((s."NMscChargeFor" != d."NMscChargeFor")  OR (s."NMscChargeFor"  is not NULL and d."NMscChargeFor"  is NULL) OR (d."NMscChargeFor"  is not NULL and s."NMscChargeFor"  is NULL)) OR
((s."NMscChargeFLoc" != d."NMscChargeFLoc")  OR (s."NMscChargeFLoc"  is not NULL and d."NMscChargeFLoc"  is NULL) OR (d."NMscChargeFLoc"  is not NULL and s."NMscChargeFLoc"  is NULL)) OR
((s."NEdiExtract" != d."NEdiExtract")  OR (s."NEdiExtract"  is not NULL and d."NEdiExtract"  is NULL) OR (d."NEdiExtract"  is not NULL and s."NEdiExtract"  is NULL)) OR
((s."MEccFlag" != d."MEccFlag")  OR (s."MEccFlag"  is not NULL and d."MEccFlag"  is NULL) OR (d."MEccFlag"  is not NULL and s."MEccFlag"  is NULL)) OR
((s."MBlanketDate" != d."MBlanketDate") OR (s."MBlanketDate"  is not NULL and d."MBlanketDate"  is NULL) OR (d."MBlanketDate"  is not NULL and s."MBlanketDate"  is NULL)) OR
((s."MContractNumber" != d."MContractNumber")  OR (s."MContractNumber"  is not NULL and d."MContractNumber"  is NULL) OR (d."MContractNumber"  is not NULL and s."MContractNumber"  is NULL)) OR
((s."MBlanketContLine" != d."MBlanketContLine")  OR (s."MBlanketContLine"  is not NULL and d."MBlanketContLine"  is NULL) OR (d."MBlanketContLine"  is not NULL and s."MBlanketContLine"  is NULL)) OR
((s."AssetFlag" != d."AssetFlag")  OR (s."AssetFlag"  is not NULL and d."AssetFlag"  is NULL) OR (d."AssetFlag"  is not NULL and s."AssetFlag"  is NULL)) OR
((s."CapexCode" != d."CapexCode")  OR (s."CapexCode"  is not NULL and d."CapexCode"  is NULL) OR (d."CapexCode"  is not NULL and s."CapexCode"  is NULL)) OR
((s."CapexLine" != d."CapexLine")  OR (s."CapexLine"  is not NULL and d."CapexLine"  is NULL) OR (d."CapexLine"  is not NULL and s."CapexLine"  is NULL)) OR
((s."SelectionCode" != d."SelectionCode")  OR (s."SelectionCode"  is not NULL and d."SelectionCode"  is NULL) OR (d."SelectionCode"  is not NULL and s."SelectionCode"  is NULL)) OR
((s."SelectionType" != d."SelectionType")  OR (s."SelectionType"  is not NULL and d."SelectionType"  is NULL) OR (d."SelectionType"  is not NULL and s."SelectionType"  is NULL)) OR
((s."User1" != d."User1")  OR (s."User1"  is not NULL and d."User1"  is NULL) OR (d."User1"  is not NULL and s."User1"  is NULL)) OR
((s."OrderLineStatus" != d."OrderLineStatus")  OR (s."OrderLineStatus"  is not NULL and d."OrderLineStatus"  is NULL) OR (d."OrderLineStatus"  is not NULL and s."OrderLineStatus"  is NULL)) OR
((s."AutoVoucherReqd" != d."AutoVoucherReqd")  OR (s."AutoVoucherReqd"  is not NULL and d."AutoVoucherReqd"  is NULL) OR (d."AutoVoucherReqd"  is not NULL and s."AutoVoucherReqd"  is NULL)) OR
((s."IncludeInMrp" != d."IncludeInMrp")  OR (s."IncludeInMrp"  is not NULL and d."IncludeInMrp"  is NULL) OR (d."IncludeInMrp"  is not NULL and s."IncludeInMrp"  is NULL)) OR
((s."WithTaxExpenseType" != d."WithTaxExpenseType") OR (s."WithTaxExpenseType"  is not NULL and d."WithTaxExpenseType"  is NULL) OR (d."WithTaxExpenseType"  is not NULL and s."WithTaxExpenseType"  is NULL))

);

END;
