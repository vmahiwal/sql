--WipMasterMain_stg0_gp


BEGIN;
insert into sysprocompanyb.wipmastermain_stg0_gp select s.*
from sysprocompanyb.wipmastermain_stg0 s 
LEFT JOIN sysprocompanyb.wipmastermain_stg0_gp d
ON s."Job"=d."Job" where d."Job" is null ;
Savepoint sp2;
--Delete
delete from sysprocompanyb.wipmastermain_stg0_gp
where sysprocompanyb.wipmastermain_stg0_gp."Job"
in
(
select d."Job"
from
sysprocompanyb.wipmastermain_stg0_gp d
left join
sysprocompanyb.wipmastermain_stg0 s
on
s."Job"=d."Job"
where s."Job" is null
);

--Update
UPDATE sysprocompanyb.wipmastermain_stg0_gp d
SET
"time"= s."time",
"JobDescription" = s."JobDescription",
"JobClassification" = s."JobClassification",
"JobType" = s."JobType",
"MasterJob" = s."MasterJob",
"Priority" = s."Priority",
"StockCode" = s."StockCode",
"StockDescription" = s."StockDescription",
"Warehouse" = s."Warehouse",
"Customer" = s."Customer",
"CustomerName" = s."CustomerName",
"JobTenderDate" = s."JobTenderDate",
"JobDeliveryDate" = s."JobDeliveryDate",
"JobStartDate" = s."JobStartDate",
"ActCompleteDate" = s."ActCompleteDate",
"Complete" = s."Complete",
"SeqCheckReq" = s."SeqCheckReq",
"DateCalcMethod" = s."DateCalcMethod",
"ExpLabour" = s."ExpLabour",
"ExpMaterial" = s."ExpMaterial",
"QtyToMake" = s."QtyToMake",
"QtyManufactured" = s."QtyManufactured",
"Source" = s."Source",
"EstSourceNum" = s."EstSourceNum",
"NextDetailLine" = s."NextDetailLine",
"PctCompleteFlag" = s."PctCompleteFlag",
"PrtFactDoc1" = s."PrtFactDoc1",
"PrtFactDoc2" = s."PrtFactDoc2",
"PrtFactDoc3" = s."PrtFactDoc3",
"PrtFactDoc4" = s."PrtFactDoc4",
"SellingPrice" = s."SellingPrice",
"AddLabPct" = s."AddLabPct",
"AddMatPct" = s."AddMatPct",
"ProfitPct" = s."ProfitPct",
"SalesOrder" = s."SalesOrder",
"MaterialBilled" = s."MaterialBilled",
"LabourBilled" = s."LabourBilled",
"NextOpForAll" = s."NextOpForAll",
"HighestOpPosted" = s."HighestOpPosted",
"TotalQtyScrapped" = s."TotalQtyScrapped",
"ConfirmedFlag" = s."ConfirmedFlag",
"HoldFlag" = s."HoldFlag",
"JobCreatedStruc" = s."JobCreatedStruc",
"LstOrderCreated" = s."LstOrderCreated",
"TraceableType" = s."TraceableType",
"NxtLinePartBook" = s."NxtLinePartBook",
"Route" = s."Route",
"WipCtlGlCode" = s."WipCtlGlCode",
"Decimals" = s."Decimals",
"SalesOrderLine" = s."SalesOrderLine",
"MatCostToDate1" = s."MatCostToDate1",
"MatCostToDate2" = s."MatCostToDate2",
"MatCostToDate3" = s."MatCostToDate3",
"LabCostToDate1" = s."LabCostToDate1",
"LabCostToDate2" = s."LabCostToDate2",
"LabCostToDate3" = s."LabCostToDate3",
"HrsBookToDate1" = s."HrsBookToDate1",
"HrsBookToDate2" = s."HrsBookToDate2",
"HrsBookToDate3" = s."HrsBookToDate3",
"MatValueIssues1" = s."MatValueIssues1",
"MatValueIssues2" = s."MatValueIssues2",
"MatValueIssues3" = s."MatValueIssues3",
"LabValueIssues1" = s."LabValueIssues1",
"LabValueIssues2" = s."LabValueIssues2",
"LabValueIssues3" = s."LabValueIssues3",
"NarrationNum" = s."NarrationNum",
"ReqPlnFlag" = s."ReqPlnFlag",
"DateJobLstUpd" = s."DateJobLstUpd",
"TimeJobLstUpd" = s."TimeJobLstUpd",
"HierarchyFlag" = s."HierarchyFlag",
"NextLineHier" = s."NextLineHier",
"EstTrailLoad" = s."EstTrailLoad",
"OrdEntSource" = s."OrdEntSource",
"Version" = s."Version",
"Release" = s."Release",
"AllocationLine" = s."AllocationLine",
"PurgeJob" = s."PurgeJob",
"HierarchyJob" = s."HierarchyJob",
"MrpFromJob" = s."MrpFromJob",
"MrpToJob" = s."MrpToJob",
"OrigDueDate" = s."OrigDueDate",
"GrossFlg" = s."GrossFlg",
"GrossQty" = s."GrossQty",
"ExpLabCurrent" = s."ExpLabCurrent",
"ExpMatCurrent" = s."ExpMatCurrent",
"ReservedLotSerFlag" = s."ReservedLotSerFlag",
"NotionalPart" = s."NotionalPart",
"CoProductCostMet" = s."CoProductCostMet",
"CoProductCostVal" = s."CoProductCostVal",
"CoProductType" = s."CoProductType",
"CapexCode" = s."CapexCode",
"CapexLine" = s."CapexLine",
"UomFlag" = s."UomFlag",
"ConvFactUom" = s."ConvFactUom",
"ConvMulDiv" = s."ConvMulDiv",
"ScheduleFlag" = s."ScheduleFlag",
"SchStartDate" = s."SchStartDate",
"SchStartTime" = s."SchStartTime",
"SchEndDate" = s."SchEndDate",
"SchEndTime" = s."SchEndTime",
"QtyToMakeEnt" = s."QtyToMakeEnt",
"QtyManufacturedEnt" = s."QtyManufacturedEnt",
"TotQtyScrappedEnt" = s."TotQtyScrappedEnt",
"GrossQtyEnt" = s."GrossQtyEnt",
"ProductCode" = s."ProductCode",
"LibraryCode" = s."LibraryCode",
"TimeStamp" = s."TimeStamp"
FROM sysprocompanyb.wipmastermain_stg0 s
Where (s."Job"=d."Job") and
(
((s."JobDescription" != d."JobDescription")  OR (s."JobDescription"  is not NULL and d."JobDescription"  is NULL) OR (d."JobDescription"  is not NULL and s."JobDescription"  is NULL)) OR
((s."JobClassification" != d."JobClassification")  OR (s."JobClassification"  is not NULL and d."JobClassification"  is NULL) OR (d."JobClassification"  is not NULL and s."JobClassification"  is NULL)) OR
((s."JobType" != d."JobType")  OR (s."JobType"  is not NULL and d."JobType"  is NULL) OR (d."JobType"  is not NULL and s."JobType"  is NULL)) OR
((s."MasterJob" != d."MasterJob")  OR (s."MasterJob"  is not NULL and d."MasterJob"  is NULL) OR (d."MasterJob"  is not NULL and s."MasterJob"  is NULL)) OR
((s."Priority" != d."Priority")  OR (s."Priority"  is not NULL and d."Priority"  is NULL) OR (d."Priority"  is not NULL and s."Priority"  is NULL)) OR
((s."StockCode" != d."StockCode")  OR (s."StockCode"  is not NULL and d."StockCode"  is NULL) OR (d."StockCode"  is not NULL and s."StockCode"  is NULL)) OR
((s."StockDescription" != d."StockDescription")  OR (s."StockDescription"  is not NULL and d."StockDescription"  is NULL) OR (d."StockDescription"  is not NULL and s."StockDescription"  is NULL)) OR
((s."Warehouse" != d."Warehouse")  OR (s."Warehouse"  is not NULL and d."Warehouse"  is NULL) OR (d."Warehouse"  is not NULL and s."Warehouse"  is NULL)) OR
((s."Customer" != d."Customer")  OR (s."Customer"  is not NULL and d."Customer"  is NULL) OR (d."Customer"  is not NULL and s."Customer"  is NULL)) OR
((s."CustomerName" != d."CustomerName")  OR (s."CustomerName"  is not NULL and d."CustomerName"  is NULL) OR (d."CustomerName"  is not NULL and s."CustomerName"  is NULL)) OR
((s."JobTenderDate" != d."JobTenderDate")  OR (s."JobTenderDate"  is not NULL and d."JobTenderDate"  is NULL) OR (d."JobTenderDate"  is not NULL and s."JobTenderDate"  is NULL)) OR
((s."JobDeliveryDate" != d."JobDeliveryDate")  OR (s."JobDeliveryDate"  is not NULL and d."JobDeliveryDate"  is NULL) OR (d."JobDeliveryDate"  is not NULL and s."JobDeliveryDate"  is NULL)) OR
((s."JobStartDate" != d."JobStartDate")  OR (s."JobStartDate"  is not NULL and d."JobStartDate"  is NULL) OR (d."JobStartDate"  is not NULL and s."JobStartDate"  is NULL)) OR
((s."ActCompleteDate" != d."ActCompleteDate")  OR (s."ActCompleteDate"  is not NULL and d."ActCompleteDate"  is NULL) OR (d."ActCompleteDate"  is not NULL and s."ActCompleteDate"  is NULL)) OR
((s."Complete" != d."Complete")  OR (s."Complete"  is not NULL and d."Complete"  is NULL) OR (d."Complete"  is not NULL and s."Complete"  is NULL)) OR
((s."SeqCheckReq" != d."SeqCheckReq")  OR (s."SeqCheckReq"  is not NULL and d."SeqCheckReq"  is NULL) OR (d."SeqCheckReq"  is not NULL and s."SeqCheckReq"  is NULL)) OR
((s."DateCalcMethod" != d."DateCalcMethod")  OR (s."DateCalcMethod"  is not NULL and d."DateCalcMethod"  is NULL) OR (d."DateCalcMethod"  is not NULL and s."DateCalcMethod"  is NULL)) OR
((s."ExpLabour" != d."ExpLabour")  OR (s."ExpLabour"  is not NULL and d."ExpLabour"  is NULL) OR (d."ExpLabour"  is not NULL and s."ExpLabour"  is NULL)) OR
((s."ExpMaterial" != d."ExpMaterial")  OR (s."ExpMaterial"  is not NULL and d."ExpMaterial"  is NULL) OR (d."ExpMaterial"  is not NULL and s."ExpMaterial"  is NULL)) OR
((s."QtyToMake" != d."QtyToMake")  OR (s."QtyToMake"  is not NULL and d."QtyToMake"  is NULL) OR (d."QtyToMake"  is not NULL and s."QtyToMake"  is NULL)) OR
((s."QtyManufactured" != d."QtyManufactured")  OR (s."QtyManufactured"  is not NULL and d."QtyManufactured"  is NULL) OR (d."QtyManufactured"  is not NULL and s."QtyManufactured"  is NULL)) OR
((s."Source" != d."Source")  OR (s."Source"  is not NULL and d."Source"  is NULL) OR (d."Source"  is not NULL and s."Source"  is NULL)) OR
((s."EstSourceNum" != d."EstSourceNum")  OR (s."EstSourceNum"  is not NULL and d."EstSourceNum"  is NULL) OR (d."EstSourceNum"  is not NULL and s."EstSourceNum"  is NULL)) OR
((s."NextDetailLine" != d."NextDetailLine")  OR (s."NextDetailLine"  is not NULL and d."NextDetailLine"  is NULL) OR (d."NextDetailLine"  is not NULL and s."NextDetailLine"  is NULL)) OR
((s."PctCompleteFlag" != d."PctCompleteFlag")  OR (s."PctCompleteFlag"  is not NULL and d."PctCompleteFlag"  is NULL) OR (d."PctCompleteFlag"  is not NULL and s."PctCompleteFlag"  is NULL)) OR
((s."PrtFactDoc1" != d."PrtFactDoc1")  OR (s."PrtFactDoc1"  is not NULL and d."PrtFactDoc1"  is NULL) OR (d."PrtFactDoc1"  is not NULL and s."PrtFactDoc1"  is NULL)) OR
((s."PrtFactDoc2" != d."PrtFactDoc2")  OR (s."PrtFactDoc2"  is not NULL and d."PrtFactDoc2"  is NULL) OR (d."PrtFactDoc2"  is not NULL and s."PrtFactDoc2"  is NULL)) OR
((s."PrtFactDoc3" != d."PrtFactDoc3")  OR (s."PrtFactDoc3"  is not NULL and d."PrtFactDoc3"  is NULL) OR (d."PrtFactDoc3"  is not NULL and s."PrtFactDoc3"  is NULL)) OR
((s."PrtFactDoc4" != d."PrtFactDoc4")  OR (s."PrtFactDoc4"  is not NULL and d."PrtFactDoc4"  is NULL) OR (d."PrtFactDoc4"  is not NULL and s."PrtFactDoc4"  is NULL)) OR
((s."SellingPrice" != d."SellingPrice")  OR (s."SellingPrice"  is not NULL and d."SellingPrice"  is NULL) OR (d."SellingPrice"  is not NULL and s."SellingPrice"  is NULL)) OR
((s."AddLabPct" != d."AddLabPct")  OR (s."AddLabPct"  is not NULL and d."AddLabPct"  is NULL) OR (d."AddLabPct"  is not NULL and s."AddLabPct"  is NULL)) OR
((s."AddMatPct" != d."AddMatPct")  OR (s."AddMatPct"  is not NULL and d."AddMatPct"  is NULL) OR (d."AddMatPct"  is not NULL and s."AddMatPct"  is NULL)) OR
((s."ProfitPct" != d."ProfitPct")  OR (s."ProfitPct"  is not NULL and d."ProfitPct"  is NULL) OR (d."ProfitPct"  is not NULL and s."ProfitPct"  is NULL)) OR
((s."SalesOrder" != d."SalesOrder")  OR (s."SalesOrder"  is not NULL and d."SalesOrder"  is NULL) OR (d."SalesOrder"  is not NULL and s."SalesOrder"  is NULL)) OR
((s."MaterialBilled" != d."MaterialBilled")  OR (s."MaterialBilled"  is not NULL and d."MaterialBilled"  is NULL) OR (d."MaterialBilled"  is not NULL and s."MaterialBilled"  is NULL)) OR
((s."LabourBilled" != d."LabourBilled")  OR (s."LabourBilled"  is not NULL and d."LabourBilled"  is NULL) OR (d."LabourBilled"  is not NULL and s."LabourBilled"  is NULL)) OR
((s."NextOpForAll" != d."NextOpForAll")  OR (s."NextOpForAll"  is not NULL and d."NextOpForAll"  is NULL) OR (d."NextOpForAll"  is not NULL and s."NextOpForAll"  is NULL)) OR
((s."HighestOpPosted" != d."HighestOpPosted")  OR (s."HighestOpPosted"  is not NULL and d."HighestOpPosted"  is NULL) OR (d."HighestOpPosted"  is not NULL and s."HighestOpPosted"  is NULL)) OR
((s."TotalQtyScrapped" != d."TotalQtyScrapped")  OR (s."TotalQtyScrapped"  is not NULL and d."TotalQtyScrapped"  is NULL) OR (d."TotalQtyScrapped"  is not NULL and s."TotalQtyScrapped"  is NULL)) OR
((s."ConfirmedFlag" != d."ConfirmedFlag")  OR (s."ConfirmedFlag"  is not NULL and d."ConfirmedFlag"  is NULL) OR (d."ConfirmedFlag"  is not NULL and s."ConfirmedFlag"  is NULL)) OR
((s."HoldFlag" != d."HoldFlag")  OR (s."HoldFlag"  is not NULL and d."HoldFlag"  is NULL) OR (d."HoldFlag"  is not NULL and s."HoldFlag"  is NULL)) OR
((s."JobCreatedStruc" != d."JobCreatedStruc")  OR (s."JobCreatedStruc"  is not NULL and d."JobCreatedStruc"  is NULL) OR (d."JobCreatedStruc"  is not NULL and s."JobCreatedStruc"  is NULL)) OR
((s."LstOrderCreated" != d."LstOrderCreated")  OR (s."LstOrderCreated"  is not NULL and d."LstOrderCreated"  is NULL) OR (d."LstOrderCreated"  is not NULL and s."LstOrderCreated"  is NULL)) OR
((s."TraceableType" != d."TraceableType")  OR (s."TraceableType"  is not NULL and d."TraceableType"  is NULL) OR (d."TraceableType"  is not NULL and s."TraceableType"  is NULL)) OR
((s."NxtLinePartBook" != d."NxtLinePartBook")  OR (s."NxtLinePartBook"  is not NULL and d."NxtLinePartBook"  is NULL) OR (d."NxtLinePartBook"  is not NULL and s."NxtLinePartBook"  is NULL)) OR
((s."Route" != d."Route")  OR (s."Route"  is not NULL and d."Route"  is NULL) OR (d."Route"  is not NULL and s."Route"  is NULL)) OR
((s."WipCtlGlCode" != d."WipCtlGlCode")  OR (s."WipCtlGlCode"  is not NULL and d."WipCtlGlCode"  is NULL) OR (d."WipCtlGlCode"  is not NULL and s."WipCtlGlCode"  is NULL)) OR
((s."Decimals" != d."Decimals")  OR (s."Decimals"  is not NULL and d."Decimals"  is NULL) OR (d."Decimals"  is not NULL and s."Decimals"  is NULL)) OR
((s."SalesOrderLine" != d."SalesOrderLine")  OR (s."SalesOrderLine"  is not NULL and d."SalesOrderLine"  is NULL) OR (d."SalesOrderLine"  is not NULL and s."SalesOrderLine"  is NULL)) OR
((s."MatCostToDate1" != d."MatCostToDate1")  OR (s."MatCostToDate1"  is not NULL and d."MatCostToDate1"  is NULL) OR (d."MatCostToDate1"  is not NULL and s."MatCostToDate1"  is NULL)) OR
((s."MatCostToDate2" != d."MatCostToDate2")  OR (s."MatCostToDate2"  is not NULL and d."MatCostToDate2"  is NULL) OR (d."MatCostToDate2"  is not NULL and s."MatCostToDate2"  is NULL)) OR
((s."MatCostToDate3" != d."MatCostToDate3")  OR (s."MatCostToDate3"  is not NULL and d."MatCostToDate3"  is NULL) OR (d."MatCostToDate3"  is not NULL and s."MatCostToDate3"  is NULL)) OR
((s."LabCostToDate1" != d."LabCostToDate1")  OR (s."LabCostToDate1"  is not NULL and d."LabCostToDate1"  is NULL) OR (d."LabCostToDate1"  is not NULL and s."LabCostToDate1"  is NULL)) OR
((s."LabCostToDate2" != d."LabCostToDate2")  OR (s."LabCostToDate2"  is not NULL and d."LabCostToDate2"  is NULL) OR (d."LabCostToDate2"  is not NULL and s."LabCostToDate2"  is NULL)) OR
((s."LabCostToDate3" != d."LabCostToDate3")  OR (s."LabCostToDate3"  is not NULL and d."LabCostToDate3"  is NULL) OR (d."LabCostToDate3"  is not NULL and s."LabCostToDate3"  is NULL)) OR
((s."HrsBookToDate1" != d."HrsBookToDate1")  OR (s."HrsBookToDate1"  is not NULL and d."HrsBookToDate1"  is NULL) OR (d."HrsBookToDate1"  is not NULL and s."HrsBookToDate1"  is NULL)) OR
((s."HrsBookToDate2" != d."HrsBookToDate2")  OR (s."HrsBookToDate2"  is not NULL and d."HrsBookToDate2"  is NULL) OR (d."HrsBookToDate2"  is not NULL and s."HrsBookToDate2"  is NULL)) OR
((s."HrsBookToDate3" != d."HrsBookToDate3")  OR (s."HrsBookToDate3"  is not NULL and d."HrsBookToDate3"  is NULL) OR (d."HrsBookToDate3"  is not NULL and s."HrsBookToDate3"  is NULL)) OR
((s."MatValueIssues1" != d."MatValueIssues1")  OR (s."MatValueIssues1"  is not NULL and d."MatValueIssues1"  is NULL) OR (d."MatValueIssues1"  is not NULL and s."MatValueIssues1"  is NULL)) OR
((s."MatValueIssues2" != d."MatValueIssues2") OR (s."MatValueIssues2"  is not NULL and d."MatValueIssues2"  is NULL) OR (d."MatValueIssues2"  is not NULL and s."MatValueIssues2"  is NULL)) OR
((s."MatValueIssues3" != d."MatValueIssues3")  OR (s."MatValueIssues3"  is not NULL and d."MatValueIssues3"  is NULL) OR (d."MatValueIssues3"  is not NULL and s."MatValueIssues3"  is NULL)) OR
((s."LabValueIssues1" != d."LabValueIssues1")  OR (s."LabValueIssues1"  is not NULL and d."LabValueIssues1"  is NULL) OR (d."LabValueIssues1"  is not NULL and s."LabValueIssues1"  is NULL)) OR
((s."LabValueIssues2" != d."LabValueIssues2")  OR (s."LabValueIssues2"  is not NULL and d."LabValueIssues2"  is NULL) OR (d."LabValueIssues2"  is not NULL and s."LabValueIssues2"  is NULL)) OR
((s."LabValueIssues3" != d."LabValueIssues3")  OR (s."LabValueIssues3"  is not NULL and d."LabValueIssues3"  is NULL) OR (d."LabValueIssues3"  is not NULL and s."LabValueIssues3"  is NULL)) OR
((s."NarrationNum" != d."NarrationNum") OR (s."NarrationNum"  is not NULL and d."NarrationNum"  is NULL) OR (d."NarrationNum"  is not NULL and s."NarrationNum"  is NULL)) OR
((s."ReqPlnFlag" != d."ReqPlnFlag")  OR (s."ReqPlnFlag"  is not NULL and d."ReqPlnFlag"  is NULL) OR (d."ReqPlnFlag"  is not NULL and s."ReqPlnFlag"  is NULL)) OR
((s."DateJobLstUpd" != d."DateJobLstUpd")  OR (s."DateJobLstUpd"  is not NULL and d."DateJobLstUpd"  is NULL) OR (d."DateJobLstUpd"  is not NULL and s."DateJobLstUpd"  is NULL)) OR
((s."TimeJobLstUpd" != d."TimeJobLstUpd")  OR (s."TimeJobLstUpd"  is not NULL and d."TimeJobLstUpd"  is NULL) OR (d."TimeJobLstUpd"  is not NULL and s."TimeJobLstUpd"  is NULL)) OR
((s."HierarchyFlag" != d."HierarchyFlag")  OR (s."HierarchyFlag"  is not NULL and d."HierarchyFlag"  is NULL) OR (d."HierarchyFlag"  is not NULL and s."HierarchyFlag"  is NULL)) OR
((s."NextLineHier" != d."NextLineHier")  OR (s."NextLineHier"  is not NULL and d."NextLineHier"  is NULL) OR (d."NextLineHier"  is not NULL and s."NextLineHier"  is NULL)) OR
((s."EstTrailLoad" != d."EstTrailLoad") OR (s."EstTrailLoad"  is not NULL and d."EstTrailLoad"  is NULL) OR (d."EstTrailLoad"  is not NULL and s."EstTrailLoad"  is NULL)) OR
((s."OrdEntSource" != d."OrdEntSource")  OR (s."OrdEntSource"  is not NULL and d."OrdEntSource"  is NULL) OR (d."OrdEntSource"  is not NULL and s."OrdEntSource"  is NULL)) OR
((s."Version" != d."Version")  OR (s."Version"  is not NULL and d."Version"  is NULL) OR (d."Version"  is not NULL and s."Version"  is NULL)) OR
((s."Release" != d."Release")  OR (s."Release"  is not NULL and d."Release"  is NULL) OR (d."Release"  is not NULL and s."Release"  is NULL)) OR
((s."AllocationLine" != d."AllocationLine") OR (s."AllocationLine"  is not NULL and d."AllocationLine"  is NULL) OR (d."AllocationLine"  is not NULL and s."AllocationLine"  is NULL)) OR
((s."PurgeJob" != d."PurgeJob")  OR (s."PurgeJob"  is not NULL and d."PurgeJob"  is NULL) OR (d."PurgeJob"  is not NULL and s."PurgeJob"  is NULL)) OR
((s."HierarchyJob" != d."HierarchyJob")  OR (s."HierarchyJob"  is not NULL and d."HierarchyJob"  is NULL) OR (d."HierarchyJob"  is not NULL and s."HierarchyJob"  is NULL)) OR
((s."MrpFromJob" != d."MrpFromJob")  OR (s."MrpFromJob"  is not NULL and d."MrpFromJob"  is NULL) OR (d."MrpFromJob"  is not NULL and s."MrpFromJob"  is NULL)) OR
((s."MrpToJob" != d."MrpToJob") OR (s."MrpToJob"  is not NULL and d."MrpToJob"  is NULL) OR (d."MrpToJob"  is not NULL and s."MrpToJob"  is NULL)) OR
((s."OrigDueDate" != d."OrigDueDate")  OR (s."OrigDueDate"  is not NULL and d."OrigDueDate"  is NULL) OR (d."OrigDueDate"  is not NULL and s."OrigDueDate"  is NULL)) OR
((s."GrossFlg" != d."GrossFlg")  OR (s."GrossFlg"  is not NULL and d."GrossFlg"  is NULL) OR (d."GrossFlg"  is not NULL and s."GrossFlg"  is NULL)) OR
((s."GrossQty" != d."GrossQty")  OR (s."GrossQty"  is not NULL and d."GrossQty"  is NULL) OR (d."GrossQty"  is not NULL and s."GrossQty"  is NULL)) OR
((s."ExpLabCurrent" != d."ExpLabCurrent")  OR (s."ExpLabCurrent"  is not NULL and d."ExpLabCurrent"  is NULL) OR (d."ExpLabCurrent"  is not NULL and s."ExpLabCurrent"  is NULL)) OR
((s."ExpMatCurrent" != d."ExpMatCurrent")  OR (s."ExpMatCurrent"  is not NULL and d."ExpMatCurrent"  is NULL) OR (d."ExpMatCurrent"  is not NULL and s."ExpMatCurrent"  is NULL)) OR
((s."ReservedLotSerFlag" != d."ReservedLotSerFlag")  OR (s."ReservedLotSerFlag"  is not NULL and d."ReservedLotSerFlag"  is NULL) OR (d."ReservedLotSerFlag"  is not NULL and s."ReservedLotSerFlag"  is NULL)) OR
((s."NotionalPart" != d."NotionalPart")  OR (s."NotionalPart"  is not NULL and d."NotionalPart"  is NULL) OR (d."NotionalPart"  is not NULL and s."NotionalPart"  is NULL)) OR
((s."CoProductCostMet" != d."CoProductCostMet")  OR (s."CoProductCostMet"  is not NULL and d."CoProductCostMet"  is NULL) OR (d."CoProductCostMet"  is not NULL and s."CoProductCostMet"  is NULL)) OR
((s."CoProductCostVal" != d."CoProductCostVal")  OR (s."CoProductCostVal"  is not NULL and d."CoProductCostVal"  is NULL) OR (d."CoProductCostVal"  is not NULL and s."CoProductCostVal"  is NULL)) OR
((s."CoProductType" != d."CoProductType")  OR (s."CoProductType"  is not NULL and d."CoProductType"  is NULL) OR (d."CoProductType"  is not NULL and s."CoProductType"  is NULL)) OR
((s."CapexCode" != d."CapexCode")  OR (s."CapexCode"  is not NULL and d."CapexCode"  is NULL) OR (d."CapexCode"  is not NULL and s."CapexCode"  is NULL)) OR
((s."CapexLine" != d."CapexLine")  OR (s."CapexLine"  is not NULL and d."CapexLine"  is NULL) OR (d."CapexLine"  is not NULL and s."CapexLine"  is NULL)) OR
((s."UomFlag" != d."UomFlag")  OR (s."UomFlag"  is not NULL and d."UomFlag"  is NULL) OR (d."UomFlag"  is not NULL and s."UomFlag"  is NULL)) OR
((s."ConvFactUom" != d."ConvFactUom")  OR (s."ConvFactUom"  is not NULL and d."ConvFactUom"  is NULL) OR (d."ConvFactUom"  is not NULL and s."ConvFactUom"  is NULL)) OR
((s."ConvMulDiv" != d."ConvMulDiv")  OR (s."ConvMulDiv"  is not NULL and d."ConvMulDiv"  is NULL) OR (d."ConvMulDiv"  is not NULL and s."ConvMulDiv"  is NULL)) OR
((s."ScheduleFlag" != d."ScheduleFlag")  OR (s."ScheduleFlag"  is not NULL and d."ScheduleFlag"  is NULL) OR (d."ScheduleFlag"  is not NULL and s."ScheduleFlag"  is NULL)) OR
((s."SchStartDate" != d."SchStartDate")  OR (s."SchStartDate"  is not NULL and d."SchStartDate"  is NULL) OR (d."SchStartDate"  is not NULL and s."SchStartDate"  is NULL)) OR
((s."SchStartTime" != d."SchStartTime")  OR (s."SchStartTime"  is not NULL and d."SchStartTime"  is NULL) OR (d."SchStartTime"  is not NULL and s."SchStartTime"  is NULL)) OR
((s."SchEndDate" != d."SchEndDate")  OR (s."SchEndDate"  is not NULL and d."SchEndDate"  is NULL) OR (d."SchEndDate"  is not NULL and s."SchEndDate"  is NULL)) OR
((s."SchEndTime" != d."SchEndTime")  OR (s."SchEndTime"  is not NULL and d."SchEndTime"  is NULL) OR (d."SchEndTime"  is not NULL and s."SchEndTime"  is NULL)) OR
((s."QtyToMakeEnt" != d."QtyToMakeEnt")  OR (s."QtyToMakeEnt"  is not NULL and d."QtyToMakeEnt"  is NULL) OR (d."QtyToMakeEnt"  is not NULL and s."QtyToMakeEnt"  is NULL)) OR
((s."QtyManufacturedEnt" != d."QtyManufacturedEnt")  OR (s."QtyManufacturedEnt"  is not NULL and d."QtyManufacturedEnt"  is NULL) OR (d."QtyManufacturedEnt"  is not NULL and s."QtyManufacturedEnt"  is NULL)) OR
((s."TotQtyScrappedEnt" != d."TotQtyScrappedEnt")  OR (s."TotQtyScrappedEnt"  is not NULL and d."TotQtyScrappedEnt"  is NULL) OR (d."TotQtyScrappedEnt"  is not NULL and s."TotQtyScrappedEnt"  is NULL)) OR
((s."GrossQtyEnt" != d."GrossQtyEnt")  OR (s."GrossQtyEnt"  is not NULL and d."GrossQtyEnt"  is NULL) OR (d."GrossQtyEnt"  is not NULL and s."GrossQtyEnt"  is NULL)) OR
((s."ProductCode" != d."ProductCode")  OR (s."ProductCode"  is not NULL and d."ProductCode"  is NULL) OR (d."ProductCode"  is not NULL and s."ProductCode"  is NULL)) OR
((s."LibraryCode" != d."LibraryCode") OR (s."LibraryCode"  is not NULL and d."LibraryCode"  is NULL) OR (d."LibraryCode"  is not NULL and s."LibraryCode"  is NULL))
);
END;
