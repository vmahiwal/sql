--WipJobPostMain_stg0_gp


BEGIN;
insert into sysprocompanyb.wipjobpostmain_stg0_gp
select s.* from sysprocompanyb.wipjobpostmain_stg0 s
 LEFT JOIN sysprocompanyb.wipjobpostmain_stg0_gp d 
ON (s."Job"=d."Job" and s."Line"=d."Line")
 where (d."Job" is null and d."Line" is null) ;

SAVEPOINT sd;

delete from sysprocompanyb.wipjobpostmain_stg0_gp where
(sysprocompanyb.wipjobpostmain_stg0_gp."Job",
sysprocompanyb.wipjobpostmain_stg0_gp."Line")
in
(
select d."Job",d."Line"
from
sysprocompanyb.wipjobpostmain_stg0_gp d left join sysprocompanyb.wipjobpostmain_stg0 s
on s."Job"=d."Job" and s."Line"=d."Line"
where s."Job" is null and s."Line" is null
);
---Update
UPDATE sysprocompanyb.wipjobpostmain_stg0_gp d
SET
"time" = s."time",
"TrnType" = s."TrnType",
"MStockCode" = s."MStockCode",
"MDescription" = s."MDescription",
"MQtyIssued" = s."MQtyIssued",
"MUom" = s."MUom",
"MWarehouse" = s."MWarehouse",
"MProductClass" = s."MProductClass",
"MUnitCost" = s."MUnitCost",
"MReference" = s."MReference",
"MAddReference" = s."MAddReference",
"MLot" = s."MLot",
"MConcessionNum" = s."MConcessionNum",
"MVersionNum" = s."MVersionNum",
"MReleaseLevel" = s."MReleaseLevel",
"MApplyCostUom" = s."MApplyCostUom",
"MCostUom" = s."MCostUom",
"MPurchaseOrder" = s."MPurchaseOrder",
"MBulkIssueItem" = s."MBulkIssueItem",
"MPurchaseOrdLin" = s."MPurchaseOrdLin",
"MAllocationLine" = s."MAllocationLine",
"MDecimals" = s."MDecimals",
"MSubJob" = s."MSubJob",
"MQtyIssuedEnt" = s."MQtyIssuedEnt",
"MSerial" = s."MSerial",
"MUnitCostActual" = s."MUnitCostActual",
"LWorkCentre" = s."LWorkCentre",
"LWorkCentreDesc" = s."LWorkCentreDesc",
"LRunTimeHours" = s."LRunTimeHours",
"LSetUpHours" = s."LSetUpHours",
"LStartupHours" = s."LStartupHours",
"LTeardownHours" = s."LTeardownHours",
"LOperation" = s."LOperation",
"LMachine" = s."LMachine",
"LRunTimeRate" = s."LRunTimeRate",
"LSetUpTimeRate" = s."LSetUpTimeRate",
"LFixedTimeRate" = s."LFixedTimeRate",
"LVarTimeRate" = s."LVarTimeRate",
"LStartTimeRate" = s."LStartTimeRate",
"LTeardownRate" = s."LTeardownRate",
"LSubcontractFlag" = s."LSubcontractFlag",
"LEmployee" = s."LEmployee",
"LQtyScrapped" = s."LQtyScrapped",
"LQtyComplete" = s."LQtyComplete",
"LWcRateInd" = s."LWcRateInd",
"LEmployeeRatInd" = s."LEmployeeRatInd",
"LScrapCode" = s."LScrapCode",
"LNonProdCode" = s."LNonProdCode",
"LReference" = s."LReference",
"LAddReference" = s."LAddReference",
"LTrnTime" = s."LTrnTime",
"LTrnSplit" = s."LTrnSplit",
"LQtyScrappedEnt" = s."LQtyScrappedEnt",
"LQtyCompleteEnt" = s."LQtyCompleteEnt",
"LRunTimeHoursEnt" = s."LRunTimeHoursEnt",
"TrnValue" = s."TrnValue",
"TrnDate" = s."TrnDate",
"Journal" = s."Journal",
"Hierarchy1" = s."Hierarchy1",
"Hierarchy2" = s."Hierarchy2",
"Hierarchy3" = s."Hierarchy3",
"Hierarchy4" = s."Hierarchy4",
"Hierarchy5" = s."Hierarchy5",
"PostYear" = s."PostYear",
"PostMonth" = s."PostMonth",
"SourceModule" = s."SourceModule",
"TimeStamp" = s."TimeStamp"
FROM sysprocompanyb.wipjobpostmain_stg0 s
WHERE
(s."Job" = d."Job" AND
s."Line" = d."Line")
AND
(
((s."TrnType" != d."TrnType")  OR (s."TrnType"  is not NULL and d."TrnType"  is NULL) OR (d."TrnType"  is not NULL and s."TrnType"  is NULL)) OR
((s."MStockCode" != d."MStockCode")  OR (s."MStockCode"  is not NULL and d."MStockCode"  is NULL) OR (d."MStockCode"  is not NULL and s."MStockCode"  is NULL)) OR
((s."MDescription" != d."MDescription")  OR (s."MDescription"  is not NULL and d."MDescription"  is NULL) OR (d."MDescription"  is not NULL and s."MDescription"  is NULL)) OR
((s."MQtyIssued" != d."MQtyIssued")  OR (s."MQtyIssued"  is not NULL and d."MQtyIssued"  is NULL) OR (d."MQtyIssued"  is not NULL and s."MQtyIssued"  is NULL)) OR
((s."MUom" != d."MUom")  OR (s."MUom"  is not NULL and d."MUom"  is NULL) OR (d."MUom"  is not NULL and s."MUom"  is NULL)) OR
((s."MWarehouse" != d."MWarehouse")  OR (s."MWarehouse"  is not NULL and d."MWarehouse"  is NULL) OR (d."MWarehouse"  is not NULL and s."MWarehouse"  is NULL)) OR
((s."MProductClass" != d."MProductClass")  OR (s."MProductClass"  is not NULL and d."MProductClass"  is NULL) OR (d."MProductClass"  is not NULL and s."MProductClass"  is NULL)) OR
((s."MUnitCost" != d."MUnitCost")  OR (s."MUnitCost"  is not NULL and d."MUnitCost"  is NULL) OR (d."MUnitCost"  is not NULL and s."MUnitCost"  is NULL)) OR
((s."MReference" != d."MReference")  OR (s."MReference"  is not NULL and d."MReference"  is NULL) OR (d."MReference"  is not NULL and s."MReference"  is NULL)) OR
((s."MAddReference" != d."MAddReference")  OR (s."MAddReference"  is not NULL and d."MAddReference"  is NULL) OR (d."MAddReference"  is not NULL and s."MAddReference"  is NULL)) OR
((s."MLot" != d."MLot")  OR (s."MLot"  is not NULL and d."MLot"  is NULL) OR (d."MLot"  is not NULL and s."MLot"  is NULL)) OR
((s."MConcessionNum" != d."MConcessionNum")  OR (s."MConcessionNum"  is not NULL and d."MConcessionNum"  is NULL) OR (d."MConcessionNum"  is not NULL and s."MConcessionNum"  is NULL)) OR
((s."MVersionNum" != d."MVersionNum")  OR (s."MVersionNum"  is not NULL and d."MVersionNum"  is NULL) OR (d."MVersionNum"  is not NULL and s."MVersionNum"  is NULL)) OR
((s."MReleaseLevel" != d."MReleaseLevel")  OR (s."MReleaseLevel"  is not NULL and d."MReleaseLevel"  is NULL) OR (d."MReleaseLevel"  is not NULL and s."MReleaseLevel"  is NULL)) OR
((s."MApplyCostUom" != d."MApplyCostUom")  OR (s."MApplyCostUom"  is not NULL and d."MApplyCostUom"  is NULL) OR (d."MApplyCostUom"  is not NULL and s."MApplyCostUom"  is NULL)) OR
((s."MCostUom" != d."MCostUom")  OR (s."MCostUom"  is not NULL and d."MCostUom"  is NULL) OR (d."MCostUom"  is not NULL and s."MCostUom"  is NULL)) OR
((s."MPurchaseOrder" != d."MPurchaseOrder")  OR (s."MPurchaseOrder"  is not NULL and d."MPurchaseOrder"  is NULL) OR (d."MPurchaseOrder"  is not NULL and s."MPurchaseOrder"  is NULL)) OR
((s."MBulkIssueItem" != d."MBulkIssueItem")  OR (s."MBulkIssueItem"  is not NULL and d."MBulkIssueItem"  is NULL) OR (d."MBulkIssueItem"  is not NULL and s."MBulkIssueItem"  is NULL)) OR
((s."MPurchaseOrdLin" != d."MPurchaseOrdLin")  OR (s."MPurchaseOrdLin"  is not NULL and d."MPurchaseOrdLin"  is NULL) OR (d."MPurchaseOrdLin"  is not NULL and s."MPurchaseOrdLin"  is NULL)) OR
((s."MAllocationLine" != d."MAllocationLine")  OR (s."MAllocationLine"  is not NULL and d."MAllocationLine"  is NULL) OR (d."MAllocationLine"  is not NULL and s."MAllocationLine"  is NULL)) OR
((s."MDecimals" != d."MDecimals")  OR (s."MDecimals"  is not NULL and d."MDecimals"  is NULL) OR (d."MDecimals"  is not NULL and s."MDecimals"  is NULL)) OR
((s."MSubJob" != d."MSubJob")  OR (s."MSubJob"  is not NULL and d."MSubJob"  is NULL) OR (d."MSubJob"  is not NULL and s."MSubJob"  is NULL)) OR
((s."MQtyIssuedEnt" != d."MQtyIssuedEnt")  OR (s."MQtyIssuedEnt"  is not NULL and d."MQtyIssuedEnt"  is NULL) OR (d."MQtyIssuedEnt"  is not NULL and s."MQtyIssuedEnt"  is NULL)) OR
((s."MSerial" != d."MSerial")  OR (s."MSerial"  is not NULL and d."MSerial"  is NULL) OR (d."MSerial"  is not NULL and s."MSerial"  is NULL)) OR
((s."MUnitCostActual" != d."MUnitCostActual")  OR (s."MUnitCostActual"  is not NULL and d."MUnitCostActual"  is NULL) OR (d."MUnitCostActual"  is not NULL and s."MUnitCostActual"  is NULL)) OR
((s."LWorkCentre" != d."LWorkCentre")  OR (s."LWorkCentre"  is not NULL and d."LWorkCentre"  is NULL) OR (d."LWorkCentre"  is not NULL and s."LWorkCentre"  is NULL)) OR
((s."LWorkCentreDesc" != d."LWorkCentreDesc")  OR (s."LWorkCentreDesc"  is not NULL and d."LWorkCentreDesc"  is NULL) OR (d."LWorkCentreDesc"  is not NULL and s."LWorkCentreDesc"  is NULL)) OR
((s."LRunTimeHours" != d."LRunTimeHours")  OR (s."LRunTimeHours"  is not NULL and d."LRunTimeHours"  is NULL) OR (d."LRunTimeHours"  is not NULL and s."LRunTimeHours"  is NULL)) OR
((s."LSetUpHours" != d."LSetUpHours")  OR (s."LSetUpHours"  is not NULL and d."LSetUpHours"  is NULL) OR (d."LSetUpHours"  is not NULL and s."LSetUpHours"  is NULL)) OR
((s."LStartupHours" != d."LStartupHours")  OR (s."LStartupHours"  is not NULL and d."LStartupHours"  is NULL) OR (d."LStartupHours"  is not NULL and s."LStartupHours"  is NULL)) OR
((s."LTeardownHours" != d."LTeardownHours")  OR (s."LTeardownHours"  is not NULL and d."LTeardownHours"  is NULL) OR (d."LTeardownHours"  is not NULL and s."LTeardownHours"  is NULL)) OR
((s."LOperation" != d."LOperation")  OR (s."LOperation"  is not NULL and d."LOperation"  is NULL) OR (d."LOperation"  is not NULL and s."LOperation"  is NULL)) OR
((s."LMachine" != d."LMachine")  OR (s."LMachine"  is not NULL and d."LMachine"  is NULL) OR (d."LMachine"  is not NULL and s."LMachine"  is NULL)) OR
((s."LRunTimeRate" != d."LRunTimeRate")  OR (s."LRunTimeRate"  is not NULL and d."LRunTimeRate"  is NULL) OR (d."LRunTimeRate"  is not NULL and s."LRunTimeRate"  is NULL)) OR
((s."LSetUpTimeRate" != d."LSetUpTimeRate")  OR (s."LSetUpTimeRate"  is not NULL and d."LSetUpTimeRate"  is NULL) OR (d."LSetUpTimeRate"  is not NULL and s."LSetUpTimeRate"  is NULL)) OR
((s."LFixedTimeRate" != d."LFixedTimeRate")  OR (s."LFixedTimeRate"  is not NULL and d."LFixedTimeRate"  is NULL) OR (d."LFixedTimeRate"  is not NULL and s."LFixedTimeRate"  is NULL)) OR
((s."LVarTimeRate" != d."LVarTimeRate")  OR (s."LVarTimeRate"  is not NULL and d."LVarTimeRate"  is NULL) OR (d."LVarTimeRate"  is not NULL and s."LVarTimeRate"  is NULL)) OR
((s."LStartTimeRate" != d."LStartTimeRate")  OR (s."LStartTimeRate"  is not NULL and d."LStartTimeRate"  is NULL) OR (d."LStartTimeRate"  is not NULL and s."LStartTimeRate"  is NULL)) OR
((s."LTeardownRate" != d."LTeardownRate")  OR (s."LTeardownRate"  is not NULL and d."LTeardownRate"  is NULL) OR (d."LTeardownRate"  is not NULL and s."LTeardownRate"  is NULL)) OR
((s."LSubcontractFlag" != d."LSubcontractFlag")  OR (s."LSubcontractFlag"  is not NULL and d."LSubcontractFlag"  is NULL) OR (d."LSubcontractFlag"  is not NULL and s."LSubcontractFlag"  is NULL)) OR
((s."LEmployee" != d."LEmployee")  OR (s."LEmployee"  is not NULL and d."LEmployee"  is NULL) OR (d."LEmployee"  is not NULL and s."LEmployee"  is NULL)) OR
((s."LQtyScrapped" != d."LQtyScrapped")  OR (s."LQtyScrapped"  is not NULL and d."LQtyScrapped"  is NULL) OR (d."LQtyScrapped"  is not NULL and s."LQtyScrapped"  is NULL)) OR
((s."LQtyComplete" != d."LQtyComplete")  OR (s."LQtyComplete"  is not NULL and d."LQtyComplete"  is NULL) OR (d."LQtyComplete"  is not NULL and s."LQtyComplete"  is NULL)) OR
((s."LWcRateInd" != d."LWcRateInd")  OR (s."LWcRateInd"  is not NULL and d."LWcRateInd"  is NULL) OR (d."LWcRateInd"  is not NULL and s."LWcRateInd"  is NULL)) OR
((s."LEmployeeRatInd" != d."LEmployeeRatInd")  OR (s."LEmployeeRatInd"  is not NULL and d."LEmployeeRatInd"  is NULL) OR (d."LEmployeeRatInd"  is not NULL and s."LEmployeeRatInd"  is NULL)) OR
((s."LScrapCode" != d."LScrapCode")  OR (s."LScrapCode"  is not NULL and d."LScrapCode"  is NULL) OR (d."LScrapCode"  is not NULL and s."LScrapCode"  is NULL)) OR
((s."LNonProdCode" != d."LNonProdCode")  OR (s."LNonProdCode"  is not NULL and d."LNonProdCode"  is NULL) OR (d."LNonProdCode"  is not NULL and s."LNonProdCode"  is NULL)) OR
((s."LReference" != d."LReference")  OR (s."LReference"  is not NULL and d."LReference"  is NULL) OR (d."LReference"  is not NULL and s."LReference"  is NULL)) OR
((s."LAddReference" != d."LAddReference")  OR (s."LAddReference"  is not NULL and d."LAddReference"  is NULL) OR (d."LAddReference"  is not NULL and s."LAddReference"  is NULL)) OR
((s."LTrnTime" != d."LTrnTime")  OR (s."LTrnTime"  is not NULL and d."LTrnTime"  is NULL) OR (d."LTrnTime"  is not NULL and s."LTrnTime"  is NULL)) OR
((s."LTrnSplit" != d."LTrnSplit")  OR (s."LTrnSplit"  is not NULL and d."LTrnSplit"  is NULL) OR (d."LTrnSplit"  is not NULL and s."LTrnSplit"  is NULL)) OR
((s."LQtyScrappedEnt" != d."LQtyScrappedEnt")  OR (s."LQtyScrappedEnt"  is not NULL and d."LQtyScrappedEnt"  is NULL) OR (d."LQtyScrappedEnt"  is not NULL and s."LQtyScrappedEnt"  is NULL)) OR
((s."LQtyCompleteEnt" != d."LQtyCompleteEnt")  OR (s."LQtyCompleteEnt"  is not NULL and d."LQtyCompleteEnt"  is NULL) OR (d."LQtyCompleteEnt"  is not NULL and s."LQtyCompleteEnt"  is NULL)) OR
((s."LRunTimeHoursEnt" != d."LRunTimeHoursEnt")  OR (s."LRunTimeHoursEnt"  is not NULL and d."LRunTimeHoursEnt"  is NULL) OR (d."LRunTimeHoursEnt"  is not NULL and s."LRunTimeHoursEnt"  is NULL)) OR
((s."TrnValue" != d."TrnValue")  OR (s."TrnValue"  is not NULL and d."TrnValue"  is NULL) OR (d."TrnValue"  is not NULL and s."TrnValue"  is NULL)) OR
((s."TrnDate" != d."TrnDate")  OR (s."TrnDate"  is not NULL and d."TrnDate"  is NULL) OR (d."TrnDate"  is not NULL and s."TrnDate"  is NULL)) OR
((s."Journal" != d."Journal")  OR (s."Journal"  is not NULL and d."Journal"  is NULL) OR (d."Journal"  is not NULL and s."Journal"  is NULL)) OR
((s."Hierarchy1" != d."Hierarchy1")  OR (s."Hierarchy1"  is not NULL and d."Hierarchy1"  is NULL) OR (d."Hierarchy1"  is not NULL and s."Hierarchy1"  is NULL)) OR
((s."Hierarchy2" != d."Hierarchy2")  OR (s."Hierarchy2"  is not NULL and d."Hierarchy2"  is NULL) OR (d."Hierarchy2"  is not NULL and s."Hierarchy2"  is NULL)) OR
((s."Hierarchy3" != d."Hierarchy3") OR (s."Hierarchy3"  is not NULL and d."Hierarchy3"  is NULL) OR (d."Hierarchy3"  is not NULL and s."Hierarchy3"  is NULL)) OR
((s."Hierarchy4" != d."Hierarchy4")  OR (s."Hierarchy4"  is not NULL and d."Hierarchy4"  is NULL) OR (d."Hierarchy4"  is not NULL and s."Hierarchy4"  is NULL)) OR
((s."Hierarchy5" != d."Hierarchy5")  OR (s."Hierarchy5"  is not NULL and d."Hierarchy5"  is NULL) OR (d."Hierarchy5"  is not NULL and s."Hierarchy5"  is NULL)) OR
((s."PostYear" != d."PostYear")  OR (s."PostYear"  is not NULL and d."PostYear"  is NULL) OR (d."PostYear"  is not NULL and s."PostYear"  is NULL)) OR
((s."PostMonth" != d."PostMonth")  OR (s."PostMonth"  is not NULL and d."PostMonth"  is NULL) OR (d."PostMonth"  is not NULL and s."PostMonth"  is NULL)) OR
((s."SourceModule" != d."SourceModule") OR (s."SourceModule"  is not NULL and d."SourceModule"  is NULL) OR (d."SourceModule"  is not NULL and s."SourceModule"  is NULL))
);

END;
