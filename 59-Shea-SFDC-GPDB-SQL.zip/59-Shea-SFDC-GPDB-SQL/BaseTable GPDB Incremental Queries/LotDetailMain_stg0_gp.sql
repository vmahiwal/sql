--LotDetailMain_stg0_gp

BEGIN;
insert into sysprocompanyb.lotdetailmain_stg0_gp select s.*
from sysprocompanyb.lotdetailmain_stg0 s LEFT JOIN sysprocompanyb.lotdetailmain_stg0_gp d
ON (s."StockCode"=d."StockCode" and s."Warehouse"=d."Warehouse"and s."Lot"=d."Lot"and s."Bin"=d."Bin") 
where (d."StockCode" is null and d."Warehouse" is null and d."Bin" is null and d."Lot" is null);
Savepoint sp2;
--Delete
delete from sysprocompanyb.lotdetailmain_stg0_gp 
where (sysprocompanyb.lotdetailmain_stg0_gp."StockCode",sysprocompanyb.lotdetailmain_stg0_gp."Warehouse",sysprocompanyb.lotdetailmain_stg0_gp."Lot",sysprocompanyb.lotdetailmain_stg0_gp."Bin")
in
(
select d."StockCode",d."Warehouse",d."Lot",d."Bin"
from
sysprocompanyb.lotdetailmain_stg0_gp d
left join
sysprocompanyb.lotdetailmain_stg0 s
on
s."StockCode"=d."StockCode" and s."Warehouse"=d."Warehouse"and s."Lot"=d."Lot"and s."Bin"=d."Bin"
where s."StockCode" is null and s."Warehouse" is null and s."Bin" is null and s."Lot" is null
);
UPDATE sysprocompanyb.lotdetailmain_stg0_gp d
SET
"time" = s."time",
"StockCode" = s."StockCode",
"Warehouse" = s."Warehouse",
"Lot" = s."Lot",
"Bin" = s."Bin",
"NextTrnLine" = s."NextTrnLine",
"OrigQtyReceived" = s."OrigQtyReceived",
"QtyOnHand" = s."QtyOnHand",
"QtyToShip" = s."QtyToShip",
"Version" = s."Version",
"Release" = s."Release",
"ExpiryDate" = s."ExpiryDate",
"CreationDate" = s."CreationDate",
"DrawOfficeNum" = s."DrawOfficeNum",
"LastTrnDate" = s."LastTrnDate",
"ArchiveFilename" = s."ArchiveFilename",
"QtyInTransit" = s."QtyInTransit",
"LotHoldFlag" = s."LotHoldFlag",
"Note" = s."Note",
"EccDummy" = s."EccDummy",
"QtyAwaitingCredit" = s."QtyAwaitingCredit",
"QtyReserved" = s."QtyReserved",
"SupplierLot" = s."SupplierLot",
"ProductShelfLife" = s."ProductShelfLife",
"InternalShelfLife" = s."InternalShelfLife",
"UseByDate" = s."UseByDate",
"SellByDate" = s."SellByDate",
"InternalExpiryDate" = s."InternalExpiryDate"
FROM sysprocompanyb.lotdetailmain_stg0 s
Where (s."StockCode"=d."StockCode" and s."Warehouse"=d."Warehouse"and s."Lot"=d."Lot"and s."Bin"=d."Bin") and
(
(
((s."StockCode" != d."StockCode")  OR (s."StockCode"  is not NULL and d."StockCode"  is NULL) OR (d."StockCode"  is not NULL and s."StockCode"  is NULL)) OR
((s."Warehouse" != d."Warehouse")  OR (s."Warehouse"  is not NULL and d."Warehouse"  is NULL) OR (d."Warehouse"  is not NULL and s."Warehouse"  is NULL)) OR
((s."Lot" != d."Lot")  OR (s."Lot"  is not NULL and d."Lot"  is NULL) OR (d."Lot"  is not NULL and s."Lot"  is NULL)) OR
((s."Bin" != d."Bin")  OR (s."Bin"  is not NULL and d."Bin"  is NULL) OR (d."Bin"  is not NULL and s."Bin"  is NULL)) OR
((s."NextTrnLine" != d."NextTrnLine")  OR (s."NextTrnLine"  is not NULL and d."NextTrnLine"  is NULL) OR (d."NextTrnLine"  is not NULL and s."NextTrnLine"  is NULL)) OR
((s."OrigQtyReceived" != d."OrigQtyReceived")  OR (s."OrigQtyReceived"  is not NULL and d."OrigQtyReceived"  is NULL) OR (d."OrigQtyReceived"  is not NULL and s."OrigQtyReceived"  is NULL)) OR
((s."QtyOnHand" != d."QtyOnHand")  OR (s."QtyOnHand"  is not NULL and d."QtyOnHand"  is NULL) OR (d."QtyOnHand"  is not NULL and s."QtyOnHand"  is NULL)) OR
((s."QtyToShip" != d."QtyToShip")  OR (s."QtyToShip"  is not NULL and d."QtyToShip"  is NULL) OR (d."QtyToShip"  is not NULL and s."QtyToShip"  is NULL)) OR
((s."Version" != d."Version")  OR (s."Version"  is not NULL and d."Version"  is NULL) OR (d."Version"  is not NULL and s."Version"  is NULL)) OR
((s."Release" != d."Release")  OR (s."Release"  is not NULL and d."Release"  is NULL) OR (d."Release"  is not NULL and s."Release"  is NULL)) OR
((s."ExpiryDate" != d."ExpiryDate")  OR (s."ExpiryDate"  is not NULL and d."ExpiryDate"  is NULL) OR (d."ExpiryDate"  is not NULL and s."ExpiryDate"  is NULL)) OR
((s."CreationDate" != d."CreationDate")  OR (s."CreationDate"  is not NULL and d."CreationDate"  is NULL) OR (d."CreationDate"  is not NULL and s."CreationDate"  is NULL)) OR
((s."DrawOfficeNum" != d."DrawOfficeNum")  OR (s."DrawOfficeNum"  is not NULL and d."DrawOfficeNum"  is NULL) OR (d."DrawOfficeNum"  is not NULL and s."DrawOfficeNum"  is NULL)) OR
((s."LastTrnDate" != d."LastTrnDate")  OR (s."LastTrnDate"  is not NULL and d."LastTrnDate"  is NULL) OR (d."LastTrnDate"  is not NULL and s."LastTrnDate"  is NULL)) OR
((s."ArchiveFilename" != d."ArchiveFilename")  OR (s."ArchiveFilename"  is not NULL and d."ArchiveFilename"  is NULL) OR (d."ArchiveFilename"  is not NULL and s."ArchiveFilename"  is NULL)) OR
((s."QtyInTransit" != d."QtyInTransit")  OR (s."QtyInTransit"  is not NULL and d."QtyInTransit"  is NULL) OR (d."QtyInTransit"  is not NULL and s."QtyInTransit"  is NULL)) OR
((s."LotHoldFlag" != d."LotHoldFlag")  OR (s."LotHoldFlag"  is not NULL and d."LotHoldFlag"  is NULL) OR (d."LotHoldFlag"  is not NULL and s."LotHoldFlag"  is NULL)) OR
((s."Note" != d."Note")  OR (s."Note"  is not NULL and d."Note"  is NULL) OR (d."Note"  is not NULL and s."Note"  is NULL)) OR
((s."EccDummy" != d."EccDummy")  OR (s."EccDummy"  is not NULL and d."EccDummy"  is NULL) OR (d."EccDummy"  is not NULL and s."EccDummy"  is NULL)) OR
((s."QtyAwaitingCredit" != d."QtyAwaitingCredit")  OR (s."QtyAwaitingCredit"  is not NULL and d."QtyAwaitingCredit"  is NULL) OR (d."QtyAwaitingCredit"  is not NULL and s."QtyAwaitingCredit"  is NULL)) OR
((s."QtyReserved" != d."QtyReserved")  OR (s."QtyReserved"  is not NULL and d."QtyReserved"  is NULL) OR (d."QtyReserved"  is not NULL and s."QtyReserved"  is NULL)) OR
((s."SupplierLot" != d."SupplierLot")  OR (s."SupplierLot"  is not NULL and d."SupplierLot"  is NULL) OR (d."SupplierLot"  is not NULL and s."SupplierLot"  is NULL)) OR
((s."ProductShelfLife" != d."ProductShelfLife")  OR (s."ProductShelfLife"  is not NULL and d."ProductShelfLife"  is NULL) OR (d."ProductShelfLife"  is not NULL and s."ProductShelfLife"  is NULL)) OR
((s."InternalShelfLife" != d."InternalShelfLife")  OR (s."InternalShelfLife"  is not NULL and d."InternalShelfLife"  is NULL) OR (d."InternalShelfLife"  is not NULL and s."InternalShelfLife"  is NULL)) OR
((s."UseByDate" != d."UseByDate")  OR (s."UseByDate"  is not NULL and d."UseByDate"  is NULL) OR (d."UseByDate"  is not NULL and s."UseByDate"  is NULL)) OR
((s."SellByDate" != d."SellByDate")  OR (s."SellByDate"  is not NULL and d."SellByDate"  is NULL) OR (d."SellByDate"  is not NULL and s."SellByDate"  is NULL)) OR
((s."InternalExpiryDate" != d."InternalExpiryDate") OR (s."InternalExpiryDate"  is not NULL and d."InternalExpiryDate"  is NULL) OR (d."InternalExpiryDate"  is not NULL and s."InternalExpiryDate"  is NULL))
));
END;
