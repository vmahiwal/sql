--InvWarehousemain_stg0_gp



BEGIN;
---insert
insert into sysprocompanyb.InvWarehousemain_stg0_gp 
select s.* from sysprocompanyb.InvWarehousemain_stg0 s
 LEFT JOIN sysprocompanyb.InvWarehousemain_stg0_gp d 
ON  s."StockCode" = d."StockCode" and s."Warehouse" = d."Warehouse" 
where d."StockCode" is null and d."Warehouse" is null;

---delete
delete from sysprocompanyb.invwarehousemain_stg0_gp 
where
( sysprocompanyb.invwarehousemain_stg0_gp."StockCode",
sysprocompanyb.invwarehousemain_stg0_gp."Warehouse")
in
( 
select d."StockCode", d."Warehouse"
from sysprocompanyb.invwarehousemain_stg0_gp d
left join sysprocompanyb.invwarehousemain_stg0 s
on s."StockCode"=d."StockCode" and s."Warehouse"=d."Warehouse"
where s."StockCode" is null and s."Warehouse" is null
);

--update Query
UPDATE sysprocompanyb.InvWarehousemain_stg0_gp d
SET
"time"= s."time",
"QtyOnHand" = s."QtyOnHand",
"MtdQtyReceived" = s."MtdQtyReceived",
"MtdQtyAdjusted" = s."MtdQtyAdjusted",
"MtdQtyTrf" = s."MtdQtyTrf",
"MtdQtyIssued" = s."MtdQtyIssued",
"MtdQtySold" = s."MtdQtySold",
"QtyAllocated" = s."QtyAllocated",
"QtyOnOrder" = s."QtyOnOrder",
"QtyOnBackOrder" = s."QtyOnBackOrder",
"MinimumQty" = s."MinimumQty",
"MaximumQty" = s."MaximumQty",
"YtdQtySold" = s."YtdQtySold",
"PrevYearQtySold" = s."PrevYearQtySold",
"OpeningBalance" = s."OpeningBalance",
"YtdUsageValue" = s."YtdUsageValue",
"AbcClass" = s."AbcClass",
"UnitCost" = s."UnitCost",
"DefaultBin" = s."DefaultBin",
"DateLastSale" = s."DateLastSale",
"DateLastStockMove" = s."DateLastStockMove",
"DateLastCostChange" = s."DateLastCostChange",
"DateLastStockCnt" = s."DateLastStockCnt",
"DateLastPurchase" = s."DateLastPurchase",
"QtyInTransit" = s."QtyInTransit",
"TransferValue" = s."TransferValue",
"SafetyStockQty" = s."SafetyStockQty",
"ReOrderQty" = s."ReOrderQty",
"QtyAllocatedWip" = s."QtyAllocatedWip",
"InterfaceFlag" = s."InterfaceFlag",
"CostMultiplier" = s."CostMultiplier",
"LastCostEntered" = s."LastCostEntered",
"MtdSalesValue" = s."MtdSalesValue",
"YtdSalesValue" = s."YtdSalesValue",
"PrevYtdSalesVal" = s."PrevYtdSalesVal",
"QtyInInspection" = s."QtyInInspection",
"PalletQty" = s."PalletQty",
"NumMonthsHistory" = s."NumMonthsHistory",
"YtdQtyIssued" = s."YtdQtyIssued",
"RequisitionFlag" = s."RequisitionFlag",
"SalesQty1" = s."SalesQty1",
"SalesQty2" = s."SalesQty2",
"SalesQty3" = s."SalesQty3",
"SalesQty4" = s."SalesQty4",
"SalesQty5" = s."SalesQty5",
"SalesQty6" = s."SalesQty6",
"SalesQty7" = s."SalesQty7",
"SalesQty8" = s."SalesQty8",
"SalesQty9" = s."SalesQty9",
"SalesQty10" = s."SalesQty10",
"SalesQty11" = s."SalesQty11",
"SalesQty12" = s."SalesQty12",
"UserField1" = s."UserField1",
"UserField2" = s."UserField2",
"UserField3" = s."UserField3",
"TrfSuppliedItem" = s."TrfSuppliedItem",
"DefaultSourceWh" = s."DefaultSourceWh",
"TrfLeadTime" = s."TrfLeadTime",
"TrfCostGlCode" = s."TrfCostGlCode",
"TrfCostMultiply" = s."TrfCostMultiply",
"QtyDispatched" = s."QtyDispatched",
"OpenBalQty1" = s."OpenBalQty1",
"OpenBalQty2" = s."OpenBalQty2",
"OpenBalQty3" = s."OpenBalQty3",
"OpenBalQty4" = s."OpenBalQty4",
"OpenBalQty5" = s."OpenBalQty5",
"OpenBalQty6" = s."OpenBalQty6",
"OpenBalQty7" = s."OpenBalQty7",
"OpenBalQty8" = s."OpenBalQty8",
"OpenBalQty9" = s."OpenBalQty9",
"OpenBalQty10" = s."OpenBalQty10",
"OpenBalQty11" = s."OpenBalQty11",
"OpenBalQty12" = s."OpenBalQty12",
"OpenBalCost1" = s."OpenBalCost1",
"OpenBalCost2" = s."OpenBalCost2",
"OpenBalCost3" = s."OpenBalCost3",
"OpenBalCost4" = s."OpenBalCost4",
"OpenBalCost5" = s."OpenBalCost5",
"OpenBalCost6" = s."OpenBalCost6",
"OpenBalCost7" = s."OpenBalCost7",
"OpenBalCost8" = s."OpenBalCost8",
"OpenBalCost9" = s."OpenBalCost9",
"OpenBalCost10" = s."OpenBalCost10",
"OpenBalCost11" = s."OpenBalCost11",
"OpenBalCost12" = s."OpenBalCost12",
"AgedQty1" = s."AgedQty1",
"AgedQty2" = s."AgedQty2",
"AgedQty3" = s."AgedQty3",
"AgedQty4" = s."AgedQty4",
"AgedQty5" = s."AgedQty5",
"AgedQty6" = s."AgedQty6",
"TrfReplenishWh" = s."TrfReplenishWh",
"TrfBuyingRule" = s."TrfBuyingRule",
"TrfDockToStock" = s."TrfDockToStock",
"TrfFixTimePeriod" = s."TrfFixTimePeriod",
"LabourCost" = s."LabourCost",
"MaterialCost" = s."MaterialCost",
"FixedOverhead" = s."FixedOverhead",
"VariableOverhead" = s."VariableOverhead",
"StdLabCostsBill" = s."StdLabCostsBill",
"SubContractCost" = s."SubContractCost",
"DateWhAdded" = s."DateWhAdded",
"RmaQtyIssued" = s."RmaQtyIssued",
"LastExtendedCost" = s."LastExtendedCost",
"OrderPolicy" = s."OrderPolicy",
"MajorOrderMult" = s."MajorOrderMult",
"MinorOrderMult" = s."MinorOrderMult",
"OrderMinimum" = s."OrderMinimum",
"OrderMaximum" = s."OrderMaximum",
"OrderFixPeriod" = s."OrderFixPeriod",
"ManualCostFlag" = s."ManualCostFlag",
"LeadTime" = s."LeadTime",
"ManufLeadTime" = s."ManufLeadTime",
"TransferCost" = s."TransferCost",
"ImplosionNum" = s."ImplosionNum",
"ExcludeFromSched" = s."ExcludeFromSched",
"QtyWipReserved" = s."QtyWipReserved",
"Supplier" = s."Supplier",
"BoughtOutWhsLvl" = s."BoughtOutWhsLvl",
"DockToStock" = s."DockToStock",
"TimeStamp" = s."TimeStamp"


FROM sysprocompanyb.InvWarehousemain_stg0 s
WHERE s."StockCode"=d."StockCode" and s."Warehouse"=d."Warehouse" and
(
((s."QtyOnHand" != d."QtyOnHand")  OR (s."QtyOnHand"  is not NULL and d."QtyOnHand"  is NULL) OR (d."QtyOnHand"  is not NULL and s."QtyOnHand"  is NULL)) OR
((s."MtdQtyReceived" != d."MtdQtyReceived")  OR (s."MtdQtyReceived"  is not NULL and d."MtdQtyReceived"  is NULL) OR (d."MtdQtyReceived"  is not NULL and s."MtdQtyReceived"  is NULL)) OR
((s."MtdQtyAdjusted" != d."MtdQtyAdjusted")  OR (s."MtdQtyAdjusted"  is not NULL and d."MtdQtyAdjusted"  is NULL) OR (d."MtdQtyAdjusted"  is not NULL and s."MtdQtyAdjusted"  is NULL)) OR
((s."MtdQtyTrf" != d."MtdQtyTrf")  OR (s."MtdQtyTrf"  is not NULL and d."MtdQtyTrf"  is NULL) OR (d."MtdQtyTrf"  is not NULL and s."MtdQtyTrf"  is NULL)) OR
((s."MtdQtyIssued" != d."MtdQtyIssued")  OR (s."MtdQtyIssued"  is not NULL and d."MtdQtyIssued"  is NULL) OR (d."MtdQtyIssued"  is not NULL and s."MtdQtyIssued"  is NULL)) OR
((s."MtdQtySold" != d."MtdQtySold")  OR (s."MtdQtySold"  is not NULL and d."MtdQtySold"  is NULL) OR (d."MtdQtySold"  is not NULL and s."MtdQtySold"  is NULL)) OR
((s."QtyAllocated" != d."QtyAllocated")  OR (s."QtyAllocated"  is not NULL and d."QtyAllocated"  is NULL) OR (d."QtyAllocated"  is not NULL and s."QtyAllocated"  is NULL)) OR
((s."QtyOnOrder" != d."QtyOnOrder")  OR (s."QtyOnOrder"  is not NULL and d."QtyOnOrder"  is NULL) OR (d."QtyOnOrder"  is not NULL and s."QtyOnOrder"  is NULL)) OR
((s."QtyOnBackOrder" != d."QtyOnBackOrder")  OR (s."QtyOnBackOrder"  is not NULL and d."QtyOnBackOrder"  is NULL) OR (d."QtyOnBackOrder"  is not NULL and s."QtyOnBackOrder"  is NULL)) OR
((s."MinimumQty" != d."MinimumQty")  OR (s."MinimumQty"  is not NULL and d."MinimumQty"  is NULL) OR (d."MinimumQty"  is not NULL and s."MinimumQty"  is NULL)) OR
((s."MaximumQty" != d."MaximumQty")  OR (s."MaximumQty"  is not NULL and d."MaximumQty"  is NULL) OR (d."MaximumQty"  is not NULL and s."MaximumQty"  is NULL)) OR
((s."YtdQtySold" != d."YtdQtySold")  OR (s."YtdQtySold"  is not NULL and d."YtdQtySold"  is NULL) OR (d."YtdQtySold"  is not NULL and s."YtdQtySold"  is NULL)) OR
((s."PrevYearQtySold" != d."PrevYearQtySold")  OR (s."PrevYearQtySold"  is not NULL and d."PrevYearQtySold"  is NULL) OR (d."PrevYearQtySold"  is not NULL and s."PrevYearQtySold"  is NULL)) OR
((s."OpeningBalance" != d."OpeningBalance")  OR (s."OpeningBalance"  is not NULL and d."OpeningBalance"  is NULL) OR (d."OpeningBalance"  is not NULL and s."OpeningBalance"  is NULL)) OR
((s."YtdUsageValue" != d."YtdUsageValue")  OR (s."YtdUsageValue"  is not NULL and d."YtdUsageValue"  is NULL) OR (d."YtdUsageValue"  is not NULL and s."YtdUsageValue"  is NULL)) OR
((s."AbcClass" != d."AbcClass")  OR (s."AbcClass"  is not NULL and d."AbcClass"  is NULL) OR (d."AbcClass"  is not NULL and s."AbcClass"  is NULL)) OR
((s."UnitCost" != d."UnitCost")  OR (s."UnitCost"  is not NULL and d."UnitCost"  is NULL) OR (d."UnitCost"  is not NULL and s."UnitCost"  is NULL)) OR
((s."DefaultBin" != d."DefaultBin")  OR (s."DefaultBin"  is not NULL and d."DefaultBin"  is NULL) OR (d."DefaultBin"  is not NULL and s."DefaultBin"  is NULL)) OR
((s."DateLastSale" != d."DateLastSale")  OR (s."DateLastSale"  is not NULL and d."DateLastSale"  is NULL) OR (d."DateLastSale"  is not NULL and s."DateLastSale"  is NULL)) OR
((s."DateLastStockMove" != d."DateLastStockMove")  OR (s."DateLastStockMove"  is not NULL and d."DateLastStockMove"  is NULL) OR (d."DateLastStockMove"  is not NULL and s."DateLastStockMove"  is NULL)) OR
((s."DateLastCostChange" != d."DateLastCostChange")  OR (s."DateLastCostChange"  is not NULL and d."DateLastCostChange"  is NULL) OR (d."DateLastCostChange"  is not NULL and s."DateLastCostChange"  is NULL)) OR
((s."DateLastStockCnt" != d."DateLastStockCnt")  OR (s."DateLastStockCnt"  is not NULL and d."DateLastStockCnt"  is NULL) OR (d."DateLastStockCnt"  is not NULL and s."DateLastStockCnt"  is NULL)) OR
((s."DateLastPurchase" != d."DateLastPurchase")  OR (s."DateLastPurchase"  is not NULL and d."DateLastPurchase"  is NULL) OR (d."DateLastPurchase"  is not NULL and s."DateLastPurchase"  is NULL)) OR
((s."QtyInTransit" != d."QtyInTransit")  OR (s."QtyInTransit"  is not NULL and d."QtyInTransit"  is NULL) OR (d."QtyInTransit"  is not NULL and s."QtyInTransit"  is NULL)) OR
((s."TransferValue" != d."TransferValue")  OR (s."TransferValue"  is not NULL and d."TransferValue"  is NULL) OR (d."TransferValue"  is not NULL and s."TransferValue"  is NULL)) OR
((s."SafetyStockQty" != d."SafetyStockQty")  OR (s."SafetyStockQty"  is not NULL and d."SafetyStockQty"  is NULL) OR (d."SafetyStockQty"  is not NULL and s."SafetyStockQty"  is NULL)) OR
((s."ReOrderQty" != d."ReOrderQty")  OR (s."ReOrderQty"  is not NULL and d."ReOrderQty"  is NULL) OR (d."ReOrderQty"  is not NULL and s."ReOrderQty"  is NULL)) OR
((s."QtyAllocatedWip" != d."QtyAllocatedWip")  OR (s."QtyAllocatedWip"  is not NULL and d."QtyAllocatedWip"  is NULL) OR (d."QtyAllocatedWip"  is not NULL and s."QtyAllocatedWip"  is NULL)) OR
((s."InterfaceFlag" != d."InterfaceFlag")  OR (s."InterfaceFlag"  is not NULL and d."InterfaceFlag"  is NULL) OR (d."InterfaceFlag"  is not NULL and s."InterfaceFlag"  is NULL)) OR
((s."CostMultiplier" != d."CostMultiplier")  OR (s."CostMultiplier"  is not NULL and d."CostMultiplier"  is NULL) OR (d."CostMultiplier"  is not NULL and s."CostMultiplier"  is NULL)) OR
((s."LastCostEntered" != d."LastCostEntered")  OR (s."LastCostEntered"  is not NULL and d."LastCostEntered"  is NULL) OR (d."LastCostEntered"  is not NULL and s."LastCostEntered"  is NULL)) OR
((s."MtdSalesValue" != d."MtdSalesValue")  OR (s."MtdSalesValue"  is not NULL and d."MtdSalesValue"  is NULL) OR (d."MtdSalesValue"  is not NULL and s."MtdSalesValue"  is NULL)) OR
((s."YtdSalesValue" != d."YtdSalesValue")  OR (s."YtdSalesValue"  is not NULL and d."YtdSalesValue"  is NULL) OR (d."YtdSalesValue"  is not NULL and s."YtdSalesValue"  is NULL)) OR
((s."PrevYtdSalesVal" != d."PrevYtdSalesVal")  OR (s."PrevYtdSalesVal"  is not NULL and d."PrevYtdSalesVal"  is NULL) OR (d."PrevYtdSalesVal"  is not NULL and s."PrevYtdSalesVal"  is NULL)) OR
((s."QtyInInspection" != d."QtyInInspection")  OR (s."QtyInInspection"  is not NULL and d."QtyInInspection"  is NULL) OR (d."QtyInInspection"  is not NULL and s."QtyInInspection"  is NULL)) OR
((s."PalletQty" != d."PalletQty")  OR (s."PalletQty"  is not NULL and d."PalletQty"  is NULL) OR (d."PalletQty"  is not NULL and s."PalletQty"  is NULL)) OR
((s."NumMonthsHistory" != d."NumMonthsHistory")  OR (s."NumMonthsHistory"  is not NULL and d."NumMonthsHistory"  is NULL) OR (d."NumMonthsHistory"  is not NULL and s."NumMonthsHistory"  is NULL)) OR
((s."YtdQtyIssued" != d."YtdQtyIssued")  OR (s."YtdQtyIssued"  is not NULL and d."YtdQtyIssued"  is NULL) OR (d."YtdQtyIssued"  is not NULL and s."YtdQtyIssued"  is NULL)) OR
((s."RequisitionFlag" != d."RequisitionFlag")  OR (s."RequisitionFlag"  is not NULL and d."RequisitionFlag"  is NULL) OR (d."RequisitionFlag"  is not NULL and s."RequisitionFlag"  is NULL)) OR
((s."SalesQty1" != d."SalesQty1")  OR (s."SalesQty1"  is not NULL and d."SalesQty1"  is NULL) OR (d."SalesQty1"  is not NULL and s."SalesQty1"  is NULL)) OR
((s."SalesQty2" != d."SalesQty2")  OR (s."SalesQty2"  is not NULL and d."SalesQty2"  is NULL) OR (d."SalesQty2"  is not NULL and s."SalesQty2"  is NULL)) OR
((s."SalesQty3" != d."SalesQty3")  OR (s."SalesQty3"  is not NULL and d."SalesQty3"  is NULL) OR (d."SalesQty3"  is not NULL and s."SalesQty3"  is NULL)) OR
((s."SalesQty4" != d."SalesQty4")  OR (s."SalesQty4"  is not NULL and d."SalesQty4"  is NULL) OR (d."SalesQty4"  is not NULL and s."SalesQty4"  is NULL)) OR
((s."SalesQty5" != d."SalesQty5")  OR (s."SalesQty5"  is not NULL and d."SalesQty5"  is NULL) OR (d."SalesQty5"  is not NULL and s."SalesQty5"  is NULL)) OR
((s."SalesQty6" != d."SalesQty6")  OR (s."SalesQty6"  is not NULL and d."SalesQty6"  is NULL) OR (d."SalesQty6"  is not NULL and s."SalesQty6"  is NULL)) OR
((s."SalesQty7" != d."SalesQty7")  OR (s."SalesQty7"  is not NULL and d."SalesQty7"  is NULL) OR (d."SalesQty7"  is not NULL and s."SalesQty7"  is NULL)) OR
((s."SalesQty8" != d."SalesQty8")  OR (s."SalesQty8"  is not NULL and d."SalesQty8"  is NULL) OR (d."SalesQty8"  is not NULL and s."SalesQty8"  is NULL)) OR
((s."SalesQty9" != d."SalesQty9")  OR (s."SalesQty9"  is not NULL and d."SalesQty9"  is NULL) OR (d."SalesQty9"  is not NULL and s."SalesQty9"  is NULL)) OR
((s."SalesQty10" != d."SalesQty10")  OR (s."SalesQty10"  is not NULL and d."SalesQty10"  is NULL) OR (d."SalesQty10"  is not NULL and s."SalesQty10"  is NULL)) OR
((s."SalesQty11" != d."SalesQty11")  OR (s."SalesQty11"  is not NULL and d."SalesQty11"  is NULL) OR (d."SalesQty11"  is not NULL and s."SalesQty11"  is NULL)) OR
((s."SalesQty12" != d."SalesQty12")  OR (s."SalesQty12"  is not NULL and d."SalesQty12"  is NULL) OR (d."SalesQty12"  is not NULL and s."SalesQty12"  is NULL)) OR
((s."UserField1" != d."UserField1")  OR (s."UserField1"  is not NULL and d."UserField1"  is NULL) OR (d."UserField1"  is not NULL and s."UserField1"  is NULL)) OR
((s."UserField2" != d."UserField2")  OR (s."UserField2"  is not NULL and d."UserField2"  is NULL) OR (d."UserField2"  is not NULL and s."UserField2"  is NULL)) OR
((s."UserField3" != d."UserField3")  OR (s."UserField3"  is not NULL and d."UserField3"  is NULL) OR (d."UserField3"  is not NULL and s."UserField3"  is NULL)) OR
((s."TrfSuppliedItem" != d."TrfSuppliedItem")  OR (s."TrfSuppliedItem"  is not NULL and d."TrfSuppliedItem"  is NULL) OR (d."TrfSuppliedItem"  is not NULL and s."TrfSuppliedItem"  is NULL)) OR
((s."DefaultSourceWh" != d."DefaultSourceWh")  OR (s."DefaultSourceWh"  is not NULL and d."DefaultSourceWh"  is NULL) OR (d."DefaultSourceWh"  is not NULL and s."DefaultSourceWh"  is NULL)) OR
((s."TrfLeadTime" != d."TrfLeadTime")  OR (s."TrfLeadTime"  is not NULL and d."TrfLeadTime"  is NULL) OR (d."TrfLeadTime"  is not NULL and s."TrfLeadTime"  is NULL)) OR
((s."TrfCostGlCode" != d."TrfCostGlCode")  OR (s."TrfCostGlCode"  is not NULL and d."TrfCostGlCode"  is NULL) OR (d."TrfCostGlCode"  is not NULL and s."TrfCostGlCode"  is NULL)) OR
((s."TrfCostMultiply" != d."TrfCostMultiply")  OR (s."TrfCostMultiply"  is not NULL and d."TrfCostMultiply"  is NULL) OR (d."TrfCostMultiply"  is not NULL and s."TrfCostMultiply"  is NULL)) OR
((s."QtyDispatched" != d."QtyDispatched")  OR (s."QtyDispatched"  is not NULL and d."QtyDispatched"  is NULL) OR (d."QtyDispatched"  is not NULL and s."QtyDispatched"  is NULL)) OR
((s."OpenBalQty1" != d."OpenBalQty1")  OR (s."OpenBalQty1"  is not NULL and d."OpenBalQty1"  is NULL) OR (d."OpenBalQty1"  is not NULL and s."OpenBalQty1"  is NULL)) OR
((s."OpenBalQty2" != d."OpenBalQty2")  OR (s."OpenBalQty2"  is not NULL and d."OpenBalQty2"  is NULL) OR (d."OpenBalQty2"  is not NULL and s."OpenBalQty2"  is NULL)) OR
((s."OpenBalQty3" != d."OpenBalQty3")  OR (s."OpenBalQty3"  is not NULL and d."OpenBalQty3"  is NULL) OR (d."OpenBalQty3"  is not NULL and s."OpenBalQty3"  is NULL)) OR
((s."OpenBalQty4" != d."OpenBalQty4")  OR (s."OpenBalQty4"  is not NULL and d."OpenBalQty4"  is NULL) OR (d."OpenBalQty4"  is not NULL and s."OpenBalQty4"  is NULL)) OR
((s."OpenBalQty5" != d."OpenBalQty5")  OR (s."OpenBalQty5"  is not NULL and d."OpenBalQty5"  is NULL) OR (d."OpenBalQty5"  is not NULL and s."OpenBalQty5"  is NULL)) OR
((s."OpenBalQty6" != d."OpenBalQty6")  OR (s."OpenBalQty6"  is not NULL and d."OpenBalQty6"  is NULL) OR (d."OpenBalQty6"  is not NULL and s."OpenBalQty6"  is NULL)) OR
((s."OpenBalQty7" != d."OpenBalQty7")  OR (s."OpenBalQty7"  is not NULL and d."OpenBalQty7"  is NULL) OR (d."OpenBalQty7"  is not NULL and s."OpenBalQty7"  is NULL)) OR
((s."OpenBalQty8" != d."OpenBalQty8")  OR (s."OpenBalQty8"  is not NULL and d."OpenBalQty8"  is NULL) OR (d."OpenBalQty8"  is not NULL and s."OpenBalQty8"  is NULL)) OR
((s."OpenBalQty9" != d."OpenBalQty9")  OR (s."OpenBalQty9"  is not NULL and d."OpenBalQty9"  is NULL) OR (d."OpenBalQty9"  is not NULL and s."OpenBalQty9"  is NULL)) OR
((s."OpenBalQty10" != d."OpenBalQty10")  OR (s."OpenBalQty10"  is not NULL and d."OpenBalQty10"  is NULL) OR (d."OpenBalQty10"  is not NULL and s."OpenBalQty10"  is NULL)) OR
((s."OpenBalQty11" != d."OpenBalQty11")  OR (s."OpenBalQty11"  is not NULL and d."OpenBalQty11"  is NULL) OR (d."OpenBalQty11"  is not NULL and s."OpenBalQty11"  is NULL)) OR
((s."OpenBalQty12" != d."OpenBalQty12")  OR (s."OpenBalQty12"  is not NULL and d."OpenBalQty12"  is NULL) OR (d."OpenBalQty12"  is not NULL and s."OpenBalQty12"  is NULL)) OR
((s."OpenBalCost1" != d."OpenBalCost1")  OR (s."OpenBalCost1"  is not NULL and d."OpenBalCost1"  is NULL) OR (d."OpenBalCost1"  is not NULL and s."OpenBalCost1"  is NULL)) OR
((s."OpenBalCost2" != d."OpenBalCost2")  OR (s."OpenBalCost2"  is not NULL and d."OpenBalCost2"  is NULL) OR (d."OpenBalCost2"  is not NULL and s."OpenBalCost2"  is NULL)) OR
((s."OpenBalCost3" != d."OpenBalCost3")  OR (s."OpenBalCost3"  is not NULL and d."OpenBalCost3"  is NULL) OR (d."OpenBalCost3"  is not NULL and s."OpenBalCost3"  is NULL)) OR
((s."OpenBalCost4" != d."OpenBalCost4")  OR (s."OpenBalCost4"  is not NULL and d."OpenBalCost4"  is NULL) OR (d."OpenBalCost4"  is not NULL and s."OpenBalCost4"  is NULL)) OR
((s."OpenBalCost5" != d."OpenBalCost5")  OR (s."OpenBalCost5"  is not NULL and d."OpenBalCost5"  is NULL) OR (d."OpenBalCost5"  is not NULL and s."OpenBalCost5"  is NULL)) OR
((s."OpenBalCost6" != d."OpenBalCost6")  OR (s."OpenBalCost6"  is not NULL and d."OpenBalCost6"  is NULL) OR (d."OpenBalCost6"  is not NULL and s."OpenBalCost6"  is NULL)) OR
((s."OpenBalCost7" != d."OpenBalCost7")  OR (s."OpenBalCost7"  is not NULL and d."OpenBalCost7"  is NULL) OR (d."OpenBalCost7"  is not NULL and s."OpenBalCost7"  is NULL)) OR
((s."OpenBalCost8" != d."OpenBalCost8")  OR (s."OpenBalCost8"  is not NULL and d."OpenBalCost8"  is NULL) OR (d."OpenBalCost8"  is not NULL and s."OpenBalCost8"  is NULL)) OR
((s."OpenBalCost9" != d."OpenBalCost9")  OR (s."OpenBalCost9"  is not NULL and d."OpenBalCost9"  is NULL) OR (d."OpenBalCost9"  is not NULL and s."OpenBalCost9"  is NULL)) OR
((s."OpenBalCost10" != d."OpenBalCost10")  OR (s."OpenBalCost10"  is not NULL and d."OpenBalCost10"  is NULL) OR (d."OpenBalCost10"  is not NULL and s."OpenBalCost10"  is NULL)) OR
((s."OpenBalCost11" != d."OpenBalCost11")  OR (s."OpenBalCost11"  is not NULL and d."OpenBalCost11"  is NULL) OR (d."OpenBalCost11"  is not NULL and s."OpenBalCost11"  is NULL)) OR
((s."OpenBalCost12" != d."OpenBalCost12")  OR (s."OpenBalCost12"  is not NULL and d."OpenBalCost12"  is NULL) OR (d."OpenBalCost12"  is not NULL and s."OpenBalCost12"  is NULL)) OR
((s."AgedQty1" != d."AgedQty1")  OR (s."AgedQty1"  is not NULL and d."AgedQty1"  is NULL) OR (d."AgedQty1"  is not NULL and s."AgedQty1"  is NULL)) OR
((s."AgedQty2" != d."AgedQty2")  OR (s."AgedQty2"  is not NULL and d."AgedQty2"  is NULL) OR (d."AgedQty2"  is not NULL and s."AgedQty2"  is NULL)) OR
((s."AgedQty3" != d."AgedQty3")  OR (s."AgedQty3"  is not NULL and d."AgedQty3"  is NULL) OR (d."AgedQty3"  is not NULL and s."AgedQty3"  is NULL)) OR
((s."AgedQty4" != d."AgedQty4")  OR (s."AgedQty4"  is not NULL and d."AgedQty4"  is NULL) OR (d."AgedQty4"  is not NULL and s."AgedQty4"  is NULL)) OR
((s."AgedQty5" != d."AgedQty5")  OR (s."AgedQty5"  is not NULL and d."AgedQty5"  is NULL) OR (d."AgedQty5"  is not NULL and s."AgedQty5"  is NULL)) OR
((s."AgedQty6" != d."AgedQty6")  OR (s."AgedQty6"  is not NULL and d."AgedQty6"  is NULL) OR (d."AgedQty6"  is not NULL and s."AgedQty6"  is NULL)) OR
((s."TrfReplenishWh" != d."TrfReplenishWh")  OR (s."TrfReplenishWh"  is not NULL and d."TrfReplenishWh"  is NULL) OR (d."TrfReplenishWh"  is not NULL and s."TrfReplenishWh"  is NULL)) OR
((s."TrfBuyingRule" != d."TrfBuyingRule")  OR (s."TrfBuyingRule"  is not NULL and d."TrfBuyingRule"  is NULL) OR (d."TrfBuyingRule"  is not NULL and s."TrfBuyingRule"  is NULL)) OR
((s."TrfDockToStock" != d."TrfDockToStock")  OR (s."TrfDockToStock"  is not NULL and d."TrfDockToStock"  is NULL) OR (d."TrfDockToStock"  is not NULL and s."TrfDockToStock"  is NULL)) OR
((s."TrfFixTimePeriod" != d."TrfFixTimePeriod")  OR (s."TrfFixTimePeriod"  is not NULL and d."TrfFixTimePeriod"  is NULL) OR (d."TrfFixTimePeriod"  is not NULL and s."TrfFixTimePeriod"  is NULL)) OR
((s."LabourCost" != d."LabourCost")  OR (s."LabourCost"  is not NULL and d."LabourCost"  is NULL) OR (d."LabourCost"  is not NULL and s."LabourCost"  is NULL)) OR
((s."MaterialCost" != d."MaterialCost")  OR (s."MaterialCost"  is not NULL and d."MaterialCost"  is NULL) OR (d."MaterialCost"  is not NULL and s."MaterialCost"  is NULL)) OR
((s."FixedOverhead" != d."FixedOverhead")  OR (s."FixedOverhead"  is not NULL and d."FixedOverhead"  is NULL) OR (d."FixedOverhead"  is not NULL and s."FixedOverhead"  is NULL)) OR
((s."VariableOverhead" != d."VariableOverhead")  OR (s."VariableOverhead"  is not NULL and d."VariableOverhead"  is NULL) OR (d."VariableOverhead"  is not NULL and s."VariableOverhead"  is NULL)) OR
((s."StdLabCostsBill" != d."StdLabCostsBill")  OR (s."StdLabCostsBill"  is not NULL and d."StdLabCostsBill"  is NULL) OR (d."StdLabCostsBill"  is not NULL and s."StdLabCostsBill"  is NULL)) OR
((s."SubContractCost" != d."SubContractCost")  OR (s."SubContractCost"  is not NULL and d."SubContractCost"  is NULL) OR (d."SubContractCost"  is not NULL and s."SubContractCost"  is NULL)) OR
((s."DateWhAdded" != d."DateWhAdded")  OR (s."DateWhAdded"  is not NULL and d."DateWhAdded"  is NULL) OR (d."DateWhAdded"  is not NULL and s."DateWhAdded"  is NULL)) OR
((s."RmaQtyIssued" != d."RmaQtyIssued")  OR (s."RmaQtyIssued"  is not NULL and d."RmaQtyIssued"  is NULL) OR (d."RmaQtyIssued"  is not NULL and s."RmaQtyIssued"  is NULL)) OR
((s."LastExtendedCost" != d."LastExtendedCost")  OR (s."LastExtendedCost"  is not NULL and d."LastExtendedCost"  is NULL) OR (d."LastExtendedCost"  is not NULL and s."LastExtendedCost"  is NULL)) OR
((s."OrderPolicy" != d."OrderPolicy")  OR (s."OrderPolicy"  is not NULL and d."OrderPolicy"  is NULL) OR (d."OrderPolicy"  is not NULL and s."OrderPolicy"  is NULL)) OR
((s."MajorOrderMult" != d."MajorOrderMult")  OR (s."MajorOrderMult"  is not NULL and d."MajorOrderMult"  is NULL) OR (d."MajorOrderMult"  is not NULL and s."MajorOrderMult"  is NULL)) OR
((s."MinorOrderMult" != d."MinorOrderMult")  OR (s."MinorOrderMult"  is not NULL and d."MinorOrderMult"  is NULL) OR (d."MinorOrderMult"  is not NULL and s."MinorOrderMult"  is NULL)) OR
((s."OrderMinimum" != d."OrderMinimum")  OR (s."OrderMinimum"  is not NULL and d."OrderMinimum"  is NULL) OR (d."OrderMinimum"  is not NULL and s."OrderMinimum"  is NULL)) OR
((s."OrderMaximum" != d."OrderMaximum")  OR (s."OrderMaximum"  is not NULL and d."OrderMaximum"  is NULL) OR (d."OrderMaximum"  is not NULL and s."OrderMaximum"  is NULL)) OR
((s."OrderFixPeriod" != d."OrderFixPeriod")  OR (s."OrderFixPeriod"  is not NULL and d."OrderFixPeriod"  is NULL) OR (d."OrderFixPeriod"  is not NULL and s."OrderFixPeriod"  is NULL)) OR
((s."ManualCostFlag" != d."ManualCostFlag")  OR (s."ManualCostFlag"  is not NULL and d."ManualCostFlag"  is NULL) OR (d."ManualCostFlag"  is not NULL and s."ManualCostFlag"  is NULL)) OR
((s."LeadTime" != d."LeadTime")  OR (s."LeadTime"  is not NULL and d."LeadTime"  is NULL) OR (d."LeadTime"  is not NULL and s."LeadTime"  is NULL)) OR
((s."ManufLeadTime" != d."ManufLeadTime")  OR (s."ManufLeadTime"  is not NULL and d."ManufLeadTime"  is NULL) OR (d."ManufLeadTime"  is not NULL and s."ManufLeadTime"  is NULL)) OR
((s."TransferCost" != d."TransferCost")  OR (s."TransferCost"  is not NULL and d."TransferCost"  is NULL) OR (d."TransferCost"  is not NULL and s."TransferCost"  is NULL)) OR
((s."ImplosionNum" != d."ImplosionNum")  OR (s."ImplosionNum"  is not NULL and d."ImplosionNum"  is NULL) OR (d."ImplosionNum"  is not NULL and s."ImplosionNum"  is NULL)) OR
((s."ExcludeFromSched" != d."ExcludeFromSched")  OR (s."ExcludeFromSched"  is not NULL and d."ExcludeFromSched"  is NULL) OR (d."ExcludeFromSched"  is not NULL and s."ExcludeFromSched"  is NULL)) OR
((s."Supplier" != d."Supplier")  OR (s."Supplier"  is not NULL and d."Supplier"  is NULL) OR (d."Supplier"  is not NULL and s."Supplier"  is NULL)) OR
((s."BoughtOutWhsLvl" != d."BoughtOutWhsLvl")  OR (s."BoughtOutWhsLvl"  is not NULL and d."BoughtOutWhsLvl"  is NULL) OR (d."BoughtOutWhsLvl"  is not NULL and s."BoughtOutWhsLvl"  is NULL)) OR
((s."DockToStock" != d."DockToStock") OR (s."DockToStock"  is not NULL and d."DockToStock"  is NULL) OR (d."DockToStock"  is not NULL and s."DockToStock"  is NULL)) 
);

END;
