--PorMasterHdrMain_stg0_gp


BEGIN;
insert into sysprocompanyb.pormasterhdrmain_stg0_gp select s.*
from sysprocompanyb.pormasterhdrmain_stg0 s LEFT JOIN sysprocompanyb.pormasterhdrmain_stg0_gp d
ON s."PurchaseOrder"=d."PurchaseOrder" where d."PurchaseOrder" is null ;
Savepoint sp2;
--Delete
delete from sysprocompanyb.pormasterhdrmain_stg0_gp
where sysprocompanyb.pormasterhdrmain_stg0_gp."PurchaseOrder"
in
(
select d."PurchaseOrder"
from
sysprocompanyb.pormasterhdrmain_stg0_gp d
left join
sysprocompanyb.pormasterhdrmain_stg0 s
on
s."PurchaseOrder"=d."PurchaseOrder"
where s."PurchaseOrder" is null
);
UPDATE sysprocompanyb.pormasterhdrmain_stg0_gp d
SET
"time"= s."time",
"NextDetailLine" = s."NextDetailLine",
"OrderStatus" = s."OrderStatus",
"ActiveFlag" = s."ActiveFlag",
"CancelledFlag" = s."CancelledFlag",
"Supplier" = s."Supplier",
"OrderEntryDate" = s."OrderEntryDate",
"OrderDueDate" = s."OrderDueDate",
"DateLastDocPrt" = s."DateLastDocPrt",
"MemoDate" = s."MemoDate",
"MemoCode" = s."MemoCode",
"OrderType" = s."OrderType",
"SupplierClass" = s."SupplierClass",
"Customer" = s."Customer",
"CustomerPoNumber" = s."CustomerPoNumber",
"PaymentTerms" = s."PaymentTerms",
"ShippingInstrs" = s."ShippingInstrs",
"Warehouse" = s."Warehouse",
"DiscPct1" = s."DiscPct1",
"DiscPct2" = s."DiscPct2",
"DiscPct3" = s."DiscPct3",
"Currency" = s."Currency",
"TaxStatus" = s."TaxStatus",
"PrintCount" = s."PrintCount",
"AmendedCount" = s."AmendedCount",
"DatePoCompleted" = s."DatePoCompleted",
"ExchangeRate" = s."ExchangeRate",
"MulDiv" = s."MulDiv",
"ExchRateFixed" = s."ExchRateFixed",
"Nationality" = s."Nationality",
"TermsCode" = s."TermsCode",
"UserConfirmation" = s."UserConfirmation",
"EdiPoFlag" = s."EdiPoFlag",
"EdiExtractFlag" = s."EdiExtractFlag",
"EdiActionFlag" = s."EdiActionFlag",
"Buyer" = s."Buyer",
"EdiConfirmation" = s."EdiConfirmation",
"FaxDocument" = s."FaxDocument",
"DeliveryName" = s."DeliveryName",
"DeliveryAddr1" = s."DeliveryAddr1",
"DeliveryAddr2" = s."DeliveryAddr2",
"DeliveryAddr3" = s."DeliveryAddr3",
"DeliveryAddr3Loc" = s."DeliveryAddr3Loc",
"DeliveryAddr4" = s."DeliveryAddr4",
"DeliveryAddr5" = s."DeliveryAddr5",
"PostalCode" = s."PostalCode",
"DeliveryGpsLat" = s."DeliveryGpsLat",
"DeliveryGpsLong" = s."DeliveryGpsLong",
"DocumentFormat" = s."DocumentFormat",
"ContractNumber" = s."ContractNumber",
"User1" = s."User1",
"DeliveryMethod" = s."DeliveryMethod",
"AutoVoucherReqd" = s."AutoVoucherReqd",
"LanguageCode" = s."LanguageCode",
"AutoUpdatePo" = s."AutoUpdatePo",
"State" = s."State",
"CountyZip" = s."CountyZip",
"City" = s."City",
"ShippingLocation" = s."ShippingLocation",
"DeliveryTerms" = s."DeliveryTerms",
"IncludeInMrp" = s."IncludeInMrp",
"TimeStamp" = s."TimeStamp"
FROM sysprocompanyb.pormasterhdrmain_stg0 s
Where (s."PurchaseOrder"=d."PurchaseOrder") and
(
((s."NextDetailLine" != d."NextDetailLine")  OR (s."NextDetailLine"  is not NULL and d."NextDetailLine"  is NULL) OR (d."NextDetailLine"  is not NULL and s."NextDetailLine"  is NULL)) OR
((s."OrderStatus" != d."OrderStatus")  OR (s."OrderStatus"  is not NULL and d."OrderStatus"  is NULL) OR (d."OrderStatus"  is not NULL and s."OrderStatus"  is NULL)) OR
((s."ActiveFlag" != d."ActiveFlag")  OR (s."ActiveFlag"  is not NULL and d."ActiveFlag"  is NULL) OR (d."ActiveFlag"  is not NULL and s."ActiveFlag"  is NULL)) OR
((s."CancelledFlag" != d."CancelledFlag")  OR (s."CancelledFlag"  is not NULL and d."CancelledFlag"  is NULL) OR (d."CancelledFlag"  is not NULL and s."CancelledFlag"  is NULL)) OR
((s."Supplier" != d."Supplier")  OR (s."Supplier"  is not NULL and d."Supplier"  is NULL) OR (d."Supplier"  is not NULL and s."Supplier"  is NULL)) OR
((s."OrderEntryDate" != d."OrderEntryDate")  OR (s."OrderEntryDate"  is not NULL and d."OrderEntryDate"  is NULL) OR (d."OrderEntryDate"  is not NULL and s."OrderEntryDate"  is NULL)) OR
((s."OrderDueDate" != d."OrderDueDate")  OR (s."OrderDueDate"  is not NULL and d."OrderDueDate"  is NULL) OR (d."OrderDueDate"  is not NULL and s."OrderDueDate"  is NULL)) OR
((s."DateLastDocPrt" != d."DateLastDocPrt")  OR (s."DateLastDocPrt"  is not NULL and d."DateLastDocPrt"  is NULL) OR (d."DateLastDocPrt"  is not NULL and s."DateLastDocPrt"  is NULL)) OR
((s."MemoDate" != d."MemoDate")  OR (s."MemoDate"  is not NULL and d."MemoDate"  is NULL) OR (d."MemoDate"  is not NULL and s."MemoDate"  is NULL)) OR
((s."MemoCode" != d."MemoCode")  OR (s."MemoCode"  is not NULL and d."MemoCode"  is NULL) OR (d."MemoCode"  is not NULL and s."MemoCode"  is NULL)) OR
((s."OrderType" != d."OrderType")  OR (s."OrderType"  is not NULL and d."OrderType"  is NULL) OR (d."OrderType"  is not NULL and s."OrderType"  is NULL)) OR
((s."SupplierClass" != d."SupplierClass")  OR (s."SupplierClass"  is not NULL and d."SupplierClass"  is NULL) OR (d."SupplierClass"  is not NULL and s."SupplierClass"  is NULL)) OR
((s."Customer" != d."Customer") OR (s."Customer"  is not NULL and d."Customer"  is NULL) OR (d."Customer"  is not NULL and s."Customer"  is NULL)) OR
((s."CustomerPoNumber" != d."CustomerPoNumber")  OR (s."CustomerPoNumber"  is not NULL and d."CustomerPoNumber"  is NULL) OR (d."CustomerPoNumber"  is not NULL and s."CustomerPoNumber"  is NULL)) OR
((s."PaymentTerms" != d."PaymentTerms")  OR (s."PaymentTerms"  is not NULL and d."PaymentTerms"  is NULL) OR (d."PaymentTerms"  is not NULL and s."PaymentTerms"  is NULL)) OR
((s."ShippingInstrs" != d."ShippingInstrs")  OR (s."ShippingInstrs"  is not NULL and d."ShippingInstrs"  is NULL) OR (d."ShippingInstrs"  is not NULL and s."ShippingInstrs"  is NULL)) OR
((s."Warehouse" != d."Warehouse")  OR (s."Warehouse"  is not NULL and d."Warehouse"  is NULL) OR (d."Warehouse"  is not NULL and s."Warehouse"  is NULL)) OR
((s."DiscPct1" != d."DiscPct1")  OR (s."DiscPct1"  is not NULL and d."DiscPct1"  is NULL) OR (d."DiscPct1"  is not NULL and s."DiscPct1"  is NULL)) OR
((s."DiscPct2" != d."DiscPct2")  OR (s."DiscPct2"  is not NULL and d."DiscPct2"  is NULL) OR (d."DiscPct2"  is not NULL and s."DiscPct2"  is NULL)) OR
((s."DiscPct3" != d."DiscPct3")  OR (s."DiscPct3"  is not NULL and d."DiscPct3"  is NULL) OR (d."DiscPct3"  is not NULL and s."DiscPct3"  is NULL)) OR
((s."Currency" != d."Currency")  OR (s."Currency"  is not NULL and d."Currency"  is NULL) OR (d."Currency"  is not NULL and s."Currency"  is NULL)) OR
((s."TaxStatus" != d."TaxStatus")  OR (s."TaxStatus"  is not NULL and d."TaxStatus"  is NULL) OR (d."TaxStatus"  is not NULL and s."TaxStatus"  is NULL)) OR
((s."PrintCount" != d."PrintCount")  OR (s."PrintCount"  is not NULL and d."PrintCount"  is NULL) OR (d."PrintCount"  is not NULL and s."PrintCount"  is NULL)) OR
((s."AmendedCount" != d."AmendedCount")  OR (s."AmendedCount"  is not NULL and d."AmendedCount"  is NULL) OR (d."AmendedCount"  is not NULL and s."AmendedCount"  is NULL)) OR
((s."DatePoCompleted" != d."DatePoCompleted")  OR (s."DatePoCompleted"  is not NULL and d."DatePoCompleted"  is NULL) OR (d."DatePoCompleted"  is not NULL and s."DatePoCompleted"  is NULL)) OR
((s."ExchangeRate" != d."ExchangeRate")  OR (s."ExchangeRate"  is not NULL and d."ExchangeRate"  is NULL) OR (d."ExchangeRate"  is not NULL and s."ExchangeRate"  is NULL)) OR
((s."MulDiv" != d."MulDiv") OR (s."MulDiv"  is not NULL and d."MulDiv"  is NULL) OR (d."MulDiv"  is not NULL and s."MulDiv"  is NULL)) OR
((s."ExchRateFixed" != d."ExchRateFixed")  OR (s."ExchRateFixed"  is not NULL and d."ExchRateFixed"  is NULL) OR (d."ExchRateFixed"  is not NULL and s."ExchRateFixed"  is NULL)) OR
((s."Nationality" != d."Nationality")  OR (s."Nationality"  is not NULL and d."Nationality"  is NULL) OR (d."Nationality"  is not NULL and s."Nationality"  is NULL)) OR
((s."TermsCode" != d."TermsCode")  OR (s."TermsCode"  is not NULL and d."TermsCode"  is NULL) OR (d."TermsCode"  is not NULL and s."TermsCode"  is NULL)) OR
((s."UserConfirmation" != d."UserConfirmation")  OR (s."UserConfirmation"  is not NULL and d."UserConfirmation"  is NULL) OR (d."UserConfirmation"  is not NULL and s."UserConfirmation"  is NULL)) OR
((s."EdiPoFlag" != d."EdiPoFlag")  OR (s."EdiPoFlag"  is not NULL and d."EdiPoFlag"  is NULL) OR (d."EdiPoFlag"  is not NULL and s."EdiPoFlag"  is NULL)) OR
((s."EdiExtractFlag" != d."EdiExtractFlag")  OR (s."EdiExtractFlag"  is not NULL and d."EdiExtractFlag"  is NULL) OR (d."EdiExtractFlag"  is not NULL and s."EdiExtractFlag"  is NULL)) OR
((s."EdiActionFlag" != d."EdiActionFlag")  OR (s."EdiActionFlag"  is not NULL and d."EdiActionFlag"  is NULL) OR (d."EdiActionFlag"  is not NULL and s."EdiActionFlag"  is NULL)) OR
((s."Buyer" != d."Buyer")  OR (s."Buyer"  is not NULL and d."Buyer"  is NULL) OR (d."Buyer"  is not NULL and s."Buyer"  is NULL)) OR
((s."EdiConfirmation" != d."EdiConfirmation")  OR (s."EdiConfirmation"  is not NULL and d."EdiConfirmation"  is NULL) OR (d."EdiConfirmation"  is not NULL and s."EdiConfirmation"  is NULL)) OR
((s."FaxDocument" != d."FaxDocument")  OR (s."FaxDocument"  is not NULL and d."FaxDocument"  is NULL) OR (d."FaxDocument"  is not NULL and s."FaxDocument"  is NULL)) OR
((s."DeliveryName" != d."DeliveryName")  OR (s."DeliveryName"  is not NULL and d."DeliveryName"  is NULL) OR (d."DeliveryName"  is not NULL and s."DeliveryName"  is NULL)) OR
((s."DeliveryAddr1" != d."DeliveryAddr1")  OR (s."DeliveryAddr1"  is not NULL and d."DeliveryAddr1"  is NULL) OR (d."DeliveryAddr1"  is not NULL and s."DeliveryAddr1"  is NULL)) OR
((s."DeliveryAddr2" != d."DeliveryAddr2")  OR (s."DeliveryAddr2"  is not NULL and d."DeliveryAddr2"  is NULL) OR (d."DeliveryAddr2"  is not NULL and s."DeliveryAddr2"  is NULL)) OR
((s."DeliveryAddr3" != d."DeliveryAddr3")  OR (s."DeliveryAddr3"  is not NULL and d."DeliveryAddr3"  is NULL) OR (d."DeliveryAddr3"  is not NULL and s."DeliveryAddr3"  is NULL)) OR
((s."DeliveryAddr3Loc" != d."DeliveryAddr3Loc")  OR (s."DeliveryAddr3Loc"  is not NULL and d."DeliveryAddr3Loc"  is NULL) OR (d."DeliveryAddr3Loc"  is not NULL and s."DeliveryAddr3Loc"  is NULL)) OR
((s."DeliveryAddr4" != d."DeliveryAddr4")  OR (s."DeliveryAddr4"  is not NULL and d."DeliveryAddr4"  is NULL) OR (d."DeliveryAddr4"  is not NULL and s."DeliveryAddr4"  is NULL)) OR
((s."DeliveryAddr5" != d."DeliveryAddr5")  OR (s."DeliveryAddr5"  is not NULL and d."DeliveryAddr5"  is NULL) OR (d."DeliveryAddr5"  is not NULL and s."DeliveryAddr5"  is NULL)) OR
((s."PostalCode" != d."PostalCode")  OR (s."PostalCode"  is not NULL and d."PostalCode"  is NULL) OR (d."PostalCode"  is not NULL and s."PostalCode"  is NULL)) OR
((s."DeliveryGpsLat" != d."DeliveryGpsLat")  OR (s."DeliveryGpsLat"  is not NULL and d."DeliveryGpsLat"  is NULL) OR (d."DeliveryGpsLat"  is not NULL and s."DeliveryGpsLat"  is NULL)) OR
((s."DeliveryGpsLong" != d."DeliveryGpsLong")  OR (s."DeliveryGpsLong"  is not NULL and d."DeliveryGpsLong"  is NULL) OR (d."DeliveryGpsLong"  is not NULL and s."DeliveryGpsLong"  is NULL)) OR
((s."DocumentFormat" != d."DocumentFormat")  OR (s."DocumentFormat"  is not NULL and d."DocumentFormat"  is NULL) OR (d."DocumentFormat"  is not NULL and s."DocumentFormat"  is NULL)) OR
((s."ContractNumber" != d."ContractNumber")  OR (s."ContractNumber"  is not NULL and d."ContractNumber"  is NULL) OR (d."ContractNumber"  is not NULL and s."ContractNumber"  is NULL)) OR
((s."User1" != d."User1")  OR (s."User1"  is not NULL and d."User1"  is NULL) OR (d."User1"  is not NULL and s."User1"  is NULL)) OR
((s."DeliveryMethod" != d."DeliveryMethod")  OR (s."DeliveryMethod"  is not NULL and d."DeliveryMethod"  is NULL) OR (d."DeliveryMethod"  is not NULL and s."DeliveryMethod"  is NULL)) OR
((s."AutoVoucherReqd" != d."AutoVoucherReqd")  OR (s."AutoVoucherReqd"  is not NULL and d."AutoVoucherReqd"  is NULL) OR (d."AutoVoucherReqd"  is not NULL and s."AutoVoucherReqd"  is NULL)) OR
((s."LanguageCode" != d."LanguageCode")  OR (s."LanguageCode"  is not NULL and d."LanguageCode"  is NULL) OR (d."LanguageCode"  is not NULL and s."LanguageCode"  is NULL)) OR
((s."AutoUpdatePo" != d."AutoUpdatePo")  OR (s."AutoUpdatePo"  is not NULL and d."AutoUpdatePo"  is NULL) OR (d."AutoUpdatePo"  is not NULL and s."AutoUpdatePo"  is NULL)) OR
((s."State" != d."State")  OR (s."State"  is not NULL and d."State"  is NULL) OR (d."State"  is not NULL and s."State"  is NULL)) OR
((s."CountyZip" != d."CountyZip")  OR (s."CountyZip"  is not NULL and d."CountyZip"  is NULL) OR (d."CountyZip"  is not NULL and s."CountyZip"  is NULL)) OR
((s."City" != d."City")  OR (s."City"  is not NULL and d."City"  is NULL) OR (d."City"  is not NULL and s."City"  is NULL)) OR
((s."ShippingLocation" != d."ShippingLocation")  OR (s."ShippingLocation"  is not NULL and d."ShippingLocation"  is NULL) OR (d."ShippingLocation"  is not NULL and s."ShippingLocation"  is NULL)) OR
((s."DeliveryTerms" != d."DeliveryTerms") OR (s."DeliveryTerms"  is not NULL and d."DeliveryTerms"  is NULL) OR (d."DeliveryTerms"  is not NULL and s."DeliveryTerms"  is NULL)) OR
((s."IncludeInMrp" != d."IncludeInMrp") OR (s."IncludeInMrp"  is not NULL and d."IncludeInMrp"  is NULL) OR (d."IncludeInMrp"  is not NULL and s."IncludeInMrp"  is NULL))
);
END;
