--Admformvalidation_stg0_gp


BEGIN;
--Insert
INSERT INTO sysprocompanyb.admformvalidationmain_stg0_gp SELECT s.* 
FROM sysprocompanyb.admformvalidationmain_stg0 s LEFT JOIN sysprocompanyb.admformvalidationmain_stg0_gp d
ON (s."FormType" = d."FormType" 
and s."FieldName" = d."FieldName"
and s."Item" = d."Item" )
WHERE (d."FormType" IS NULL and d."FieldName" IS NULL and d."Item" IS NULL); 

SAVEPOINT sd;
-----
delete from sysprocompanyb.admformvalidationmain_stg0_gp
where(sysprocompanyb.admformvalidationmain_stg0_gp."FormType", 
sysprocompanyb.admformvalidationmain_stg0_gp."FieldName",
 sysprocompanyb.admformvalidationmain_stg0_gp."Item" )
in
(
select d."FormType", d."FieldName", d."Item"
from
sysprocompanyb.admformvalidationmain_stg0_gp d 
left join
sysprocompanyb.admformvalidationmain_stg0 s
on
s."FormType"=d."FormType" and s."FieldName" = d."FieldName" and s."Item" = d."Item"
where s."FormType" is null  and s."FieldName" is null and s."Item" is null
);


--Update
UPDATE sysprocompanyb.admformvalidationmain_stg0_gp d
SET
"Description" = s."Description",
"DefaultItem" = s."DefaultItem"
FROM sysprocompanyb.AdmFormValidationmain_stg0 s 
WHERE 
d."time" = s."time" and
d."FormType" = s."FormType" and
d."FieldName" = s."FieldName" and
d."Item" = s."Item"
AND
(
((s."time" != d."time")  OR (s."time"  is not NULL and d."time"  is NULL) OR (d."time"  is not NULL and s."time"  is NULL)) OR
((s."Description" != d."Description")  OR (s."Description"  is not NULL and d."Description"  is NULL) OR (d."Description"  is not NULL and s."Description"  is NULL)) OR
((s."DefaultItem" != d."DefaultItem") OR (s."DefaultItem"  is not NULL and d."DefaultItem"  is NULL) OR (d."DefaultItem"  is not NULL and s."DefaultItem"  is NULL))
);
