--WipPartBookMain_stg0_gp



BEGIN;
insert into sysprocompanyb.wippartbookmain_stg0_gp 
select s.* from 
sysprocompanyb.wippartbookmain_stg0 s LEFT JOIN sysprocompanyb.wippartbookmain_stg0_gp d 
ON (s."Line"=d."Line" and s."Job"=d."Job") 
where (d."Line" is null and d."Job" is null) ;


delete from sysprocompanyb.wippartbookmain_stg0_gp
 where
(sysprocompanyb.wippartbookmain_stg0_gp."Line",
sysprocompanyb.wippartbookmain_stg0_gp."Job")
in
(
select d."Line",d."Job"
from
sysprocompanyb.wippartbookmain_stg0_gp d 
left join sysprocompanyb.wippartbookmain_stg0 s
on s."Line"=d."Line" and s."Job"=d."Job"
where
s."Line" is null and s."Job" is null
);
---Update
UPDATE sysprocompanyb.wippartbookmain_stg0_gp d
SET
"time" = s."time",
"QtySupplied" = s."QtySupplied",
"TrnDate" = s."TrnDate",
"Journal" = s."Journal",
"LabourValue" = s."LabourValue",
"MaterialValue" = s."MaterialValue",
"Reference" = s."Reference",
"AddReference" = s."AddReference",
"SalesOrder" = s."SalesOrder",
"MasterJob" = s."MasterJob",
"CoProductLine" = s."CoProductLine",
"CoProduct" = s."CoProduct",
"QtySuppliedEnt" = s."QtySuppliedEnt",
"GlIntUpdated" = s."GlIntUpdated",
"GlIntPrinted" = s."GlIntPrinted",
"GlIntYear" = s."GlIntYear",
"GlIntPeriod" = s."GlIntPeriod",
"GlJournal" = s."GlJournal",
"TimeStamp" = s."TimeStamp"
FROM sysprocompanyb.wippartbookmain_stg0 s
WHERE
(s."Line" = d."Line" AND
s."Job" = d."Job")
AND
(
((s."QtySupplied" != d."QtySupplied")  OR (s."QtySupplied"  is not NULL and d."QtySupplied"  is NULL) OR (d."QtySupplied"  is not NULL and s."QtySupplied"  is NULL)) OR
((s."TrnDate" != d."TrnDate")  OR (s."TrnDate"  is not NULL and d."TrnDate"  is NULL) OR (d."TrnDate"  is not NULL and s."TrnDate"  is NULL)) OR
((s."Journal" != d."Journal")  OR (s."Journal"  is not NULL and d."Journal"  is NULL) OR (d."Journal"  is not NULL and s."Journal"  is NULL)) OR
((s."LabourValue" != d."LabourValue")  OR (s."LabourValue"  is not NULL and d."LabourValue"  is NULL) OR (d."LabourValue"  is not NULL and s."LabourValue"  is NULL)) OR
((s."MaterialValue" != d."MaterialValue")  OR (s."MaterialValue"  is not NULL and d."MaterialValue"  is NULL) OR (d."MaterialValue"  is not NULL and s."MaterialValue"  is NULL)) OR
((s."Reference" != d."Reference")  OR (s."Reference"  is not NULL and d."Reference"  is NULL) OR (d."Reference"  is not NULL and s."Reference"  is NULL)) OR
((s."AddReference" != d."AddReference")  OR (s."AddReference"  is not NULL and d."AddReference"  is NULL) OR (d."AddReference"  is not NULL and s."AddReference"  is NULL)) OR
((s."SalesOrder" != d."SalesOrder")  OR (s."SalesOrder"  is not NULL and d."SalesOrder"  is NULL) OR (d."SalesOrder"  is not NULL and s."SalesOrder"  is NULL)) OR
((s."MasterJob" != d."MasterJob")  OR (s."MasterJob"  is not NULL and d."MasterJob"  is NULL) OR (d."MasterJob"  is not NULL and s."MasterJob"  is NULL)) OR
((s."CoProductLine" != d."CoProductLine")  OR (s."CoProductLine"  is not NULL and d."CoProductLine"  is NULL) OR (d."CoProductLine"  is not NULL and s."CoProductLine"  is NULL)) OR
((s."CoProduct" != d."CoProduct")  OR (s."CoProduct"  is not NULL and d."CoProduct"  is NULL) OR (d."CoProduct"  is not NULL and s."CoProduct"  is NULL)) OR
((s."QtySuppliedEnt" != d."QtySuppliedEnt")  OR (s."QtySuppliedEnt"  is not NULL and d."QtySuppliedEnt"  is NULL) OR (d."QtySuppliedEnt"  is not NULL and s."QtySuppliedEnt"  is NULL)) OR
((s."GlIntUpdated" != d."GlIntUpdated")  OR (s."GlIntUpdated"  is not NULL and d."GlIntUpdated"  is NULL) OR (d."GlIntUpdated"  is not NULL and s."GlIntUpdated"  is NULL)) OR
((s."GlIntPrinted" != d."GlIntPrinted")  OR (s."GlIntPrinted"  is not NULL and d."GlIntPrinted"  is NULL) OR (d."GlIntPrinted"  is not NULL and s."GlIntPrinted"  is NULL)) OR
((s."GlIntYear" != d."GlIntYear")  OR (s."GlIntYear"  is not NULL and d."GlIntYear"  is NULL) OR (d."GlIntYear"  is not NULL and s."GlIntYear"  is NULL)) OR
((s."GlIntPeriod" != d."GlIntPeriod")  OR (s."GlIntPeriod"  is not NULL and d."GlIntPeriod"  is NULL) OR (d."GlIntPeriod"  is not NULL and s."GlIntPeriod"  is NULL)) OR
((s."GlJournal" != d."GlJournal") OR (s."GlJournal"  is not NULL and d."GlJournal"  is NULL) OR (d."GlJournal"  is not NULL and s."GlJournal"  is NULL))
);

END;
