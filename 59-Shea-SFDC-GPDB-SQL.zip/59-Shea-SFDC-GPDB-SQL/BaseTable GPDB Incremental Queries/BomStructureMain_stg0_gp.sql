--BomStructure_stg0_gp



BEGIN;

--insert Query
insert into sysprocompanyb.bomstructuremain_stg0_gp select s.* from sysprocompanyb.bomstructuremain_stg0 s 
LEFT JOIN sysprocompanyb.bomstructuremain_stg0_gp d ON s."ParentPart"=d."ParentPart" 
and s."Version"=d."Version" 
and s."Release"=d."Release" 
and s."Route"=d."Route" 
and s."SequenceNum"=d."SequenceNum" 
and s."Component"=d."Component"
where d."ParentPart" is null 
and d."Version" is null
and d."Release" is null
and d."Route" is null
and d."SequenceNum" is null
and d."Component" is null
;

--update Query
UPDATE sysprocompanyb.bomstructuremain_stg0_gp d
SET

"time" = s."time",
"ComVersion" = s."ComVersion",
"ComRelease" = s."ComRelease",
"EccConsumption" = s."EccConsumption",
"StructureOnDate" = s."StructureOnDate",
"StructureOffDate" = s."StructureOffDate",
"OpOffsetFlag" = s."OpOffsetFlag",
"OperationOffset" = s."OperationOffset",
"QtyPer" = s."QtyPer",
"ScrapPercentage" = s."ScrapPercentage",
"ScrapQuantity" = s."ScrapQuantity",
"SoOptionFlag" = s."SoOptionFlag",
"SoPrintFlag" = s."SoPrintFlag",
"InclScrapFlag" = s."InclScrapFlag",
"ReasonForChange" = s."ReasonForChange",
"RefDesignator" = s."RefDesignator",
"AssemblyPlace" = s."AssemblyPlace",
"ItemNumber" = s."ItemNumber",
"AutoNarrCode" = s."AutoNarrCode",
"ComponentType" = s."ComponentType",
"InclKitIssues" = s."InclKitIssues",
"CreateSubJob" = s."CreateSubJob",
"WetWeightPercent" = s."WetWeightPercent",
"IncludeBatch" = s."IncludeBatch",
"IncludeFromJob" = s."IncludeFromJob",
"IncludeToJob" = s."IncludeToJob",
"FixedQtyPerFlag" = s."FixedQtyPerFlag",
"FixedQtyPer" = s."FixedQtyPer",
"RollUpCost" = s."RollUpCost",
"Warehouse" = s."Warehouse",
"IgnoreFloorFlag" = s."IgnoreFloorFlag",
"CoProductCostVal" = s."CoProductCostVal",
"UomFlag" = s."UomFlag",
"QtyPerEnt" = s."QtyPerEnt",
"ScrapQuantityEnt" = s."ScrapQuantityEnt",
"FixedQtyPerEnt" = s."FixedQtyPerEnt",
"ProductCode" = s."ProductCode",
"LibraryCode" = s."LibraryCode",
"FirstSeq" = s."FirstSeq",
"SecondSeq" = s."SecondSeq",
"OvrEccSpecIss" = s."OvrEccSpecIss"

FROM sysprocompanyb.bomstructuremain_stg0 s
WHERE( s."ParentPart"=d."ParentPart" 
and s."Version"=d."Version" 
and  s."Release"=d."Release" 
and s."Route"=d."Route" 
and s."SequenceNum"=d."SequenceNum" 
and s."Component"=d."Component" )
and(
((s."time" != d."time")  OR (s."time"  is not NULL and d."time"  is NULL) OR (d."time"  is not NULL and s."time"  is NULL)) OR
((s."ComVersion" != d."ComVersion")  OR (s."ComVersion"  is not NULL and d."ComVersion"  is NULL) OR (d."ComVersion"  is not NULL and s."ComVersion"  is NULL)) OR
((s."ComRelease" != d."ComRelease")  OR (s."ComRelease"  is not NULL and d."ComRelease"  is NULL) OR (d."ComRelease"  is not NULL and s."ComRelease"  is NULL)) OR
((s."EccConsumption" != d."EccConsumption")  OR (s."EccConsumption"  is not NULL and d."EccConsumption"  is NULL) OR (d."EccConsumption"  is not NULL and s."EccConsumption"  is NULL)) OR
((s."StructureOnDate" != d."StructureOnDate")  OR (s."StructureOnDate"  is not NULL and d."StructureOnDate"  is NULL) OR (d."StructureOnDate"  is not NULL and s."StructureOnDate"  is NULL)) OR
((s."StructureOffDate" != d."StructureOffDate")  OR (s."StructureOffDate"  is not NULL and d."StructureOffDate"  is NULL) OR (d."StructureOffDate"  is not NULL and s."StructureOffDate"  is NULL)) OR
((s."OpOffsetFlag" != d."OpOffsetFlag")  OR (s."OpOffsetFlag"  is not NULL and d."OpOffsetFlag"  is NULL) OR (d."OpOffsetFlag"  is not NULL and s."OpOffsetFlag"  is NULL)) OR
((s."OperationOffset" != d."OperationOffset")  OR (s."OperationOffset"  is not NULL and d."OperationOffset"  is NULL) OR (d."OperationOffset"  is not NULL and s."OperationOffset"  is NULL)) OR
((s."QtyPer" != d."QtyPer")  OR (s."QtyPer"  is not NULL and d."QtyPer"  is NULL) OR (d."QtyPer"  is not NULL and s."QtyPer"  is NULL)) OR
((s."ScrapPercentage" != d."ScrapPercentage")  OR (s."ScrapPercentage"  is not NULL and d."ScrapPercentage"  is NULL) OR (d."ScrapPercentage"  is not NULL and s."ScrapPercentage"  is NULL)) OR
((s."ScrapQuantity" != d."ScrapQuantity")  OR (s."ScrapQuantity"  is not NULL and d."ScrapQuantity"  is NULL) OR (d."ScrapQuantity"  is not NULL and s."ScrapQuantity"  is NULL)) OR
((s."SoOptionFlag" != d."SoOptionFlag")  OR (s."SoOptionFlag"  is not NULL and d."SoOptionFlag"  is NULL) OR (d."SoOptionFlag"  is not NULL and s."SoOptionFlag"  is NULL)) OR
((s."SoPrintFlag" != d."SoPrintFlag")  OR (s."SoPrintFlag"  is not NULL and d."SoPrintFlag"  is NULL) OR (d."SoPrintFlag"  is not NULL and s."SoPrintFlag"  is NULL)) OR
((s."InclScrapFlag" != d."InclScrapFlag")  OR (s."InclScrapFlag"  is not NULL and d."InclScrapFlag"  is NULL) OR (d."InclScrapFlag"  is not NULL and s."InclScrapFlag"  is NULL)) OR
((s."ReasonForChange" != d."ReasonForChange")  OR (s."ReasonForChange"  is not NULL and d."ReasonForChange"  is NULL) OR (d."ReasonForChange"  is not NULL and s."ReasonForChange"  is NULL)) OR
((s."RefDesignator" != d."RefDesignator")  OR (s."RefDesignator"  is not NULL and d."RefDesignator"  is NULL) OR (d."RefDesignator"  is not NULL and s."RefDesignator"  is NULL)) OR
((s."AssemblyPlace" != d."AssemblyPlace")  OR (s."AssemblyPlace"  is not NULL and d."AssemblyPlace"  is NULL) OR (d."AssemblyPlace"  is not NULL and s."AssemblyPlace"  is NULL)) OR
((s."ItemNumber" != d."ItemNumber")  OR (s."ItemNumber"  is not NULL and d."ItemNumber"  is NULL) OR (d."ItemNumber"  is not NULL and s."ItemNumber"  is NULL)) OR
((s."AutoNarrCode" != d."AutoNarrCode")  OR (s."AutoNarrCode"  is not NULL and d."AutoNarrCode"  is NULL) OR (d."AutoNarrCode"  is not NULL and s."AutoNarrCode"  is NULL)) OR
((s."ComponentType" != d."ComponentType")  OR (s."ComponentType"  is not NULL and d."ComponentType"  is NULL) OR (d."ComponentType"  is not NULL and s."ComponentType"  is NULL)) OR
((s."InclKitIssues" != d."InclKitIssues")  OR (s."InclKitIssues"  is not NULL and d."InclKitIssues"  is NULL) OR (d."InclKitIssues"  is not NULL and s."InclKitIssues"  is NULL)) OR
((s."CreateSubJob" != d."CreateSubJob")  OR (s."CreateSubJob"  is not NULL and d."CreateSubJob"  is NULL) OR (d."CreateSubJob"  is not NULL and s."CreateSubJob"  is NULL)) OR
((s."WetWeightPercent" != d."WetWeightPercent")  OR (s."WetWeightPercent"  is not NULL and d."WetWeightPercent"  is NULL) OR (d."WetWeightPercent"  is not NULL and s."WetWeightPercent"  is NULL)) OR
((s."IncludeBatch" != d."IncludeBatch")  OR (s."IncludeBatch"  is not NULL and d."IncludeBatch"  is NULL) OR (d."IncludeBatch"  is not NULL and s."IncludeBatch"  is NULL)) OR
((s."IncludeFromJob" != d."IncludeFromJob")  OR (s."IncludeFromJob"  is not NULL and d."IncludeFromJob"  is NULL) OR (d."IncludeFromJob"  is not NULL and s."IncludeFromJob"  is NULL)) OR
((s."IncludeToJob" != d."IncludeToJob")  OR (s."IncludeToJob"  is not NULL and d."IncludeToJob"  is NULL) OR (d."IncludeToJob"  is not NULL and s."IncludeToJob"  is NULL)) OR
((s."FixedQtyPerFlag" != d."FixedQtyPerFlag")  OR (s."FixedQtyPerFlag"  is not NULL and d."FixedQtyPerFlag"  is NULL) OR (d."FixedQtyPerFlag"  is not NULL and s."FixedQtyPerFlag"  is NULL)) OR
((s."FixedQtyPer" != d."FixedQtyPer")  OR (s."FixedQtyPer"  is not NULL and d."FixedQtyPer"  is NULL) OR (d."FixedQtyPer"  is not NULL and s."FixedQtyPer"  is NULL)) OR
((s."RollUpCost" != d."RollUpCost")  OR (s."RollUpCost"  is not NULL and d."RollUpCost"  is NULL) OR (d."RollUpCost"  is not NULL and s."RollUpCost"  is NULL)) OR
((s."Warehouse" != d."Warehouse")  OR (s."Warehouse"  is not NULL and d."Warehouse"  is NULL) OR (d."Warehouse"  is not NULL and s."Warehouse"  is NULL)) OR
((s."IgnoreFloorFlag" != d."IgnoreFloorFlag")  OR (s."IgnoreFloorFlag"  is not NULL and d."IgnoreFloorFlag"  is NULL) OR (d."IgnoreFloorFlag"  is not NULL and s."IgnoreFloorFlag"  is NULL)) OR
((s."CoProductCostVal" != d."CoProductCostVal")  OR (s."CoProductCostVal"  is not NULL and d."CoProductCostVal"  is NULL) OR (d."CoProductCostVal"  is not NULL and s."CoProductCostVal"  is NULL)) OR
((s."UomFlag" != d."UomFlag")  OR (s."UomFlag"  is not NULL and d."UomFlag"  is NULL) OR (d."UomFlag"  is not NULL and s."UomFlag"  is NULL)) OR
((s."QtyPerEnt" != d."QtyPerEnt")  OR (s."QtyPerEnt"  is not NULL and d."QtyPerEnt"  is NULL) OR (d."QtyPerEnt"  is not NULL and s."QtyPerEnt"  is NULL)) OR
((s."ScrapQuantityEnt" != d."ScrapQuantityEnt")  OR (s."ScrapQuantityEnt"  is not NULL and d."ScrapQuantityEnt"  is NULL) OR (d."ScrapQuantityEnt"  is not NULL and s."ScrapQuantityEnt"  is NULL)) OR
((s."FixedQtyPerEnt" != d."FixedQtyPerEnt")  OR (s."FixedQtyPerEnt"  is not NULL and d."FixedQtyPerEnt"  is NULL) OR (d."FixedQtyPerEnt"  is not NULL and s."FixedQtyPerEnt"  is NULL)) OR
((s."ProductCode" != d."ProductCode")  OR (s."ProductCode"  is not NULL and d."ProductCode"  is NULL) OR (d."ProductCode"  is not NULL and s."ProductCode"  is NULL)) OR
((s."LibraryCode" != d."LibraryCode")  OR (s."LibraryCode"  is not NULL and d."LibraryCode"  is NULL) OR (d."LibraryCode"  is not NULL and s."LibraryCode"  is NULL)) OR
((s."FirstSeq" != d."FirstSeq")  OR (s."FirstSeq"  is not NULL and d."FirstSeq"  is NULL) OR (d."FirstSeq"  is not NULL and s."FirstSeq"  is NULL)) OR
((s."SecondSeq" != d."SecondSeq")  OR (s."SecondSeq"  is not NULL and d."SecondSeq"  is NULL) OR (d."SecondSeq"  is not NULL and s."SecondSeq"  is NULL)) OR
((s."OvrEccSpecIss" != d."OvrEccSpecIss") OR (s."OvrEccSpecIss"  is not NULL and d."OvrEccSpecIss"  is NULL) OR (d."OvrEccSpecIss"  is not NULL and s."OvrEccSpecIss"  is NULL))

);

--Delete Query

delete from sysprocompanyb.bomstructuremain_stg0_gp where
(sysprocompanyb.bomstructuremain_stg0_gp."ParentPart",
sysprocompanyb.bomstructuremain_stg0_gp."Version",
sysprocompanyb.bomstructuremain_stg0_gp."Release",
sysprocompanyb.bomstructuremain_stg0_gp."Route",
sysprocompanyb.bomstructuremain_stg0_gp."SequenceNum",
sysprocompanyb.bomstructuremain_stg0_gp."Component")
in
(
  select d."ParentPart",d."Version", d."Release",d."Route",
  d."SequenceNum",d."Component"
  from   sysprocompanyb.bomstructuremain_stg0_gp d 
  left join   sysprocompanyb.bomstructuremain_stg0 s
  on   s."ParentPart"=d."ParentPart" 
  and   s."Version"=d."Version" 
  and   s."Release"=d."Release" 
  and   s."Route"=d."Route" 
  and   s."SequenceNum"=d."SequenceNum"
  and   s."Component"=d."Component"   
  where   s."ParentPart" is null and s."Version" is null
and s."Release" is null and s."Route" is null
and s."SequenceNum" is null and s."Component" is null
);

END;
