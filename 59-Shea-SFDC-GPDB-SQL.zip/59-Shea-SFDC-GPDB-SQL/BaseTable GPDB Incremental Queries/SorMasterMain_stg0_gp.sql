--SorMasterMain_stg0_gp

BEGIN;
insert into sysprocompanyb.sormastermain_stg0_gp select s.* 
from sysprocompanyb.sormastermain_stg0 s LEFT JOIN sysprocompanyb.sormastermain_stg0_gp d 
ON s."SalesOrder"=d."SalesOrder"  where d."SalesOrder" is null ;
Savepoint sp2;

--Delete
delete from sysprocompanyb.sormastermain_stg0_gp
where sysprocompanyb.sormastermain_stg0_gp."SalesOrder"
in
(
select d."SalesOrder"
from
sysprocompanyb.sormastermain_stg0_gp d 
left join
sysprocompanyb.sormastermain_stg0 s
on
s."SalesOrder"=d."SalesOrder" 
where s."SalesOrder" is null
);


UPDATE sysprocompanyb.sormastermain_stg0_gp d
SET
"time"= s."time",
"NextDetailLine"= s."NextDetailLine",
"OrderStatus"= s."OrderStatus",
"ActiveFlag"= s."ActiveFlag",
"CancelledFlag"= s."CancelledFlag",
"DocumentType"= s."DocumentType",
"Customer"= s."Customer",
"Salesperson"= s."Salesperson",
"CustomerPoNumber"= s."CustomerPoNumber",
"OrderDate"= s."OrderDate",
"EntrySystemDate"= s."EntrySystemDate",
"ReqShipDate"= s."ReqShipDate",
"DateLastDocPrt"= s."DateLastDocPrt",
"ShippingInstrs"= s."ShippingInstrs",
"Branch"= s."Branch",
"SpecialInstrs"= s."SpecialInstrs",
"DiscPct1"= s."DiscPct1",
"DiscPct2"= s."DiscPct2",
"DiscPct3"= s."DiscPct3",
"OrderType"= s."OrderType",
"LastInvoice"= s."LastInvoice",
"InterWhSale"= s."InterWhSale",
"SourceWarehouse"= s."SourceWarehouse",
"CustomerName"= s."CustomerName",
"ShipAddress1"= s."ShipAddress1",
"ShipAddress2"= s."ShipAddress2",
"ShipAddress3"= s."ShipAddress3",
"ShipAddress4"= s."ShipAddress4",
"ShipAddress5"= s."ShipAddress5",
"ShipPostalCode"= s."ShipPostalCode",
"Email"= s."Email"
FROM sysprocompanyb.sormastermain_stg0 s
Where (s."SalesOrder"=d."SalesOrder") and 
(
((s."NextDetailLine"!=d."NextDetailLine")  OR (s."NextDetailLine" is not NULL and d."NextDetailLine" is NULL) OR (d."NextDetailLine" is not NULL and s."NextDetailLine" is NULL)) OR
((s."OrderStatus"!=d."OrderStatus")  OR (s."OrderStatus" is not NULL and d."OrderStatus" is NULL) OR (d."OrderStatus" is not NULL and s."OrderStatus" is NULL)) OR
((s."ActiveFlag"!=d."ActiveFlag")  OR (s."ActiveFlag" is not NULL and d."ActiveFlag" is NULL) OR (d."ActiveFlag" is not NULL and s."ActiveFlag" is NULL)) OR
((s."CancelledFlag"!=d."CancelledFlag")  OR (s."CancelledFlag" is not NULL and d."CancelledFlag" is NULL) OR (d."CancelledFlag" is not NULL and s."CancelledFlag" is NULL)) OR
((s."DocumentType"!=d."DocumentType")  OR (s."DocumentType" is not NULL and d."DocumentType" is NULL) OR (d."DocumentType" is not NULL and s."DocumentType" is NULL)) OR
((s."Customer"!=d."Customer")  OR (s."Customer" is not NULL and d."Customer" is NULL) OR (d."Customer" is not NULL and s."Customer" is NULL)) OR
((s."Salesperson"!=d."Salesperson")  OR (s."Salesperson" is not NULL and d."Salesperson" is NULL) OR (d."Salesperson" is not NULL and s."Salesperson" is NULL)) OR
((s."CustomerPoNumber"!=d."CustomerPoNumber")  OR (s."CustomerPoNumber" is not NULL and d."CustomerPoNumber" is NULL) OR (d."CustomerPoNumber" is not NULL and s."CustomerPoNumber" is NULL)) OR
((s."OrderDate"!=d."OrderDate")  OR (s."OrderDate" is not NULL and d."OrderDate" is NULL) OR (d."OrderDate" is not NULL and s."OrderDate" is NULL)) OR
((s."EntrySystemDate"!=d."EntrySystemDate")  OR (s."EntrySystemDate" is not NULL and d."EntrySystemDate" is NULL) OR (d."EntrySystemDate" is not NULL and s."EntrySystemDate" is NULL)) OR
((s."ReqShipDate"!=d."ReqShipDate")  OR (s."ReqShipDate" is not NULL and d."ReqShipDate" is NULL) OR (d."ReqShipDate" is not NULL and s."ReqShipDate" is NULL)) OR
((s."DateLastDocPrt"!=d."DateLastDocPrt")  OR (s."DateLastDocPrt" is not NULL and d."DateLastDocPrt" is NULL) OR (d."DateLastDocPrt" is not NULL and s."DateLastDocPrt" is NULL)) OR
((s."ShippingInstrs"!=d."ShippingInstrs") OR (s."ShippingInstrs" is not NULL and d."ShippingInstrs" is NULL) OR (d."ShippingInstrs" is not NULL and s."ShippingInstrs" is NULL)) OR
((s."Branch"!=d."Branch")  OR (s."Branch" is not NULL and d."Branch" is NULL) OR (d."Branch" is not NULL and s."Branch" is NULL)) OR
((s."SpecialInstrs"!=d."SpecialInstrs")  OR (s."SpecialInstrs" is not NULL and d."SpecialInstrs" is NULL) OR (d."SpecialInstrs" is not NULL and s."SpecialInstrs" is NULL)) OR
((s."DiscPct1"!=d."DiscPct1")  OR (s."DiscPct1" is not NULL and d."DiscPct1" is NULL) OR (d."DiscPct1" is not NULL and s."DiscPct1" is NULL)) OR
((s."DiscPct2"!=d."DiscPct2") OR (s."DiscPct2" is not NULL and d."DiscPct2" is NULL) OR (d."DiscPct2" is not NULL and s."DiscPct2" is NULL)) OR
((s."DiscPct3"!=d."DiscPct3")  OR (s."DiscPct3" is not NULL and d."DiscPct3" is NULL) OR (d."DiscPct3" is not NULL and s."DiscPct3" is NULL)) OR
((s."OrderType"!=d."OrderType")  OR (s."OrderType" is not NULL and d."OrderType" is NULL) OR (d."OrderType" is not NULL and s."OrderType" is NULL)) OR
((s."LastInvoice"!=d."LastInvoice")  OR (s."LastInvoice" is not NULL and d."LastInvoice" is NULL) OR (d."LastInvoice" is not NULL and s."LastInvoice" is NULL)) OR
((s."InterWhSale"!=d."InterWhSale") OR (s."InterWhSale" is not NULL and d."InterWhSale" is NULL) OR (d."InterWhSale" is not NULL and s."InterWhSale" is NULL)) OR
((s."SourceWarehouse"!=d."SourceWarehouse")  OR (s."SourceWarehouse" is not NULL and d."SourceWarehouse" is NULL) OR (d."SourceWarehouse" is not NULL and s."SourceWarehouse" is NULL)) OR
((s."CustomerName"!=d."CustomerName")  OR (s."CustomerName" is not NULL and d."CustomerName" is NULL) OR (d."CustomerName" is not NULL and s."CustomerName" is NULL)) OR
((s."ShipAddress1"!=d."ShipAddress1")  OR (s."ShipAddress1" is not NULL and d."ShipAddress1" is NULL) OR (d."ShipAddress1" is not NULL and s."ShipAddress1" is NULL)) OR
((s."ShipAddress2"!=d."ShipAddress2")  OR (s."ShipAddress2" is not NULL and d."ShipAddress2" is NULL) OR (d."ShipAddress2" is not NULL and s."ShipAddress2" is NULL)) OR
((s."ShipAddress3"!=d."ShipAddress3")  OR (s."ShipAddress3" is not NULL and d."ShipAddress3" is NULL) OR (d."ShipAddress3" is not NULL and s."ShipAddress3" is NULL)) OR
((s."ShipAddress4"!=d."ShipAddress4") OR (s."ShipAddress4" is not NULL and d."ShipAddress4" is NULL) OR (d."ShipAddress4" is not NULL and s."ShipAddress4" is NULL)) OR
((s."ShipAddress5"!=d."ShipAddress5")  OR (s."ShipAddress5" is not NULL and d."ShipAddress5" is NULL) OR (d."ShipAddress5" is not NULL and s."ShipAddress5" is NULL)) OR
((s."ShipPostalCode"!=d."ShipPostalCode")  OR (s."ShipPostalCode" is not NULL and d."ShipPostalCode" is NULL) OR (d."ShipPostalCode" is not NULL and s."ShipPostalCode" is NULL)) OR
((s."Email"!=d."Email") OR (s."Email" is not NULL and d."Email" is NULL) OR (d."Email" is not NULL and s."Email" is NULL))
);
END;
