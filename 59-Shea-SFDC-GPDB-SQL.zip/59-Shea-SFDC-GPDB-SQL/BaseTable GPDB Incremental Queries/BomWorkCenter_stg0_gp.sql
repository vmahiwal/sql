--BomWorkCenter_stg0_gp



Begin;

INSERT INTO sysprocompanyb.bomworkcentermain_stg0_gp SELECT s.* 
FROM sysprocompanyb.bomworkcentermain_stg0 s 
LEFT JOIN sysprocompanyb.bomworkcentermain_stg0_gp d
ON (s."WorkCentre"=d."WorkCentre" )
WHERE (d."WorkCentre" is NULL); 


delete from sysprocompanyb.bomworkcentermain_stg0_gp
where sysprocompanyb.bomworkcentermain_stg0_gp."WorkCentre"
in
(
select d."WorkCentre"
from sysprocompanyb.bomworkcentermain_stg0_gp d 
left join sysprocompanyb.bomworkcentermain_stg0 s
on s."WorkCentre" = d."WorkCentre" where s."WorkCentre" is NULL 
);

UPDATE sysprocompanyb.bomworkcentermain_stg0_gp d
SET
"time" = s."time",
"Description" = s."Description",
"CostCentre" = s."CostCentre",
"SetUpRate1" = s."SetUpRate1",
"SetUpRate2" = s."SetUpRate2",
"SetUpRate3" = s."SetUpRate3",
"SetUpRate4" = s."SetUpRate4",
"SetUpRate5" = s."SetUpRate5",
"SetUpRate6" = s."SetUpRate6",
"SetUpRate7" = s."SetUpRate7",
"SetUpRate8" = s."SetUpRate8",
"SetUpRate9" = s."SetUpRate9",
"RunTimeRate1" = s."RunTimeRate1",
"RunTimeRate2" = s."RunTimeRate2",
"RunTimeRate3" = s."RunTimeRate3",
"RunTimeRate4" = s."RunTimeRate4",
"RunTimeRate5" = s."RunTimeRate5",
"RunTimeRate6" = s."RunTimeRate6",
"RunTimeRate7" = s."RunTimeRate7",
"RunTimeRate8" = s."RunTimeRate8",
"RunTimeRate9" = s."RunTimeRate9",
"FixOverRate1" = s."FixOverRate1",
"FixOverRate2" = s."FixOverRate2",
"FixOverRate3" = s."FixOverRate3",
"FixOverRate4" = s."FixOverRate4",
"FixOverRate5" = s."FixOverRate5",
"FixOverRate6" = s."FixOverRate6",
"FixOverRate7" = s."FixOverRate7",
"FixOverRate8" = s."FixOverRate8",
"FixOverRate9" = s."FixOverRate9",
"VarOverRate1" = s."VarOverRate1",
"VarOverRate2" = s."VarOverRate2",
"VarOverRate3" = s."VarOverRate3",
"VarOverRate4" = s."VarOverRate4",
"VarOverRate5" = s."VarOverRate5",
"VarOverRate6" = s."VarOverRate6",
"VarOverRate7" = s."VarOverRate7",
"VarOverRate8" = s."VarOverRate8",
"VarOverRate9" = s."VarOverRate9",
"StartupRate1" = s."StartupRate1",
"StartupRate2" = s."StartupRate2",
"StartupRate3" = s."StartupRate3",
"StartupRate4" = s."StartupRate4",
"StartupRate5" = s."StartupRate5",
"StartupRate6" = s."StartupRate6",
"StartupRate7" = s."StartupRate7",
"StartupRate8" = s."StartupRate8",
"StartupRate9" = s."StartupRate9",
"TeardownRate1" = s."TeardownRate1",
"TeardownRate2" = s."TeardownRate2",
"TeardownRate3" = s."TeardownRate3",
"TeardownRate4" = s."TeardownRate4",
"TeardownRate5" = s."TeardownRate5",
"TeardownRate6" = s."TeardownRate6",
"TeardownRate7" = s."TeardownRate7",
"TeardownRate8" = s."TeardownRate8",
"TeardownRate9" = s."TeardownRate9",
"TimeUom" = s."TimeUom",
"EtCalcMeth" = s."EtCalcMeth",
"CapacityUom" = s."CapacityUom",
"CstToCapFact" = s."CstToCapFact",
"CstToCapMulDiv" = s."CstToCapMulDiv",
"ProdUnitDesc" = s."ProdUnitDesc",
"SubcontractFlag" = s."SubcontractFlag",
"UseEmployeeRate" = s."UseEmployeeRate",
"ProductClass" = s."ProductClass",
"RunTime" = s."RunTime",
"SetupTime" = s."SetupTime",
"FixTime" = s."FixTime",
"VarTime" = s."VarTime",
"StartTime" = s."StartTime",
"TeardownTime" = s."TeardownTime",
"NonRunTime" = s."NonRunTime",
"NonSetupTime" = s."NonSetupTime",
"NonFixTime" = s."NonFixTime",
"NonVarTime" = s."NonVarTime",
"NonStartTime" = s."NonStartTime",
"NonTearTime" = s."NonTearTime",
"PtdStdHours" = s."PtdStdHours",
"PtdNonHours" = s."PtdNonHours",
"PtdActHours" = s."PtdActHours",
"MtdStdHours" = s."MtdStdHours",
"MtdNonHours" = s."MtdNonHours",
"MtdActHours" = s."MtdActHours",
"YtdStdHours" = s."YtdStdHours",
"YtdNonHours" = s."YtdNonHours",
"YtdActHours" = s."YtdActHours",
"UtilisePct" = s."UtilisePct",
"OvertimeCapPct" = s."OvertimeCapPct",
"UseOvertimeCap" = s."UseOvertimeCap",
"NormalCapacity" = s."NormalCapacity",
"QueueTime" = s."QueueTime",
"DefSubSupplier" = s."DefSubSupplier",
"DefSubPlanner" = s."DefSubPlanner",
"DefSubBuyer" = s."DefSubBuyer",
"WorkOperators" = s."WorkOperators",
"ProdUnits" = s."ProdUnits",
"TimePerUnit" = s."TimePerUnit",
"CalcCapConvFact" = s."CalcCapConvFact",
"LoadLevelScale" = s."LoadLevelScale",
"LoadLevelSclFlg" = s."LoadLevelSclFlg",
"CellId" = s."CellId",
"ChargeCode" = s."ChargeCode",
"OpSplitFlag" = s."OpSplitFlag",
"TimeStamp" = s."TimeStamp"

FROM sysprocompanyb.bomworkcentermain_stg0 s 
WHERE s."WorkCentre"=d."WorkCentre" and 
(
((s."Description" != d."Description")  OR (s."Description"  is not NULL and d."Description"  is NULL) OR (d."Description"  is not NULL and s."Description"  is NULL)) OR
((s."CostCentre" != d."CostCentre")  OR (s."CostCentre"  is not NULL and d."CostCentre"  is NULL) OR (d."CostCentre"  is not NULL and s."CostCentre"  is NULL)) OR
((s."SetUpRate1" != d."SetUpRate1")  OR (s."SetUpRate1"  is not NULL and d."SetUpRate1"  is NULL) OR (d."SetUpRate1"  is not NULL and s."SetUpRate1"  is NULL)) OR
((s."SetUpRate2" != d."SetUpRate2")  OR (s."SetUpRate2"  is not NULL and d."SetUpRate2"  is NULL) OR (d."SetUpRate2"  is not NULL and s."SetUpRate2"  is NULL)) OR
((s."SetUpRate3" != d."SetUpRate3")  OR (s."SetUpRate3"  is not NULL and d."SetUpRate3"  is NULL) OR (d."SetUpRate3"  is not NULL and s."SetUpRate3"  is NULL)) OR
((s."SetUpRate4" != d."SetUpRate4")  OR (s."SetUpRate4"  is not NULL and d."SetUpRate4"  is NULL) OR (d."SetUpRate4"  is not NULL and s."SetUpRate4"  is NULL)) OR
((s."SetUpRate5" != d."SetUpRate5")  OR (s."SetUpRate5"  is not NULL and d."SetUpRate5"  is NULL) OR (d."SetUpRate5"  is not NULL and s."SetUpRate5"  is NULL)) OR
((s."SetUpRate6" != d."SetUpRate6")  OR (s."SetUpRate6"  is not NULL and d."SetUpRate6"  is NULL) OR (d."SetUpRate6"  is not NULL and s."SetUpRate6"  is NULL)) OR
((s."SetUpRate7" != d."SetUpRate7")  OR (s."SetUpRate7"  is not NULL and d."SetUpRate7"  is NULL) OR (d."SetUpRate7"  is not NULL and s."SetUpRate7"  is NULL)) OR
((s."SetUpRate8" != d."SetUpRate8")  OR (s."SetUpRate8"  is not NULL and d."SetUpRate8"  is NULL) OR (d."SetUpRate8"  is not NULL and s."SetUpRate8"  is NULL)) OR
((s."SetUpRate9" != d."SetUpRate9")  OR (s."SetUpRate9"  is not NULL and d."SetUpRate9"  is NULL) OR (d."SetUpRate9"  is not NULL and s."SetUpRate9"  is NULL)) OR
((s."RunTimeRate1" != d."RunTimeRate1")  OR (s."RunTimeRate1"  is not NULL and d."RunTimeRate1"  is NULL) OR (d."RunTimeRate1"  is not NULL and s."RunTimeRate1"  is NULL)) OR
((s."RunTimeRate2" != d."RunTimeRate2")  OR (s."RunTimeRate2"  is not NULL and d."RunTimeRate2"  is NULL) OR (d."RunTimeRate2"  is not NULL and s."RunTimeRate2"  is NULL)) OR
((s."RunTimeRate3" != d."RunTimeRate3")  OR (s."RunTimeRate3"  is not NULL and d."RunTimeRate3"  is NULL) OR (d."RunTimeRate3"  is not NULL and s."RunTimeRate3"  is NULL)) OR
((s."RunTimeRate4" != d."RunTimeRate4")  OR (s."RunTimeRate4"  is not NULL and d."RunTimeRate4"  is NULL) OR (d."RunTimeRate4"  is not NULL and s."RunTimeRate4"  is NULL)) OR
((s."RunTimeRate5" != d."RunTimeRate5")  OR (s."RunTimeRate5"  is not NULL and d."RunTimeRate5"  is NULL) OR (d."RunTimeRate5"  is not NULL and s."RunTimeRate5"  is NULL)) OR
((s."RunTimeRate6" != d."RunTimeRate6")  OR (s."RunTimeRate6"  is not NULL and d."RunTimeRate6"  is NULL) OR (d."RunTimeRate6"  is not NULL and s."RunTimeRate6"  is NULL)) OR
((s."RunTimeRate7" != d."RunTimeRate7")  OR (s."RunTimeRate7"  is not NULL and d."RunTimeRate7"  is NULL) OR (d."RunTimeRate7"  is not NULL and s."RunTimeRate7"  is NULL)) OR
((s."RunTimeRate8" != d."RunTimeRate8")  OR (s."RunTimeRate8"  is not NULL and d."RunTimeRate8"  is NULL) OR (d."RunTimeRate8"  is not NULL and s."RunTimeRate8"  is NULL)) OR
((s."RunTimeRate9" != d."RunTimeRate9")  OR (s."RunTimeRate9"  is not NULL and d."RunTimeRate9"  is NULL) OR (d."RunTimeRate9"  is not NULL and s."RunTimeRate9"  is NULL)) OR
((s."FixOverRate1" != d."FixOverRate1")  OR (s."FixOverRate1"  is not NULL and d."FixOverRate1"  is NULL) OR (d."FixOverRate1"  is not NULL and s."FixOverRate1"  is NULL)) OR
((s."FixOverRate2" != d."FixOverRate2")  OR (s."FixOverRate2"  is not NULL and d."FixOverRate2"  is NULL) OR (d."FixOverRate2"  is not NULL and s."FixOverRate2"  is NULL)) OR
((s."FixOverRate3" != d."FixOverRate3")  OR (s."FixOverRate3"  is not NULL and d."FixOverRate3"  is NULL) OR (d."FixOverRate3"  is not NULL and s."FixOverRate3"  is NULL)) OR
((s."FixOverRate4" != d."FixOverRate4")  OR (s."FixOverRate4"  is not NULL and d."FixOverRate4"  is NULL) OR (d."FixOverRate4"  is not NULL and s."FixOverRate4"  is NULL)) OR
((s."FixOverRate5" != d."FixOverRate5")  OR (s."FixOverRate5"  is not NULL and d."FixOverRate5"  is NULL) OR (d."FixOverRate5"  is not NULL and s."FixOverRate5"  is NULL)) OR
((s."FixOverRate6" != d."FixOverRate6")  OR (s."FixOverRate6"  is not NULL and d."FixOverRate6"  is NULL) OR (d."FixOverRate6"  is not NULL and s."FixOverRate6"  is NULL)) OR
((s."FixOverRate7" != d."FixOverRate7")  OR (s."FixOverRate7"  is not NULL and d."FixOverRate7"  is NULL) OR (d."FixOverRate7"  is not NULL and s."FixOverRate7"  is NULL)) OR
((s."FixOverRate8" != d."FixOverRate8")  OR (s."FixOverRate8"  is not NULL and d."FixOverRate8"  is NULL) OR (d."FixOverRate8"  is not NULL and s."FixOverRate8"  is NULL)) OR
((s."FixOverRate9" != d."FixOverRate9")  OR (s."FixOverRate9"  is not NULL and d."FixOverRate9"  is NULL) OR (d."FixOverRate9"  is not NULL and s."FixOverRate9"  is NULL)) OR
((s."VarOverRate1" != d."VarOverRate1")  OR (s."VarOverRate1"  is not NULL and d."VarOverRate1"  is NULL) OR (d."VarOverRate1"  is not NULL and s."VarOverRate1"  is NULL)) OR
((s."VarOverRate2" != d."VarOverRate2")  OR (s."VarOverRate2"  is not NULL and d."VarOverRate2"  is NULL) OR (d."VarOverRate2"  is not NULL and s."VarOverRate2"  is NULL)) OR
((s."VarOverRate3" != d."VarOverRate3")  OR (s."VarOverRate3"  is not NULL and d."VarOverRate3"  is NULL) OR (d."VarOverRate3"  is not NULL and s."VarOverRate3"  is NULL)) OR
((s."VarOverRate4" != d."VarOverRate4")  OR (s."VarOverRate4"  is not NULL and d."VarOverRate4"  is NULL) OR (d."VarOverRate4"  is not NULL and s."VarOverRate4"  is NULL)) OR
((s."VarOverRate5" != d."VarOverRate5")  OR (s."VarOverRate5"  is not NULL and d."VarOverRate5"  is NULL) OR (d."VarOverRate5"  is not NULL and s."VarOverRate5"  is NULL)) OR
((s."VarOverRate6" != d."VarOverRate6")  OR (s."VarOverRate6"  is not NULL and d."VarOverRate6"  is NULL) OR (d."VarOverRate6"  is not NULL and s."VarOverRate6"  is NULL)) OR
((s."VarOverRate7" != d."VarOverRate7")  OR (s."VarOverRate7"  is not NULL and d."VarOverRate7"  is NULL) OR (d."VarOverRate7"  is not NULL and s."VarOverRate7"  is NULL)) OR
((s."VarOverRate8" != d."VarOverRate8")  OR (s."VarOverRate8"  is not NULL and d."VarOverRate8"  is NULL) OR (d."VarOverRate8"  is not NULL and s."VarOverRate8"  is NULL)) OR
((s."VarOverRate9" != d."VarOverRate9")  OR (s."VarOverRate9"  is not NULL and d."VarOverRate9"  is NULL) OR (d."VarOverRate9"  is not NULL and s."VarOverRate9"  is NULL)) OR
((s."StartupRate1" != d."StartupRate1")  OR (s."StartupRate1"  is not NULL and d."StartupRate1"  is NULL) OR (d."StartupRate1"  is not NULL and s."StartupRate1"  is NULL)) OR
((s."StartupRate2" != d."StartupRate2")  OR (s."StartupRate2"  is not NULL and d."StartupRate2"  is NULL) OR (d."StartupRate2"  is not NULL and s."StartupRate2"  is NULL)) OR
((s."StartupRate3" != d."StartupRate3")  OR (s."StartupRate3"  is not NULL and d."StartupRate3"  is NULL) OR (d."StartupRate3"  is not NULL and s."StartupRate3"  is NULL)) OR
((s."StartupRate4" != d."StartupRate4")  OR (s."StartupRate4"  is not NULL and d."StartupRate4"  is NULL) OR (d."StartupRate4"  is not NULL and s."StartupRate4"  is NULL)) OR
((s."StartupRate5" != d."StartupRate5")  OR (s."StartupRate5"  is not NULL and d."StartupRate5"  is NULL) OR (d."StartupRate5"  is not NULL and s."StartupRate5"  is NULL)) OR
((s."StartupRate6" != d."StartupRate6")  OR (s."StartupRate6"  is not NULL and d."StartupRate6"  is NULL) OR (d."StartupRate6"  is not NULL and s."StartupRate6"  is NULL)) OR
((s."StartupRate7" != d."StartupRate7")  OR (s."StartupRate7"  is not NULL and d."StartupRate7"  is NULL) OR (d."StartupRate7"  is not NULL and s."StartupRate7"  is NULL)) OR
((s."StartupRate8" != d."StartupRate8")  OR (s."StartupRate8"  is not NULL and d."StartupRate8"  is NULL) OR (d."StartupRate8"  is not NULL and s."StartupRate8"  is NULL)) OR
((s."StartupRate9" != d."StartupRate9")  OR (s."StartupRate9"  is not NULL and d."StartupRate9"  is NULL) OR (d."StartupRate9"  is not NULL and s."StartupRate9"  is NULL)) OR
((s."TeardownRate1" != d."TeardownRate1")  OR (s."TeardownRate1"  is not NULL and d."TeardownRate1"  is NULL) OR (d."TeardownRate1"  is not NULL and s."TeardownRate1"  is NULL)) OR
((s."TeardownRate2" != d."TeardownRate2")  OR (s."TeardownRate2"  is not NULL and d."TeardownRate2"  is NULL) OR (d."TeardownRate2"  is not NULL and s."TeardownRate2"  is NULL)) OR
((s."TeardownRate3" != d."TeardownRate3")  OR (s."TeardownRate3"  is not NULL and d."TeardownRate3"  is NULL) OR (d."TeardownRate3"  is not NULL and s."TeardownRate3"  is NULL)) OR
((s."TeardownRate4" != d."TeardownRate4")  OR (s."TeardownRate4"  is not NULL and d."TeardownRate4"  is NULL) OR (d."TeardownRate4"  is not NULL and s."TeardownRate4"  is NULL)) OR
((s."TeardownRate5" != d."TeardownRate5")  OR (s."TeardownRate5"  is not NULL and d."TeardownRate5"  is NULL) OR (d."TeardownRate5"  is not NULL and s."TeardownRate5"  is NULL)) OR
((s."TeardownRate6" != d."TeardownRate6")  OR (s."TeardownRate6"  is not NULL and d."TeardownRate6"  is NULL) OR (d."TeardownRate6"  is not NULL and s."TeardownRate6"  is NULL)) OR
((s."TeardownRate7" != d."TeardownRate7")  OR (s."TeardownRate7"  is not NULL and d."TeardownRate7"  is NULL) OR (d."TeardownRate7"  is not NULL and s."TeardownRate7"  is NULL)) OR
((s."TeardownRate8" != d."TeardownRate8")  OR (s."TeardownRate8"  is not NULL and d."TeardownRate8"  is NULL) OR (d."TeardownRate8"  is not NULL and s."TeardownRate8"  is NULL)) OR
((s."TeardownRate9" != d."TeardownRate9")  OR (s."TeardownRate9"  is not NULL and d."TeardownRate9"  is NULL) OR (d."TeardownRate9"  is not NULL and s."TeardownRate9"  is NULL)) OR
((s."TimeUom" != d."TimeUom")  OR (s."TimeUom"  is not NULL and d."TimeUom"  is NULL) OR (d."TimeUom"  is not NULL and s."TimeUom"  is NULL)) OR
((s."EtCalcMeth" != d."EtCalcMeth")  OR (s."EtCalcMeth"  is not NULL and d."EtCalcMeth"  is NULL) OR (d."EtCalcMeth"  is not NULL and s."EtCalcMeth"  is NULL)) OR
((s."CapacityUom" != d."CapacityUom")  OR (s."CapacityUom"  is not NULL and d."CapacityUom"  is NULL) OR (d."CapacityUom"  is not NULL and s."CapacityUom"  is NULL)) OR
((s."CstToCapFact" != d."CstToCapFact")  OR (s."CstToCapFact"  is not NULL and d."CstToCapFact"  is NULL) OR (d."CstToCapFact"  is not NULL and s."CstToCapFact"  is NULL)) OR
((s."CstToCapMulDiv" != d."CstToCapMulDiv")  OR (s."CstToCapMulDiv"  is not NULL and d."CstToCapMulDiv"  is NULL) OR (d."CstToCapMulDiv"  is not NULL and s."CstToCapMulDiv"  is NULL)) OR
((s."ProdUnitDesc" != d."ProdUnitDesc")  OR (s."ProdUnitDesc"  is not NULL and d."ProdUnitDesc"  is NULL) OR (d."ProdUnitDesc"  is not NULL and s."ProdUnitDesc"  is NULL)) OR
((s."SubcontractFlag" != d."SubcontractFlag")  OR (s."SubcontractFlag"  is not NULL and d."SubcontractFlag"  is NULL) OR (d."SubcontractFlag"  is not NULL and s."SubcontractFlag"  is NULL)) OR
((s."UseEmployeeRate" != d."UseEmployeeRate")  OR (s."UseEmployeeRate"  is not NULL and d."UseEmployeeRate"  is NULL) OR (d."UseEmployeeRate"  is not NULL and s."UseEmployeeRate"  is NULL)) OR
((s."ProductClass" != d."ProductClass")  OR (s."ProductClass"  is not NULL and d."ProductClass"  is NULL) OR (d."ProductClass"  is not NULL and s."ProductClass"  is NULL)) OR
((s."RunTime" != d."RunTime")  OR (s."RunTime"  is not NULL and d."RunTime"  is NULL) OR (d."RunTime"  is not NULL and s."RunTime"  is NULL)) OR
((s."SetupTime" != d."SetupTime")  OR (s."SetupTime"  is not NULL and d."SetupTime"  is NULL) OR (d."SetupTime"  is not NULL and s."SetupTime"  is NULL)) OR
((s."FixTime" != d."FixTime")  OR (s."FixTime"  is not NULL and d."FixTime"  is NULL) OR (d."FixTime"  is not NULL and s."FixTime"  is NULL)) OR
((s."VarTime" != d."VarTime")  OR (s."VarTime"  is not NULL and d."VarTime"  is NULL) OR (d."VarTime"  is not NULL and s."VarTime"  is NULL)) OR
((s."StartTime" != d."StartTime")  OR (s."StartTime"  is not NULL and d."StartTime"  is NULL) OR (d."StartTime"  is not NULL and s."StartTime"  is NULL)) OR
((s."TeardownTime" != d."TeardownTime")  OR (s."TeardownTime"  is not NULL and d."TeardownTime"  is NULL) OR (d."TeardownTime"  is not NULL and s."TeardownTime"  is NULL)) OR
((s."NonRunTime" != d."NonRunTime")  OR (s."NonRunTime"  is not NULL and d."NonRunTime"  is NULL) OR (d."NonRunTime"  is not NULL and s."NonRunTime"  is NULL)) OR
((s."NonSetupTime" != d."NonSetupTime")  OR (s."NonSetupTime"  is not NULL and d."NonSetupTime"  is NULL) OR (d."NonSetupTime"  is not NULL and s."NonSetupTime"  is NULL)) OR
((s."NonFixTime" != d."NonFixTime")  OR (s."NonFixTime"  is not NULL and d."NonFixTime"  is NULL) OR (d."NonFixTime"  is not NULL and s."NonFixTime"  is NULL)) OR
((s."NonVarTime" != d."NonVarTime")  OR (s."NonVarTime"  is not NULL and d."NonVarTime"  is NULL) OR (d."NonVarTime"  is not NULL and s."NonVarTime"  is NULL)) OR
((s."NonStartTime" != d."NonStartTime")  OR (s."NonStartTime"  is not NULL and d."NonStartTime"  is NULL) OR (d."NonStartTime"  is not NULL and s."NonStartTime"  is NULL)) OR
((s."NonTearTime" != d."NonTearTime")  OR (s."NonTearTime"  is not NULL and d."NonTearTime"  is NULL) OR (d."NonTearTime"  is not NULL and s."NonTearTime"  is NULL)) OR
((s."PtdStdHours" != d."PtdStdHours")  OR (s."PtdStdHours"  is not NULL and d."PtdStdHours"  is NULL) OR (d."PtdStdHours"  is not NULL and s."PtdStdHours"  is NULL)) OR
((s."PtdNonHours" != d."PtdNonHours")  OR (s."PtdNonHours"  is not NULL and d."PtdNonHours"  is NULL) OR (d."PtdNonHours"  is not NULL and s."PtdNonHours"  is NULL)) OR
((s."PtdActHours" != d."PtdActHours")  OR (s."PtdActHours"  is not NULL and d."PtdActHours"  is NULL) OR (d."PtdActHours"  is not NULL and s."PtdActHours"  is NULL)) OR
((s."MtdStdHours" != d."MtdStdHours")  OR (s."MtdStdHours"  is not NULL and d."MtdStdHours"  is NULL) OR (d."MtdStdHours"  is not NULL and s."MtdStdHours"  is NULL)) OR
((s."MtdNonHours" != d."MtdNonHours")  OR (s."MtdNonHours"  is not NULL and d."MtdNonHours"  is NULL) OR (d."MtdNonHours"  is not NULL and s."MtdNonHours"  is NULL)) OR
((s."MtdActHours" != d."MtdActHours")  OR (s."MtdActHours"  is not NULL and d."MtdActHours"  is NULL) OR (d."MtdActHours"  is not NULL and s."MtdActHours"  is NULL)) OR
((s."YtdStdHours" != d."YtdStdHours")  OR (s."YtdStdHours"  is not NULL and d."YtdStdHours"  is NULL) OR (d."YtdStdHours"  is not NULL and s."YtdStdHours"  is NULL)) OR
((s."YtdNonHours" != d."YtdNonHours")  OR (s."YtdNonHours"  is not NULL and d."YtdNonHours"  is NULL) OR (d."YtdNonHours"  is not NULL and s."YtdNonHours"  is NULL)) OR
((s."YtdActHours" != d."YtdActHours")  OR (s."YtdActHours"  is not NULL and d."YtdActHours"  is NULL) OR (d."YtdActHours"  is not NULL and s."YtdActHours"  is NULL)) OR
((s."UtilisePct" != d."UtilisePct")  OR (s."UtilisePct"  is not NULL and d."UtilisePct"  is NULL) OR (d."UtilisePct"  is not NULL and s."UtilisePct"  is NULL)) OR
((s."OvertimeCapPct" != d."OvertimeCapPct")  OR (s."OvertimeCapPct"  is not NULL and d."OvertimeCapPct"  is NULL) OR (d."OvertimeCapPct"  is not NULL and s."OvertimeCapPct"  is NULL)) OR
((s."UseOvertimeCap" != d."UseOvertimeCap")  OR (s."UseOvertimeCap"  is not NULL and d."UseOvertimeCap"  is NULL) OR (d."UseOvertimeCap"  is not NULL and s."UseOvertimeCap"  is NULL)) OR
((s."NormalCapacity" != d."NormalCapacity")  OR (s."NormalCapacity"  is not NULL and d."NormalCapacity"  is NULL) OR (d."NormalCapacity"  is not NULL and s."NormalCapacity"  is NULL)) OR
((s."QueueTime" != d."QueueTime")  OR (s."QueueTime"  is not NULL and d."QueueTime"  is NULL) OR (d."QueueTime"  is not NULL and s."QueueTime"  is NULL)) OR
((s."DefSubSupplier" != d."DefSubSupplier")  OR (s."DefSubSupplier"  is not NULL and d."DefSubSupplier"  is NULL) OR (d."DefSubSupplier"  is not NULL and s."DefSubSupplier"  is NULL)) OR
((s."DefSubPlanner" != d."DefSubPlanner")  OR (s."DefSubPlanner"  is not NULL and d."DefSubPlanner"  is NULL) OR (d."DefSubPlanner"  is not NULL and s."DefSubPlanner"  is NULL)) OR
((s."DefSubBuyer" != d."DefSubBuyer")  OR (s."DefSubBuyer"  is not NULL and d."DefSubBuyer"  is NULL) OR (d."DefSubBuyer"  is not NULL and s."DefSubBuyer"  is NULL)) OR
((s."WorkOperators" != d."WorkOperators")  OR (s."WorkOperators"  is not NULL and d."WorkOperators"  is NULL) OR (d."WorkOperators"  is not NULL and s."WorkOperators"  is NULL)) OR
((s."ProdUnits" != d."ProdUnits")  OR (s."ProdUnits"  is not NULL and d."ProdUnits"  is NULL) OR (d."ProdUnits"  is not NULL and s."ProdUnits"  is NULL)) OR
((s."TimePerUnit" != d."TimePerUnit")  OR (s."TimePerUnit"  is not NULL and d."TimePerUnit"  is NULL) OR (d."TimePerUnit"  is not NULL and s."TimePerUnit"  is NULL)) OR
((s."CalcCapConvFact" != d."CalcCapConvFact")  OR (s."CalcCapConvFact"  is not NULL and d."CalcCapConvFact"  is NULL) OR (d."CalcCapConvFact"  is not NULL and s."CalcCapConvFact"  is NULL)) OR
((s."LoadLevelScale" != d."LoadLevelScale")  OR (s."LoadLevelScale"  is not NULL and d."LoadLevelScale"  is NULL) OR (d."LoadLevelScale"  is not NULL and s."LoadLevelScale"  is NULL)) OR
((s."LoadLevelSclFlg" != d."LoadLevelSclFlg")  OR (s."LoadLevelSclFlg"  is not NULL and d."LoadLevelSclFlg"  is NULL) OR (d."LoadLevelSclFlg"  is not NULL and s."LoadLevelSclFlg"  is NULL)) OR
((s."CellId" != d."CellId")  OR (s."CellId"  is not NULL and d."CellId"  is NULL) OR (d."CellId"  is not NULL and s."CellId"  is NULL)) OR
((s."ChargeCode" != d."ChargeCode")  OR (s."ChargeCode"  is not NULL and d."ChargeCode"  is NULL) OR (d."ChargeCode"  is not NULL and s."ChargeCode"  is NULL)) OR
((s."OpSplitFlag" != d."OpSplitFlag") OR (s."OpSplitFlag"  is not NULL and d."OpSplitFlag"  is NULL) OR (d."OpSplitFlag"  is not NULL and s."OpSplitFlag"  is NULL)) 

 );

END;
